/* ============================================================
   CERTIFICATE SYSTEM — Accountancy by Abhinash
   Fully new feature. Does not touch or depend on any existing
   certificate code (there was none), and does not alter the
   Exam Mode data model — it only reads examState after
   submission. Storage is isolated in its own localStorage key
   so it can later move to a real backend without any redesign:
   every write goes through certSaveAll()/certGenerate(), so a
   future version can swap those two functions for API calls
   and nothing else in this file (or the UI it renders) has to
   change.
   ============================================================ */

/* ---------- 1. Storage (isolated from the main STATE) ------ */
const CERT_STORE_KEY = "abhinash_certificates_v1";
const CERT_COUNTER_KEY = "abhinash_certificate_counter_v1";
const CERT_WEBSITE_NAME = "Accountancy by Abhinash";
const CERT_WEBSITE_URL = "https://accountancybyabhinash.netlify.app/";

function certLoadAll() {
  try {
    const raw = localStorage.getItem(CERT_STORE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (e) { return []; }
}
function certSaveAll(list) {
  try { localStorage.setItem(CERT_STORE_KEY, JSON.stringify(list)); } catch (e) { /* storage full/blocked */ }
}
function certFindById(id) {
  return certLoadAll().find(c => c.id === id) || null;
}
function certNextId() {
  const year = new Date().getFullYear();
  let n = 1;
  try { n = parseInt(localStorage.getItem(CERT_COUNTER_KEY) || "0", 10) + 1; } catch (e) {}
  try { localStorage.setItem(CERT_COUNTER_KEY, String(n)); } catch (e) {}
  return `ACC-${year}-${String(n).padStart(6, "0")}`;
}

/* ---------- 2. Grading ------------------------------------- */
function certGrade(pct) {
  if (pct >= 95) return "A+";
  if (pct >= 90) return "A";
  if (pct >= 80) return "B+";
  if (pct >= 70) return "B";
  if (pct >= 60) return "C";
  if (pct >= 50) return "D";
  return "F";
}

/* ---------- 3. Eligibility + generation --------------------
   Called only from renderExamResults(), only after submission,
   with the exact same `questions`/`answers`/`pct` the results
   page itself computed — no separate recalculation that could
   drift from what the student actually sees.
   ------------------------------------------------------------ */
function certIsEligible(config) {
  return !!config && config.coverage === "all";
}

function certGenerate(examStateSnapshot, score, pct, timeTakenSeconds) {
  const { questions, answers, config } = examStateSnapshot;
  const attempted = answers.filter(a => a !== null).length;
  const wrong = attempted - score;
  const unattempted = questions.length - attempted;
  const name = (STATE.userName && STATE.userName !== "Student") ? STATE.userName : (STATE.userName || "Student");

  const cert = {
    id: certNextId(),
    studentName: name,
    websiteName: CERT_WEBSITE_NAME,
    examMode: "Exam Mode — Full Syllabus Examination",
    chaptersCovered: "All Chapters (Ch.1–Ch.10)",
    totalQuestions: questions.length,
    correct: score,
    wrong: wrong,
    unattempted: unattempted,
    marksObtained: score,
    maxMarks: questions.length,
    percentage: pct,
    grade: certGrade(pct),
    resultStatus: pct >= 60 ? "Pass" : "Fail",
    timeTakenSeconds: timeTakenSeconds,
    issuedAt: new Date().toISOString(),
  };
  const list = certLoadAll();
  list.push(cert);
  certSaveAll(list);
  return cert;
}

function certFormatDate(iso) {
  const d = new Date(iso);
  return d.toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" }) +
    " · " + d.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" });
}
function certFormatTime(seconds) {
  const m = Math.floor(seconds / 60), s = seconds % 60;
  return `${m}m ${s}s`;
}

/* ---------- 4. Lazy-loaded export libraries -----------------
   Only fetched the first time someone actually opens a
   certificate — nobody pays this cost just for using Exam Mode
   or the rest of the site.
   ------------------------------------------------------------ */
function certLoadScriptWithTimeout(src, timeoutMs) {
  return new Promise((resolve, reject) => {
    const s = document.createElement("script");
    let done = false;
    const timer = setTimeout(() => { if (!done) { done = true; s.remove(); reject(new Error("timeout loading " + src)); } }, timeoutMs);
    s.src = src;
    s.onload = () => { if (!done) { done = true; clearTimeout(timer); resolve(); } };
    s.onerror = () => { if (!done) { done = true; clearTimeout(timer); s.remove(); reject(new Error("failed to load " + src)); } };
    document.head.appendChild(s);
  });
}

let certOtherLibsPromise = null;
function certLoadLibs() {
  if (certOtherLibsPromise) return certOtherLibsPromise;
  certOtherLibsPromise = Promise.all([
    window.html2canvas ? Promise.resolve() : certLoadScriptWithTimeout("https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js", 8000),
    (window.jspdf && window.jspdf.jsPDF) ? Promise.resolve() : certLoadScriptWithTimeout("https://cdn.jsdelivr.net/npm/jspdf@2.5.1/dist/jspdf.umd.min.js", 8000),
  ]).catch((e) => { certOtherLibsPromise = null; throw e; });
  return certOtherLibsPromise;
}

/* ---------- 5. Certificate visual (shared by the on-screen view,
   PNG/PDF export, and print) ----------------------------------- */
function certInjectStyles() {
  if (document.getElementById("certStylesTag")) return;
  // Certificate-only display serif — loaded lazily, scoped to this
  // feature, so nobody pays for it anywhere else on the site.
  if (!document.getElementById("certFontsTag")) {
    const fontLink = document.createElement("link");
    fontLink.id = "certFontsTag";
    fontLink.rel = "stylesheet";
    fontLink.href = "https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,600;0,700;0,800;1,600&display=swap";
    document.head.appendChild(fontLink);
  }
  const style = document.createElement("style");
  style.id = "certStylesTag";
  style.textContent = `
.cert-sheet {
  position: relative; width: 1200px; height: 849px; margin: 0 auto;
  background-image:
    linear-gradient(150deg, rgba(255,254,251,0.32) 0%, rgba(251,247,236,0.22) 55%, rgba(250,244,228,0.32) 100%),
    url("assets/cert-border-bg.jpg");
  background-size: 100% 100%;
  background-position: center;
  background-repeat: no-repeat;
  font-family: 'Inter', sans-serif; color: #14213D; overflow: hidden;
  box-shadow: 0 20px 60px rgba(20,33,61,0.18);
}

.cert-content { position: absolute; top: 96px; right: 110px; bottom: 150px; left: 110px; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; }

.cert-brandrow { display: flex; flex-direction: column; align-items: center; }
.cert-brand { font-family: 'Poppins', sans-serif; font-weight: 700; font-size: 14px; letter-spacing: 3.5px; color: #14213D; }
.cert-brand-sub { font-size: 10px; letter-spacing: 3.5px; color: #C9A227; font-weight: 600; margin-top: 4px; text-transform: uppercase; }

.cert-title-block { margin-top: 22px; display: flex; align-items: center; gap: 18px; }
.cert-title-flourish { width: 54px; height: 1px; background: linear-gradient(90deg, transparent, #C9A227); }
.cert-title-flourish.right { background: linear-gradient(90deg, #C9A227, transparent); }
.cert-title { font-family: 'Playfair Display', serif; font-weight: 700; font-size: 38px; letter-spacing: 5px; color: #14213D; text-transform: uppercase; white-space: nowrap; }
.cert-title-rule { width: 90px; height: 1px; background: #C9A227; margin: 12px auto 0; position: relative; }
.cert-title-rule::before { content: "◆"; position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%); font-size: 7px; color: #C9A227; background: inherit; }

.cert-msg-intro { font-style: italic; font-size: 14px; letter-spacing: 0.3px; color: #5A6274; margin-top: 18px; }
.cert-name { font-family: 'Playfair Display', serif; font-weight: 700; color: #14213D; margin: 10px 0 2px; padding: 0 6px 10px; display: inline-block; max-width: 940px; line-height: 1.15; border-bottom: 1.5px solid #C9A227; overflow-wrap: break-word; }
.cert-msg { font-size: 14px; line-height: 1.8; max-width: 740px; color: #2B3A55; margin-top: 14px; }

.cert-divider { display: flex; align-items: center; gap: 10px; width: 100%; max-width: 540px; margin: 18px 0 0; }
.cert-divider .line { flex: 1; height: 1px; background: #E3D9BE; }
.cert-divider .dot { width: 4px; height: 4px; border-radius: 50%; background: #C9A227; }

.cert-statgrid { display: grid; grid-template-columns: repeat(4, 1fr); width: 100%; max-width: 900px; margin-top: 16px; }
.cert-statgrid.row2 { margin-top: 0; }
.cert-stat { padding: 11px 8px 5px; border-right: 1px solid #E9E1CB; border-top: 1px solid #E3D9BE; }
.cert-stat:last-child { border-right: none; }
.cert-statgrid.row2 .cert-stat { border-top: none; padding-top: 7px; }
.cert-stat-label { font-size: 9.5px; letter-spacing: 1.2px; text-transform: uppercase; color: #8A7A4E; font-weight: 600; }
.cert-stat-value { font-family: 'Poppins', sans-serif; font-size: 18px; font-weight: 700; color: #14213D; margin-top: 4px; font-variant-numeric: tabular-nums; }

.cert-resultpanel { display: flex; align-items: center; justify-content: center; gap: 34px; margin-top: 18px; padding: 12px 30px; border: 1px solid #E3D9BE; border-radius: 6px; background: rgba(201,162,39,0.045); }
.cert-gradebar { display: flex; align-items: center; gap: 12px; }
.cert-grade-badge { position: relative; width: 58px; height: 58px; border-radius: 50%; border: 1.5px solid #C9A227; display: flex; align-items: center; justify-content: center; font-family: 'Playfair Display', serif; font-weight: 700; font-size: 21px; color: #14213D; background: #FFF9E8; flex-shrink: 0; }
.cert-grade-badge::before { content: ""; position: absolute; inset: -5px; border: 1px solid rgba(201,162,39,0.4); border-radius: 50%; }
.cert-grade-text { text-align: left; }
.cert-grade-text .lbl { font-size: 9px; letter-spacing: 1.5px; text-transform: uppercase; color: #8A7A4E; font-weight: 600; }
.cert-grade-text .val { font-family: 'Poppins', sans-serif; font-weight: 700; font-size: 15px; color: #14213D; margin-top: 2px; }
.cert-result-divider { width: 1px; height: 40px; background: #E3D9BE; }
.cert-result-pill { padding: 9px 26px; border-radius: 3px; font-family: 'Poppins', sans-serif; font-weight: 700; font-size: 14px; letter-spacing: 2.5px; }
.cert-result-pass { background: #EAF5EE; color: #1E7A46; border: 1px solid #1E7A46; }
.cert-result-fail { background: #FBEAE8; color: #B23A2F; border: 1px solid #B23A2F; }

.cert-footer { position: absolute; left: 148px; right: 148px; bottom: 104px; padding-top: 14px; display: flex; justify-content: space-between; align-items: flex-end; }
.cert-auth-block { text-align: left; min-width: 230px; }
.cert-auth-line1 { font-family: 'Poppins', sans-serif; font-weight: 700; font-size: 12px; letter-spacing: 1.3px; color: #14213D; }
.cert-auth-line2 { font-size: 10.5px; color: #6B6B6B; margin-top: 2px; }
.cert-auth-line3 { font-size: 10px; color: #C9A227; font-weight: 600; margin-top: 7px; letter-spacing: 0.4px; }
.cert-idblock { text-align: center; display: flex; flex-direction: column; align-items: center; }
.cert-idblock .cert-id-text { font-family: 'JetBrains Mono', monospace; font-size: 12px; color: #14213D; font-weight: 700; letter-spacing: 0.3px; }
.cert-idblock .cert-id-label { font-size: 8.5px; color: #8A7A4E; letter-spacing: 1.3px; text-transform: uppercase; margin-top: 3px; }
.cert-dateblock { text-align: right; min-width: 230px; }
.cert-dateblock .cert-date-label { font-size: 9px; letter-spacing: 1.2px; text-transform: uppercase; color: #8A7A4E; font-weight: 600; }
.cert-dateblock .cert-date-value { font-family: 'Poppins', sans-serif; font-weight: 700; font-size: 13px; color: #14213D; margin-top: 4px; }

@media (max-width: 860px) {
  .cert-sheet-scale-wrap { overflow-x: auto; }
}
body.cert-printing .topbar, body.cert-printing .sidebar, body.cert-printing .bottom-nav,
body.cert-printing .floating-panel, body.cert-printing .toast-root, body.cert-printing .sidebar-overlay { display: none !important; }
@media print {
  body.cert-printing > *:not(#certPrintArea) { display: none !important; }
  body.cert-printing #certPrintArea { display: block !important; position: static; }
  /* The on-screen sheet is a fixed 1200x849px box (matching A4 landscape's
     1.414 aspect ratio). At the browser's standard 96px/inch, 1200px prints
     ~12.5in wide — wider than A4 landscape's 11.69in — which clipped the
     right edge. Scaling it to fit an exact-mm print page fixes that. */
  .cert-print-page { width: 297mm; height: 210mm; overflow: hidden; position: relative; }
  .cert-print-page .cert-sheet { position: absolute; top: 0; left: 0; transform: scale(0.93543); transform-origin: top left; box-shadow: none; margin: 0; }
  @page { size: A4 landscape; margin: 0; }
}
`;
  document.head.appendChild(style);
}

// Long names shouldn't overflow the fixed-width sheet or break the
// layout — scale the name down in steps based on length rather than
// relying on CSS alone, since the sheet is captured at a fixed size.
function certNameFontSize(name) {
  const len = (name || "").length;
  if (len <= 16) return 42;
  if (len <= 22) return 36;
  if (len <= 30) return 30;
  if (len <= 40) return 25;
  return 21;
}

// Builds the actual certificate DOM node. Rendered at a fixed,
// non-responsive size so html2canvas captures pixel-perfect layout
// regardless of the viewport it's built in.
function certBuildSheet(cert) {
  certInjectStyles();
  const wrap = document.createElement("div");
  wrap.className = "cert-sheet";
  wrap.id = "certSheet-" + cert.id;
  wrap.innerHTML = `
    <div class="cert-content">
      <div class="cert-brandrow">
        <div class="cert-brand">ACCOUNTANCY BY ABHINASH</div>
        <div class="cert-brand-sub">Learning Platform</div>
      </div>

      <div class="cert-title-block">
        <div class="cert-title-flourish"></div>
        <div class="cert-title">Certificate of Achievement</div>
        <div class="cert-title-flourish right"></div>
      </div>
      <div class="cert-title-rule"></div>

      <div class="cert-msg-intro">This is to certify that</div>
      <div class="cert-name" style="font-size:${certNameFontSize(cert.studentName)}px;">${escapeHtml(cert.studentName)}</div>
      <div class="cert-msg">has successfully completed the Full Syllabus Examination on the Accountancy Learning Platform,
      demonstrating knowledge and understanding across all chapters, and has achieved the result recorded below.</div>

      <div class="cert-divider"><div class="line"></div><div class="dot"></div><div class="line"></div></div>

      <div class="cert-statgrid">
        <div class="cert-stat"><div class="cert-stat-label">Total Questions</div><div class="cert-stat-value">${cert.totalQuestions}</div></div>
        <div class="cert-stat"><div class="cert-stat-label">Correct</div><div class="cert-stat-value">${cert.correct}</div></div>
        <div class="cert-stat"><div class="cert-stat-label">Wrong</div><div class="cert-stat-value">${cert.wrong}</div></div>
        <div class="cert-stat"><div class="cert-stat-label">Unattempted</div><div class="cert-stat-value">${cert.unattempted}</div></div>
      </div>
      <div class="cert-statgrid row2">
        <div class="cert-stat"><div class="cert-stat-label">Marks Obtained</div><div class="cert-stat-value">${cert.marksObtained} / ${cert.maxMarks}</div></div>
        <div class="cert-stat"><div class="cert-stat-label">Percentage</div><div class="cert-stat-value">${cert.percentage}%</div></div>
        <div class="cert-stat"><div class="cert-stat-label">Time Taken</div><div class="cert-stat-value">${certFormatTime(cert.timeTakenSeconds)}</div></div>
        <div class="cert-stat"><div class="cert-stat-label">Exam Mode</div><div class="cert-stat-value" style="font-size:12.5px;">Full Syllabus</div></div>
      </div>

      <div class="cert-resultpanel">
        <div class="cert-gradebar">
          <div class="cert-grade-badge">${cert.grade}</div>
          <div class="cert-grade-text"><div class="lbl">Grade</div><div class="val">${cert.grade}</div></div>
        </div>
        <div class="cert-result-divider"></div>
        <div class="cert-result-pill ${cert.resultStatus === "Pass" ? "cert-result-pass" : "cert-result-fail"}">${cert.resultStatus === "Pass" ? "PASS" : "FAIL"}</div>
      </div>
    </div>
    <div class="cert-footer">
      <div class="cert-auth-block">
        <div class="cert-auth-line1">ACCOUNTANCY BY ABHINASH</div>
        <div class="cert-auth-line2">Learning Platform</div>
        <div class="cert-auth-line3">Digitally Generated · No Signature Required</div>
      </div>
      <div class="cert-idblock">
        <div class="cert-id-text">${cert.id}</div>
        <div class="cert-id-label">Certificate ID</div>
      </div>
      <div class="cert-dateblock">
        <div class="cert-date-label">Date Issued</div>
        <div class="cert-date-value">${certFormatDate(cert.issuedAt)}</div>
      </div>
    </div>
  `;
  return wrap;
}

/* ---------- 6. Export actions ------------------------------- */
function certRasterize(cert) {
  // Build an off-screen, fixed-size copy so export quality never
  // depends on the current viewport/zoom of the visible one.
  const offstage = document.createElement("div");
  offstage.style.cssText = "position:fixed; left:-9999px; top:0;";
  const sheet = certBuildSheet(cert);
  offstage.appendChild(sheet);
  document.body.appendChild(offstage);
  // Wait for web fonts (Playfair Display etc.) to finish loading so the
  // captured canvas doesn't get a flash-of-fallback-font moment baked in.
  const fontsReady = (document.fonts && document.fonts.ready) ? document.fonts.ready : Promise.resolve();
  return fontsReady.then(() => certLoadLibs()).then(() =>
    window.html2canvas(sheet, { scale: 2, backgroundColor: "#FFFEFB", useCORS: true })
  ).finally(() => offstage.remove());
}

function certDownloadPNG(cert) {
  toast("Preparing your certificate…", "info", "loader");
  certRasterize(cert).then(canvas => {
    canvas.toBlob(blob => {
      if (!blob) { toast("Couldn't generate the certificate — please try again.", "error", "alert-triangle"); return; }
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${cert.id}-certificate.png`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 4000);
      toast("Certificate downloaded (PNG).", "success", "download");
    }, "image/png");
  }).catch(() => toast("Couldn't generate the certificate — check your connection and try again.", "error", "alert-triangle"));
}

function certDownloadPDF(cert) {
  toast("Preparing your certificate…", "info", "loader");
  certRasterize(cert).then(canvas => {
    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF({ orientation: "landscape", unit: "mm", format: "a4" });
    const w = pdf.internal.pageSize.getWidth(), h = pdf.internal.pageSize.getHeight();
    pdf.addImage(canvas.toDataURL("image/png"), "PNG", 0, 0, w, h, undefined, "FAST");
    pdf.save(`${cert.id}-certificate.pdf`);
    toast("Certificate downloaded (PDF).", "success", "download");
  }).catch(() => toast("Couldn't generate the certificate — check your connection and try again.", "error", "alert-triangle"));
}

// The certificate sheet is a fixed 1200×849px node — at the browser's
// standard 96dpi that's ~317.5mm wide, wider than an A4 landscape page
// (297mm), so printing it unscaled clips the right edge. Wrapping it in
// a page-sized box (see the ".cert-print-page" print rule above) and
// scaling it down to fit guarantees the whole certificate lands on one
// page with nothing cut off, independent of the printing browser's own margins.
function certPrint(cert) {
  const area = document.createElement("div");
  area.id = "certPrintArea";
  const page = document.createElement("div");
  page.className = "cert-print-page";
  const sheet = certBuildSheet(cert);
  page.appendChild(sheet);
  area.appendChild(page);
  document.body.appendChild(area);
  toast("Preparing your certificate for print…", "info", "loader");
  const fontsReady = (document.fonts && document.fonts.ready) ? document.fonts.ready : Promise.resolve();
  fontsReady.then(() => new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)))).then(() => {
    document.body.classList.add("cert-printing");
    window.print();
    const cleanup = () => { document.body.classList.remove("cert-printing"); area.remove(); window.removeEventListener("afterprint", cleanup); };
    window.addEventListener("afterprint", cleanup);
  }).catch(() => {
    area.remove();
    toast("Couldn't prepare the certificate for print — please try again.", "error", "alert-triangle");
  });
}

function certShare(cert) {
  const text = `Proud achievement through Accountancy by Abhinash — Learn • Practice • Grow.\n${CERT_WEBSITE_URL}`;
  function shareTextOnly() {
    if (navigator.share) { navigator.share({ title: "Certificate of Achievement", text }).catch(() => {}); return; }
    if (navigator.clipboard) { navigator.clipboard.writeText(text).then(() => toast("Message copied to clipboard.", "success", "link")); return; }
    prompt("Copy this to share:", text);
  }
  toast("Preparing your certificate to share…", "info", "loader");
  certRasterize(cert).then(canvas => new Promise(resolve => canvas.toBlob(resolve, "image/png")))
    .then(blob => {
      if (!blob) throw new Error("no blob");
      const file = new File([blob], `${cert.id}-certificate.png`, { type: "image/png" });
      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        return navigator.share({ files: [file], title: "Certificate of Achievement", text }).catch(() => {});
      }
      shareTextOnly();
    })
    .catch(() => shareTextOnly());
}

/* ---------- 7. On-screen certificate view -------------------- */
function renderCertificateFullView(root, cert) {
  root.appendChild(el("div", "hero", `
    <span class="hero-eyebrow">Achievement</span>
    <h1>Your Certificate</h1>

    <p>Earned by completing the Full Syllabus Examination across all chapters. Download, print, or share it any time — it's also saved under Progress.</p>
  `));

  const actions = el("div", "");
  actions.style.cssText = "display:flex; gap:10px; flex-wrap:wrap; margin-bottom:22px;";
  actions.innerHTML = `
    <button class="btn-primary ripple-surface" id="certPdfBtn"><i data-lucide="file-down"></i> Download PDF</button>
    <button class="chip" id="certPngBtn"><i data-lucide="image-down"></i> Download PNG</button>
    <button class="chip" id="certPrintBtn"><i data-lucide="printer"></i> Print Certificate</button>
    <button class="chip" id="certShareBtn"><i data-lucide="share-2"></i> Share Certificate</button>
  `;
  root.appendChild(actions);

  const scaleWrap = el("div", "cert-sheet-scale-wrap");
  scaleWrap.style.cssText = "width:100%; display:flex; justify-content:center;";
  const inner = el("div", "");
  inner.style.cssText = "transform-origin: top center; width: 1200px; max-width: 100%;";
  scaleWrap.appendChild(inner);
  root.appendChild(scaleWrap);

  const sheet = certBuildSheet(cert);
  inner.appendChild(sheet);

  // Scale the fixed 1200px sheet down to fit narrower screens without
  // altering the layout that gets captured for export.
  function fitScale() {
    const avail = scaleWrap.clientWidth;
    const scale = Math.min(1, avail / 1200);
    inner.style.transform = `scale(${scale})`;
    inner.style.marginBottom = (849 * scale - 849) + "px";
  }
  fitScale();
  window.addEventListener("resize", fitScale);

  $("#certPdfBtn", actions).addEventListener("click", () => certDownloadPDF(cert));
  $("#certPngBtn", actions).addEventListener("click", () => certDownloadPNG(cert));
  $("#certPrintBtn", actions).addEventListener("click", () => certPrint(cert));
  $("#certShareBtn", actions).addEventListener("click", () => certShare(cert));
}

/* ---------- 8. Exam-results hook (called from app.js) --------
   Kept as a single narrow entry point so the integration edit
   inside renderExamResults() stays tiny and easy to audit.
   ------------------------------------------------------------ */
function certHandleExamCompletion(examStateSnapshot, score, pct, timeTakenSeconds) {
  if (!certIsEligible(examStateSnapshot.config)) return null;
  return certGenerate(examStateSnapshot, score, pct, timeTakenSeconds);
}

function renderCertificateEarnedBanner(root, cert) {
  const banner = el("div", "card-solid", "");
  banner.style.cssText = "padding:22px; margin-top:18px; border:1.5px solid var(--gold); background:linear-gradient(135deg, var(--gold-soft), transparent);";
  banner.innerHTML = `
    <div style="display:flex; align-items:center; gap:14px; flex-wrap:wrap;">
      <i data-lucide="award" style="width:34px;height:34px; color:var(--gold); flex-shrink:0;"></i>
      <div style="flex:1; min-width:200px;">
        <div style="font-family:var(--font-head); font-weight:700; font-size:1.05rem;">Certificate earned — Grade ${cert.grade}</div>
        <div style="font-size:0.85rem; color:var(--ink-faint); margin-top:2px;">Full Syllabus Examination · ${cert.id}</div>
      </div>
      <button class="btn-primary ripple-surface" id="certViewBtn"><i data-lucide="award"></i> View Certificate</button>
    </div>
  `;
  root.appendChild(banner);
  $("#certViewBtn", banner).addEventListener("click", () => {
    certOpenCertId = cert.id;
    navigate("certificate-view");
  });
}

/* ---------- 9. Progress-page "My Certificates" section -------
   Called from renderPerformance() with one line; entirely
   self-rendering otherwise.
   ------------------------------------------------------------ */
function renderMyCertificatesSection(root) {
  const list = certLoadAll();
  root.appendChild(sectionTitle("My Certificates"));
  if (!list.length) {
    const empty = el("div", "card", "");
    empty.style.cssText = "padding:20px; text-align:center; color:var(--ink-faint); font-size:0.87rem;";
    empty.innerHTML = `<i data-lucide="award" style="width:22px;height:22px; opacity:0.5;"></i><p style="margin-top:8px;">Complete an Exam Mode paper with <b>All Chapters</b> selected to earn your first certificate.</p>`;
    root.appendChild(empty);
    return;
  }
  list.slice().reverse().forEach(cert => {
    const card = el("div", "card q-card", "");
    card.style.marginBottom = "12px";
    card.innerHTML = `
      <div style="display:flex; align-items:center; gap:14px; flex-wrap:wrap;">
        <i data-lucide="award" style="width:26px;height:26px; color:var(--gold); flex-shrink:0;"></i>
        <div style="flex:1; min-width:180px;">
          <div style="font-weight:700; font-size:0.95rem;">${cert.grade} · ${cert.percentage}% · ${cert.resultStatus}</div>
          <div style="font-size:0.78rem; color:var(--ink-faint); margin-top:2px;">${cert.id} · ${certFormatDate(cert.issuedAt)}</div>
        </div>
        <div style="display:flex; gap:8px; flex-wrap:wrap;">
          <button class="chip sm" data-act="view" data-id="${cert.id}"><i data-lucide="eye"></i> View</button>
          <button class="chip sm" data-act="pdf" data-id="${cert.id}"><i data-lucide="file-down"></i> PDF</button>
          <button class="chip sm" data-act="print" data-id="${cert.id}"><i data-lucide="printer"></i> Print</button>
          <button class="chip sm" data-act="share" data-id="${cert.id}"><i data-lucide="share-2"></i> Share</button>
        </div>
      </div>
    `;
    card.addEventListener("click", (e) => {
      const btn = e.target.closest("button[data-act]");
      if (!btn) return;
      const c = certFindById(btn.dataset.id);
      if (!c) return;
      if (btn.dataset.act === "view") { certOpenCertId = c.id; navigate("certificate-view"); }
      if (btn.dataset.act === "pdf") certDownloadPDF(c);
      if (btn.dataset.act === "print") certPrint(c);
      if (btn.dataset.act === "share") certShare(c);
    });
    root.appendChild(card);
  });
}

/* ---------- 10. Routed certificate view ---------------------- */
let certOpenCertId = null;
function renderCertificateViewRoute(root) {
  const cert = certOpenCertId ? certFindById(certOpenCertId) : null;
  if (!cert) {
    root.appendChild(el("div", "hero", `<h1>Certificate not found</h1><p>This certificate may have been generated on a different device — certificates are stored locally on the device that earned them.</p>`));
    return;
  }
  renderCertificateFullView(root, cert);
}
