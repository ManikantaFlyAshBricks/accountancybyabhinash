# Daily Push Notifications — setup & testing guide

This site now has a real Web Push system: students who opt in get one
notification a day on their phone/desktop, delivered by the browser's push
service even when the site is completely closed and the phone is locked.
It is **not** a `setInterval`/timer trick — see "How it actually works" below.

## 1. Required Netlify environment variables

Site settings → Environment variables → add:

| Variable            | Value                                                                 |
|----------------------|------------------------------------------------------------------------|
| `VAPID_PUBLIC_KEY`  | `BJM1Em8rPxIy2N0A3R_SESfLB46ZS735V57eS7KtgeQup3JIfI9KW8Z5rSlYJnYoglWZ16B8FKpnX5R1XWD3XZg` |
| `VAPID_PRIVATE_KEY` | `-hMUDw8gAJsZffcCfWpsElp5SVkpLIv2IUYaEEFYX2g` |
| `VAPID_SUBJECT`     | `mailto:your-real-email@example.com` (any contact address — required by the Web Push spec, shown only to push services, never to students) |

This keypair was generated for you as a working starting point. **Treat
`VAPID_PRIVATE_KEY` as a secret** — it's already kept out of the frontend
code and only ever read from this environment variable, server-side, in
`netlify/functions/send-test.js` and `netlify/functions/daily-notify.js`.

`VAPID_PUBLIC_KEY` is *not* secret by design (it's meant to be public) and
is already hardcoded in `app.js` as `VAPID_PUBLIC_KEY`, matching the value
above. **If you ever regenerate the keypair** (`npx web-push
generate-vapid-keys`), update both the Netlify env vars *and* that constant
in `app.js` together, or subscriptions will silently fail.

No other setup is needed for storage — `@netlify/blobs` (used to remember
who's subscribed) works automatically on any Netlify site, no database to
provision.

## 2. How it actually works

```
Student taps "Enable Daily Notifications"
        ↓
Browser creates a PushSubscription (tied to VAPID_PUBLIC_KEY)
        ↓
Frontend POSTs it to netlify/functions/save-subscription.js
        ↓
Stored in Netlify Blobs, keyed by a hash of the subscription endpoint
        ↓
netlify/functions/daily-notify.js runs every hour on Netlify's own
server-side cron (netlify.toml → [functions."daily-notify"] schedule)
— completely independent of any browser tab
        ↓
For each subscriber: is it currently their chosen local hour, AND have
they not already been notified today (their local date)? If yes → send.
        ↓
Browser's push service delivers it to the OS, which wakes sw.js's
"push" handler — even with the site closed / phone locked
        ↓
sw.js shows the notification; tapping it focuses/opens the site
```

## 3. Honest limitation: exact delivery time

Netlify Scheduled Functions run on **one shared UTC cron**, not a separate
schedule per student's timezone. There is no native way to run "at 8:00 AM
in each student's own timezone" on Netlify's scheduler.

The reliable workaround implemented here: `daily-notify.js` runs **every
hour**, and independently checks each subscriber's own local hour (computed
from the UTC offset their browser reported when they subscribed). Result:
every student gets exactly one notification per local calendar day, inside
their chosen hour (e.g. "8:00 AM" arrives sometime between 8:00–8:59 AM
their time) — not the exact minute, and it won't auto-adjust for DST
changes mid-year (it re-reads their offset every time they open Settings
and change something, but not continuously in the background).

## 4. Testing

1. Deploy to Netlify with the env vars above set.
2. Open the live site (HTTPS is required — push doesn't work on `http://`
   or plain `file://`).
3. Go through the welcome flow (or Settings → Daily Learning
   Notifications) and enable notifications; accept the browser's
   permission prompt.
4. Click **Send Test Notification** in Settings — you should see a real
   OS-level notification within a few seconds, including with the site
   tab closed.
5. To test the actual daily send without waiting for the top of the hour,
   go to Netlify's dashboard → your site → Functions → `daily-notify` →
   "Trigger" (manual invoke), and check the response body — it reports
   `{ sent, skipped, removed, failed }`.

## 5. Installing the PWA on a phone

- **Android (Chrome/Edge):** open the site, tap the browser menu → "Install
  app" / "Add to Home screen" (or use the in-app "Install" card on the
  Home tab).
- **iPhone (Safari):** tap the Share icon → "Add to Home Screen." iOS
  Safari doesn't support the automatic install-prompt banner other
  browsers use — the site detects this and shows the manual steps instead.

## 6. Enabling / disabling notifications

- **Enable:** welcome flow's second step, or Settings → Daily Learning
  Notifications → toggle On.
- **Disable:** Settings → toggle Off. This unsubscribes the browser and
  tells the server to delete the stored subscription — no further
  notifications will be sent to that device.
- If a student denies the browser permission prompt, Settings explains how
  to re-enable it from the browser's own site settings (there is no way
  for the site to re-prompt once explicitly denied — that's a browser
  security rule, not a bug here).

## 7. Duplicate-notification prevention

Each subscriber record stores `lastNotifiedDate` (their local calendar
date). `daily-notify.js` only sends if that date isn't today — so
refreshing the page, multiple tabs, or re-running the scheduled function
never results in two notifications the same day. Changing notification
time in Settings re-saves the subscription but preserves
`lastNotifiedDate`, so it can't be used to trigger a second send.

Reinstalling the PWA does create a *new* browser subscription (a Web Push
characteristic, not something this app controls) — the old one will
naturally stop being deliverable and gets cleaned up automatically the
next time `daily-notify.js` gets a "gone" response from the push service.

## 8. Browser/OS support

Supported: Chrome, Edge, Firefox (Android & desktop), Safari 16.4+ (macOS
and iOS, **only after the site is added to the home screen** — iOS Safari
does not support push notifications for a regular open browser tab, only
for installed PWAs). Not supported: browsers without Push API/Notification
API support.
