/* ============================================================
   ACCOUNTANCY BY ABHINASH — APPLICATION LOGIC
   Sections: State & Storage | Utilities | Router | Views |
   Equation Tools | Search | Gamification | Floating Tools
   ============================================================ */

/* ---------------------------------------------------------
   1. STATE & PERSISTENCE (localStorage-backed)
   --------------------------------------------------------- */
const STORE_KEY = "abhinash_accountancy_v1";

const defaultState = {
  theme: "light",
  colorTheme: "classic",
  fontScale: 1,
  colorblind: false,
  highContrast: false,
  reduceMotion: false,
  soundOn: true,
  xp: 0,
  xpGained: 0,             // lifetime running total of every positive XP award (never decreases)
  xpDeducted: 0,           // lifetime running total of every XP penalty (never decreases)
  streak: 0,
  lastActiveDate: null,
  studySeconds: 0,
  chapterProgress: { eq: 0, dc: 0, jr: 0, lg: 0, cb: 0, sp2: 0, brs: 0, gst: 0, tb: 0, dep: 0 },
  solved: {},              // { "eq-12": {correct:true, attempts:1, time:34} }
  bookmarks: [],
  mistakes: [],            // ids of missed questions (legacy — kept for compatibility)
  mistakeBook: {},         // { key: { key, question, chapter, chapterLabel, topic, type,
                            //   studentAnswer, correctAnswer, explanation, firstMistakeAt,
                            //   lastAttemptAt, mistakeCount, correctAfterMistakeCount,
                            //   correctStreak, status: "review"|"improved"|"mastered" } }
  badges: [],
  bestScores: {},
  activityLog: [],         // recent activity strings
  panelPositions: {},      // { floatingCalc: {top, left}, scratchPad: {...}, pomodoroPanel: {...} } — persisted drag positions
  aiChats: [],             // [{ id, title, messages: [{role,text,image?,ts}], updatedAt, chapterContext }]
  aiActiveChatId: null,
  lastChapterViewed: null,
  userName: null,          // set via first-visit welcome flow; null = not onboarded yet
  onboardedAt: null,
  notificationsEnabled: false,
  notifyHour: 8,           // 0-23, local hour; daily reminder arrives within this hour
  notificationsPromptDismissed: false,
};

let STATE = loadState();
// Migration safety: existing saved state (from before Chapter 5 existed)
// has a chapterProgress object that fully overwrote the default via the
// shallow Object.assign in loadState(), so it may be missing the "cb"
// key entirely. Backfill it so per-chapter averages never turn into NaN.
if (STATE.chapterProgress && STATE.chapterProgress.cb === undefined) STATE.chapterProgress.cb = 0;

function loadState() {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (!raw) return structuredClone(defaultState);
    const parsed = JSON.parse(raw);
    return Object.assign(structuredClone(defaultState), parsed);
  } catch (e) {
    return structuredClone(defaultState);
  }
}
function saveState() {
  try { localStorage.setItem(STORE_KEY, JSON.stringify(STATE)); } catch (e) { /* storage full or blocked */ }
}

/* ---------------------------------------------------------
   2. UTILITIES
   --------------------------------------------------------- */
/* ---------------------------------------------------------
   1c. PWA INSTALLABILITY — capture the browser's install prompt
   so the Home page can offer a real "Install" button instead of
   relying on the user to find their browser's menu option.
   --------------------------------------------------------- */
let deferredInstallPrompt = null;
window.addEventListener("beforeinstallprompt", (e) => {
  e.preventDefault();
  deferredInstallPrompt = e;
});
window.addEventListener("appinstalled", () => {
  deferredInstallPrompt = null;
  localStorage.setItem("aba_install_dismissed", "1");
});
function isStandalone() {
  return window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone === true;
}
function isIOS() {
  return /iphone|ipad|ipod/i.test(navigator.userAgent) && !window.MSStream;
}

/* ---------------------------------------------------------
   1d. DAILY PUSH NOTIFICATIONS — real Web Push, not a timer.
   The browser creates a PushSubscription tied to this VAPID public
   key; it's sent to save-subscription.js and stored server-side.
   The scheduled netlify/functions/daily-notify.js function (see
   netlify.toml) sends the actual push once a day per subscriber,
   entirely server-side — this code's job is only to opt the
   student in/out and hand off the subscription.

   VAPID_PUBLIC_KEY is safe to embed in frontend code by design —
   it's the public half of the keypair. Only the private key (kept
   server-side, in Netlify env vars) can actually sign pushes.
   --------------------------------------------------------- */
const VAPID_PUBLIC_KEY = "BJM1Em8rPxIy2N0A3R_SESfLB46ZS735V57eS7KtgeQup3JIfI9KW8Z5rSlYJnYoglWZ16B8FKpnX5R1XWD3XZg";

function pushSupported() {
  return "serviceWorker" in navigator && "PushManager" in window && "Notification" in window;
}
function urlBase64ToUint8Array(base64String) {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const rawData = atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; i++) outputArray[i] = rawData.charCodeAt(i);
  return outputArray;
}
function currentTzOffsetMinutes() {
  // JS getTimezoneOffset() is UTC-minus-local (backwards from how people
  // think about it) — flip the sign so +330 really means "IST, 5.5h ahead".
  return -new Date().getTimezoneOffset();
}
function buildNotifyContext() {
  const order = ["eq", "dc", "jr", "lg", "cb", "sp2", "brs", "gst", "tb", "dep"];
  const chapterMap = {}; APP_DATA.chapters.forEach(c => chapterMap[c.id] = c);
  const contId = pickContinueTarget ? pickContinueTarget() : order.find(id => (STATE.chapterProgress[id] || 0) < 100);
  const ch = chapterMap[contId];
  return {
    name: STATE.userName || null,
    tzOffsetMinutes: currentTzOffsetMinutes(),
    notifyHour: STATE.notifyHour,
    streak: STATE.streak || 0,
    chapterContext: ch ? { id: ch.id, name: ch.name } : null,
  };
}
async function subscribeToPush() {
  if (!pushSupported()) { toast("This browser doesn't support push notifications.", "success", "bell-off"); return false; }
  if (Notification.permission === "denied") {
    toast("Notifications are blocked for this site in your browser settings. Enable them there, then try again.", "success", "bell-off");
    return false;
  }
  const permission = await Notification.requestPermission();
  if (permission !== "granted") return false;

  try {
    const reg = await navigator.serviceWorker.ready;
    let sub = await reg.pushManager.getSubscription();
    if (!sub) {
      sub = await reg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY),
      });
    }
    const ctx = buildNotifyContext();
    await fetch("/.netlify/functions/save-subscription", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ subscription: sub.toJSON(), ...ctx }),
    });
    STATE.notificationsEnabled = true;
    saveState();
    return true;
  } catch (err) {
    console.error("subscribeToPush failed", err);
    toast("Couldn't enable notifications on this device. Please try again.", "success", "bell-off");
    return false;
  }
}
async function unsubscribeFromPush() {
  STATE.notificationsEnabled = false;
  saveState();
  if (!pushSupported()) return;
  try {
    const reg = await navigator.serviceWorker.ready;
    const sub = await reg.pushManager.getSubscription();
    if (sub) {
      await fetch("/.netlify/functions/remove-subscription", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ endpoint: sub.endpoint }),
      });
      await sub.unsubscribe();
    }
  } catch (err) {
    console.error("unsubscribeFromPush failed", err);
  }
}
async function sendTestPush() {
  if (!pushSupported()) { toast("This browser doesn't support push notifications.", "success", "bell-off"); return; }
  try {
    const reg = await navigator.serviceWorker.ready;
    const sub = await reg.pushManager.getSubscription();
    if (!sub) { toast("Enable notifications first, then send a test.", "success", "bell"); return; }
    const res = await fetch("/.netlify/functions/send-test", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ subscription: sub.toJSON(), name: STATE.userName }),
    });
    if (res.ok) toast("Test notification sent — check your notification panel.", "success", "bell-ring");
    else toast("Test send failed. Check the server's VAPID environment variables.", "success", "bell-off");
  } catch (err) {
    console.error("sendTestPush failed", err);
    toast("Test send failed.", "success", "bell-off");
  }
}

function fmtINR(n) {
  if (n === null || n === undefined || isNaN(n)) return "—";
  return "₹" + Number(n).toLocaleString("en-IN");
}
function escapeHtml(s) {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

/* ---------------------------------------------------------
   1b. PERSONALIZATION — name, time-based greeting, welcome flow
   --------------------------------------------------------- */
function getGreeting() {
  const h = new Date().getHours();
  if (h >= 5 && h < 12) return { text: "Good morning", icon: "sunrise" };
  if (h >= 12 && h < 17) return { text: "Good afternoon", icon: "sun" };
  if (h >= 17 && h < 21) return { text: "Good evening", icon: "sunset" };
  return { text: "Good night", icon: "moon-star" };
}
function greetingLine() {
  const g = getGreeting();
  // A real Lucide icon instead of a raw emoji character — emoji glyph
  // support varies wildly across Android OEM fonts and was rendering as
  // a blank "tofu" box on at least one real device, which an icon from
  // the site's own icon system never will.
  const iconHtml = `<i data-lucide="${g.icon}" class="greeting-icon"></i>`;
  return STATE.userName ? `${g.text}, ${escapeHtml(STATE.userName)} ${iconHtml}` : `${g.text} ${iconHtml}`;
}
function firstName() {
  if (!STATE.userName) return "";
  return STATE.userName.trim().split(/\s+/)[0];
}
function showWelcomeModal() {
  const overlay = el("div", "welcome-modal-overlay");
  overlay.id = "welcomeModalOverlay";
  overlay.innerHTML = `
    <div class="welcome-modal" role="dialog" aria-modal="true" aria-labelledby="wmTitle">
      <div class="wm-mark" aria-hidden="true">
        <img src="assets/icon-192.png" alt="" width="52" height="52" style="border-radius:14px;">
      </div>
      <h2 id="wmTitle">Welcome to Accountancy By Abhinash 👋</h2>
      <p>What should we call you? This just personalizes your dashboard — nothing is sent anywhere, it stays on this device.</p>
      <input type="text" id="wmNameInput" maxlength="40" placeholder="Enter your name" autocomplete="off" aria-label="Your name">
      <button class="btn-primary ripple-surface" id="wmContinueBtn"><i data-lucide="arrow-right"></i> Continue</button>
      <button type="button" class="wm-skip" id="wmSkipBtn">Skip for now</button>
    </div>
  `;
  document.body.appendChild(overlay);
  icons();
  const modalBox = $(".welcome-modal", overlay);
  const input = $("#wmNameInput", overlay);

  const closeOverlay = () => {
    overlay.classList.add("closing");
    setTimeout(() => overlay.remove(), STATE.reduceMotion ? 0 : 220);
    renderRoute();
  };

  const showNotifStep = () => {
    if (!pushSupported() || Notification.permission === "denied") { closeOverlay(); return; }
    modalBox.innerHTML = `
      <div class="wm-mark" aria-hidden="true"><i data-lucide="bell" style="width:34px; height:34px; color:var(--gold);"></i></div>
      <h2>Would you like a daily reminder?</h2>
      <p>One short notification a day to keep your Accountancy learning going — even when the site is closed. You can turn this off any time in Settings.</p>
      <button class="btn-primary ripple-surface" id="wmEnableNotifBtn"><i data-lucide="bell"></i> Enable Daily Notifications</button>
      <button type="button" class="wm-skip" id="wmNotNowBtn">Not now</button>
    `;
    icons();
    $("#wmEnableNotifBtn", modalBox).addEventListener("click", async () => {
      const ok = await subscribeToPush();
      if (ok) toast("Daily reminders are on 🔔", "success", "bell-ring");
      closeOverlay();
    });
    $("#wmNotNowBtn", modalBox).addEventListener("click", closeOverlay);
  };

  const finish = (name) => {
    STATE.userName = name ? name.slice(0, 40) : "Student";
    STATE.onboardedAt = Date.now();
    saveState();
    if (name) toast(`Welcome, ${firstName()}!`, "success", "sparkles");
    showNotifStep();
  };
  $("#wmContinueBtn", overlay).addEventListener("click", () => finish(input.value.trim()));
  $("#wmSkipBtn", overlay).addEventListener("click", () => finish(""));
  input.addEventListener("keydown", e => { if (e.key === "Enter") finish(input.value.trim()); });
  setTimeout(() => input.focus(), STATE.reduceMotion ? 0 : 250);
}
function $(sel, root = document) { return root.querySelector(sel); }
function $all(sel, root = document) { return Array.from(root.querySelectorAll(sel)); }
function el(tag, cls, html) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html !== undefined) e.innerHTML = html;
  return e;
}
function icons() { if (window.lucide) lucide.createIcons(); }

function toast(msg, type = "success", icon = "check-circle") {
  const root = $("#toastRoot");
  const t = el("div", `toast ${type}`, `<i data-lucide="${icon}"></i><span>${msg}</span>`);
  root.appendChild(t);
  icons();
  setTimeout(() => { t.classList.add("leaving"); setTimeout(() => t.remove(), 300); }, 3200);
}

/* XP awarded for a correct first attempt at a question; XP deducted
   for an incorrect first attempt. Applied consistently everywhere a
   question is checked for correctness — never on a second attempt at
   the same question (see the `!STATE.solved[key]` guards at each
   call site), so refreshing, double-clicking, or reopening a page
   can never re-trigger either the gain or the penalty. */
const XP_WRONG_PENALTY = 1;

function addXP(amount, reason) {
  STATE.xp = Math.max(0, STATE.xp + amount);
  if (amount > 0) STATE.xpGained += amount;
  else if (amount < 0) STATE.xpDeducted += Math.abs(amount);
  saveState();
  $("#xpCount").textContent = STATE.xp;
  pulseElement($("#xpCount").closest(".xp-pill"));
  if (amount < 0) {
    toast(`${amount} XP — ${reason}`, "error", "alert-circle");
  } else {
    toast(`+${amount} XP — ${reason}`, "xp", "sparkles");
  }
  checkBadges();
}

/* Brief scale-pulse used to draw the eye to a value that just changed
   (XP total, streak count) without needing a full toast every time. */
function pulseElement(el) {
  if (!el || STATE.reduceMotion) return;
  el.classList.remove("pulse-once");
  void el.offsetWidth; // restart animation if triggered again quickly
  el.classList.add("pulse-once");
}

function logActivity(text) {
  STATE.activityLog.unshift({ text, at: Date.now() });
  STATE.activityLog = STATE.activityLog.slice(0, 12);
  saveState();
}

function touchStreak() {
  const today = new Date().toDateString();
  if (STATE.lastActiveDate === today) return;
  const yesterday = new Date(Date.now() - 86400000).toDateString();
  const wasFirstVisitEver = STATE.lastActiveDate === null;
  STATE.streak = (STATE.lastActiveDate === yesterday) ? STATE.streak + 1 : 1;
  STATE.lastActiveDate = today;
  saveState();
  $("#streakCount").textContent = STATE.streak;
  pulseElement($("#streakCount").closest(".streak-pill"));
  if (!wasFirstVisitEver && STATE.streak > 1) {
    toast(`${STATE.streak}-day streak — keep it up`, "xp", "flame");
    playNotificationSound();
  }
}

function checkBadges() {
  const rules = [
    { id: "first-solve", label: "First Solve", test: () => Object.keys(STATE.solved).length >= 1 },
    { id: "ten-solved", label: "Ledger Apprentice", test: () => Object.keys(STATE.solved).length >= 10 },
    { id: "fifty-solved", label: "Balance Keeper", test: () => Object.keys(STATE.solved).length >= 50 },
    { id: "streak-3", label: "3-Day Streak", test: () => STATE.streak >= 3 },
    { id: "xp-100", label: "Century Club", test: () => STATE.xp >= 100 }
  ];
  let newBadge = false;
  rules.forEach(r => {
    if (r.test() && !STATE.badges.includes(r.id)) {
      STATE.badges.push(r.id);
      newBadge = true;
      toast(`Badge earned: ${r.label}`, "badge", "award");
      launchConfetti();
      playAchievementSound();
    }
  });
  if (newBadge) saveState();
}

/* ---- Confetti (lightweight canvas) ---- */
function launchConfetti() {
  if (STATE.reduceMotion) return; // celebratory motion is exactly what reduced-motion users want skipped
  const canvas = $("#confettiCanvas");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  canvas.width = window.innerWidth; canvas.height = window.innerHeight;
  const colors = ["#B8863B", "#2D6A4F", "#3D4F91", "#B23A2F"];
  const gravity = 0.12;
  const drag = 0.995;
  const pieces = Array.from({ length: 90 }, () => ({
    x: Math.random() * canvas.width, y: -20 - Math.random() * 200,
    vx: (Math.random() - 0.5) * 5, vy: 1 + Math.random() * 3,
    size: 4 + Math.random() * 5, color: colors[Math.floor(Math.random() * colors.length)],
    rot: Math.random() * 360, vr: (Math.random() - 0.5) * 12,
    wobble: Math.random() * Math.PI * 2, wobbleSpeed: 0.05 + Math.random() * 0.05
  }));
  const totalFrames = 150;
  let frame = 0;
  function tick() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    frame++;
    const fadeStart = totalFrames - 30;
    const alpha = frame > fadeStart ? Math.max(0, 1 - (frame - fadeStart) / 30) : 1;
    pieces.forEach(p => {
      p.vy = (p.vy + gravity) * drag;
      p.vx *= drag;
      p.wobble += p.wobbleSpeed;
      p.x += p.vx + Math.sin(p.wobble) * 0.6; // gentle side-to-side drift, like real paper falling
      p.y += p.vy; p.rot += p.vr;
      ctx.save(); ctx.globalAlpha = alpha; ctx.translate(p.x, p.y); ctx.rotate(p.rot * Math.PI / 180);
      ctx.fillStyle = p.color; ctx.fillRect(-p.size/2, -p.size/2, p.size, p.size*0.6);
      ctx.restore();
    });
    if (frame < totalFrames) requestAnimationFrame(tick); else ctx.clearRect(0,0,canvas.width,canvas.height);
  }
  tick();
}

/* ---- Ripple effect ---- */
function attachRipple(container) {
  container.addEventListener("click", function (e) {
    const target = e.target.closest(".ripple-surface");
    if (!target) return;
    const rect = target.getBoundingClientRect();
    const r = el("span", "ripple-el");
    const size = Math.max(rect.width, rect.height);
    r.style.width = r.style.height = size + "px";
    r.style.left = (e.clientX - rect.left - size / 2) + "px";
    r.style.top = (e.clientY - rect.top - size / 2) + "px";
    target.appendChild(r);
    setTimeout(() => r.remove(), 650);
  });
}

/* ---------------------------------------------------------
   2b. SOUND ENGINE — synthesized via Web Audio API, so the
       app stays a self-contained set of files with no audio
       assets to load. Respects STATE.soundOn at all times.

       Redesigned for a subtle, premium, modern feel: every
       sound is short, low-volume, and passed through a gentle
       lowpass filter to soften the harmonics that make raw
       synthesized tones feel harsh, tinny, or arcade-like.
       Each interaction category has its own distinct, but
       related, timbre so the whole set feels like one
       coherent sound identity rather than a grab-bag of beeps.
       Pitches are randomized slightly on repeatable sounds
       (click, tab) so rapid interaction never sounds robotic
       or fatiguing.
   --------------------------------------------------------- */
let AUDIO_CTX = null;
function getAudioCtx() {
  if (!AUDIO_CTX) {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return null;
    AUDIO_CTX = new Ctx();
  }
  if (AUDIO_CTX.state === "suspended") AUDIO_CTX.resume();
  return AUDIO_CTX;
}

/* Shared helper: one soft, filtered oscillator "note" with a fast,
   click-free attack and a smooth exponential decay. Every sound in
   this file is built from one or more calls to this, which keeps
   the whole set consistent in character (same envelope shape, same
   gentle low-pass warmth) while letting pitch/gain/duration vary
   per interaction. `start` is an offset in seconds from `now`. */
function playTone(ctx, now, { freq, start = 0, dur = 0.12, gain = 0.045, type = "sine", filterFreq = 2400 }) {
  const t0 = now + start;
  const osc = ctx.createOscillator();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, t0);

  const filter = ctx.createBiquadFilter();
  filter.type = "lowpass";
  filter.frequency.setValueAtTime(filterFreq, t0);
  filter.Q.setValueAtTime(0.7, t0);

  const g = ctx.createGain();
  g.gain.setValueAtTime(0.0001, t0);
  g.gain.linearRampToValueAtTime(gain, t0 + Math.min(0.012, dur * 0.25));
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);

  osc.connect(filter);
  filter.connect(g);
  g.connect(ctx.destination);
  osc.start(t0);
  osc.stop(t0 + dur + 0.04);
  return osc;
}

/* BUTTON CLICK — a single, very soft, short tap. Pitch wobbles a
   few Hz each time so a burst of clicks never sounds mechanical. */
function playClickSound() {
  if (!STATE.soundOn) return;
  const ctx = getAudioCtx();
  if (!ctx) return;
  const now = ctx.currentTime;
  const base = 600 + Math.random() * 35;
  playTone(ctx, now, { freq: base, dur: 0.055, gain: 0.04, type: "sine", filterFreq: 2100 });
}

/* TAB / MENU INTERACTION — a touch lower and slightly softer than
   the button click, with a faint second partial a fifth above, so
   switching tabs or nav items reads as "moving to a new place"
   rather than "pressing a button". */
function playTabSound() {
  if (!STATE.soundOn) return;
  const ctx = getAudioCtx();
  if (!ctx) return;
  const now = ctx.currentTime;
  const base = 440 + Math.random() * 25;
  playTone(ctx, now, { freq: base, dur: 0.07, gain: 0.035, type: "sine", filterFreq: 1700 });
  playTone(ctx, now, { start: 0.014, freq: base * 1.5, dur: 0.08, gain: 0.018, type: "sine", filterFreq: 1900 });
}

/* CORRECT ANSWER — a warm, brief two-note upward interval. Softer
   and shorter than a full "achievement" chime, since this fires
   often (every correct answer) and must never grow tiresome. */
function playSuccessSound() {
  if (!STATE.soundOn) return;
  const ctx = getAudioCtx();
  if (!ctx) return;
  const now = ctx.currentTime;
  playTone(ctx, now, { freq: 523.25, dur: 0.15, gain: 0.05, filterFreq: 2500 });          // C5
  playTone(ctx, now, { start: 0.065, freq: 659.25, dur: 0.19, gain: 0.05, filterFreq: 2700 }); // E5
}

/* INCORRECT ANSWER — one soft, brief downward tone. Informational,
   not harsh: a plain sine through a low-pass filter, never a buzzy
   or square/triangle "wrong" arcade sound. */
function playErrorSound() {
  if (!STATE.soundOn) return;
  const ctx = getAudioCtx();
  if (!ctx) return;
  const now = ctx.currentTime;
  const osc = ctx.createOscillator();
  osc.type = "sine";
  osc.frequency.setValueAtTime(300, now);
  osc.frequency.exponentialRampToValueAtTime(232, now + 0.16);

  const filter = ctx.createBiquadFilter();
  filter.type = "lowpass";
  filter.frequency.setValueAtTime(1400, now);

  const gain = ctx.createGain();
  gain.gain.setValueAtTime(0.0001, now);
  gain.gain.linearRampToValueAtTime(0.045, now + 0.015);
  gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.19);

  osc.connect(filter);
  filter.connect(gain);
  gain.connect(ctx.destination);
  osc.start(now);
  osc.stop(now + 0.22);
}

/* QUIZ / EXAM COMPLETION — a gentle three-note upward resolve.
   Distinct from a single correct answer (longer, three notes,
   settles on a held final note) without becoming a fanfare. */
function playCompletionSound() {
  if (!STATE.soundOn) return;
  const ctx = getAudioCtx();
  if (!ctx) return;
  const now = ctx.currentTime;
  const notes = [
    { freq: 493.88, start: 0.00, dur: 0.16 }, // B4
    { freq: 587.33, start: 0.11, dur: 0.18 }, // D5
    { freq: 783.99, start: 0.23, dur: 0.36 }  // G5 — held, the "resolve"
  ];
  notes.forEach(n => playTone(ctx, now, { ...n, gain: 0.045, filterFreq: 2600 }));
}

/* ACHIEVEMENT / SUCCESS MILESTONE — badge unlocks and chapter
   mastery. A soft, layered bell-like chime (root + soft fifth +
   faintly detuned octave for a little shimmer), longer and gentler
   than any other sound in the set, reserved for genuinely special
   moments so it never becomes routine. */
function playAchievementSound() {
  if (!STATE.soundOn) return;
  const ctx = getAudioCtx();
  if (!ctx) return;
  const now = ctx.currentTime;
  const root = 587.33; // D5
  [
    { mult: 1,     gain: 0.045, dur: 0.55 },
    { mult: 1.5,   gain: 0.03,  dur: 0.5  },
    { mult: 2.006, gain: 0.02,  dur: 0.45 } // very slightly detuned octave for shimmer, not dissonance
  ].forEach((n, i) => playTone(ctx, now, { start: i * 0.02, freq: root * n.mult, dur: n.dur, gain: n.gain, filterFreq: 3200 }));
}

/* IMPORTANT NOTIFICATION — reserved for rare, meaningful pings
   (e.g. the once-a-day streak notice) rather than every toast, so
   it stays noticeable instead of blending into routine feedback.
   A simple two-note soft "ping" distinct from the click/tab family. */
function playNotificationSound() {
  if (!STATE.soundOn) return;
  const ctx = getAudioCtx();
  if (!ctx) return;
  const now = ctx.currentTime;
  playTone(ctx, now, { freq: 740, dur: 0.13, gain: 0.045, filterFreq: 3000 });
  playTone(ctx, now, { start: 0.09, freq: 880, dur: 0.16, gain: 0.032, filterFreq: 3200 });
}

/* The intro sound — a short, soft rising three-note chime timed to
   sync with the 3.5s intro animation (balance scale settling +
   brand reveal). Played once, right as the preloader animation
   starts. Same notes/timing as before, softened to match the rest
   of the redesigned set. */
function playIntroSound() {
  if (!STATE.soundOn) return;
  const ctx = getAudioCtx();
  if (!ctx) return;
  const now = ctx.currentTime;
  const notes = [
    { freq: 392.0,  start: 0.0,  dur: 0.5 },  // G4
    { freq: 523.25, start: 0.25, dur: 0.55 }, // C5
    { freq: 659.25, start: 0.55, dur: 0.9 }   // E5, held — resolves as the brand text lands
  ];
  notes.forEach(n => playTone(ctx, now, { ...n, gain: 0.045, filterFreq: 2400 }));
}

/* Global delegated click-sound handler — fires for any click on a
   button, .chip, .nav-item, or [data-sound] element, anywhere in the
   app, without needing per-element listeners. A user gesture is
   required to unlock AudioContext on some browsers, which this
   naturally satisfies since it only runs in response to a click.
   Tab/menu-style elements (.chip, .nav-item) get the softer,
   navigation-flavoured sound; everything else gets the plain click. */
function attachClickSound(container) {
  container.addEventListener("click", (e) => {
    const target = e.target.closest("button, .chip, .nav-item, [data-sound], .theme-swatch, .ripple-surface");
    if (!target || target.disabled) return;
    if (target.matches(".chip, .nav-item")) playTabSound();
    else playClickSound();
  }, { capture: true });
}

/* ---------------------------------------------------------
   3. THEME / SETTINGS
   --------------------------------------------------------- */
function applyTheme() {
  document.documentElement.classList.toggle("dark", STATE.theme === "dark");
  document.documentElement.setAttribute("data-color-theme", STATE.colorTheme || "classic");
  $("#themeIconMoon").hidden = STATE.theme === "dark";
  $("#themeIconSun").hidden = STATE.theme !== "dark";
  document.documentElement.classList.toggle("reduce-motion", STATE.reduceMotion);
  document.documentElement.classList.toggle("high-contrast", STATE.highContrast);
  document.documentElement.classList.toggle("colorblind-mode", STATE.colorblind);
  document.documentElement.style.fontSize = (16 * STATE.fontScale) + "px";
}
$("#themeToggle").addEventListener("click", () => {
  STATE.theme = STATE.theme === "dark" ? "light" : "dark";
  saveState(); applyTheme();
});

/* ---------------------------------------------------------
   4. ROUTER
   --------------------------------------------------------- */
const routes = {
  "home": renderHome,
  "about": renderAbout,
  "ch-eq": renderEquationChapter,
  "ch-dc": renderDCChapter,
  "ch-jr": renderJournalChapter,
  "ch-lg": renderLedgerChapter,
  "ch-cb": renderCashBookChapter,
  "ch-sp2": renderSp2Chapter,
  "ch-brs": renderBrsChapter,
  "ch-gst": renderGstChapter,
  "ch-tb": renderTbChapter,
  "ch-dep": renderDepChapter,
  "chapters-list": renderChaptersList,
  "practice-hub": renderPracticeHub,
  "mistake-book": renderMistakeBook,
  "accounting-cycle": renderAccountingCycle,
  "more": renderMoreHub,
  "bookmarks": renderBookmarks,
  "numerical-solver": renderNumericalSolver,
  "quiz": renderQuiz,
  "flashcards": renderFlashcards,
  "formula-sheet": renderFormulaSheet,
  "important-questions": renderImportantQuestions,
  "exam-mode": renderExamMode,
  "performance": renderPerformance,
  "settings": renderSettings,
  "ai-tutor": renderAITutor,
  "certificate-view": renderCertificateViewRoute
};

const ROUTE_TITLES = {
  "home": "Home", "about": "About This Website", "ch-eq": "Accounting Equation", "ch-dc": "Debit & Credit", "ch-jr": "Journal", "ch-lg": "Ledger", "ch-cb": "Special Purpose Books 1 - Cash Book", "ch-sp2": "Special Purpose Books 2 - Other Books", "ch-brs": "Bank Reconciliation Statement (BRS)", "ch-gst": "Accounting of GST", "ch-tb": "Trial Balance", "ch-dep": "Depreciation",
  "chapters-list": "Chapters", "practice-hub": "Practice", "mistake-book": "Mistake Book", "accounting-cycle": "Accounting Cycle", "more": "More", "bookmarks": "Bookmarks",
  "numerical-solver": "Numerical Practice", "quiz": "Quiz", "flashcards": "Flashcards", "formula-sheet": "Formula Sheet",
  "important-questions": "Important Questions", "exam-mode": "Exam Mode", "performance": "Progress", "settings": "Settings",
  "ai-tutor": "AI Tutor", "certificate-view": "Certificate"
};
const BOTTOM_NAV_MAP = {
  "home": "home",
  "ch-eq": "chapters-list", "ch-dc": "chapters-list", "ch-jr": "chapters-list", "ch-lg": "chapters-list", "ch-cb": "chapters-list", "ch-sp2": "chapters-list", "ch-brs": "chapters-list", "ch-gst": "chapters-list", "ch-tb": "chapters-list", "ch-dep": "chapters-list", "chapters-list": "chapters-list",
  "practice-hub": "practice-hub",
  "mistake-book": "practice-hub",
  "accounting-cycle": "accounting-cycle",
  "performance": "performance"
};

function animateProgressBars(container) {
  const bars = container.querySelectorAll(".progress-fill[data-target]");
  if (!bars.length) return;
  if (STATE.reduceMotion) {
    bars.forEach(b => { b.style.width = b.dataset.target + "%"; });
    return;
  }
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      bars.forEach(b => { b.style.width = b.dataset.target + "%"; });
    });
  });
}

function navigate(route) {
  window.location.hash = route;
}
window.addEventListener("hashchange", renderRoute);

function renderRoute() {
  const route = window.location.hash.replace("#", "") || "home";
  const fn = routes[route] || renderHome;
  // A maximized whiteboard covers the whole screen — closing it on
  // navigation stops it silently blocking whatever page comes next.
  // A small floating whiteboard doesn't cover content, so it's left open,
  // same as the calculator/scratch pad/pomodoro already behave.
  const wbPanel = $("#whiteboardPanel");
  if (wbPanel && !wbPanel.hidden && wbPanel.classList.contains("wb-maximized")) closePanel("whiteboardPanel");
  $all(".nav-item").forEach(n => n.classList.toggle("active", n.dataset.route === route));
  $all(".bottom-nav-item").forEach(n => n.classList.toggle("active", n.dataset.route === (BOTTOM_NAV_MAP[route] || "more")));
  const titleEl = $("#topbarPageTitle");
  if (titleEl) titleEl.textContent = ROUTE_TITLES[route] || "Accountancy By Abhinash";
  $(".topbar").classList.remove("search-open");
  const root = $("#view-root");
  root.classList.add("view-leaving");
  setTimeout(() => {
    root.innerHTML = "";
    // Routes like AI Tutor add layout-specific classes (e.g. ai-route-root)
    // directly onto #view-root. Reset back to the base class before the
    // next route renders, or those classes leak into every page after it.
    root.className = "view-root";
    fn(root);
    icons();
    animateProgressBars(root);
    root.classList.remove("view-leaving");
    root.classList.add("view-entering");
    // Force a reflow so the entering animation reliably restarts even
    // when navigating quickly between routes with the same class present.
    void root.offsetWidth;
    root.classList.remove("view-entering");
    if (window.innerWidth <= 860) closeSidebar();
    window.scrollTo({ top: 0, behavior: STATE.reduceMotion ? "auto" : "smooth" });
  }, 110);
  touchStreak();
  updateNavProgress();
}

$all(".nav-item").forEach(n => n.addEventListener("click", () => navigate(n.dataset.route)));
$all(".bottom-nav-item").forEach(n => n.addEventListener("click", () => navigate(n.dataset.route)));

function closeSidebar() {
  $("#sidebar").classList.remove("open");
  $("#sidebarOverlay").classList.remove("open");
  $("#sidebarToggle").setAttribute("aria-expanded", "false");
}
function openSidebar() {
  $("#sidebar").classList.add("open");
  $("#sidebarOverlay").classList.add("open");
  $("#sidebarToggle").setAttribute("aria-expanded", "true");
}

function updateNavProgress() {
  $all(".nav-progress").forEach(p => {
    const ch = p.dataset.progress;
    p.textContent = (STATE.chapterProgress[ch] || 0) + "%";
  });
}

const CHAPTER_BANK = { eq: () => APP_DATA.equation.numericals, dc: () => APP_DATA.debitCredit.numericals, jr: () => APP_DATA.journal.numericals, lg: () => getLedgerPracticePool(), cb: () => APP_DATA.cashBook.numericals, sp2: () => APP_DATA.specialBooks2.numericals, brs: () => APP_DATA.brs.numericals, gst: () => APP_DATA.gst.numericals, tb: () => APP_DATA.tb.numericals, dep: () => APP_DATA.dep.numericals };
function computeChapterProgress(chId) {
  const bank = CHAPTER_BANK[chId] ? CHAPTER_BANK[chId]() : null;
  if (!bank || !bank.length) return 0;
  const solvedCount = Object.keys(STATE.solved).filter(k => k.startsWith(chId + "-")).length;
  return Math.round((solvedCount / bank.length) * 100);
}
function refreshProgress() {
  const CH_NAMES = { eq: "Accounting Equation", dc: "Rules of Debit & Credit", jr: "Journal", lg: "Ledger", cb: "Special Purpose Books 1 - Cash Book", sp2: "Special Purpose Books 2 - Other Books", brs: "Bank Reconciliation Statement (BRS)", gst: "Accounting of GST", tb: "Trial Balance", dep: "Depreciation" };
  ["eq", "dc", "jr", "lg", "cb", "sp2", "brs", "gst", "tb", "dep"].forEach(id => {
    const before = STATE.chapterProgress[id] || 0;
    const after = computeChapterProgress(id);
    STATE.chapterProgress[id] = after;
    const badgeId = `mastered-${id}`;
    if (before < 100 && after >= 100 && !STATE.badges.includes(badgeId)) {
      STATE.badges.push(badgeId);
      addXP(25, `${CH_NAMES[id]} mastered`);
      logActivity(`Completed every learning stage in ${CH_NAMES[id]} 🎉`);
      launchConfetti();
      toast(`${CH_NAMES[id]} complete! You've finished every learning stage.`, "badge", "trophy");
      playAchievementSound();
    }
  });
  saveState();
  updateNavProgress();
}

/* ---------------------------------------------------------
   5. HOME VIEW
   --------------------------------------------------------- */
// Which chapter + what to do next, given the student's actual local
// progress. Prefers the chapter they were last on (if unfinished), then
// falls back to the first incomplete chapter in syllabus order, then
// treats a fully-complete student as ready for revision.
function pickContinueTarget() {
  const order = ["eq", "dc", "jr", "lg", "cb", "sp2", "brs", "gst", "tb", "dep"];
  const last = STATE.lastChapterViewed;
  if (last && (STATE.chapterProgress[last] || 0) < 100) return last;
  const firstIncomplete = order.find(id => (STATE.chapterProgress[id] || 0) < 100);
  return firstIncomplete || last || "eq";
}
/* ---------------------------------------------------------
   3b. ABOUT THIS WEBSITE — a welcome + guide page. Reuses the
   same design tokens as the rest of the app (no parallel style
   system) and stays skimmable: short explanations up front,
   <details> for anything deeper, real "try it" buttons that
   jump straight into the feature being described.
   --------------------------------------------------------- */
function renderAbout(root) {
  const contId = pickContinueTarget();

  const logoWrap = el("div", "");
  logoWrap.style.cssText = "background:#fff; border-radius:var(--radius-md); padding:20px; display:flex; justify-content:center; margin-bottom:24px; border:1px solid var(--line);";
  logoWrap.innerHTML = `<img src="assets/logo-full.png" alt="Accountancy By Abhinash — Class 11" style="max-width:320px; width:100%; height:auto;">`;
  root.appendChild(logoWrap);

  /* Quick start hero */
  const hero = el("section", "continue-hero");
  hero.innerHTML = `
    <span class="ch-eyebrow">New here? Start in 3 steps</span>
    <h2 style="margin-top:10px;">1️⃣ Choose a chapter · 2️⃣ Learn &amp; practice · 3️⃣ Take a quiz and review mistakes</h2>
    <p class="ch-sub">Accountancy By Abhinash is a free, interactive learning platform for CBSE Class 11 Commerce — no account, no email, no password.</p>
    <button class="btn-primary ripple-surface" id="aboutStartBtn" style="margin-top:6px;"><i data-lucide="arrow-right"></i> Start Learning</button>
  `;
  root.appendChild(hero);

  /* What is this website */
  root.appendChild(sectionTitle("What is this website?"));
  const whatCard = el("div", "card-solid");
  whatCard.style.padding = "24px";
  whatCard.innerHTML = `
    <p style="font-size:0.92rem; line-height:1.65; margin:0 0 14px;"><b>Accountancy By Abhinash</b> is an interactive learning platform built to help Class 11 Commerce students learn, practice, revise, and understand Accountancy in one place — instead of jumping between a textbook, a YouTube video, a doubt-solving app, and a separate revision notebook.</p>
    <p style="font-size:0.92rem; line-height:1.65; margin:0 0 14px; color:var(--ink-soft);">It brings together chapter learning, theory and concepts, numerical practice, quizzes, flashcards, formula revision, important questions, a timed Exam Mode, performance tracking, and an AI-powered tutor — all covering the Accounting Equation, Rules of Debit &amp; Credit, Journal, Ledger, Special Purpose Books 1 - Cash Book, Special Purpose Books 2 - Other Books, Bank Reconciliation Statement (BRS), Accounting of GST, Trial Balance, and Depreciation.</p>
    <p style="font-size:0.95rem; line-height:1.65; margin:0; font-weight:600;">Learn. Practice. Understand. Improve.</p>
  `;
  root.appendChild(whatCard);

  /* Creator section */
  root.appendChild(sectionTitle("Who made this"));
  const creatorCard = el("div", "card-solid");
  creatorCard.style.cssText = "padding:30px 26px; text-align:center;";
  creatorCard.innerHTML = `
    <img src="assets/icon-192.png" alt="" width="48" height="48" style="border-radius:12px; margin-bottom:14px;">
    <p style="font-size:0.78rem; text-transform:uppercase; letter-spacing:0.08em; color:var(--ink-faint); margin:0 0 6px;">Designed &amp; developed by</p>
    <h3 style="font-family:var(--font-head); font-size:1.3rem; margin:0 0 10px;">D. Abhinash Reddy</h3>
    <p style="font-size:0.86rem; color:var(--ink-soft); max-width:520px; margin:0 auto 14px; line-height:1.6;">Built through <b>Vibe Coding</b> — an approach where ideas, creativity, problem-solving, and AI-assisted development come together to turn an idea into a working digital product.</p>
    <p style="font-size:0.86rem; color:var(--ink-soft); max-width:520px; margin:0 auto; line-height:1.6;">Accountancy By Abhinash was created with one goal: make Accountancy learning more organized, interactive, and easier to understand. It's a personal project, not a company product — and it's still evolving.</p>
  `;
  root.appendChild(creatorCard);

  /* How to use — step journey */
  root.appendChild(sectionTitle("How to use this website"));
  const steps = [
    { icon: "book-open", title: "1. Start with a chapter", body: "Pick Accounting Equation, Rules of Debit &amp; Credit, Journal, or Ledger. Understand the concepts before jumping into hard questions." },
    { icon: "lightbulb", title: "2. Learn the concepts", body: "Each chapter's Theory and Concepts tabs cover the definitions, rules, and logic — the goal is understanding <i>why</i> an account is debited or credited, not memorizing answers." },
    { icon: "pencil-line", title: "3. Practice", body: "Try Journal entries and numerical questions yourself before revealing the solution." },
    { icon: "bot", title: "4. Ask the AI Tutor when confused", body: "Stuck, or not sure why something is debited or credited? Ask the AI Tutor — it's a learning assistant, not just an answer generator." },
    { icon: "help-circle", title: "5. Test your knowledge", body: "Use Quiz, chapter tests, or Exam Mode to check whether you actually understand the topic." },
    { icon: "layers", title: "6. Revise", body: "Flashcards for quick memory checks, the Formula Sheet for rules and formulas, Important Questions for exam prep, and Bookmarks for anything you flagged for a second look." },
    { icon: "bar-chart-3", title: "7. Track progress", body: "XP, streak, chapter progress, and questions solved answer three questions: what have I learned, what am I weak in, and what should I study next." },
  ];
  const stepsWrap = el("div", "");
  stepsWrap.style.cssText = "display:flex; flex-direction:column; gap:10px;";
  steps.forEach(s => {
    const row = el("div", "focus-item");
    row.style.cursor = "default";
    row.innerHTML = `<span class="fi-icon"><i data-lucide="${s.icon}"></i></span><span><b>${s.title.replace(/^\d+\.\s/, "")}</b><br><span style="color:var(--ink-soft); font-weight:400;">${s.body}</span></span>`;
    stepsWrap.appendChild(row);
  });
  root.appendChild(stepsWrap);

  /* Best learning path */
  root.appendChild(sectionTitle("The best way to study here"));
  const pathCard = el("div", "card-solid");
  pathCard.style.padding = "24px";
  const pathStages = ["Learn", "Understand", "Practice", "Ask Questions", "Take a Quiz", "Review Mistakes", "Revise", "Improve"];
  pathCard.innerHTML = `
    <p style="font-size:0.86rem; color:var(--ink-soft); margin:0 0 16px;">Don't try to use every feature at once. Follow this order, one chapter at a time:</p>
    <div class="journey-stepper" style="margin-bottom:4px;">
      ${pathStages.map((s, i) => `<div class="journey-step js-done" style="min-width:76px;"><span class="js-dot">${i+1}</span><span class="js-label">${s}</span></div>${i < pathStages.length-1 ? '<div class="js-connector"></div>' : ''}`).join("")}
    </div>
  `;
  root.appendChild(pathCard);

  /* Meet the AI Tutor — interactive prompts */
  root.appendChild(sectionTitle("Meet your Accountancy AI Tutor"));
  const aiCard = el("div", "card-solid");
  aiCard.style.padding = "24px";
  const aiPrompts = [
    "Why is Cash debited in this transaction?",
    "Explain this Journal entry like I'm a beginner.",
    "Give me a hint without revealing the answer.",
    "Give me a similar practice question on the Accounting Equation.",
  ];
  aiCard.innerHTML = `
    <p style="font-size:0.9rem; line-height:1.6; margin:0 0 16px;">The AI Tutor is designed to help you <b>understand</b> Accountancy — not just hand you answers. Try tapping one of these:</p>
    <div class="focus-list" id="aiPromptList"></div>
    <button class="btn-ghost ripple-surface" id="aboutTryAI" style="margin-top:16px;"><i data-lucide="bot"></i> Open AI Tutor</button>
  `;
  root.appendChild(aiCard);
  const promptList = $("#aiPromptList", aiCard);
  aiPrompts.forEach(p => {
    const item = el("div", "focus-item");
    item.innerHTML = `<span class="fi-icon"><i data-lucide="message-circle"></i></span><span>"${p}"</span><i data-lucide="chevron-right" style="margin-left:auto; width:16px; height:16px; color:var(--ink-faint);"></i>`;
    item.addEventListener("click", () => askAIAbout(p, null));
    promptList.appendChild(item);
  });

  /* Study tools */
  root.appendChild(sectionTitle("Study tools"));
  const toolsCard = el("div", "card-solid");
  toolsCard.style.padding = "24px";
  toolsCard.innerHTML = `
    <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:16px; font-size:0.86rem; line-height:1.55;">
      <div><b><i data-lucide="calculator" style="width:14px;height:14px; vertical-align:-2px;"></i> Calculator</b><br><span style="color:var(--ink-soft);">Quick calculations while you study.</span></div>
      <div><b><i data-lucide="notebook-pen" style="width:14px;height:14px; vertical-align:-2px;"></i> Scratch Pad</b><br><span style="color:var(--ink-soft);">Rough working, temporary notes, or jotting a thought.</span></div>
      <div><b><i data-lucide="timer" style="width:14px;height:14px; vertical-align:-2px;"></i> Pomodoro</b><br><span style="color:var(--ink-soft);">Focused study sessions with built-in breaks.</span></div>
      <div><b><i data-lucide="maximize" style="width:14px;height:14px; vertical-align:-2px;"></i> Fullscreen</b><br><span style="color:var(--ink-soft);">A more focused, distraction-free view.</span></div>
    </div>
    <p style="font-size:0.8rem; color:var(--ink-faint); margin:16px 0 0;">On mobile, find these under <b>More → Study tools</b>. On desktop, they're pinned to the bottom of the sidebar.</p>
  `;
  root.appendChild(toolsCard);

  /* Personalization + Progress */
  root.appendChild(sectionTitle("Personalization, progress &amp; XP"));
  const persCard = el("div", "card-solid");
  persCard.style.padding = "24px";
  persCard.innerHTML = `
    <p style="font-size:0.88rem; line-height:1.6; margin:0 0 12px;"><b>Your name</b> is asked once, on your first visit, so the dashboard can greet you naturally — "Good evening, ${STATE.userName ? escapeHtml(firstName()) : "Abhinash"}" — based on the time of day on your device. It's stored only on this device, not sent anywhere, and you can change or clear it any time in Settings.</p>
    <p style="font-size:0.88rem; line-height:1.6; margin:0 0 12px;"><b>XP</b> reflects your learning activity. <b>Streak</b> encourages studying consistently. <b>Progress</b> shows how far through a chapter's learning journey you are. <b>Achievements</b> celebrate meaningful milestones, like finishing a chapter. None of these are meant to pressure you — they're just a way to see your own consistency.</p>
    <p style="font-size:0.88rem; line-height:1.6; margin:0;">Everything — name, XP, progress, quiz history, bookmarks, AI Tutor chats — lives in your browser's local storage. Nothing requires an account, and nothing leaves your device.</p>
  `;
  root.appendChild(persCard);

  /* FAQ */
  root.appendChild(sectionTitle("FAQ"));
  const faqs = [
    ["Is this website free to use?", "Yes — it's a personal project with no payment or subscription anywhere on the site."],
    ["Do I need to create an account?", "No. On your first visit you're asked what to call you (optional), and that's stored locally on your device — there's no email or password."],
    ["Can I use this on mobile?", "Yes, the whole site is responsive, and it can be installed on your phone's home screen like an app (look for \"Add to Home Screen\" / \"Install\" in your browser menu)."],
    ["What should I do if I don't understand a question?", "Open the AI Tutor — either from the sidebar, or tap \"Ask AI about this\" directly on the question — or go back and re-read that chapter's Theory and Concepts tabs."],
    ["Can I track my progress?", "Yes — see the Progress tab for XP, streak, accuracy, chapter completion, and badges earned."],
    ["Can I reset my progress?", "Yes, from Settings → Progress data. You can reset just your progress (keeps your name and preferences), or wipe everything on the device."],
  ];
  const faqWrap = el("div", "card-solid");
  faqWrap.style.padding = "8px 24px";
  faqs.forEach(([q, a], i) => {
    const d = document.createElement("details");
    d.className = "faq-item";
    if (i > 0) d.style.borderTop = "1px solid var(--line)";
    d.innerHTML = `<summary>${q}</summary><p>${a}</p>`;
    faqWrap.appendChild(d);
  });
  root.appendChild(faqWrap);

  /* Closing CTA */
  const closing = el("div", "continue-hero");
  closing.style.marginTop = "40px";
  closing.innerHTML = `
    <span class="ch-eyebrow">Ready?</span>
    <h2>Let's get started</h2>
    <p class="ch-sub">Jump back into ${(APP_DATA.chapters.find(c=>c.id===contId)||{}).name || "your chapter"}, or explore from the dashboard.</p>
    <button class="btn-primary ripple-surface" id="aboutStartBtn2"><i data-lucide="play"></i> Continue Learning</button>
  `;
  root.appendChild(closing);

  /* Intro video — the very last thing on the page, as requested */
  root.appendChild(sectionTitle("Watch: A quick look at the website"));
  const videoCard = el("div", "card-solid");
  videoCard.style.padding = "16px";
  videoCard.innerHTML = `
    <video controls preload="metadata" playsinline poster="assets/video/about-website-poster.jpg" style="width:100%; border-radius:var(--radius-md); display:block; background:#000;">
      <source src="assets/video/about-website.mp4" type="video/mp4">
      Your browser doesn't support embedded video — you can download it directly instead.
    </video>
  `;
  root.appendChild(videoCard);

  attachRipple(root);
  const goStart = () => navigate(`ch-${contId}`);
  $("#aboutStartBtn").addEventListener("click", goStart);
  $("#aboutStartBtn2").addEventListener("click", goStart);
  $("#aboutTryAI").addEventListener("click", () => navigate("ai-tutor"));
}

function renderHome(root) {
  const solvedCount = Object.keys(STATE.solved).length;
  const accuracy = solvedCount ? Math.round(100 * Object.values(STATE.solved).filter(s => s.correct).length / solvedCount) : 0;
  const overallPct = Math.round((( STATE.chapterProgress.eq||0) + (STATE.chapterProgress.dc||0) + (STATE.chapterProgress.jr||0) + (STATE.chapterProgress.lg||0) + (STATE.chapterProgress.cb||0) + (STATE.chapterProgress.sp2||0) + (STATE.chapterProgress.brs||0) + (STATE.chapterProgress.gst||0) + (STATE.chapterProgress.tb||0) + (STATE.chapterProgress.dep||0)) / 10);
  const chapterMap = {}; APP_DATA.chapters.forEach(c => chapterMap[c.id] = c);
  const contId = pickContinueTarget();
  const cont = chapterMap[contId];
  const contProgress = STATE.chapterProgress[contId] || 0;
  const CH_SOFT_BG = { eq: "c-eq-soft", dc: "c-dc-soft", jr: "c-jr-soft", lg: "c-lg-soft", cb: "c-cb-soft", sp2: "c-sp2-soft", brs: "c-brs-soft", gst: "c-gst-soft", tb: "c-tb-soft", dep: "c-dep-soft" };

  /* ---- 1. Personal greeting (light — sets context, doesn't shout) ---- */
  const greetWrap = el("div", "dash-greeting");
  greetWrap.innerHTML = `
    <h1>${greetingLine()}</h1>
    <p>Ready to make a little progress today?</p>
  `;
  root.appendChild(greetWrap);

  /* ---- 2. Continue Learning — the one primary action on this page ---- */
  const contHero = el("section", "continue-hero");
  if (overallPct >= 100) {
    contHero.innerHTML = `
      <span class="ch-eyebrow">All ten chapters complete</span>
      <h2>Time to consolidate 🎯</h2>
      <p class="ch-sub">You've been through every chapter at least once. A mixed Exam Mode run is the best way to find any remaining weak spots.</p>
      <button class="btn-primary ripple-surface" id="continueBtn"><i data-lucide="timer"></i> Take a Mixed Exam</button>
    `;
  } else {
    contHero.innerHTML = `
      <span class="ch-eyebrow">Continue Learning</span>
      <h2>${cont.name}</h2>
      <p class="ch-sub">You're ${contProgress}% through this chapter.</p>
      <div class="progress-track"><div class="progress-fill" data-target="${contProgress}" style="width:0%"></div></div>
      <button class="btn-primary ripple-surface" id="continueBtn" style="margin-top:18px;"><i data-lucide="play"></i> Continue Learning</button>
    `;
  }
  root.appendChild(contHero);

  /* ---- 3. Today's Focus — 2-3 specific, concrete next actions ---- */
  const focusItems = [];
  if (STATE.mistakeBook && Object.values(STATE.mistakeBook).some(m => m.status !== "mastered")) {
    const activeCount = Object.values(STATE.mistakeBook).filter(m => m.status !== "mastered").length;
    focusItems.push({ icon: "brain", text: `Review ${activeCount} question${activeCount===1?"":"s"} in your Mistake Book`, route: "mistake-book" });
  } else if (STATE.mistakes && STATE.mistakes.length > 0) {
    focusItems.push({ icon: "brain", text: `Review ${STATE.mistakes.length} question${STATE.mistakes.length===1?"":"s"} you got wrong`, route: "mistake-book" });
  }
  if (contProgress < 100) {
    focusItems.push({ icon: "book-open", text: `Keep going on ${cont.name}`, route: `ch-${contId}` });
  }
  const anyChapterStarted = Object.values(STATE.chapterProgress).some(p => p > 0);
  if (anyChapterStarted) {
    focusItems.push({ icon: "help-circle", text: "Take a quick quiz to test what you know", route: "quiz" });
  } else {
    focusItems.push({ icon: "bot", text: "Not sure where to start? Ask the AI Tutor", route: "ai-tutor" });
  }
  focusItems.push({ icon: "layers", text: "Run through today's flashcards", route: "flashcards" });
  const focusSection = el("div", "today-focus");
  focusSection.appendChild(sectionTitle("Today's focus"));
  const focusList = el("div", "focus-list");
  focusItems.slice(0, 3).forEach(f => {
    const item = el("div", "focus-item ripple-surface");
    item.innerHTML = `<span class="fi-icon"><i data-lucide="${f.icon}"></i></span><span>${f.text}</span><i data-lucide="chevron-right" style="margin-left:auto; width:16px; height:16px; color:var(--ink-faint);"></i>`;
    item.addEventListener("click", () => navigate(f.route));
    focusList.appendChild(item);
  });
  focusSection.appendChild(focusList);
  root.appendChild(focusSection);

  /* ---- 4. Progress summary — meaningful signals, compact, not decorative ---- */
  const summaryWrap = el("div", "progress-summary-row");
  summaryWrap.innerHTML = `
    <span class="ps-chip"><i data-lucide="sparkles" style="width:14px;height:14px;color:var(--gold);"></i> <b class="tnum">${STATE.xp}</b> XP</span>
    <span class="ps-chip"><i data-lucide="flame" style="width:14px;height:14px;color:var(--flag);"></i> <b class="tnum">${STATE.streak}</b> day streak</span>
    <span class="ps-chip"><i data-lucide="check-circle" style="width:14px;height:14px;color:var(--c-eq);"></i> <b class="tnum">${overallPct}%</b> overall</span>
    <span class="ps-chip"><i data-lucide="calculator" style="width:14px;height:14px;color:var(--c-jr);"></i> <b class="tnum">${solvedCount}</b> solved${solvedCount ? ` · ${accuracy}% accurate` : ""}</span>
  `;
  root.appendChild(summaryWrap);

  /* ---- 5b. Install App banner — only shown when installable and not dismissed/already installed ---- */
  if (!isStandalone() && localStorage.getItem("aba_install_dismissed") !== "1") {
    const installCard = el("div", "teaser-card");
    installCard.style.marginTop = "28px";
    const iosHint = isIOS();
    installCard.innerHTML = `
      <button class="teaser-dismiss" aria-label="Dismiss"><i data-lucide="x"></i></button>
      <div class="teaser-icon"><i data-lucide="download"></i></div>
      <div class="teaser-body">
        <h4>Install this app</h4>
        <p>${iosHint ? "Add it to your home screen: tap the Share icon in Safari, then \"Add to Home Screen.\"" : "Add Accountancy By Abhinash to your home screen for one-tap access, even offline."}</p>
      </div>
      ${iosHint ? "" : `<button class="btn-primary sm ripple-surface" id="installAppBtn"><i data-lucide="download"></i> Install</button>`}
    `;
    root.appendChild(installCard);
    $(".teaser-dismiss", installCard).addEventListener("click", () => {
      localStorage.setItem("aba_install_dismissed", "1");
      installCard.remove();
    });
    if (!iosHint) {
      const installBtn = $("#installAppBtn", installCard);
      installBtn.addEventListener("click", async () => {
        if (!deferredInstallPrompt) { toast("Your browser doesn't support one-tap install here — check its menu for \"Install app\".", "success", "info"); return; }
        deferredInstallPrompt.prompt();
        const choice = await deferredInstallPrompt.userChoice;
        if (choice.outcome === "accepted") { installCard.remove(); }
        deferredInstallPrompt = null;
      });
    }
  }

  /* ---- 5c. About This Website — teaser card, full guide is one tap away ---- */
  const aboutTeaser = el("div", "teaser-card about-teaser ripple-surface");
  aboutTeaser.innerHTML = `
    <div class="teaser-icon"><i data-lucide="info"></i></div>
    <div class="teaser-body">
      <h4>New here? About This Website</h4>
      <p>What this is, who made it, how the AI Tutor works, and the best way to study here — a 2-minute guide.</p>
    </div>
    <span class="teaser-cta">Learn more <i data-lucide="arrow-right"></i></span>
  `;
  aboutTeaser.style.marginTop = "28px";
  aboutTeaser.addEventListener("click", () => navigate("about"));
  root.appendChild(aboutTeaser);

  /* ---- 6. All chapters — supporting, browsable, below the fold ---- */
  root.appendChild(sectionTitle("All chapters"));
  const chGrid = el("div", "grid-4");
  APP_DATA.chapters.forEach(ch => {
    const progress = STATE.chapterProgress[ch.id] || 0;
    const card = el("div", "card liftable chapter-card ripple-surface");
    card.innerHTML = `
      <div class="ch-icon" style="background:var(--${CH_SOFT_BG[ch.id] || 'c-jr-soft'}); color:${ch.color};">
        <i data-lucide="${ch.icon}"></i>
      </div>
      <span class="ch-num">Chapter ${ch.num}</span>
      <h3>${ch.name}</h3>
      <p>${ch.tagline}</p>
      <div class="progress-track"><div class="progress-fill" data-target="${progress}" style="width:0%"></div></div>
      <span style="font-family:var(--font-mono); font-size:0.78rem; color:var(--ink-faint);">${progress}% complete</span>
      <button class="btn-primary sm ripple-surface" data-act="start" style="margin-top:12px; width:100%;">${progress > 0 ? "Continue" : "Start Learning"}</button>
    `;
    card.addEventListener("click", () => navigate(`ch-${ch.id}`));
    chGrid.appendChild(card);
  });
  root.appendChild(chGrid);

  /* ---- 7. Recent activity ---- */
  root.appendChild(sectionTitle("Recent activity"));
  const actCard = el("div", "card-solid", "");
  actCard.style.padding = "8px 20px";
  if (STATE.activityLog.length === 0) {
    actCard.innerHTML = `<p style="padding:16px 0; color:var(--ink-faint); font-size:0.87rem;">Nothing yet — solve a question or take a quiz to see your activity here.</p>`;
  } else {
    STATE.activityLog.forEach((a, i) => {
      const row = el("div", "");
      row.style.cssText = `padding:14px 0; ${i < STATE.activityLog.length-1 ? 'border-bottom:1px solid var(--line);' : ''} display:flex; justify-content:space-between; font-size:0.87rem;`;
      row.innerHTML = `<span>${a.text}</span><span style="color:var(--ink-faint); font-family:var(--font-mono); font-size:0.78rem;">${timeAgo(a.at)}</span>`;
      actCard.appendChild(row);
    });
  }
  root.appendChild(actCard);

  attachRipple(root);
  $("#continueBtn").addEventListener("click", () => navigate(overallPct >= 100 ? "exam-mode" : `ch-${contId}`));
}

function statCard(icon, label, value, sub) {
  const c = el("div", "card liftable stat-card");
  c.innerHTML = `
    <div class="icon-wrap"><i data-lucide="${icon}"></i></div>
    <div class="value">${value}</div>
    <div class="label">${label}</div>
    <div style="font-size:0.76rem; color:var(--ink-faint);">${sub}</div>
  `;
  return c;
}
function sectionTitle(text) {
  const s = el("div", "section-title", `<h2>${text}</h2>`);
  return s;
}

/* ---------------------------------------------------------
   2b. LEARNING JOURNEY STEPPER — shown at the top of every
   chapter page. Maps that chapter's tabs onto a shared
   Learn → Examples → Ask AI → Practice → Quiz → Mastery
   journey so students always know where they are and what's
   next, instead of a bare percentage.
   --------------------------------------------------------- */
const JOURNEY_STAGES = ["Learn", "Examples", "Ask AI", "Practice", "Quiz", "Mastery"];
const JOURNEY_TAB_MAP = {
  "Theory": 0, "Format": 0, "Introduction": 0,
  "Concepts": 1, "Mind Map": 1, "Common Mistakes": 1, "Full Balance Sheets": 1, "Posting Rules": 1,
  "Balance Verifier": 3, "Random Generator": 3, "Practice Bank": 3, "Quick Checks": 3,
  "Entry Generator": 3, "Ledger Posting": 3, "Practice": 3, "Balancing": 3,
  "Balance Sheet Qs": 1,
  "Journal → Ledger Practice": 3, "Balancing Accounts": 3,
  "Format & Rules": 1, "Illustrations": 3,
  "Exam Questions": 4, "Quick Revision": 5, "BRS Detective": 3, "GST Bill Detective": 3, "Depreciation Lab": 3, "Trial Balance Checkpoint": 3
};
function renderJourneyStepper(container, chId) {
  const stepper = el("div", "journey-stepper");
  stepper.id = `journey-${chId}`;
  container.appendChild(stepper);
  return stepper;
}
function updateJourneyStepper(stepperEl, chId, tabName) {
  if (!stepperEl) return;
  const progress = STATE.chapterProgress[chId] || 0;
  const activeIdx = JOURNEY_TAB_MAP[tabName] ?? 0;
  const masteryReached = progress >= 90;
  const parts = JOURNEY_STAGES.map((label, i) => {
    let state = "todo";
    if (i === 5) state = masteryReached ? "done" : (activeIdx >= 4 ? "current" : "todo");
    else if (i < activeIdx) state = "done";
    else if (i === activeIdx) state = "current";
    const dot = state === "done" ? `<i data-lucide="check"></i>` : (i + 1);
    return `<div class="journey-step js-${state}" title="${label}"><span class="js-dot">${dot}</span><span class="js-label">${label}</span></div>`;
  });
  stepperEl.innerHTML = parts.join(`<div class="js-connector"></div>`);
  icons();
}

/* Mobile "one question at a time" pager. Wraps whatever .q-card
   elements are already direct children of `panel` with a sticky
   progress bar + Prev/Next controls. On screens wider than 640px
   the pager bar is hidden and every card forced visible again by
   CSS, so this is a no-op on desktop regardless of when it runs. */
function applyMobilePager(panel) {
  const cards = Array.from(panel.children).filter(c => c.classList && c.classList.contains("q-card"));
  if (cards.length < 2) return;
  let current = 0;

  const bar = el("div", "q-pager-bar", "");
  const progressLabel = el("div", "q-pager-progress", `Question 1 of ${cards.length}`);
  const track = el("div", "q-pager-track", `<div class="q-pager-fill" style="width:${100/cards.length}%"></div>`);
  const controls = el("div", "q-pager-controls", "");
  const prevBtn = el("button", "btn-ghost sm ripple-surface", `<i data-lucide="chevron-left"></i> Prev`);
  const nextBtn = el("button", "btn-primary sm ripple-surface", `Next <i data-lucide="chevron-right"></i>`);
  controls.appendChild(prevBtn);
  controls.appendChild(nextBtn);
  bar.appendChild(progressLabel);
  bar.appendChild(track);
  bar.appendChild(controls);

  function show(i) {
    current = Math.max(0, Math.min(cards.length - 1, i));
    cards.forEach((c, idx) => c.classList.toggle("q-hidden", idx !== current));
    progressLabel.textContent = `Question ${current + 1} of ${cards.length}`;
    $(".q-pager-fill", track).style.width = `${((current + 1) / cards.length) * 100}%`;
    prevBtn.disabled = current === 0;
    nextBtn.innerHTML = current === cards.length - 1 ? `Done <i data-lucide="check"></i>` : `Next <i data-lucide="chevron-right"></i>`;
    icons();
    if (bar.scrollIntoView) bar.scrollIntoView({ block: "nearest", behavior: STATE.reduceMotion ? "auto" : "smooth" });
  }
  prevBtn.addEventListener("click", () => show(current - 1));
  nextBtn.addEventListener("click", () => { if (current < cards.length - 1) show(current + 1); });

  cards[0].parentNode.insertBefore(bar, cards[0]);
  show(0);
}

function formatSeconds(s) {
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60);
  if (h > 0) return `${h}h ${m}m`;
  return `${m}m`;
}
function timeAgo(ts) {
  const diff = Math.floor((Date.now() - ts) / 1000);
  if (diff < 60) return "just now";
  if (diff < 3600) return Math.floor(diff/60) + "m ago";
  if (diff < 86400) return Math.floor(diff/3600) + "h ago";
  return Math.floor(diff/86400) + "d ago";
}

/* ---------------------------------------------------------
   5b. MOBILE HUB PAGES
   These back the bottom-nav's Chapters / Practice / More tabs
   (and the Revision / Bookmarks pages reachable from More).
   They render on any screen size, but only the bottom nav
   itself is mobile-only — on desktop these are simply reached
   via the sidebar like any other page.
   --------------------------------------------------------- */
function buildHubCard(icon, title, desc, route, color) {
  const card = el("div", "card liftable ripple-surface hub-card");
  card.style.cssText = "padding:20px; display:flex; align-items:center; gap:16px; cursor:pointer; margin-bottom:14px;";
  card.innerHTML = `
    <div class="ch-icon" style="width:44px; height:44px; flex-shrink:0; background:${color}22; color:${color};">
      <i data-lucide="${icon}"></i>
    </div>
    <div style="flex:1; min-width:0;">
      <h3 style="font-size:1rem; margin-bottom:3px;">${title}</h3>
      <p style="font-size:0.84rem; color:var(--ink-soft); line-height:1.45; margin:0;">${desc}</p>
    </div>
    <i data-lucide="chevron-right" style="color:var(--ink-faint); width:18px; height:18px; flex-shrink:0;"></i>
  `;
  card.addEventListener("click", () => navigate(route));
  return card;
}

function renderChaptersList(root) {
  root.appendChild(sectionTitle("Chapters"));
  const hint = el("p", "", "Pick a chapter to open its notes, mind map, and practice bank.");
  hint.style.cssText = "font-size:0.85rem; color:var(--ink-faint); margin:-8px 0 18px;";
  root.appendChild(hint);

  const chGrid = el("div", "grid-4");
  const CH_SOFT_BG = { eq: "c-eq-soft", dc: "c-dc-soft", jr: "c-jr-soft", lg: "c-lg-soft", cb: "c-cb-soft", sp2: "c-sp2-soft", brs: "c-brs-soft", gst: "c-gst-soft", tb: "c-tb-soft", dep: "c-dep-soft" };
  APP_DATA.chapters.forEach(ch => {
    const progress = STATE.chapterProgress[ch.id] || 0;
    const card = el("div", "card liftable chapter-card ripple-surface");
    card.innerHTML = `
      <div class="ch-icon" style="background:var(--${CH_SOFT_BG[ch.id] || 'c-jr-soft'}); color:${ch.color};">
        <i data-lucide="${ch.icon}"></i>
      </div>
      <span class="ch-num">Chapter ${ch.num}</span>
      <h3>${ch.name}</h3>
      <p>${ch.tagline}</p>
      <div class="progress-track"><div class="progress-fill" data-target="${progress}" style="width:0%"></div></div>
      <span style="font-family:var(--font-mono); font-size:0.78rem; color:var(--ink-faint);">${progress}% complete</span>
      <button class="btn-primary sm ripple-surface" data-act="start" style="margin-top:12px; width:100%;">Start Learning</button>
    `;
    card.addEventListener("click", () => navigate(`ch-${ch.id}`));
    chGrid.appendChild(card);
  });
  root.appendChild(chGrid);
  attachRipple(root);
}

const CH_FULL_NAME = { eq: "Accounting Equation", dc: "Debit & Credit", jr: "Journal", lg: "Ledger", cb: "Special Purpose Books 1 - Cash Book", sp2: "Special Purpose Books 2 - Other Books", brs: "Bank Reconciliation Statement (BRS)", gst: "Accounting of GST", tb: "Trial Balance", dep: "Depreciation" };
const MISTAKE_MASTERY_STREAK = 2; // correct attempts in a row (after a mistake) needed to reach "Mastered"

/* Records (or updates) a Mistake Book entry for a genuinely wrong
   Practice/Quiz attempt. Never call this speculatively — only from a
   real graded answer-check where the student was actually incorrect. */
function mistakeBookRecord(opts) {
  const now = Date.now();
  let rec = STATE.mistakeBook[opts.key];
  if (!rec) {
    rec = {
      key: opts.key, question: opts.question, chapter: opts.chapter, chapterLabel: opts.chapterLabel,
      topic: opts.topic || opts.chapterLabel, type: opts.type,
      firstMistakeAt: now, mistakeCount: 0, correctAfterMistakeCount: 0, correctStreak: 0
    };
    STATE.mistakeBook[opts.key] = rec;
  }
  rec.studentAnswer = opts.studentAnswer;
  rec.correctAnswer = opts.correctAnswer;
  rec.explanation = opts.explanation;
  rec.lastAttemptAt = now;
  rec.mistakeCount += 1;
  rec.correctStreak = 0;
  rec.status = "review";
  if (!STATE.mistakes.includes(opts.key)) STATE.mistakes.push(opts.key); // legacy compatibility
  saveState();
}

/* Records a correct attempt against an *existing* mistake (from either
   the original practice widget or a Mistake Book review session). A
   no-op if this question was never actually a recorded mistake. */
function mistakeBookRecordCorrect(key) {
  const rec = STATE.mistakeBook[key];
  if (!rec) return false;
  rec.lastAttemptAt = Date.now();
  rec.correctAfterMistakeCount = (rec.correctAfterMistakeCount || 0) + 1;
  rec.correctStreak = (rec.correctStreak || 0) + 1;
  rec.status = rec.correctStreak >= MISTAKE_MASTERY_STREAK ? "mastered" : "improved";
  saveState();
  return true;
}

/* Resolves a Mistake Book key back to the original question object and
   the accounts pool it needs (for the Ledger Posting picker), so a
   review session can present the exact same real question again —
   never a fabricated one. */
function resolveMistakeQuestion(rec) {
  if (rec.type === "Ledger Posting") {
    const id = parseInt(rec.key.slice(3), 10);
    const pool = getLedgerPracticePool();
    const q = pool.find(x => x.id === id);
    if (q) return { kind: "ledger", q, accountPool: [...new Set(pool.flatMap(p => [p.debitAccount, p.creditAccount]))] };
  }
  if (rec.type === "Quiz MCQ") {
    const id = parseInt(rec.key.slice(5), 10);
    const q = APP_DATA.quiz.find(x => x.id === id);
    if (q) return { kind: "quiz", q };
  }
  return null;
}

/* ---------------------------------------------------------
   MISTAKE BOOK — lives inside the Practice tab. Reads and
   writes STATE.mistakeBook only; never touches the practice
   widgets it draws its records from beyond what was added
   above (mistakeBookRecord / mistakeBookRecordCorrect).
   --------------------------------------------------------- */
let mbFilterStatus = "all";     // all | review | improved | mastered
let mbFilterChapter = "all";
let mbFilterType = "all";
let mbSearchTerm = "";
let mbSelected = new Set();

const MB_STATUS_META = {
  review: { label: "Needs Review", dot: "🟠", color: "var(--flag)" },
  improved: { label: "Improved", dot: "🟢", color: "var(--c-eq)" },
  mastered: { label: "Mastered", dot: "🔵", color: "var(--c-dc)" }
};

function mbRecords() {
  return Object.values(STATE.mistakeBook || {});
}

function renderMistakeBook(root) {
  mbSelected = new Set();
  root.appendChild(sectionTitle("Mistake Book"));
  const hint = el("p", "", "Every question you've answered incorrectly in Practice or Quiz lands here automatically — review it, try again, and it's marked Mastered once you've shown you've got it.");
  hint.style.cssText = "font-size:0.85rem; color:var(--ink-faint); margin:-8px 0 18px;";
  root.appendChild(hint);

  const body = el("div", "");
  root.appendChild(body);

  function renderBody() {
    body.innerHTML = "";
    const all = mbRecords();

    /* ---- stats ---- */
    const total = all.length;
    const unreviewed = all.filter(m => m.status === "review").length;
    const mastered = all.filter(m => m.status === "mastered").length;
    const topicCounts = {};
    all.forEach(m => { topicCounts[m.topic] = (topicCounts[m.topic] || 0) + m.mistakeCount; });
    const topTopic = Object.entries(topicCounts).sort((a, b) => b[1] - a[1])[0];

    const stats = el("div", "mb-stats");
    stats.innerHTML = `
      <div class="mb-stat"><span class="mb-stat-num tnum">${total}</span><span class="mb-stat-label">Total Mistakes</span></div>
      <div class="mb-stat"><span class="mb-stat-num tnum" style="color:var(--flag);">${unreviewed}</span><span class="mb-stat-label">Unreviewed</span></div>
      <div class="mb-stat"><span class="mb-stat-num tnum" style="color:var(--c-dc);">${mastered}</span><span class="mb-stat-label">Mastered</span></div>
      <div class="mb-stat"><span class="mb-stat-num" style="font-size:0.95rem;">${topTopic ? topTopic[0] : "—"}</span><span class="mb-stat-label">Most Mistaken Topic</span></div>
    `;
    body.appendChild(stats);

    if (!total) {
      const empty = el("div", "card-solid", "");
      empty.style.cssText = "padding:36px; text-align:center; color:var(--ink-faint); margin-top:18px;";
      empty.innerHTML = `<i data-lucide="brain" style="width:32px; height:32px; margin-bottom:10px;"></i><p style="font-size:0.9rem;">No mistakes recorded yet — nice! Answer questions in the Ledger practice or Quiz and anything you get wrong will show up here for revision.</p>`;
      body.appendChild(empty);
      icons();
      return;
    }

    /* ---- search ---- */
    const searchWrap = el("div", "");
    searchWrap.style.cssText = "margin:18px 0 12px; position:relative;";
    searchWrap.innerHTML = `<input type="text" id="mbSearchInput" placeholder="Search by question, chapter, or topic..." class="mb-search-input" value="${mbSearchTerm.replace(/"/g, "&quot;")}">`;
    body.appendChild(searchWrap);
    $("#mbSearchInput", searchWrap).addEventListener("input", (e) => { mbSearchTerm = e.target.value; renderList(); });

    /* ---- filters ---- */
    const filterBar = el("div", "");
    filterBar.style.cssText = "display:flex; gap:8px; flex-wrap:wrap; margin-bottom:10px;";
    [["all", "All Mistakes"], ["review", "Needs Review"], ["improved", "Improved"], ["mastered", "Mastered"]].forEach(([id, label]) => {
      const chip = el("button", `chip ${mbFilterStatus === id ? "active" : ""}`, label);
      chip.addEventListener("click", () => { mbFilterStatus = id; renderBody(); });
      filterBar.appendChild(chip);
    });
    body.appendChild(filterBar);

    const chapters = [...new Set(all.map(m => m.chapter))];
    const types = [...new Set(all.map(m => m.type))];
    if (chapters.length > 1 || types.length > 1) {
      const filterBar2 = el("div", "");
      filterBar2.style.cssText = "display:flex; gap:8px; flex-wrap:wrap; margin-bottom:18px;";
      const chSel = el("select", "mb-select");
      chSel.innerHTML = `<option value="all">All Chapters</option>` + chapters.map(c => `<option value="${c}" ${mbFilterChapter === c ? "selected" : ""}>${CH_FULL_NAME[c] || c}</option>`).join("");
      chSel.addEventListener("change", () => { mbFilterChapter = chSel.value; renderBody(); });
      filterBar2.appendChild(chSel);
      const typeSel = el("select", "mb-select");
      typeSel.innerHTML = `<option value="all">All Types</option>` + types.map(t => `<option value="${t}" ${mbFilterType === t ? "selected" : ""}>${t}</option>`).join("");
      typeSel.addEventListener("change", () => { mbFilterType = typeSel.value; renderBody(); });
      filterBar2.appendChild(typeSel);
      body.appendChild(filterBar2);
    }

    /* ---- bulk action bar ---- */
    const bulkBar = el("div", "mb-bulk-bar");
    bulkBar.innerHTML = `
      <button class="btn-ghost sm ripple-surface" id="mbPracticeAll"><i data-lucide="play"></i> Practice All</button>
      <button class="btn-primary sm ripple-surface" id="mbPracticeSelected" disabled><i data-lucide="target"></i> Practice Selected (<span id="mbSelCount">0</span>)</button>
      <button class="btn-ghost sm ripple-surface" id="mbRemoveSelected" disabled style="color:var(--flag);"><i data-lucide="trash-2"></i> Remove Selected</button>
      <button class="btn-ghost sm ripple-surface" id="mbClearAll" style="margin-left:auto; color:var(--flag);"><i data-lucide="trash"></i> Clear All</button>
    `;
    body.appendChild(bulkBar);

    const listWrap = el("div", "mb-list");
    body.appendChild(listWrap);

    function updateBulkBar() {
      $("#mbSelCount", bulkBar).textContent = mbSelected.size;
      $("#mbPracticeSelected", bulkBar).disabled = mbSelected.size === 0;
      $("#mbRemoveSelected", bulkBar).disabled = mbSelected.size === 0;
    }

    function renderList() {
      listWrap.innerHTML = "";
      const term = mbSearchTerm.trim().toLowerCase();
      const filtered = all
        .filter(m => mbFilterStatus === "all" || m.status === mbFilterStatus)
        .filter(m => mbFilterChapter === "all" || m.chapter === mbFilterChapter)
        .filter(m => mbFilterType === "all" || m.type === mbFilterType)
        .filter(m => !term || m.question.toLowerCase().includes(term) || (m.chapterLabel || "").toLowerCase().includes(term) || (m.topic || "").toLowerCase().includes(term))
        .sort((a, b) => b.lastAttemptAt - a.lastAttemptAt);

      if (!filtered.length) {
        listWrap.innerHTML = `<p style="color:var(--ink-faint); font-size:0.87rem; padding:18px 0;">No mistakes match this filter.</p>`;
        icons();
        return;
      }

      filtered.forEach(m => listWrap.appendChild(buildMistakeCard(m)));
      icons();
    }

    function buildMistakeCard(m) {
      const meta = MB_STATUS_META[m.status] || MB_STATUS_META.review;
      const card = el("div", "card mb-card");
      card.innerHTML = `
        <div class="mb-card-top">
          <label class="mb-check"><input type="checkbox" data-key="${m.key}" ${mbSelected.has(m.key) ? "checked" : ""}></label>
          <span class="diff-badge" style="background:var(--gold-soft); color:var(--gold);">${m.chapterLabel || m.chapter} · ${m.topic}</span>
          <span class="mb-status" style="margin-left:auto; color:${meta.color};">${meta.dot} ${meta.label}</span>
        </div>
        <div class="q-body" style="margin-top:10px;">${m.question}</div>
        <div class="mb-answer-grid">
          <div><span class="mb-answer-label">Your Answer</span><p class="mb-answer-val wrong">${m.studentAnswer}</p></div>
          <div><span class="mb-answer-label">Correct Answer</span><p class="mb-answer-val right">${m.correctAnswer}</p></div>
        </div>
        <div class="reveal-block" style="margin-top:10px;"><p style="font-size:0.85rem; line-height:1.55;">${m.explanation || "Review the correct answer above and compare it with what you chose."}</p></div>
        <div class="mb-card-footer">
          <span><i data-lucide="repeat" style="width:13px;height:13px;"></i> Missed ${m.mistakeCount}×</span>
          <span><i data-lucide="clock" style="width:13px;height:13px;"></i> ${timeAgo(m.lastAttemptAt)}</span>
        </div>
        <div class="q-actions" style="margin-top:12px;">
          <button class="btn-primary sm ripple-surface" data-act="review"><i data-lucide="refresh-cw"></i> Review</button>
          <button class="btn-ghost sm ripple-surface" data-act="remove" style="color:var(--flag);"><i data-lucide="x"></i> Remove</button>
        </div>
        <div class="mb-review-area"></div>
      `;
      card.addEventListener("change", (e) => {
        if (e.target.matches("input[type=checkbox]")) {
          if (e.target.checked) mbSelected.add(m.key); else mbSelected.delete(m.key);
          updateBulkBar();
        }
      });
      card.addEventListener("click", (e) => {
        const btn = e.target.closest("button[data-act]");
        if (!btn) return;
        if (btn.dataset.act === "remove") {
          delete STATE.mistakeBook[m.key];
          const idx = STATE.mistakes.indexOf(m.key);
          if (idx >= 0) STATE.mistakes.splice(idx, 1);
          saveState();
          renderBody();
          toast("Removed from Mistake Book", "success", "trash-2");
        }
        if (btn.dataset.act === "review") {
          const area = $(".mb-review-area", card);
          if (area.childElementCount) { area.innerHTML = ""; return; }
          renderReviewSession([m.key], area, () => { renderBody(); });
        }
      });
      return card;
    }

    $("#mbPracticeAll", bulkBar).addEventListener("click", () => {
      const keys = mbRecords().filter(m => mbFilterStatus === "all" || m.status === mbFilterStatus).map(m => m.key);
      if (!keys.length) { toast("No mistakes to practice.", "success", "info"); return; }
      openPracticeSessionOverlay(keys, () => renderBody());
    });
    $("#mbPracticeSelected", bulkBar).addEventListener("click", () => {
      if (!mbSelected.size) return;
      openPracticeSessionOverlay([...mbSelected], () => renderBody());
    });
    $("#mbRemoveSelected", bulkBar).addEventListener("click", () => {
      if (!mbSelected.size) return;
      if (!confirm(`Remove ${mbSelected.size} selected mistake${mbSelected.size === 1 ? "" : "s"} from your Mistake Book?`)) return;
      mbSelected.forEach(k => {
        delete STATE.mistakeBook[k];
        const idx = STATE.mistakes.indexOf(k);
        if (idx >= 0) STATE.mistakes.splice(idx, 1);
      });
      saveState();
      renderBody();
      toast("Selected mistakes removed", "success", "trash-2");
    });
    $("#mbClearAll", bulkBar).addEventListener("click", () => {
      if (!confirm("Clear your ENTIRE Mistake Book? This can't be undone.")) return;
      STATE.mistakeBook = {};
      STATE.mistakes = [];
      saveState();
      renderBody();
      toast("Mistake Book cleared", "success", "trash");
    });

    renderList();
    updateBulkBar();
  }

  renderBody();
  icons();
}

/* Renders a self-contained re-attempt UI for the given mistake keys,
   directly inside `container` (used for a single "Review" card). Each
   question is the real original question (via resolveMistakeQuestion) —
   never a fabricated one. onDone fires once every question in the
   batch has been attempted, so the caller can refresh counts/status. */
function renderReviewSession(keys, container, onDone) {
  let idx = 0;
  let fixedCount = 0;
  const total = keys.length;

  function next() {
    if (idx >= keys.length) {
      container.innerHTML = `<div class="reveal-block" style="margin-top:10px;"><h4>Session complete</h4><p style="font-size:0.87rem;">You corrected ${fixedCount} of ${total} mistake${total === 1 ? "" : "s"}.</p></div>`;
      icons();
      if (onDone) onDone();
      return;
    }
    const key = keys[idx];
    const rec = STATE.mistakeBook[key];
    if (!rec) { idx++; next(); return; }
    const resolved = resolveMistakeQuestion(rec);
    container.innerHTML = "";
    const wrap = el("div", "mb-review-inline");
    if (total > 1) wrap.appendChild(el("p", "", `Question ${idx + 1} of ${total}`));
    if (!resolved) {
      wrap.innerHTML += `<div class="reveal-block"><p style="font-size:0.86rem;">This question type can't be re-attempted interactively here — but here's the correct answer again: <b>${rec.correctAnswer}</b>. ${rec.explanation || ""}</p></div>
        <div class="q-actions" style="margin-top:10px;"><button class="btn-primary sm ripple-surface" data-act="ok">Got it</button></div>`;
      container.appendChild(wrap);
      $("button[data-act='ok']", wrap).addEventListener("click", () => { idx++; next(); });
      icons();
      return;
    }
    if (resolved.kind === "ledger") {
      const q = resolved.q;
      const options = accs => { const d = resolved.accountPool.filter(a => a !== accs); for (let i = d.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [d[i], d[j]] = [d[j], d[i]]; } return [accs, ...d.slice(0, 3)].sort(() => Math.random() - 0.5); };
      const debitOptions = options(q.debitAccount), creditOptions = options(q.creditAccount);
      let picked = { debit: null, credit: null };
      wrap.innerHTML += `
        <div class="q-body tnum" style="font-size:0.9rem; background:var(--line); padding:12px; border-radius:10px;">${q.transaction}</div>
        <p style="font-size:0.78rem; text-transform:uppercase; color:var(--ink-faint); margin:12px 0 6px;">Debited?</p>
        <div class="opt-group" data-role="debit" style="display:flex; flex-wrap:wrap; gap:8px;">${debitOptions.map(o => `<button class="chip" data-val="${o}">${o}</button>`).join("")}</div>
        <p style="font-size:0.78rem; text-transform:uppercase; color:var(--ink-faint); margin:12px 0 6px;">Credited?</p>
        <div class="opt-group" data-role="credit" style="display:flex; flex-wrap:wrap; gap:8px;">${creditOptions.map(o => `<button class="chip" data-val="${o}">${o}</button>`).join("")}</div>
        <div class="q-actions" style="margin-top:12px;"><button class="btn-primary sm ripple-surface" data-act="check">Check</button></div>
        <div class="reveal-area"></div>
      `;
      container.appendChild(wrap);
      wrap.addEventListener("click", (e) => {
        const optBtn = e.target.closest(".opt-group button[data-val]");
        if (optBtn) {
          const group = optBtn.closest(".opt-group");
          $all("button", group).forEach(b => b.classList.remove("active"));
          optBtn.classList.add("active");
          picked[group.dataset.role] = optBtn.dataset.val;
          return;
        }
        if (e.target.closest("button[data-act='check']")) {
          if (!picked.debit || !picked.credit) return;
          const correct = picked.debit === q.debitAccount && picked.credit === q.creditAccount;
          const revealArea = $(".reveal-area", wrap);
          if (correct) {
            fixedCount++;
            mistakeBookRecordCorrect(key);
            revealArea.innerHTML = `<div class="reveal-block"><h4>Correct!</h4><p style="font-size:0.86rem;">${q.explanation}</p></div>`;
          } else {
            mistakeBookRecord({ key, question: q.transaction, chapter: "lg", chapterLabel: "Ledger", topic: "Journal → Ledger Posting", type: "Ledger Posting", studentAnswer: `Debit: ${picked.debit} · Credit: ${picked.credit}`, correctAnswer: `Debit: ${q.debitAccount} · Credit: ${q.creditAccount}`, explanation: q.explanation });
            revealArea.innerHTML = `<div class="reveal-block" style="background:var(--flag-soft); border-left-color:var(--flag);"><h4>Still not quite</h4><p style="font-size:0.86rem;">Correct: <b>${q.debitAccount}</b> debited, <b>${q.creditAccount}</b> credited. ${q.explanation}</p></div>`;
          }
          revealArea.innerHTML += `<div class="q-actions" style="margin-top:10px;"><button class="btn-primary sm ripple-surface" data-act="next">${idx + 1 < total ? "Next" : "Finish"}</button></div>`;
          icons();
          $("button[data-act='next']", revealArea).addEventListener("click", () => { idx++; next(); });
        }
      });
    } else if (resolved.kind === "quiz") {
      const q = resolved.q;
      wrap.innerHTML += `<div class="card-solid" style="padding:20px;"><h3 style="font-size:0.98rem; margin-bottom:14px;">${q.q}</h3><div id="mbQuizOpts"></div><div id="mbQuizFeedback" style="margin-top:12px;"></div></div>`;
      container.appendChild(wrap);
      const optWrap = $("#mbQuizOpts", wrap);
      q.options.forEach((opt, i) => {
        const b = el("button", "chip ripple-surface", opt);
        b.style.cssText = "display:block; width:100%; text-align:left; margin-bottom:8px; padding:12px 14px; border-radius:12px;";
        b.addEventListener("click", () => {
          $all("button", optWrap).forEach(x => x.disabled = true);
          const correct = i === q.answerIndex;
          if (correct) { fixedCount++; mistakeBookRecordCorrect(key); b.style.borderColor = "var(--c-eq)"; b.style.background = "var(--c-eq-soft)"; }
          else {
            mistakeBookRecord({ key, question: q.q, chapter: q.chapter, chapterLabel: CH_FULL_NAME[q.chapter] || q.chapter, topic: CH_FULL_NAME[q.chapter] || q.chapter, type: "Quiz MCQ", studentAnswer: q.options[i], correctAnswer: q.options[q.answerIndex], explanation: q.explanation });
            b.style.borderColor = "var(--flag)"; b.style.background = "var(--flag-soft)";
          }
          const fb = $("#mbQuizFeedback", wrap);
          fb.innerHTML = `<div class="reveal-block" style="${correct ? "" : "background:var(--flag-soft); border-left-color:var(--flag);"}"><h4>${correct ? "Correct" : "Not quite"}</h4><p style="font-size:0.86rem;">${q.explanation}</p></div><div class="q-actions" style="margin-top:10px;"><button class="btn-primary sm ripple-surface" data-act="next">${idx + 1 < total ? "Next" : "Finish"}</button></div>`;
          icons();
          $("button[data-act='next']", fb).addEventListener("click", () => { idx++; next(); });
        });
        optWrap.appendChild(b);
      });
    }
    icons();
  }
  next();
}

/* Practice-Again for "Practice All" / "Practice Selected" — a small
   full-width session panel above the list, reusing renderReviewSession
   for the actual question-by-question logic. */
function openPracticeSessionOverlay(keys, onDone) {
  const existing = $("#mbSessionPanel");
  if (existing) existing.remove();
  const panel = el("div", "card-solid mb-session-panel", "");
  panel.id = "mbSessionPanel";
  panel.style.cssText = "padding:22px; margin-bottom:20px;";
  const header = el("div", "", `<h3 style="font-size:1rem; margin-bottom:12px;">Practice session — ${keys.length} question${keys.length === 1 ? "" : "s"}</h3>`);
  panel.appendChild(header);
  const area = el("div", "");
  panel.appendChild(area);
  const body = $(".mb-list")?.parentElement || document.querySelector(".view-root");
  body.insertBefore(panel, body.firstChild.nextSibling);
  panel.scrollIntoView({ behavior: STATE.reduceMotion ? "auto" : "smooth", block: "start" });
  renderReviewSession(keys, area, () => { onDone && onDone(); setTimeout(() => panel.remove(), 1800); });
}

function renderPracticeHub(root) {
  root.appendChild(sectionTitle("Practice"));
  const hint = el("p", "", "Every practice tool in one place. Pick a chapter to learn from the Chapters tab — this is where you drill.");
  hint.style.cssText = "font-size:0.85rem; color:var(--ink-faint); margin:-8px 0 18px;";
  root.appendChild(hint);

  const mistakeCount = Object.keys(STATE.mistakeBook || {}).filter(k => STATE.mistakeBook[k].status !== "mastered").length;
  const mistakeCard = buildHubCard("brain", "Mistake Book", mistakeCount
    ? `${mistakeCount} question${mistakeCount === 1 ? "" : "s"} waiting for review.`
    : "Questions you get wrong are saved here automatically for revision.", "mistake-book", "var(--flag)");
  if (mistakeCount) {
    const badge = el("span", "", String(mistakeCount));
    badge.style.cssText = "flex-shrink:0; background:var(--flag); color:#fff; font-size:0.72rem; font-weight:700; min-width:20px; height:20px; border-radius:999px; display:flex; align-items:center; justify-content:center; padding:0 6px;";
    mistakeCard.insertBefore(badge, mistakeCard.lastElementChild);
  }
  root.appendChild(mistakeCard);
  root.appendChild(buildHubCard("help-circle", "Quiz", "Rapid-fire multiple choice across every chapter.", "quiz", "var(--c-eq)"));
  root.appendChild(buildHubCard("layers", "Flashcards", "Flip through key terms and rules.", "flashcards", "var(--c-dc)"));
  root.appendChild(buildHubCard("calculator", "Numerical Practice", "Solve accounting numericals with instant checking.", "numerical-solver", "var(--c-jr)"));
  root.appendChild(buildHubCard("star", "Important Questions", "Board-style questions worth extra revision time.", "important-questions", "var(--gold)"));
  root.appendChild(buildHubCard("scroll-text", "Formula Sheet", "Every rule and formula on one printable page.", "formula-sheet", "var(--c-lg)"));
  root.appendChild(buildHubCard("zap", "Revision", "A fast-track hub for last-minute review.", "revision", "var(--flag)"));
  root.appendChild(buildHubCard("bookmark", "Bookmarks", "Everything you've saved for later, in one place.", "bookmarks", "var(--c-eq)"));
  root.appendChild(buildHubCard("timer", "Exam Mode", "A timed, distraction-free mixed paper across all chapters.", "exam-mode", "var(--ink-soft)"));
  attachRipple(root);
}

function renderMoreHub(root) {
  root.appendChild(sectionTitle("More"));
  const hint = el("p", "", "Theme, data, and study preferences.");
  hint.style.cssText = "font-size:0.85rem; color:var(--ink-faint); margin:-8px 0 18px;";
  root.appendChild(hint);

  root.appendChild(buildHubCard("bot", "AI Tutor", "Ask questions, get step-by-step help, and check your answers.", "ai-tutor", "var(--gold)"));
  root.appendChild(buildHubCard("info", "About This Website", "What this is, who made it, and how to get the most out of it.", "about", "var(--c-jr)"));
  root.appendChild(buildHubCard("settings", "Settings", "Theme, data, and study preferences.", "settings", "var(--ink-soft)"));

  root.appendChild(sectionTitle("Study tools"));
  const toolsGrid = el("div", "qa-grid");
  [
    { icon: "calculator", label: "Calculator", id: "floatingCalcToggle" },
    { icon: "notebook-pen", label: "Scratch Pad", id: "scratchPadToggle" },
    { icon: "timer", label: "Pomodoro", id: "pomodoroToggle" },
    { icon: "layout-dashboard", label: "Whiteboard", id: "whiteboardToggle" },
    { icon: "maximize", label: "Fullscreen", id: "fullscreenToggle" },
  ].forEach(t => {
    const b = el("button", "qa-btn ripple-surface", `<i data-lucide="${t.icon}"></i><span>${t.label}</span>`);
    b.addEventListener("click", () => { const src = document.getElementById(t.id); if (src) src.click(); });
    toolsGrid.appendChild(b);
  });
  root.appendChild(toolsGrid);

  attachRipple(root);
}

function renderRevisionHub(root) {
  root.appendChild(sectionTitle("Revision"));
  const hint = el("p", "", "A fast-track set of links for the day before an exam.");
  hint.style.cssText = "font-size:0.85rem; color:var(--ink-faint); margin:-8px 0 18px;";
  root.appendChild(hint);

  root.appendChild(buildHubCard("scroll-text", "Formula Sheet", "Every rule and formula across all ten chapters.", "formula-sheet", "var(--c-lg)"));
  root.appendChild(buildHubCard("book-marked", "Ledger Quick Revision", "Definition, posting rules, balancing steps, and a mnemonic.", "ch-lg", "var(--c-lg)"));
  root.appendChild(buildHubCard("wallet", "Cash Book Quick Revision", "Definition, key points, balancing steps, and common mistakes.", "ch-cb", "var(--c-cb)"));
  root.appendChild(buildHubCard("star", "Important Questions", "Board-style questions worth extra revision time.", "important-questions", "var(--gold)"));
  root.appendChild(buildHubCard("timer", "Exam Mode", "A timed, distraction-free mixed paper across all chapters.", "exam-mode", "var(--flag)"));
  root.appendChild(buildHubCard("bookmark", "Bookmarks", "Everything you've flagged for a second look.", "bookmarks", "var(--c-eq)"));
  attachRipple(root);
}
routes["revision"] = renderRevisionHub;
ROUTE_TITLES["revision"] = "Revision";

/* ---- Bookmarks page — resolves every bookmark key format used
   across the site (chapter practice banks, DC balance-sheet
   questions, Ledger exam questions, Important Questions) back
   to its original question. ---- */
function resolveBookmark(key) {
  const CH_LABEL = { eq: "Ch.1 · Accounting Equation", dc: "Ch.2 · Debit & Credit", "dc-bs": "Ch.2 · Balance Sheet Qs", jr: "Ch.3 · Journal", lg: "Ch.4 · Ledger", cb: "Ch.5 · Cash Book", sp2: "Ch.6 · Special Purpose Books 2", brs: "Ch.7 · Bank Reconciliation Statement", gst: "Ch.8 · Accounting of GST", tb: "Ch.9 · Trial Balance", dep: "Ch.10 · Depreciation" };
  if (key.startsWith("iq-")) {
    const parts = key.slice(3).split("-");
    const chapter = parts[0], idx = parseInt(parts[1], 10);
    const q = (APP_DATA.importantQuestions[chapter] || [])[idx];
    if (q) return { title: q.q, sub: `${CH_LABEL[chapter] || chapter} · Important Question`, route: "important-questions", body: q.answer };
  }
  if (key.startsWith("lg-exam-")) {
    const m = key.match(/^lg-exam-(easy|medium|hard)-(\d+)$/);
    if (m) {
      const q = (APP_DATA.ledger.examQuestions[m[1]] || [])[parseInt(m[2], 10)];
      if (q) return { title: q.q, sub: "Ch.4 · Exam Question", route: "ch-lg", body: q.a };
    }
  }
  if (key.startsWith("dc-bs-")) {
    const id = parseInt(key.slice(6), 10);
    const q = (APP_DATA.debitCredit.balanceSheetQuestions || []).find(x => x.id === id);
    if (q) return { title: q.transaction || `Balance sheet question ${id}`, sub: CH_LABEL["dc-bs"], route: "ch-dc", body: q.explanation || "" };
  }
  if (key.startsWith("eq-")) {
    const q = APP_DATA.equation.numericals.find(x => x.id === parseInt(key.slice(3), 10));
    if (q) return { title: q.transaction, sub: CH_LABEL.eq, route: "ch-eq", body: q.explanation || "" };
  }
  if (key.startsWith("dc-")) {
    const q = APP_DATA.debitCredit.numericals.find(x => x.id === parseInt(key.slice(3), 10));
    if (q) return { title: q.transaction, sub: CH_LABEL.dc, route: "ch-dc", body: q.explanation || "" };
  }
  if (key.startsWith("jr-")) {
    const q = APP_DATA.journal.numericals.find(x => x.id === parseInt(key.slice(3), 10));
    if (q) return { title: q.transaction, sub: CH_LABEL.jr, route: "ch-jr", body: q.explanation || "" };
  }
  return null;
}

function renderBookmarks(root) {
  root.appendChild(sectionTitle("Bookmarks"));
  const hint = el("p", "", "Everything you've tapped the bookmark icon on, across every chapter and question bank.");
  hint.style.cssText = "font-size:0.85rem; color:var(--ink-faint); margin:-8px 0 18px;";
  root.appendChild(hint);

  if (!STATE.bookmarks.length) {
    const empty = el("div", "card-solid", "");
    empty.style.cssText = "padding:32px; text-align:center; color:var(--ink-faint);";
    empty.innerHTML = `<i data-lucide="bookmark" style="width:32px; height:32px; margin-bottom:10px;"></i><p style="font-size:0.9rem;">No bookmarks yet. Look for the bookmark icon on any question card.</p>`;
    root.appendChild(empty);
    icons();
    return;
  }

  STATE.bookmarks.slice().reverse().forEach(key => {
    const resolved = resolveBookmark(key);
    const card = el("div", "card q-card", "");
    if (!resolved) {
      card.innerHTML = `<div class="q-body" style="color:var(--ink-faint); font-size:0.85rem;">A saved bookmark from an older version of this question bank (${key}).</div>`;
    } else {
      card.innerHTML = `
        <div class="q-meta">
          <span class="diff-badge" style="background:var(--gold-soft); color:var(--gold);">${resolved.sub}</span>
          <button class="icon-btn sm" data-act="unbookmark" style="margin-left:auto;" title="Remove bookmark"><i data-lucide="bookmark-check"></i></button>
        </div>
        <div class="q-body">${resolved.title}</div>
        ${resolved.body ? `<div class="reveal-block" style="margin-top:12px;"><p style="font-size:0.85rem; line-height:1.55;">${resolved.body}</p></div>` : ""}
        <div class="q-actions" style="margin-top:14px;">
          <button class="btn-ghost sm ripple-surface" data-act="goto"><i data-lucide="arrow-right"></i> Open chapter</button>
        </div>
      `;
      card.addEventListener("click", (e) => {
        const btn = e.target.closest("button[data-act]");
        if (!btn) return;
        if (btn.dataset.act === "goto") navigate(resolved.route);
        if (btn.dataset.act === "unbookmark") {
          const idx = STATE.bookmarks.indexOf(key);
          if (idx >= 0) STATE.bookmarks.splice(idx, 1);
          saveState();
          card.remove();
          if (!STATE.bookmarks.length) { root.innerHTML = ""; renderBookmarks(root); }
        }
      });
    }
    root.appendChild(card);
  });
  attachRipple(root);
  icons();
}

/* ---------------------------------------------------------
   6. CHAPTER 1 — ACCOUNTING EQUATION (full build)
   --------------------------------------------------------- */
let eqFilterDifficulty = "All";
let eqCurrentIndex = 0;

function renderEquationChapter(root) {
  const data = APP_DATA.equation;

  root.appendChild(el("div", "hero", `
    <span class="hero-eyebrow">Chapter 1</span>
    <h1>The Accounting Equation</h1>
    <p>${APP_DATA.chapters[0].tagline}. Master the theory below, then drill it with 84 original practice problems and the live balance verifier.</p>
  `));

  const journeyEl = renderJourneyStepper(root, "eq");

  // Tabs
  const tabs = ["Theory", "Concepts", "Mind Map", "Balance Verifier", "Random Generator", "Practice Bank"];
  const tabBar = el("div", "", "");
  tabBar.style.cssText = "display:flex; gap:8px; flex-wrap:wrap; margin-bottom:22px;";
  tabs.forEach((t, i) => {
    const chip = el("button", `chip ${i===0?'active':''}`, t);
    chip.dataset.tab = t;
    tabBar.appendChild(chip);
  });
  root.appendChild(tabBar);

  const panel = el("div", "");
  root.appendChild(panel);

  function showTab(name) {
    $all(".chip", tabBar).forEach(c => c.classList.toggle("active", c.dataset.tab === name));
    panel.innerHTML = "";
    updateJourneyStepper(journeyEl, "eq", name);
    if (name === "Theory") renderEqTheory(panel, data);
    if (name === "Concepts") renderEqConcepts(panel, data);
    if (name === "Mind Map") renderMindMap(panel, "eq");
    if (name === "Balance Verifier") renderEqVerifier(panel);
    if (name === "Random Generator") renderEqGenerator(panel);
    if (name === "Practice Bank") renderEqPracticeBank(panel, data);
    icons();
  }
  tabBar.addEventListener("click", e => {
    const chip = e.target.closest(".chip");
    if (chip) showTab(chip.dataset.tab);
  });
  showTab("Theory");
}

function renderEqTheory(panel, data) {
  const wrap = el("div", "grid-2");

  const simpleCard = el("div", "card-solid", "");
  simpleCard.style.padding = "26px";
  simpleCard.innerHTML = `<h3 style="margin-bottom:14px;"><i data-lucide="book-open" style="width:18px;height:18px;vertical-align:-3px;color:var(--c-eq);"></i> Simple Explanation</h3>`;
  data.theory.simple.forEach(block => {
    const b = el("div", "ledger-rule");
    b.style.marginTop = "16px";
    let html = `<h4 style="font-size:0.95rem; margin-bottom:8px;">${block.h}</h4>`;
    if (block.p) html += `<p style="font-size:0.9rem; line-height:1.65; color:var(--ink-soft); margin-bottom:10px;">${block.p}</p>`;
    if (block.formula) html += `<div class="tnum" style="text-align:center; font-size:1.15rem; font-weight:700; color:var(--c-eq); background:var(--c-eq-soft); padding:12px; border-radius:10px; margin:10px 0;">${block.formula}</div>`;
    if (block.p2) html += `<p style="font-size:0.9rem; line-height:1.65; color:var(--ink-soft);">${block.p2}</p>`;
    if (block.list) {
      html += `<ul style="padding-left:18px; margin-top:8px;">`;
      block.list.forEach(item => html += `<li style="margin-bottom:8px; font-size:0.88rem;"><b>${item.term}:</b> ${item.def}</li>`);
      html += `</ul>`;
    }
    b.innerHTML = html;
    simpleCard.appendChild(b);
  });

  const advCard = el("div", "card-solid", "");
  advCard.style.padding = "26px";
  advCard.innerHTML = `<h3 style="margin-bottom:14px;"><i data-lucide="brain" style="width:18px;height:18px;vertical-align:-3px;color:var(--c-eq);"></i> Advanced Explanation</h3>`;
  data.theory.advanced.forEach(block => {
    const b = el("div", "ledger-rule");
    b.style.marginTop = "16px";
    let html = `<h4 style="font-size:0.95rem; margin-bottom:8px;">${block.h}</h4>`;
    if (block.p) html += `<p style="font-size:0.9rem; line-height:1.65; color:var(--ink-soft); margin-bottom:10px;">${block.p}</p>`;
    if (block.formula) html += `<div class="tnum" style="text-align:center; font-size:1.05rem; font-weight:700; color:var(--c-eq); background:var(--c-eq-soft); padding:12px; border-radius:10px; margin:10px 0;">${block.formula}</div>`;
    if (block.p2) html += `<p style="font-size:0.9rem; line-height:1.65; color:var(--ink-soft);">${block.p2}</p>`;
    if (block.list) {
      html += `<ul style="padding-left:18px; margin-top:8px;">`;
      block.list.forEach(item => html += `<li style="margin-bottom:8px; font-size:0.88rem;"><b>${item.term}:</b> ${item.def}</li>`);
      html += `</ul>`;
    }
    b.innerHTML = html;
    advCard.appendChild(b);
  });

  wrap.appendChild(simpleCard);
  wrap.appendChild(advCard);
  panel.appendChild(wrap);
}

function renderEqConcepts(panel, data) {
  panel.appendChild(sectionTitle("Key concepts"));
  const grid = el("div", "grid-3");
  data.concepts.forEach(c => {
    const card = el("div", "card liftable", "");
    card.style.padding = "22px";
    card.innerHTML = `<h4 style="font-size:1rem; margin-bottom:8px; color:var(--c-eq);">${c.title}</h4><p style="font-size:0.87rem; line-height:1.6; color:var(--ink-soft);">${c.body}</p>`;
    grid.appendChild(card);
  });
  panel.appendChild(grid);
}

/* ---------------------------------------------------------
   MIND MAP — shared radial SVG renderer, used by all three
   chapters. Center node + primary branches fanning outward,
   each branch carrying its own small sub-nodes. This is the
   genuine visual map (NotebookLM-style); "Key Concepts" above
   is the plain-text companion, not a substitute for it.
   --------------------------------------------------------- */
function renderMindMap(panel, chapterId) {
  const map = APP_DATA.mindmaps[chapterId];
  if (!map) { panel.innerHTML = `<p style="color:var(--ink-faint);">Mind map not available for this chapter.</p>`; return; }

  if (window.innerWidth <= 860) { renderMindMapOutline(panel, map, chapterId); return; }

  panel.appendChild(sectionTitle("Mind map"));
  const hint = el("p", "", "A bird's-eye view of how this chapter fits together. Tap any branch's +/– badge to expand or collapse it, or drag any box — topic or sub-topic — to spread things out so nothing overlaps.");
  hint.style.cssText = "font-size:0.85rem; color:var(--ink-faint); margin:-8px 0 18px;";
  panel.appendChild(hint);

  const wrap = el("div", "card-solid mindmap-wrap");
  wrap.style.cssText = "padding:20px; overflow:auto; touch-action:none;";
  panel.appendChild(wrap);

  // Layout geometry: center at (cx, cy), branches distributed evenly
  // around a circle of radius R, sub-nodes fanned out further along
  // each branch's own angle so the whole thing reads as spokes.
  // Sized generously (with extra radius/spread for branches that carry
  // more children) so the default layout is far less likely to overlap;
  // on top of that every box below is individually draggable.
  const width = 1120, height = 860;
  const cx = width / 2, cy = height / 2;
  const R = 250;               // distance from center to branch nodes
  const subR = 195;            // additional distance from branch to its sub-nodes
  const n = map.branches.length;
  const mindmapState = window.__mindmapExpanded || (window.__mindmapExpanded = {});
  const posState = window.__mindmapPositions || (window.__mindmapPositions = {});
  const stateKey = chapterId;
  if (!mindmapState[stateKey]) mindmapState[stateKey] = new Set(map.branches.map((_, i) => i)); // all expanded by default
  if (!posState[stateKey]) posState[stateKey] = {}; // custom dragged positions, keyed by node key
  const positions = posState[stateKey];

  function wrapText(text, maxCharsPerLine) {
    const words = String(text).split(" ");
    const lines = [];
    let cur = "";
    words.forEach(w => {
      if ((cur + " " + w).trim().length > maxCharsPerLine) { lines.push(cur.trim()); cur = w; }
      else cur = (cur + " " + w).trim();
    });
    if (cur) lines.push(cur.trim());
    return lines;
  }

  function branchAngle(i) { return (i / n) * 2 * Math.PI - Math.PI / 2; }

  function defaultBranchPos(i) {
    const angle = branchAngle(i);
    // branches with more children get pushed a bit further out so their
    // fan of sub-nodes has room without crowding the neighbouring branch
    const extra = Math.max(0, map.branches[i].children.length - 3) * 22;
    return { x: cx + (R + extra) * Math.cos(angle), y: cy + (R + extra) * Math.sin(angle) };
  }

  function defaultChildPos(i, j) {
    const b = map.branches[i];
    const bp = getBranchPos(i);
    const angle = branchAngle(i);
    const spread = Math.min(1.05, 0.5 + b.children.length * 0.11);
    const t = b.children.length === 1 ? 0 : (j / (b.children.length - 1)) - 0.5;
    const childAngle = angle + t * spread;
    return { x: bp.x + subR * Math.cos(childAngle), y: bp.y + subR * Math.sin(childAngle) };
  }

  function getBranchPos(i) {
    const key = `b${i}`;
    if (!positions[key]) positions[key] = defaultBranchPos(i);
    return positions[key];
  }

  function getChildPos(i, j) {
    const key = `b${i}c${j}`;
    if (!positions[key]) positions[key] = defaultChildPos(i, j);
    return positions[key];
  }

  function buildSvg() {
    const expanded = mindmapState[stateKey];
    let svg = `<svg viewBox="0 0 ${width} ${height}" width="100%" style="min-width:640px; display:block;">`;

    // Connective lines drawn first so nodes sit on top
    map.branches.forEach((b, i) => {
      const bp = getBranchPos(i);
      svg += `<line x1="${cx}" y1="${cy}" x2="${bp.x}" y2="${bp.y}" stroke="${b.color}" stroke-width="2" opacity="0.55"/>`;
      if (expanded.has(i)) {
        b.children.forEach((child, j) => {
          const sp = getChildPos(i, j);
          svg += `<line x1="${bp.x}" y1="${bp.y}" x2="${sp.x}" y2="${sp.y}" stroke="${b.color}" stroke-width="1.3" opacity="0.35"/>`;
        });
      }
    });

    // Center node
    const centerLines = String(map.center).split("\n");
    svg += `<g>
      <rect x="${cx - 78}" y="${cy - 30}" width="156" height="60" rx="16" fill="var(--ink)" />
      <text x="${cx}" y="${cy - (centerLines.length - 1) * 8}" text-anchor="middle" font-family="Poppins" font-weight="700" font-size="15" fill="var(--paper)">
        ${centerLines.map((l, i) => `<tspan x="${cx}" dy="${i === 0 ? 0 : 18}">${l}</tspan>`).join("")}
      </text>
    </g>`;

    // Branch nodes + their sub-nodes
    map.branches.forEach((b, i) => {
      const bp = getBranchPos(i);
      const lines = wrapText(b.label, 16);
      const boxW = Math.max(110, Math.max(...lines.map(l => l.length)) * 7.5 + 24);
      const boxH = 26 + lines.length * 16;

      svg += `<g class="mindmap-branch" data-key="b${i}" data-branch="${i}" style="cursor:grab;">
        <rect x="${bp.x - boxW/2}" y="${bp.y - boxH/2}" width="${boxW}" height="${boxH}" rx="12" fill="${b.color}" opacity="0.16" stroke="${b.color}" stroke-width="1.6"/>
        <text x="${bp.x}" y="${bp.y - (lines.length - 1) * 7 + 4}" text-anchor="middle" font-family="Poppins" font-weight="600" font-size="12.5" fill="${b.color}" style="pointer-events:none;">
          ${lines.map((l, li) => `<tspan x="${bp.x}" dy="${li === 0 ? 0 : 15}">${l}</tspan>`).join("")}
        </text>
        <g class="mindmap-toggle" data-toggle="1" data-branch="${i}" style="cursor:pointer;">
          <circle cx="${bp.x + boxW/2 - 10}" cy="${bp.y - boxH/2 + 10}" r="8" fill="${b.color}"/>
          <text x="${bp.x + boxW/2 - 10}" y="${bp.y - boxH/2 + 14}" text-anchor="middle" font-family="JetBrains Mono" font-size="10" fill="var(--paper)" style="pointer-events:none;">${expanded.has(i) ? "–" : "+"}</text>
        </g>
      </g>`;

      if (expanded.has(i)) {
        b.children.forEach((child, j) => {
          const sp = getChildPos(i, j);
          const clines = wrapText(child, 20);
          const cW = Math.max(120, Math.max(...clines.map(l => l.length)) * 6.4 + 20);
          const cH = 20 + clines.length * 13;
          svg += `<g class="mindmap-child" data-key="b${i}c${j}" style="cursor:grab;">
            <rect x="${sp.x - cW/2}" y="${sp.y - cH/2}" width="${cW}" height="${cH}" rx="9" fill="var(--paper-raised)" stroke="${b.color}" stroke-width="1" opacity="0.95"/>
            <text x="${sp.x}" y="${sp.y - (clines.length - 1) * 5.5 + 4}" text-anchor="middle" font-family="Inter" font-size="10.5" fill="var(--ink-soft)" style="pointer-events:none;">
              ${clines.map((l, li) => `<tspan x="${sp.x}" dy="${li === 0 ? 0 : 13}">${l}</tspan>`).join("")}
            </text>
          </g>`;
        });
      }
    });

    svg += `</svg>`;
    return svg;
  }

  wrap.innerHTML = buildSvg();

  // ---- Toggle expand/collapse (only via the small +/– badge) ----
  wrap.addEventListener("click", (e) => {
    const toggleEl = e.target.closest("[data-toggle]");
    if (!toggleEl) return;
    const idx = parseInt(toggleEl.dataset.branch, 10);
    const expanded = mindmapState[stateKey];
    if (expanded.has(idx)) expanded.delete(idx); else expanded.add(idx);
    wrap.innerHTML = buildSvg();
  });

  // ---- Drag any topic (branch) or sub-topic (child) box freely ----
  let dragKey = null, dragOffset = { x: 0, y: 0 };

  function svgPoint(evt) {
    const svgEl = wrap.querySelector("svg");
    if (!svgEl) return { x: 0, y: 0 };
    const pt = svgEl.createSVGPoint();
    pt.x = evt.clientX; pt.y = evt.clientY;
    const ctm = svgEl.getScreenCTM();
    if (!ctm) return { x: 0, y: 0 };
    const loc = pt.matrixTransform(ctm.inverse());
    return { x: loc.x, y: loc.y };
  }

  wrap.addEventListener("pointerdown", (e) => {
    if (e.target.closest("[data-toggle]")) return; // toggle handled by click, not drag
    const nodeEl = e.target.closest("[data-key]");
    if (!nodeEl) return;
    const key = nodeEl.dataset.key;
    if (!positions[key]) {
      const m = key.match(/^b(\d+)c(\d+)$/);
      if (m) getChildPos(parseInt(m[1], 10), parseInt(m[2], 10));
      else getBranchPos(parseInt(key.slice(1), 10));
    }
    const current = positions[key];
    if (!current) return;
    const p = svgPoint(e);
    dragKey = key;
    dragOffset = { x: p.x - current.x, y: p.y - current.y };
    wrap.setPointerCapture(e.pointerId);
    nodeEl.style.cursor = "grabbing";
  });

  wrap.addEventListener("pointermove", (e) => {
    if (!dragKey) return;
    const p = svgPoint(e);
    positions[dragKey] = { x: p.x - dragOffset.x, y: p.y - dragOffset.y };
    wrap.innerHTML = buildSvg();
  });

  function endDrag(e) {
    if (dragKey && wrap.hasPointerCapture && e && e.pointerId !== undefined) {
      try { wrap.releasePointerCapture(e.pointerId); } catch (err) {}
    }
    dragKey = null;
  }
  wrap.addEventListener("pointerup", endDrag);
  wrap.addEventListener("pointercancel", endDrag);

  const controls = el("div", "");
  controls.style.cssText = "display:flex; gap:8px; margin-top:14px; flex-wrap:wrap;";
  const expandAllBtn = el("button", "btn-ghost sm ripple-surface", `<i data-lucide="maximize-2"></i> Expand all`);
  const collapseAllBtn = el("button", "btn-ghost sm ripple-surface", `<i data-lucide="minimize-2"></i> Collapse all`);
  const resetLayoutBtn = el("button", "btn-ghost sm ripple-surface", `<i data-lucide="rotate-ccw"></i> Reset layout`);
  expandAllBtn.addEventListener("click", () => { mindmapState[stateKey] = new Set(map.branches.map((_, i) => i)); wrap.innerHTML = buildSvg(); icons(); });
  collapseAllBtn.addEventListener("click", () => { mindmapState[stateKey] = new Set(); wrap.innerHTML = buildSvg(); icons(); });
  resetLayoutBtn.addEventListener("click", () => { posState[stateKey] = {}; wrap.innerHTML = buildSvg(); icons(); });
  controls.appendChild(expandAllBtn);
  controls.appendChild(collapseAllBtn);
  controls.appendChild(resetLayoutBtn);
  panel.appendChild(controls);
  icons();
}

/* ---- Mobile mind map: a tappable accordion outline instead of the
   large draggable SVG, which doesn't fit comfortably on a phone
   screen. Same expand/collapse state (window.__mindmapExpanded) is
   shared with the desktop version so switching between them (e.g.
   resizing) stays consistent. ---- */
function renderMindMapOutline(panel, map, chapterId) {
  panel.innerHTML = "";
  panel.appendChild(sectionTitle("Mind map"));
  const hint = el("p", "", "A tap-friendly outline of how this chapter fits together — tap any topic to expand it.");
  hint.style.cssText = "font-size:0.85rem; color:var(--ink-faint); margin:-8px 0 18px;";
  panel.appendChild(hint);

  const centerText = String(map.center).split("\n").join(" ");
  const centerCard = el("div", "", `<div style="text-align:center; font-family:var(--font-head); font-weight:700; font-size:1rem;">${centerText}</div>`);
  centerCard.style.cssText = "padding:16px; margin-bottom:16px; background:var(--ink); color:var(--paper); border-radius:16px;";
  panel.appendChild(centerCard);

  const mindmapState = window.__mindmapExpanded || (window.__mindmapExpanded = {});
  const stateKey = chapterId;
  if (!mindmapState[stateKey]) mindmapState[stateKey] = new Set(map.branches.map((_, i) => i));
  const expanded = mindmapState[stateKey];

  map.branches.forEach((b, i) => {
    const isOpen = expanded.has(i);
    const branchCard = el("div", "card mindmap-outline-branch");
    branchCard.style.cssText = `margin-bottom:12px; padding:0; overflow:hidden; border-left:4px solid ${b.color};`;
    branchCard.innerHTML = `
      <button class="mindmap-outline-toggle" data-branch="${i}" style="width:100%; display:flex; align-items:center; justify-content:space-between; gap:10px; padding:16px; background:none; border:none; cursor:pointer; text-align:left; min-height:44px;">
        <span style="font-weight:600; font-size:0.92rem; color:${b.color};">${b.label}</span>
        <i data-lucide="${isOpen ? "chevron-up" : "chevron-down"}" style="color:${b.color}; flex-shrink:0; width:18px; height:18px;"></i>
      </button>
      <div style="display:${isOpen ? "block" : "none"}; padding:0 16px 14px;">
        ${b.children.map(c => `<div style="padding:9px 0 9px 14px; border-left:2px solid var(--line); margin-bottom:2px; font-size:0.85rem; color:var(--ink-soft); line-height:1.5;">${c}</div>`).join("")}
      </div>
    `;
    panel.appendChild(branchCard);
  });

  function handleToggle(e) {
    const btn = e.target.closest(".mindmap-outline-toggle");
    if (!btn) return;
    const idx = parseInt(btn.dataset.branch, 10);
    if (expanded.has(idx)) expanded.delete(idx); else expanded.add(idx);
    panel.removeEventListener("click", handleToggle);
    renderMindMapOutline(panel, map, chapterId);
  }
  panel.addEventListener("click", handleToggle);

  const controls = el("div", "");
  controls.style.cssText = "display:flex; gap:8px; margin-top:4px; flex-wrap:wrap;";
  const expandAllBtn = el("button", "btn-ghost sm ripple-surface", `<i data-lucide="maximize-2"></i> Expand all`);
  const collapseAllBtn = el("button", "btn-ghost sm ripple-surface", `<i data-lucide="minimize-2"></i> Collapse all`);
  expandAllBtn.addEventListener("click", () => { mindmapState[stateKey] = new Set(map.branches.map((_, i) => i)); panel.removeEventListener("click", handleToggle); renderMindMapOutline(panel, map, chapterId); });
  collapseAllBtn.addEventListener("click", () => { mindmapState[stateKey] = new Set(); panel.removeEventListener("click", handleToggle); renderMindMapOutline(panel, map, chapterId); });
  controls.appendChild(expandAllBtn);
  controls.appendChild(collapseAllBtn);
  panel.appendChild(controls);
  icons();
}

/* ---- BALANCE VERIFIER (signature interactive element) ---- */
function renderEqVerifier(panel) {
  const wrap = el("div", "grid-2");

  const formCard = el("div", "card-solid", "");
  formCard.style.padding = "26px";
  formCard.innerHTML = `
    <h3 style="margin-bottom:16px;">Check your equation</h3>
    <div class="field-group"><label>Assets (₹)</label><input type="number" class="field-input" id="vAssets" placeholder="e.g. 150000"></div>
    <div class="field-group"><label>Liabilities (₹)</label><input type="number" class="field-input" id="vLiabilities" placeholder="e.g. 40000"></div>
    <div class="field-group"><label>Capital (₹)</label><input type="number" class="field-input" id="vCapital" placeholder="e.g. 110000"></div>
    <button class="btn-primary ripple-surface" id="verifyBtn" style="width:100%; margin-top:6px;"><i data-lucide="check"></i> Verify Balance</button>
    <div id="verifyResult" style="margin-top:16px;"></div>
  `;

  const scaleCard = el("div", "card-solid", "");
  scaleCard.style.padding = "10px 20px 26px";
  scaleCard.innerHTML = `
    <div class="scale-widget">
      <div class="scale-svg-wrap">
        <svg viewBox="0 0 420 220" width="100%">
          <line x1="210" y1="70" x2="210" y2="190" stroke="var(--ink-faint)" stroke-width="4"/>
          <polygon points="185,190 235,190 245,205 175,205" fill="var(--ink-faint)"/>
          <g class="scale-beam-group" id="scaleBeam">
            <line x1="70" y1="70" x2="350" y2="70" stroke="var(--gold)" stroke-width="5" stroke-linecap="round"/>
            <circle cx="210" cy="70" r="7" fill="var(--gold)"/>
            <line x1="70" y1="70" x2="70" y2="115" stroke="var(--ink-faint)" stroke-width="2"/>
            <path d="M40,115 Q70,145 100,115 Z" fill="var(--c-eq-soft)" stroke="var(--c-eq)" stroke-width="2"/>
            <text x="70" y="135" text-anchor="middle" font-family="JetBrains Mono" font-size="11" fill="var(--ink)">Assets</text>
            <line x1="350" y1="70" x2="350" y2="115" stroke="var(--ink-faint)" stroke-width="2"/>
            <path d="M320,115 Q350,145 380,115 Z" fill="var(--gold-soft)" stroke="var(--gold)" stroke-width="2"/>
            <text x="350" y="135" text-anchor="middle" font-family="JetBrains Mono" font-size="11" fill="var(--ink)">C + L</text>
          </g>
        </svg>
      </div>
      <div class="scale-verified-badge neutral" id="scaleBadge"><i data-lucide="minus"></i><span>Enter values to check</span></div>
    </div>
  `;

  wrap.appendChild(formCard);
  wrap.appendChild(scaleCard);
  panel.appendChild(wrap);

  function tiltScale(diff) {
    const beam = $("#scaleBeam");
    const badge = $("#scaleBadge");
    let angle = 0;
    if (diff > 0) angle = Math.min(12, diff / 5000);       // assets heavier -> tips left down... visualized as rotation
    if (diff < 0) angle = Math.max(-12, diff / 5000);
    beam.style.transform = `rotate(${angle}deg)`;
    if (diff === 0) {
      badge.className = "scale-verified-badge ok";
      badge.innerHTML = `<i data-lucide="check-circle"></i><span>Balanced — the equation holds!</span>`;
    } else {
      badge.className = "scale-verified-badge bad";
      const side = diff > 0 ? "Assets" : "Capital + Liabilities";
      badge.innerHTML = `<i data-lucide="alert-triangle"></i><span>Off by ${fmtINR(Math.abs(diff))} — ${side} is higher</span>`;
    }
    icons();
  }

  $("#verifyBtn").addEventListener("click", () => {
    const a = parseFloat($("#vAssets").value) || 0;
    const l = parseFloat($("#vLiabilities").value) || 0;
    const c = parseFloat($("#vCapital").value) || 0;
    const diff = a - (c + l);
    tiltScale(diff);
    const resBox = $("#verifyResult");
    if (diff === 0) {
      resBox.innerHTML = `<div class="reveal-block"><h4>Result</h4><p style="font-size:0.88rem;">Assets (${fmtINR(a)}) exactly equals Capital + Liabilities (${fmtINR(c+l)}). Your books balance.</p></div>`;
      if (!STATE.solved["eq-verifier-balanced"]) {
        STATE.solved["eq-verifier-balanced"] = { correct: true, attempts: 1 };
        saveState();
        addXP(5, "Verified a balanced equation");
      }
    } else {
      const mistakeMsg = diff > 0
        ? `Assets exceed Capital + Liabilities by ${fmtINR(diff)}. This usually means an asset has been overstated, or a liability/capital source of funding hasn't been fully recorded.`
        : `Capital + Liabilities exceed Assets by ${fmtINR(-diff)}. This usually means a liability or capital figure has been overstated, or an asset is missing from the books.`;
      resBox.innerHTML = `<div class="reveal-block" style="background:var(--flag-soft); border-left-color:var(--flag);"><h4>Mistake detected</h4><p style="font-size:0.88rem;">${mistakeMsg}</p></div>`;
    }
  });
}

/* ---- RANDOM PROBLEM GENERATOR with timer + score ---- */
let genState = { score: 0, attempts: 0, timerId: null, seconds: 0, current: null, answered: false };

function renderEqGenerator(panel) {
  genState = { score: 0, attempts: 0, timerId: null, seconds: 0, current: null, answered: false };

  const card = el("div", "card-solid", "");
  card.style.padding = "26px";
  card.innerHTML = `
    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:18px;">
      <h3>Unlimited random practice</h3>
      <div style="display:flex; gap:16px; align-items:center;">
        <span class="tnum" style="font-size:0.9rem;"><i data-lucide="timer" style="width:14px;height:14px;vertical-align:-2px;"></i> <span id="genTimer">00:00</span></span>
        <span class="tnum" style="font-size:0.9rem;">Score: <b id="genScore">0</b>/<span id="genAttempts">0</span></span>
      </div>
    </div>
    <div id="genProblemArea"></div>
  `;
  panel.appendChild(card);

  function generateProblem() {
    const assets = Math.round((Math.random() * 190 + 10)) * 1000;
    const liabPercent = 0.15 + Math.random() * 0.4;
    const liabilities = Math.round((assets * liabPercent) / 500) * 500;
    const capital = assets - liabilities;
    const askOptions = ["capital", "liabilities", "assets"];
    const ask = askOptions[Math.floor(Math.random() * 3)];
    let given = {}, answer;
    if (ask === "capital") { given = { assets, liabilities }; answer = capital; }
    if (ask === "liabilities") { given = { assets, capital }; answer = liabilities; }
    if (ask === "assets") { given = { capital, liabilities }; answer = capital + liabilities; }
    genState.current = { given, ask, answer };
    return genState.current;
  }

  function renderProblem() {
    const p = generateProblem();
    genState.answered = false;
    const labelMap = { assets: "Assets", liabilities: "Liabilities", capital: "Capital" };
    const givenText = Object.entries(p.given).map(([k,v]) => `${labelMap[k]} = ${fmtINR(v)}`).join(",  ");
    const area = $("#genProblemArea");
    area.innerHTML = `
      <p style="font-size:0.95rem; margin-bottom:10px;">Given: <b class="tnum">${givenText}</b>. Find <b>${labelMap[p.ask]}</b>.</p>
      <div style="display:flex; gap:10px; max-width:320px;">
        <input type="number" class="field-input" id="genAnswerInput" placeholder="Your answer">
        <button class="btn-primary ripple-surface" id="genSubmitBtn">Submit</button>
      </div>
      <div id="genFeedback" style="margin-top:14px;"></div>
    `;
    icons();
    $("#genSubmitBtn").addEventListener("click", checkGenAnswer);
    $("#genAnswerInput").addEventListener("keydown", e => { if (e.key === "Enter") checkGenAnswer(); });
    $("#genAnswerInput").focus();
  }

  function checkGenAnswer() {
    if (genState.answered) return; // already submitted for this problem — locked until the next one loads
    genState.answered = true;
    const val = parseFloat($("#genAnswerInput").value);
    const p = genState.current;
    genState.attempts++;
    const fb = $("#genFeedback");
    if (val === p.answer) {
      genState.score++;
      fb.innerHTML = `<div class="reveal-block"><h4>Correct</h4><p style="font-size:0.88rem;">The answer is ${fmtINR(p.answer)}.</p></div>`;
      addXP(3, "Generator problem solved");
      launchMiniConfettiIfMilestone();
    } else {
      fb.innerHTML = `<div class="reveal-block" style="background:var(--flag-soft); border-left-color:var(--flag);"><h4>Not quite</h4><p style="font-size:0.88rem;">The correct answer was ${fmtINR(p.answer)}. Assets = Capital + Liabilities always.</p></div>`;
      addXP(-XP_WRONG_PENALTY, "Generator problem incorrect");
    }
    $("#genScore").textContent = genState.score;
    $("#genAttempts").textContent = genState.attempts;
    setTimeout(renderProblem, 1600);
  }

  function launchMiniConfettiIfMilestone() {
    if (genState.score > 0 && genState.score % 10 === 0) launchConfetti();
  }

  genState.timerId = setInterval(() => {
    genState.seconds++;
    const m = String(Math.floor(genState.seconds/60)).padStart(2,"0");
    const s = String(genState.seconds%60).padStart(2,"0");
    const t = $("#genTimer");
    if (t) t.textContent = `${m}:${s}`; else clearInterval(genState.timerId);
  }, 1000);

  renderProblem();
}

/* ---- PRACTICE BANK (the 84 numericals, with hint/solution/answer reveal) ---- */
function renderEqPracticeBank(panel, data) {
  const filterBar = el("div", "", "");
  filterBar.style.cssText = "display:flex; gap:8px; margin-bottom:18px; flex-wrap:wrap;";
  ["All", "Easy", "Medium", "Hard"].forEach(d => {
    const chip = el("button", `chip ${d === eqFilterDifficulty ? "active" : ""}`, d);
    chip.addEventListener("click", () => {
      eqFilterDifficulty = d;
      renderEqPracticeBank(panel, data);
    });
    filterBar.appendChild(chip);
  });
  panel.innerHTML = "";
  panel.appendChild(filterBar);

  const list = data.numericals.filter(q => eqFilterDifficulty === "All" || q.difficulty === eqFilterDifficulty);
  const countLabel = el("p", "", `Showing ${list.length} of ${data.numericals.length} questions`);
  countLabel.style.cssText = "font-size:0.83rem; color:var(--ink-faint); margin-bottom:16px;";
  panel.appendChild(countLabel);

  list.forEach(q => panel.appendChild(renderQuestionCard(q, "eq")));
  applyMobilePager(panel);
  icons();
}

function renderQuestionCard(q, chapterId, topicLabel) {
  const label = topicLabel || (chapterId === "dc-bs" ? "Balance Sheet (Ch 2)" : "Accounting Equation");
  const solvedKey = `${chapterId}-${q.id}`;
  const alreadySolved = STATE.solved[solvedKey];
  const card = el("div", "card q-card", "");
  const questionText = q.transaction || `Given the figures below, find the missing value.`;
  let givenHtml = "";
  if (q.given) {
    givenHtml = `<div class="q-given">` + Object.entries(q.given).map(([k,v]) => `<div><b>${k[0].toUpperCase()+k.slice(1)}</b>${fmtINR(v)}</div>`).join("") + `</div>`;
  }
  card.innerHTML = `
    <div class="q-meta">
      <span class="diff-badge ${q.difficulty}">${q.difficulty}</span>
      <span class="q-id">Q${q.id}</span>
      ${alreadySolved ? `<span style="margin-left:auto; color:var(--c-eq); font-size:0.78rem; display:flex; align-items:center; gap:4px;"><i data-lucide="check-circle" style="width:13px;height:13px;"></i> Solved</span>` : ""}
    </div>
    <div class="q-body">${questionText}</div>
    ${givenHtml}
    <div class="q-actions">
      <button class="btn-ghost sm ripple-surface" data-act="hint"><i data-lucide="lightbulb"></i> Hint</button>
      <button class="btn-ghost sm ripple-surface" data-act="solution"><i data-lucide="list-ordered"></i> Solution</button>
      <button class="btn-primary sm ripple-surface" data-act="answer"><i data-lucide="eye"></i> Reveal Answer</button>
      <button class="icon-btn sm" data-act="bookmark" title="Bookmark"><i data-lucide="${STATE.bookmarks.includes(solvedKey) ? 'bookmark-check' : 'bookmark'}"></i></button>
      <button class="btn-ghost sm ripple-surface ask-ai-btn" data-act="ask-ai" title="Ask the AI Tutor about this question"><i data-lucide="bot"></i> Ask AI about this</button>
    </div>
    <div class="reveal-area"></div>
  `;
  const revealArea = $(".reveal-area", card);

  card.addEventListener("click", (e) => {
    const btn = e.target.closest("button[data-act]");
    if (!btn) return;
    const act = btn.dataset.act;
    if (act === "ask-ai") {
      askAIAbout(`I'm stuck on this ${label} question: "${questionText}". Can you walk me through how to think about it?`, chapterId === "dc-bs" ? "dc" : chapterId);
      return;
    }
    if (act === "hint") {
      revealArea.innerHTML = `<div class="reveal-block hint-block"><h4>Hint</h4><p style="font-size:0.88rem;">${q.hint}</p></div>`;
    }
    if (act === "solution") {
      revealArea.innerHTML = `<div class="reveal-block"><h4>Step-by-step solution</h4><ol>${q.steps.map(s => `<li>${s}</li>`).join("")}</ol></div>`;
    }
    if (act === "answer") {
      revealArea.innerHTML = `
        <div class="reveal-block">
          <h4>Final answer</h4>
          <div class="reveal-answer tnum">${fmtINR(q.answer)}</div>
          <p style="font-size:0.87rem; color:var(--ink-soft);">${q.explanation}</p>
          <div class="self-check" style="margin-top:14px; display:flex; align-items:center; gap:10px; flex-wrap:wrap;">
            <span style="font-size:0.83rem; color:var(--ink-faint);">Did you get this right?</span>
            <button class="btn-ghost sm ripple-surface" data-act="self-correct"><i data-lucide="check"></i> Yes, I got it right</button>
            <button class="btn-ghost sm ripple-surface" data-act="self-wrong"><i data-lucide="x"></i> No, I got it wrong</button>
          </div>
        </div>`;
      icons();
    }
    if (act === "self-correct" || act === "self-wrong") {
      const gotItRight = act === "self-correct";
      STATE.solved[solvedKey] = { correct: gotItRight, attempts: (STATE.solved[solvedKey]?.attempts || 0) + 1 };
      if (gotItRight) {
        saveState();
        addXP(4, `Solved Q${q.id}`);
        logActivity(`Solved ${label} Q${q.id} (${q.difficulty})`);
        mistakeBookRecordCorrect(solvedKey);
      } else {
        if (!STATE.mistakes.includes(solvedKey)) STATE.mistakes.push(solvedKey);
        saveState();
        mistakeBookRecord({
          key: solvedKey, question: questionText, chapter: chapterId === "dc-bs" ? "dc" : chapterId,
          chapterLabel: label, topic: label, type: "Practice Bank (self-assessed)",
          studentAnswer: "Marked as incorrect by student", correctAnswer: fmtINR(q.answer), explanation: q.explanation
        });
      }
      refreshProgress();
      const selfCheckEl = $(".self-check", revealArea);
      if (selfCheckEl) selfCheckEl.innerHTML = gotItRight
        ? `<span style="font-size:0.83rem; color:var(--c-eq);"><i data-lucide="check-circle" style="width:14px;height:14px; vertical-align:-2px;"></i> Marked correct — nice work!</span>`
        : `<span style="font-size:0.83rem; color:var(--flag);"><i data-lucide="alert-circle" style="width:14px;height:14px; vertical-align:-2px;"></i> Added to your Mistake Book for review.</span>`;
      icons();
    }
    if (act === "bookmark") {
      const idx = STATE.bookmarks.indexOf(solvedKey);
      if (idx >= 0) { STATE.bookmarks.splice(idx, 1); btn.querySelector("i").setAttribute("data-lucide", "bookmark"); }
      else { STATE.bookmarks.push(solvedKey); btn.querySelector("i").setAttribute("data-lucide", "bookmark-check"); }
      saveState(); icons();
    }
    icons();
  });

  return card;
}

/* ---------------------------------------------------------
   6b. CHAPTER 2 — RULES OF DEBIT & CREDIT (full build)
   --------------------------------------------------------- */
let dcFilterDifficulty = "All";

function renderDCChapter(root) {
  const data = APP_DATA.debitCredit;
  root.appendChild(el("div", "hero", `
    <span class="hero-eyebrow">Chapter 2</span>
    <h1>Rules of Debit &amp; Credit</h1>
    <p>${APP_DATA.chapters[1].tagline}. Learn both the Golden Rules and the Modern approach, classify 36 original transactions, and practice with the Balance Sheet question bank.</p>
  `));

  const tabs = ["Theory", "Concepts", "Mind Map", "Common Mistakes", "Balance Sheet Qs", "Practice Bank"];
  const tabBar = el("div", "", "");
  tabBar.style.cssText = "display:flex; gap:8px; flex-wrap:wrap; margin-bottom:22px;";
  tabs.forEach((t, i) => {
    const chip = el("button", `chip ${i===0?'active':''}`, t);
    chip.dataset.tab = t;
    tabBar.appendChild(chip);
  });
  const journeyEl = renderJourneyStepper(root, "dc");
  root.appendChild(tabBar);
  const panel = el("div", "");
  root.appendChild(panel);

  function showTab(name) {
    $all(".chip", tabBar).forEach(c => c.classList.toggle("active", c.dataset.tab === name));
    panel.innerHTML = "";
    updateJourneyStepper(journeyEl, "dc", name);
    if (name === "Theory") renderGenericTheory(panel, data, "dc");
    if (name === "Concepts") renderGenericConcepts(panel, data, "dc");
    if (name === "Mind Map") renderMindMap(panel, "dc");
    if (name === "Common Mistakes") renderCommonMistakes(panel, data);
    if (name === "Balance Sheet Qs") renderDCBalanceSheetBank(panel, data);
    if (name === "Practice Bank") renderDCPracticeBank(panel, data);
    icons();
  }
  tabBar.addEventListener("click", e => {
    const chip = e.target.closest(".chip");
    if (chip) showTab(chip.dataset.tab);
  });
  showTab("Theory");
}

/* ---- COMMON MISTAKES & TRAPS (new Chapter 2 section) ---- */
function renderCommonMistakes(panel, data) {
  panel.appendChild(sectionTitle("Common mistakes & traps"));
  const hint = el("p", "", "A checklist of classification errors students repeat most often, worth a final scan right before a test.");
  hint.style.cssText = "font-size:0.85rem; color:var(--ink-faint); margin:-8px 0 18px;";
  panel.appendChild(hint);

  data.commonMistakes.forEach((m, i) => {
    const card = el("div", "card q-card", "");
    card.innerHTML = `
      <div class="q-meta">
        <span class="diff-badge" style="background:var(--flag-soft); color:var(--flag);">Trap ${i + 1}</span>
        <span class="q-id">${m.trap}</span>
      </div>
      <div style="display:grid; grid-template-columns: 1fr; gap:12px; margin-top:8px;">
        <div style="padding:12px 14px; border-radius:10px; background:var(--flag-soft); border-left:3px solid var(--flag);">
          <h4 style="font-size:0.78rem; text-transform:uppercase; letter-spacing:0.04em; color:var(--flag); margin-bottom:6px;">What students often do</h4>
          <p style="font-size:0.87rem; line-height:1.6;">${m.wrong}</p>
        </div>
        <div style="padding:12px 14px; border-radius:10px; background:var(--c-eq-soft); border-left:3px solid var(--c-eq);">
          <h4 style="font-size:0.78rem; text-transform:uppercase; letter-spacing:0.04em; color:var(--c-eq); margin-bottom:6px;">What's actually correct</h4>
          <p style="font-size:0.87rem; line-height:1.6;">${m.right}</p>
        </div>
      </div>
      <p style="font-size:0.8rem; color:var(--ink-faint); margin-top:10px;"><i data-lucide="link-2" style="width:12px;height:12px; vertical-align:-1px;"></i> ${m.chapterLink}</p>
    `;
    panel.appendChild(card);
  });
  icons();
}

/* ---- BALANCE SHEET QUESTIONS (Chapter 2 — the missing question type) ---- */
let dcBsFilterDifficulty = "All";

function renderDCBalanceSheetBank(panel, data) {
  panel.appendChild(sectionTitle("Balance sheet type questions"));
  const hint = el("p", "", "Two kinds of practice here: full Balance Sheet statements to build or read exactly as they'd appear in an answer sheet, and quicker single-figure checks that use the same underlying link between correct debits/credits and the final statement.");
  hint.style.cssText = "font-size:0.85rem; color:var(--ink-faint); margin:-8px 0 20px;";
  panel.appendChild(hint);

  const subTabBar = el("div", "", "");
  subTabBar.style.cssText = "display:flex; gap:8px; margin-bottom:20px;";
  ["Full Balance Sheets", "Quick Checks"].forEach((t, i) => {
    const chip = el("button", `chip ${i === 0 ? "active" : ""}`, t);
    chip.dataset.subtab = t;
    subTabBar.appendChild(chip);
  });
  panel.appendChild(subTabBar);

  const subPanel = el("div", "");
  panel.appendChild(subPanel);

  function showSub(name) {
    $all(".chip", subTabBar).forEach(c => c.classList.toggle("active", c.dataset.subtab === name));
    subPanel.innerHTML = "";
    if (name === "Full Balance Sheets") renderFullBalanceSheets(subPanel, data);
    if (name === "Quick Checks") renderQuickBalanceSheetChecks(subPanel, data);
    icons();
  }
  subTabBar.addEventListener("click", (e) => {
    const chip = e.target.closest(".chip");
    if (chip) showSub(chip.dataset.subtab);
  });
  showSub("Full Balance Sheets");
}

/* ---- Full two-column Balance Sheet statement questions ---- */
function renderFullBalanceSheets(panel, data) {
  const statements = data.balanceSheetStatements || [];
  statements.forEach(s => panel.appendChild(renderBalanceSheetStatementCard(s)));
  applyMobilePager(panel);
}

function renderBalanceSheetStatementCard(s) {
  const key = `dc-bsstmt-${s.id}`;
  const card = el("div", "card q-card", "");
  card.innerHTML = `
    <div class="q-meta">
      <span class="diff-badge ${s.difficulty}">${s.difficulty}</span>
      <span class="q-id">Statement ${s.id}</span>
    </div>
    <div class="q-body">${s.prompt}</div>
    <div style="margin:14px 0; padding:14px; background:var(--line); border-radius:10px;">
      <p style="font-size:0.78rem; text-transform:uppercase; letter-spacing:0.04em; color:var(--ink-faint); margin-bottom:8px;">Figures given</p>
      <div style="display:flex; flex-wrap:wrap; gap:8px;">
        ${s.rawFigures.map(f => `<span class="tnum" style="font-size:0.82rem; padding:5px 10px; background:var(--paper-raised); border-radius:999px; border:1px solid var(--line-strong);">${f}</span>`).join("")}
      </div>
    </div>
    <div class="q-actions">
      <button class="btn-primary sm ripple-surface" data-act="showbs"><i data-lucide="table-2"></i> Prepare Balance Sheet</button>
    </div>
    <div class="reveal-area"></div>
  `;
  const revealArea = $(".reveal-area", card);

  card.addEventListener("click", (e) => {
    const btn = e.target.closest("button[data-act]");
    if (!btn) return;
    revealArea.innerHTML = buildBalanceSheetHTML(s);
    if (!STATE.solved[key]) {
      STATE.solved[key] = { correct: true, attempts: 1 };
      saveState();
      addXP(5, `Prepared Balance Sheet ${s.id}`);
      logActivity(`Prepared a full Balance Sheet statement (Ch.2)`);
    }
    icons();
  });
  return card;
}

/* Renders a Balance Sheet in the traditional two-column CBSE format:
   Liabilities (with Capital built up via Add/Less lines) on the left,
   Assets (grouped Fixed/Current) on the right, both grand-totalled
   and ruled off — matching the standard printed layout. */
function buildBalanceSheetHTML(s) {
  const rowHTML = (item, isLiab) => {
    if (item.isGroupHeader) {
      return `<tr><td colspan="2" style="padding-top:12px; font-weight:600; font-size:0.8rem; color:var(--ink-faint); border-bottom:none;">${item.label}</td></tr>`;
    }
    const amountDisplay = item.subtotal !== undefined
      ? `<span class="tnum">${fmtINR(item.subtotal)}</span>`
      : (item.isAddition || item.isSubtraction ? "" : `<span class="tnum">${fmtINR(item.amount)}</span>`);
    const leftFigure = (item.isAddition || item.isSubtraction) ? `<span class="tnum" style="color:var(--ink-faint); font-size:0.8rem;">${fmtINR(Math.abs(item.amount))}</span>` : "";
    return `<tr>
      <td style="padding:6px 10px; font-size:0.85rem;">${item.label}${leftFigure ? ` &nbsp; ${leftFigure}` : ""}</td>
      <td style="padding:6px 10px; text-align:right; font-weight:${item.subtotal !== undefined ? "700" : "400"};">${amountDisplay}</td>
    </tr>`;
  };

  return `
    <div class="reveal-block">
      <h4 style="text-align:center; margin-bottom:4px;">Balance Sheet as on ${s.asOn}</h4>
      <div style="display:grid; grid-template-columns:1fr 1fr; border:1.5px solid var(--line-strong); border-radius:10px; overflow:hidden; margin-top:14px;">
        <table style="width:100%; border-collapse:collapse; border-right:1.5px solid var(--line-strong);">
          <thead>
            <tr style="background:var(--paper-raised);">
              <th colspan="2" style="padding:8px 10px; text-align:center; font-size:0.83rem; border-bottom:1.5px solid var(--line-strong);">Liabilities</th>
            </tr>
          </thead>
          <tbody>
            ${s.liabilitiesSide.map(item => rowHTML(item, true)).join("")}
            <tr style="background:var(--gold-soft); font-weight:700;">
              <td style="padding:8px 10px; font-size:0.85rem;">Total</td>
              <td style="padding:8px 10px; text-align:right;"><span class="tnum">${fmtINR(s.grandTotal)}</span></td>
            </tr>
          </tbody>
        </table>
        <table style="width:100%; border-collapse:collapse;">
          <thead>
            <tr style="background:var(--paper-raised);">
              <th colspan="2" style="padding:8px 10px; text-align:center; font-size:0.83rem; border-bottom:1.5px solid var(--line-strong);">Assets</th>
            </tr>
          </thead>
          <tbody>
            ${s.assetsSide.map(item => rowHTML(item, false)).join("")}
            <tr style="background:var(--gold-soft); font-weight:700;">
              <td style="padding:8px 10px; font-size:0.85rem;">Total</td>
              <td style="padding:8px 10px; text-align:right;"><span class="tnum">${fmtINR(s.grandTotal)}</span></td>
            </tr>
          </tbody>
        </table>
      </div>
      <p style="font-size:0.87rem; color:var(--ink-soft); margin-top:14px; line-height:1.65;">${s.explanation}</p>
    </div>
  `;
}

/* ---- Existing quick single-figure checks, kept as a secondary set ---- */
function renderQuickBalanceSheetChecks(panel, data) {
  const filterBar = el("div", "", "");
  filterBar.style.cssText = "display:flex; gap:8px; margin-bottom:18px; flex-wrap:wrap;";
  ["All", "Easy", "Medium", "Hard"].forEach(d => {
    const chip = el("button", `chip ${d === dcBsFilterDifficulty ? "active" : ""}`, d);
    chip.addEventListener("click", () => { dcBsFilterDifficulty = d; renderQuickBalanceSheetChecks(panel, data); });
    filterBar.appendChild(chip);
  });
  panel.innerHTML = "";
  panel.appendChild(filterBar);

  const bank = data.balanceSheetQuestions || [];
  const list = bank.filter(q => dcBsFilterDifficulty === "All" || q.difficulty === dcBsFilterDifficulty);
  const countLabel = el("p", "", `Showing ${list.length} of ${bank.length} questions`);
  countLabel.style.cssText = "font-size:0.83rem; color:var(--ink-faint); margin-bottom:16px;";
  panel.appendChild(countLabel);

  list.forEach(q => panel.appendChild(renderQuestionCard(q, "dc-bs", "Balance Sheet (Ch 2)")));
  applyMobilePager(panel);
  icons();
}

function renderDCPracticeBank(panel, data) {
  const filterBar = el("div", "", "");
  filterBar.style.cssText = "display:flex; gap:8px; margin-bottom:18px; flex-wrap:wrap;";
  ["All", "Easy", "Medium", "Hard"].forEach(d => {
    const chip = el("button", `chip ${d === dcFilterDifficulty ? "active" : ""}`, d);
    chip.addEventListener("click", () => { dcFilterDifficulty = d; renderDCPracticeBank(panel, data); });
    filterBar.appendChild(chip);
  });
  panel.innerHTML = "";
  panel.appendChild(filterBar);
  const list = data.numericals.filter(q => dcFilterDifficulty === "All" || q.difficulty === dcFilterDifficulty);
  const countLabel = el("p", "", `Showing ${list.length} of ${data.numericals.length} transactions`);
  countLabel.style.cssText = "font-size:0.83rem; color:var(--ink-faint); margin-bottom:16px;";
  panel.appendChild(countLabel);
  list.forEach(q => panel.appendChild(renderDCQuestionCard(q)));
  applyMobilePager(panel);
  icons();
}

function renderDCQuestionCard(q) {
  const solvedKey = `dc-${q.id}`;
  const alreadySolved = STATE.solved[solvedKey];
  const card = el("div", "card q-card", "");
  card.innerHTML = `
    <div class="q-meta">
      <span class="diff-badge ${q.difficulty}">${q.difficulty}</span>
      <span class="q-id">Q${q.id}</span>
      ${alreadySolved ? `<span style="margin-left:auto; color:var(--c-dc); font-size:0.78rem; display:flex; align-items:center; gap:4px;"><i data-lucide="check-circle" style="width:13px;height:13px;"></i> Solved</span>` : ""}
    </div>
    <div class="q-body">${q.transaction}</div>
    <div class="q-actions">
      <button class="btn-ghost sm ripple-surface" data-act="hint"><i data-lucide="lightbulb"></i> Hint</button>
      <button class="btn-primary sm ripple-surface" data-act="answer"><i data-lucide="eye"></i> Reveal Classification</button>
      <button class="icon-btn sm" data-act="bookmark" title="Bookmark"><i data-lucide="${STATE.bookmarks.includes(solvedKey) ? 'bookmark-check' : 'bookmark'}"></i></button>
      <button class="btn-ghost sm ripple-surface ask-ai-btn" data-act="ask-ai" title="Ask the AI Tutor about this question"><i data-lucide="bot"></i> Ask AI about this</button>
    </div>
    <div class="reveal-area"></div>
  `;
  const revealArea = $(".reveal-area", card);
  card.addEventListener("click", (e) => {
    const btn = e.target.closest("button[data-act]");
    if (!btn) return;
    const act = btn.dataset.act;
    if (act === "ask-ai") {
      askAIAbout(`I'm stuck on classifying this transaction for Rules of Debit & Credit: "${q.transaction}". Which accounts are involved and why?`, "dc");
      return;
    }
    if (act === "hint") {
      revealArea.innerHTML = `<div class="reveal-block hint-block"><h4>Hint</h4><p style="font-size:0.88rem;">${q.hint}</p></div>`;
    }
    if (act === "answer") {
      const rows = q.accounts.map(a => `
        <tr>
          <td>${a.name}</td>
          <td><span class="diff-badge" style="background:var(--c-dc-soft); color:var(--c-dc);">${a.type}</span></td>
          <td><b style="color:${a.treatment === 'Debit' ? 'var(--c-eq)' : 'var(--flag)'};">${a.treatment}</b></td>
          <td style="font-size:0.83rem; color:var(--ink-soft);">${a.reason}</td>
        </tr>`).join("");
      revealArea.innerHTML = `
        <div class="reveal-block">
          <h4>Classification</h4>
          <table class="ledger-table"><thead><tr><th>Account</th><th>Type</th><th>Treatment</th><th>Why</th></tr></thead><tbody>${rows}</tbody></table>
          <p style="font-size:0.85rem; margin-top:10px;"><b>Modern approach:</b> Debit — ${q.modern.debit}. Credit — ${q.modern.credit}.</p>
          <p style="font-size:0.87rem; color:var(--ink-soft); margin-top:8px;">${q.explanation}</p>
          <div class="self-check" style="margin-top:14px; display:flex; align-items:center; gap:10px; flex-wrap:wrap;">
            <span style="font-size:0.83rem; color:var(--ink-faint);">Did you classify this correctly?</span>
            <button class="btn-ghost sm ripple-surface" data-act="self-correct"><i data-lucide="check"></i> Yes, I got it right</button>
            <button class="btn-ghost sm ripple-surface" data-act="self-wrong"><i data-lucide="x"></i> No, I got it wrong</button>
          </div>
        </div>`;
      icons();
    }
    if (act === "self-correct" || act === "self-wrong") {
      const gotItRight = act === "self-correct";
      STATE.solved[solvedKey] = { correct: gotItRight, attempts: (STATE.solved[solvedKey]?.attempts || 0) + 1 };
      if (gotItRight) {
        saveState(); addXP(4, `Classified Q${q.id}`); logActivity(`Classified Debit & Credit Q${q.id} (${q.difficulty})`);
        mistakeBookRecordCorrect(solvedKey);
      } else {
        if (!STATE.mistakes.includes(solvedKey)) STATE.mistakes.push(solvedKey);
        saveState();
        mistakeBookRecord({
          key: solvedKey, question: q.transaction, chapter: "dc", chapterLabel: "Debit & Credit",
          topic: "Debit & Credit Classification", type: "Practice Bank (self-assessed)",
          studentAnswer: "Marked as incorrect by student",
          correctAnswer: `Modern approach — Debit: ${q.modern.debit}. Credit: ${q.modern.credit}.`,
          explanation: q.explanation
        });
      }
      refreshProgress();
      const selfCheckEl = $(".self-check", revealArea);
      if (selfCheckEl) selfCheckEl.innerHTML = gotItRight
        ? `<span style="font-size:0.83rem; color:var(--c-dc);"><i data-lucide="check-circle" style="width:14px;height:14px; vertical-align:-2px;"></i> Marked correct — nice work!</span>`
        : `<span style="font-size:0.83rem; color:var(--flag);"><i data-lucide="alert-circle" style="width:14px;height:14px; vertical-align:-2px;"></i> Added to your Mistake Book for review.</span>`;
      icons();
    }
    if (act === "bookmark") {
      const idx = STATE.bookmarks.indexOf(solvedKey);
      if (idx >= 0) { STATE.bookmarks.splice(idx, 1); btn.querySelector("i").setAttribute("data-lucide", "bookmark"); }
      else { STATE.bookmarks.push(solvedKey); btn.querySelector("i").setAttribute("data-lucide", "bookmark-check"); }
      saveState(); icons();
    }
    icons();
  });
  return card;
}

/* ---------------------------------------------------------
   6c. CHAPTER 3 — JOURNAL (full build)
   --------------------------------------------------------- */
let jrFilterDifficulty = "All";

function renderJournalChapter(root) {
  const data = APP_DATA.journal;
  root.appendChild(el("div", "hero", `
    <span class="hero-eyebrow">Chapter 3</span>
    <h1>Journal</h1>
    <p>${APP_DATA.chapters[2].tagline}. Master the journal format, then write out 36 original entries — including compound entries and discount/dishonour cases.</p>
  `));

  const tabs = ["Theory", "Concepts", "Mind Map", "Entry Generator", "Ledger Posting", "Practice Bank"];
  const tabBar = el("div", "", "");
  tabBar.style.cssText = "display:flex; gap:8px; flex-wrap:wrap; margin-bottom:22px;";
  tabs.forEach((t, i) => {
    const chip = el("button", `chip ${i===0?'active':''}`, t);
    chip.dataset.tab = t;
    tabBar.appendChild(chip);
  });
  const journeyEl = renderJourneyStepper(root, "jr");
  root.appendChild(tabBar);
  const panel = el("div", "");
  root.appendChild(panel);

  function showTab(name) {
    $all(".chip", tabBar).forEach(c => c.classList.toggle("active", c.dataset.tab === name));
    panel.innerHTML = "";
    updateJourneyStepper(journeyEl, "jr", name);
    if (name === "Theory") renderGenericTheory(panel, data, "jr");
    if (name === "Concepts") renderGenericConcepts(panel, data, "jr");
    if (name === "Mind Map") renderMindMap(panel, "jr");
    if (name === "Entry Generator") renderJournalEntryGenerator(panel, data);
    if (name === "Ledger Posting") renderLedgerPosting(panel, data);
    if (name === "Practice Bank") renderJRPracticeBank(panel, data);
    icons();
  }
  tabBar.addEventListener("click", e => {
    const chip = e.target.closest(".chip");
    if (chip) showTab(chip.dataset.tab);
  });
  showTab("Theory");
}

/* ---- JOURNAL ENTRY GENERATOR (new Chapter 3 section) ----
   A rule-based matcher: the student types any transaction in
   plain English, and this looks for the best-matching pattern
   from APP_DATA.journalEntryPatterns (keyword overlap scoring),
   pulls out the amount and, where needed, a proper-noun name,
   and renders the resulting journal entry. Being static-site
   pattern matching rather than a real language model, it's
   upfront when it can't confidently match anything, rather
   than guessing and presenting a wrong entry as certain. */
/* ---------------------------------------------------------
   2c. GOODS TRANSACTION CALCULATOR — a genuine rule-based engine,
   not a lookup table. Given a cost/list price plus any combination
   of profit %, trade discount %, and cash discount %, it derives
   Selling Price, Invoice Value, and the cash actually paid/received
   algebraically, then builds the correct compound journal entry.
   Works for any percentage — 5%, 7.5%, 33.33%, whatever is typed in.
   --------------------------------------------------------- */
function computeGoodsTransaction(p) {
  // p: { txnType: 'sale'|'purchase', basePrice, profitPct, profitBasis: 'cost'|'sp'|'none',
  //      tradeDiscountPct, cashDiscountPct, paymentMode: 'cash'|'credit'|'part', partCashPct, partyName }
  const round2 = (n) => Math.round(n * 100) / 100;
  const workings = [];
  const base = Number(p.basePrice) || 0;

  // Step 1 — Selling Price (sale side only; a purchase's stated price IS the list price)
  let sp = base;
  if (p.txnType === "sale" && p.profitBasis !== "none" && p.profitPct > 0) {
    if (p.profitBasis === "cost") {
      sp = base * (1 + p.profitPct / 100);
      workings.push(`Selling Price = Cost + ${p.profitPct}% of Cost = ₹${fmtNum(base)} + ₹${fmtNum(sp - base)} = ₹${fmtNum(sp)}`);
    } else {
      sp = base / (1 - p.profitPct / 100);
      workings.push(`Selling Price = Cost ÷ (1 − ${p.profitPct}%) = ₹${fmtNum(base)} ÷ ${round2(1 - p.profitPct / 100)} = ₹${fmtNum(sp)}`);
    }
  } else if (p.txnType === "sale") {
    workings.push(`Selling Price = List Price = ₹${fmtNum(sp)} (no profit % given)`);
  } else {
    workings.push(`List Price = ₹${fmtNum(sp)}`);
  }

  // Step 2 — Trade Discount (always deducted before any entry is made; never journalised on its own)
  let invoiceValue = sp;
  let tradeDiscountAmt = 0;
  if (p.tradeDiscountPct > 0) {
    tradeDiscountAmt = round2(sp * p.tradeDiscountPct / 100);
    invoiceValue = round2(sp - tradeDiscountAmt);
    workings.push(`Trade Discount = ${p.tradeDiscountPct}% of ₹${fmtNum(sp)} = ₹${fmtNum(tradeDiscountAmt)} → Invoice Value = ₹${fmtNum(sp)} − ₹${fmtNum(tradeDiscountAmt)} = ₹${fmtNum(invoiceValue)}`);
  } else {
    invoiceValue = round2(sp);
  }

  // Step 3 — split cash vs credit portion of the invoice value
  let cashPortion = 0, creditPortion = 0;
  if (p.paymentMode === "cash") cashPortion = invoiceValue;
  else if (p.paymentMode === "credit") creditPortion = invoiceValue;
  else { // part
    const pct = Math.min(Math.max(Number(p.partCashPct) || 0, 0), 100);
    cashPortion = round2(invoiceValue * pct / 100);
    creditPortion = round2(invoiceValue - cashPortion);
    workings.push(`Payment split: ${pct}% received now = ₹${fmtNum(cashPortion)}; remaining on credit = ₹${fmtNum(creditPortion)}`);
  }

  // Step 4 — Cash Discount applies only to the cash-settled portion, at the moment of payment
  let cashDiscountAmt = 0, netCash = cashPortion;
  if (p.cashDiscountPct > 0 && cashPortion > 0) {
    cashDiscountAmt = round2(cashPortion * p.cashDiscountPct / 100);
    netCash = round2(cashPortion - cashDiscountAmt);
    workings.push(`Cash Discount = ${p.cashDiscountPct}% of ₹${fmtNum(cashPortion)} (the cash-settled portion) = ₹${fmtNum(cashDiscountAmt)} → Net cash = ₹${fmtNum(netCash)}`);
  }

  const name = (p.partyName || "").trim() || "the party";
  const lines = [];
  if (p.txnType === "sale") {
    if (netCash > 0) lines.push({ label: "Cash/Bank A/c", dr: netCash });
    if (cashDiscountAmt > 0) lines.push({ label: "Discount Allowed A/c", dr: cashDiscountAmt });
    if (creditPortion > 0) lines.push({ label: `${name}'s A/c`, dr: creditPortion });
    lines.push({ label: "Sales A/c", cr: invoiceValue });
  } else {
    lines.push({ label: "Purchases A/c", dr: invoiceValue });
    if (netCash > 0) lines.push({ label: "Cash/Bank A/c", cr: netCash });
    if (cashDiscountAmt > 0) lines.push({ label: "Discount Received A/c", cr: cashDiscountAmt });
    if (creditPortion > 0) lines.push({ label: `${name}'s A/c`, cr: creditPortion });
  }

  const narrationParts = [];
  if (p.txnType === "sale") narrationParts.push(`goods sold`); else narrationParts.push(`goods purchased`);
  if (p.profitPct > 0 && p.txnType === "sale") narrationParts.push(`at ${p.profitPct}% profit on ${p.profitBasis === "sp" ? "selling price" : "cost"}`);
  if (p.tradeDiscountPct > 0) narrationParts.push(`less ${p.tradeDiscountPct}% trade discount`);
  if (p.cashDiscountPct > 0) narrationParts.push(`${p.cashDiscountPct}% cash discount allowed/received on prompt payment`);

  return {
    sp: round2(sp), invoiceValue, cashPortion, creditPortion, cashDiscountAmt, netCash,
    lines, workings, narration: `(Being ${narrationParts.join(", ")})`
  };
}
function fmtNum(n) {
  const r = Math.round(n * 100) / 100;
  return r % 1 === 0 ? r.toLocaleString("en-IN") : r.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function extractAmount(text) {
  // Matches "₹15,000", "Rs 15000", "15,000", "15000" — first number-like token found
  const match = text.match(/(?:₹|rs\.?\s*)?[\d][\d,]*(?:\.\d+)?/i);
  if (!match) return null;
  const num = parseFloat(match[0].replace(/[₹,]/gi, "").replace(/rs\.?/gi, "").trim());
  return isNaN(num) ? null : num;
}

function extractName(text) {
  // Looks for a capitalized word that isn't a common accounting term or
  // generic sentence-starter — a rough heuristic for "Suresh", "Meera
  // Traders", etc. Deliberately does NOT skip the first word: a name is
  // often the very first word ("Shyam became insolvent...").
  const commonWords = new Set(["Cash","Bank","Rent","Salary","Sold","Paid","Received","Purchased","Goods","Credit","The","A","An","Furniture","Machinery","Loan","Interest","Discount","Depreciation","Insurance","Started","Business","Old","Book","Value","Full","Settlement","Bill","Balance","Bought","Cheque","Advance","Later","Compensation","Amount","Commission","Payment","Official","Receiver","Computer","Building","Deposited","Withdrew","Issued","Given","Introduced","Sent","Supplied","Placed","Charged","Made","Returned","Gave","Took","Transferred"]);
  const words = text.split(/\s+/);
  for (let i = 0; i < words.length; i++) {
    const w = words[i].replace(/[^a-zA-Z]/g, "");
    if (w.length > 2 && /^[A-Z]/.test(w) && !commonWords.has(w)) {
      return w;
    }
  }
  return "the party";
}

/* Common alternate phrasings mapped onto the single term each pattern's
   keyword list actually checks for. Runs as a normalization pass before
   matching, so patterns themselves stay simple — new synonyms are added
   here in one place rather than edited into every affected pattern. */
const JOURNAL_SYNONYMS = [
  [/\bbought\b/gi, "purchased"],
  [/\bgot\b/gi, "received"],
  [/\bgave\b/gi, "paid"],
  [/\btook\b(?!\s+goods)/gi, "withdrew"],
  [/\bspent\b/gi, "paid"],
  [/\bearned\b/gi, "received"],
  [/\bfor own use\b/gi, "for personal use"],
  [/\bhis own use\b/gi, "personal use"],
  [/\bstarted (a |the )?business\b/gi, "started business"],
  [/\bcommenced business\b/gi, "started business"],
  [/\bpurchases?\b(?! a\/c)/gi, "purchased"],
  [/\bcheque\b/gi, "cheque bank"] // cheque implies bank, so surfaces bank-flavoured pattern text if needed later
];

function normalizeTransactionText(text) {
  let out = text;
  JOURNAL_SYNONYMS.forEach(([pattern, replacement]) => { out = out.replace(pattern, replacement); });
  return out;
}

/* ---------------------------------------------------------
   2d. COMPOUND ENTRY ENGINE — for transaction types that
   genuinely need more than one extracted number or more than
   2 output lines (asset sale at profit/loss, part-cash-part-
   credit purchases, full settlement with discount, travelling
   advance adjustment, insurance claims admitted at a %, and
   opening entries). The simple matchJournalPattern() below this
   stays 2-line-only by design — forcing those cases through it
   risked showing a balanced-looking but WRONG number, since a
   single extracted amount can't represent (say) both a book
   value and a sale price. This engine extracts the numbers it
   actually needs and returns null (never a guess) if it can't
   find them confidently.
   --------------------------------------------------------- */
function extractAllAmounts(text) {
  const cleaned = text.replace(/\d+(?:\.\d+)?\s*%/g, "").replace(/\d+(?:\.\d+)?\s*paise/gi, ""); // exclude percentages and paise figures
  const matches = cleaned.match(/(?:₹|rs\.?\s*)?[\d][\d,]*(?:\.\d+)?/gi) || [];
  return matches
    .map(m => parseFloat(m.replace(/[₹,]/gi, "").replace(/rs\.?/gi, "").trim()))
    .filter(n => !isNaN(n));
}
function extractPercent(text) {
  const m = text.match(/(\d+(?:\.\d+)?)\s*%/);
  return m ? parseFloat(m[1]) : null;
}
function extractPaise(text) {
  const m = text.match(/(\d+(?:\.\d+)?)\s*paise/i);
  return m ? parseFloat(m[1]) : null;
}
// Finds the number closest by character distance to a keyword — more
// reliable than a fixed window, which can accidentally grab a nearby
// but unrelated figure (e.g. an earlier clause's amount).
function extractNear(keyword, text) {
  const lower = text.toLowerCase();
  const kwIdx = lower.indexOf(keyword.toLowerCase());
  if (kwIdx === -1) return null;
  const kwEnd = kwIdx + keyword.length;
  const numRegex = /(?:₹|rs\.?\s*)?[\d][\d,]*(?:\.\d+)?(?!\s*%)/gi;
  let m, best = null, bestDist = Infinity;
  while ((m = numRegex.exec(text)) !== null) {
    const val = parseFloat(m[0].replace(/[₹,]/gi, "").replace(/rs\.?/gi, "").trim());
    if (isNaN(val)) continue;
    const dist = m.index >= kwEnd ? (m.index - kwEnd) : (kwIdx - (m.index + m[0].length));
    if (dist >= 0 && dist < bestDist) { bestDist = dist; best = val; }
  }
  return best;
}
function paidMethod(text) { return text.toLowerCase().includes("cheque") ? "Bank A/c" : "Cash A/c"; }

// General "expense due/outstanding" — works for any expense noun (rent,
// salary, wages, commission, interest, etc.), not one hardcoded per type.
const EXPENSE_WORDS = ["rent", "salary", "salaries", "wages", "interest", "commission", "electricity", "telephone", "insurance", "carriage"];
function handleOutstandingExpense(text) {
  const lower = text.toLowerCase();
  if (!lower.includes("due") && !lower.includes("outstanding")) return null;
  if (lower.includes("settlement") || lower.includes("insolvent") || lower.includes("paise") || lower.includes("account") || lower.includes("dues")) return null;
  const expense = EXPENSE_WORDS.find(w => lower.includes(w));
  if (!expense) return null;
  const amt = extractNear(expense, text);
  if (amt === null) return null;
  let title = expense.charAt(0).toUpperCase() + expense.slice(1);
  if (title === "Salaries") title = "Salary";
  return { lines: [[`${title} A/c`, amt, null], [`To Outstanding ${title} A/c`, null, amt]],
    narration: `Being ${title.toLowerCase()} due but not yet paid` };
}
function handleClaimPercent(text) {
  const lower = text.toLowerCase();
  if (!lower.includes("claim") || !lower.includes("admitted")) return null;
  const pct = extractPercent(text);
  if (pct === null) return null;
  const loss = extractNear("loss", text);
  if (loss === null) return null;
  const claim = Math.round(loss * pct) / 100;
  return { lines: [["Insurance Claim A/c", claim, null], ["To Loss by Fire A/c", null, claim]],
    narration: `Being insurance claim admitted at ${pct}% of the loss, in full and final settlement` };
}
function handleAssetSale(text) {
  const lower = text.toLowerCase();
  if (!lower.includes("sold") || !lower.includes("book value")) return null;
  let asset = null;
  ["machinery", "furniture", "computer", "building", "vehicle"].forEach(a => { if (lower.includes(a) && !asset) asset = a; });
  if (!asset) return null;
  const bookValue = extractNear("book value", text);
  if (bookValue === null) return null;
  const saleValue = extractAllAmounts(text).find(a => a !== bookValue);
  if (saleValue === undefined) return null;
  const isCredit = lower.includes(" credit") || / to [A-Z]/.test(text);
  const name = isCredit ? extractName(text) : null;
  const diff = saleValue - bookValue;
  const assetTitle = asset.charAt(0).toUpperCase() + asset.slice(1);
  const debitLabel = isCredit ? `${name}'s A/c` : paidMethod(text);
  const lines = [[debitLabel, saleValue, null]];
  if (diff < 0) lines.push([`Loss on Sale of ${assetTitle} A/c`, -diff, null]);
  lines.push([`To ${assetTitle} A/c`, null, bookValue]);
  if (diff > 0) lines.push([`To Gain (Profit) on Sale of ${assetTitle} A/c`, null, diff]);
  return { lines, narration: `Being old ${asset} sold ${isCredit ? "on credit" : "for cash"} at a ${diff >= 0 ? "profit" : "loss"}` };
}
function handleAssetPartPayment(text) {
  const lower = text.toLowerCase();
  if ((!lower.includes("purchased") && !lower.includes("bought")) || !lower.includes("balance")) return null;
  if (extractPercent(text) !== null) return null; // percentage-based split is handleAssetPercentSplit's job
  let asset = null;
  ["machinery", "furniture", "computer", "building"].forEach(a => { if (lower.includes(a) && !asset) asset = a; });
  if (!asset) return null;
  const amts = extractAllAmounts(text);
  if (amts.length < 2) return null;
  const total = amts[0], immediate = amts[1], balance = total - immediate;
  if (balance <= 0) return null;
  const assetTitle = asset.charAt(0).toUpperCase() + asset.slice(1);
  return { lines: [[`${assetTitle} A/c`, total, null], [`To ${paidMethod(text)}`, null, immediate], ["To Supplier's A/c", null, balance]],
    narration: `Being ${asset} purchased, part paid immediately and balance on credit` };
}
// Handles the case (Bug 1) where the split is given as a percentage rather
// than two absolute amounts — "paying 60% by cheque immediately" — no
// "balance" keyword needed, since the remaining % is implicitly the rest.
function handleAssetPercentSplit(text) {
  const lower = text.toLowerCase();
  if (!lower.includes("purchased") && !lower.includes("bought")) return null;
  let asset = null;
  ["computer", "machinery", "furniture", "building"].forEach(a => { if (lower.includes(a) && !asset) asset = a; });
  if (!asset) return null;
  const pct = extractPercent(text);
  if (pct === null || pct <= 0 || pct >= 100) return null;
  const amts = extractAllAmounts(text);
  if (!amts.length) return null;
  const total = amts[0];
  const immediate = Math.round(total * pct) / 100;
  const balance = total - immediate;
  const assetTitle = asset.charAt(0).toUpperCase() + asset.slice(1);
  return { lines: [[`${assetTitle} A/c`, total, null], [`To ${paidMethod(text)}`, null, immediate], [`To ${assetTitle} Supplier's A/c`, null, balance]],
    narration: `Being ${asset} purchased, ${pct}% paid immediately and balance on credit` };
}
function handleSettlement(text) {
  const lower = text.toLowerCase();
  if (!lower.includes("settlement")) return null;
  if (extractPercent(text) !== null) return null; // percentage-discount settlement is handleSettlementPercent's job
  const amts = extractAllAmounts(text);
  if (amts.length < 2) return null;
  const paidOrReceived = amts[0];
  const due = amts.find(a => a > paidOrReceived);
  if (due === undefined) return null;
  const discount = due - paidOrReceived;
  if (discount <= 0) return null;
  const name = extractName(text);
  const method = paidMethod(text);
  const isReceipt = lower.includes("received") && lower.indexOf("received") < lower.indexOf("settlement");
  if (isReceipt) {
    return { lines: [[method, paidOrReceived, null], ["Discount Allowed A/c", discount, null], [`To ${name}'s A/c`, null, due]],
      narration: `Being cash/cheque received from ${name} in full settlement, discount allowed` };
  }
  return { lines: [[`${name}'s A/c`, due, null], [`To ${method}`, null, paidOrReceived], ["To Discount Received A/c", null, discount]],
    narration: `Being cash/cheque paid to ${name} in full settlement, discount received` };
}
// Handles settlement expressed as a single net figure plus a discount
// PERCENTAGE (rather than two absolute amounts) — the original amount due
// has to be reverse-calculated: due = net / (1 - discount%).
function handleSettlementPercent(text) {
  const lower = text.toLowerCase();
  if (!lower.includes("settlement") && !lower.includes("dues")) return null;
  const pct = extractPercent(text);
  if (pct === null || pct <= 0 || pct >= 100) return null;
  const amts = extractAllAmounts(text);
  if (!amts.length) return null;
  const net = amts[0];
  const due = Math.round((net / (1 - pct / 100)) * 100) / 100;
  const discount = Math.round((due - net) * 100) / 100;
  if (discount <= 0) return null;
  const name = extractName(text);
  const method = paidMethod(text);
  const isPaid = lower.indexOf("paid") !== -1 && (lower.indexOf("settlement") === -1 || lower.indexOf("paid") < lower.indexOf("settlement"));
  if (isPaid) {
    return { lines: [[`${name}'s A/c`, due, null], [`To ${method}`, null, net], ["To Discount Received A/c", null, discount]],
      narration: `Being cash/cheque paid to ${name} in full settlement, ${pct}% discount received` };
  }
  return { lines: [[method, net, null], ["Discount Allowed A/c", discount, null], [`To ${name}'s A/c`, null, due]],
    narration: `Being cash/cheque received from ${name} in full settlement, ${pct}% discount allowed` };
}
// Purchase or sale of goods settled immediately (cash/cheque) with a plain
// cash-discount percentage — distinct from the Calculator's trade-discount
// math, and distinct from handleSettlement (which is for settling an
// *existing* debtor/creditor balance, not a fresh goods transaction).
function handlePurchaseSaleDiscountPercent(text) {
  const lower = text.toLowerCase();
  const isPurchase = lower.includes("purchased") || lower.includes("bought");
  const isSale = lower.includes("sold");
  if (!isPurchase && !isSale) return null;
  if (!lower.includes("goods")) return null;
  if (lower.includes("trade discount")) return null;
  // "Conditional discount forfeited" is a different concept entirely — the
  // % here describes a *partial payment split*, not a cash-discount rate,
  // and applying this handler's straightforward math would be wrong.
  if (lower.includes("condition") || lower.includes("within") || /no\s+(cash\s+)?discount/.test(lower) || lower.includes("not allowed")) return null;
  const pct = extractPercent(text);
  if (pct === null || pct <= 0 || pct >= 100) return null;
  const amts = extractAllAmounts(text);
  if (!amts.length) return null;
  const invoiceValue = amts[0];
  const discount = Math.round(invoiceValue * pct) / 100;
  const net = invoiceValue - discount;
  const method = paidMethod(text);
  const methodWord = method === "Bank A/c" ? "cheque" : "cash";
  if (isPurchase) {
    return { lines: [["Purchases A/c", invoiceValue, null], [`To ${method}`, null, net], ["To Discount Received A/c", null, discount]],
      narration: `Being goods purchased against ${methodWord}, ${pct}% cash discount availed` };
  }
  return { lines: [[method, net, null], ["Discount Allowed A/c", discount, null], ["To Sales A/c", null, invoiceValue]],
    narration: `Being goods sold against ${methodWord}, ${pct}% cash discount allowed` };
}
// General insolvency at "X paise in the rupee" — works for any paise value
// and any amount due, not just the one specific case that happened to be
// pre-written into the numericals.
function handleInsolvencyPaise(text) {
  const lower = text.toLowerCase();
  if (!lower.includes("insolvent")) return null;
  const paise = extractPaise(text);
  if (paise === null) return null;
  const due = extractNear("due", text) ?? extractNear("owed", text);
  if (due === null) return null;
  const received = Math.round(due * paise) / 100;
  const badDebt = due - received;
  if (badDebt < 0) return null;
  const name = extractName(text);
  return { lines: [["Cash/Bank A/c", received, null], ["Bad Debts A/c", badDebt, null], [`To ${name}'s A/c`, null, due]],
    narration: `Being ${paise} paise in the rupee received on ${name}'s insolvency, balance written off as bad debt` };
}
function handleTravelAdvance(text) {
  const lower = text.toLowerCase();
  if (!lower.includes("advance") || !lower.includes("travel") || !lower.includes("bill")) return null;
  const advance = extractNear("advance", text);
  const bill = extractNear("bill", text);
  if (advance === null || bill === null) return null;
  const diff = advance - bill;
  if (diff > 0) return { lines: [["Travelling Expenses A/c", bill, null], ["Cash A/c", diff, null], ["To Travelling Advance A/c", null, advance]],
    narration: "Being travelling expenses adjusted against advance, balance refunded in cash" };
  return { lines: [["Travelling Expenses A/c", bill, null], ["To Cash A/c", null, -diff], ["To Travelling Advance A/c", null, advance]],
    narration: "Being travelling expenses adjusted against advance, extra amount paid in cash" };
}
const OPEN_LIABILITY = [["bank loan", "Bank Loan A/c"], ["creditors", "Creditors A/c"], ["loan", "Loan A/c"]];
const OPEN_ASSET = [["cash", "Cash A/c"], ["bank balance", "Bank A/c"], ["bank", "Bank A/c"], ["stock", "Stock A/c"], ["furniture", "Furniture A/c"], ["debtors", "Debtors A/c"], ["machinery", "Machinery A/c"], ["building", "Building A/c"], ["computer", "Computer A/c"], ["goods", "Purchases A/c"]];
function handleOpeningEntry(text) {
  const lower = text.toLowerCase();
  if (!lower.includes("started business") && !lower.includes("balances")) return null;
  // Split into clauses on ; or , — but never on a comma that's really a
  // thousands separator (the ',' inside "20,000"), or "20,000" would get
  // sliced into "20" and "000".
  const clauses = text.split(/;|,(?!\d{3}(?:\D|$))/).map(s => s.trim()).filter(Boolean);
  const assets = [], liabilities = [];
  clauses.forEach(clause => {
    const cLower = clause.toLowerCase();
    const rupeeMatch = clause.match(/₹[\d][\d,]*(?:\.\d+)?/);
    const amt = rupeeMatch ? parseFloat(rupeeMatch[0].replace(/[₹,]/g, "")) : extractAllAmounts(clause)[0];
    if (amt === undefined || isNaN(amt)) return;
    const liab = OPEN_LIABILITY.find(([kw]) => cLower.includes(kw));
    if (liab) { liabilities.push([liab[1], amt]); return; }
    const asset = OPEN_ASSET.find(([kw]) => cLower.includes(kw));
    if (asset) assets.push([asset[1], amt]);
  });
  if (assets.length < 2) return null;
  const totalA = assets.reduce((s, [, a]) => s + a, 0), totalL = liabilities.reduce((s, [, a]) => s + a, 0);
  const capital = totalA - totalL;
  if (capital <= 0) return null;
  const lines = [...assets.map(([l, a]) => [l, a, null]), ...liabilities.map(([l, a]) => [`To ${l}`, null, a]), ["To Capital A/c", null, capital]];
  return { lines, narration: "Being balances of assets and liabilities brought forward" };
}
const COMPOUND_HANDLERS = [handleClaimPercent, handleAssetSale, handleAssetPercentSplit, handleAssetPartPayment, handleSettlementPercent, handleSettlement, handlePurchaseSaleDiscountPercent, handleInsolvencyPaise, handleTravelAdvance, handleOpeningEntry, handleOutstandingExpense];
function matchCompoundPattern(text) {
  for (const h of COMPOUND_HANDLERS) {
    const result = h(text);
    if (result) return result;
  }
  return null;
}

function matchJournalPattern(inputText) {
  const lower = normalizeTransactionText(inputText).toLowerCase();
  const patterns = APP_DATA.journalEntryPatterns;
  let best = null, bestScore = 0;
  patterns.forEach(p => {
    const hasAllKeywords = p.keywords.every(kw => lower.includes(kw.toLowerCase()));
    if (!hasAllKeywords) return;
    const hasExcluded = (p.notKeywords || []).some(kw => lower.includes(kw.toLowerCase()));
    if (hasExcluded) return;
    const score = p.keywords.length + (p.notKeywords ? 0.5 : 0); // more specific patterns (more keywords, or with exclusions) win ties
    if (score > bestScore) { bestScore = score; best = p; }
  });
  return best;
}

function renderJournalEntryGenerator(panel, data) {
  panel.appendChild(sectionTitle("Journal entry generator"));
  const hint = el("p", "", "Use the calculator for goods transactions involving profit, trade discount, and cash discount at any percentage.");
  hint.style.cssText = "font-size:0.85rem; color:var(--ink-faint); margin:-8px 0 18px; line-height:1.6;";
  panel.appendChild(hint);

  const textCard = el("div", "card-solid", "");
  textCard.style.cssText = "padding:26px; display:none;";
  textCard.innerHTML = `
    <div class="field-group">
      <label>Describe the transaction</label>
      <textarea id="jegInput" class="field-input" style="min-height:80px; font-family:var(--font-body); resize:vertical;" placeholder="e.g. Paid rent ₹5,000 in cash&#10;e.g. Sold goods on credit to Meera ₹18,000&#10;e.g. Purchased furniture for cash ₹15,000"></textarea>
    </div>
    <button class="btn-primary ripple-surface" id="jegGenerateBtn"><i data-lucide="wand-2"></i> Generate Journal Entry</button>
    <div id="jegResult" style="margin-top:18px;"></div>
    <div style="margin-top:20px;">
      <p style="font-size:0.78rem; text-transform:uppercase; letter-spacing:0.04em; color:var(--ink-faint); margin-bottom:8px;">Try one of these</p>
      <div id="jegExamples" style="display:flex; flex-wrap:wrap; gap:8px;"></div>
    </div>
  `;
  panel.appendChild(textCard);

  const calcCard = el("div", "card-solid", "");
  calcCard.style.cssText = "padding:26px;";
  calcCard.innerHTML = `
    <p style="font-size:0.85rem; color:var(--ink-soft); margin:0 0 18px; line-height:1.6;">Enter any figures — this actually calculates Selling Price, Invoice Value, and cash discount algebraically (works for 5%, 7.5%, 33⅓%, anything), then builds the correct compound entry. It doesn't look up a stored answer.</p>
    <div class="field-group">
      <label>Transaction</label>
      <div style="display:flex; gap:8px;">
        <button class="chip active" id="jegTxnSale">Sale of goods</button>
        <button class="chip" id="jegTxnPurchase">Purchase of goods</button>
      </div>
    </div>
    <div class="field-group">
      <label id="jegBaseLabel">Cost Price (₹)</label>
      <input type="number" id="jegBasePrice" class="field-input" placeholder="e.g. 3600" min="0" step="0.01">
    </div>
    <div class="field-group" id="jegProfitGroup">
      <label>Profit % (leave blank if none)</label>
      <div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center;">
        <input type="number" id="jegProfitPct" class="field-input" style="max-width:120px;" placeholder="e.g. 20" min="0" step="0.01">
        <button class="chip active" id="jegProfitOnCost">on Cost</button>
        <button class="chip" id="jegProfitOnSP">on Selling Price</button>
      </div>
    </div>
    <div class="field-group">
      <label>Trade Discount % (leave blank if none)</label>
      <input type="number" id="jegTradeDisc" class="field-input" style="max-width:120px;" placeholder="e.g. 10" min="0" max="100" step="0.01">
    </div>
    <div class="field-group">
      <label>Payment</label>
      <div style="display:flex; gap:8px; flex-wrap:wrap;">
        <button class="chip active" id="jegPayCash">Full — immediately</button>
        <button class="chip" id="jegPayCredit">Full — on credit</button>
        <button class="chip" id="jegPayPart">Part cash, part credit</button>
      </div>
    </div>
    <div class="field-group" id="jegPartGroup" style="display:none;">
      <label>% received immediately</label>
      <input type="number" id="jegPartPct" class="field-input" style="max-width:120px;" placeholder="e.g. 50" min="0" max="100" step="0.01">
    </div>
    <div class="field-group" id="jegCashDiscGroup">
      <label>Cash Discount % on the immediate portion (leave blank if none)</label>
      <input type="number" id="jegCashDisc" class="field-input" style="max-width:120px;" placeholder="e.g. 5" min="0" max="100" step="0.01">
    </div>
    <div class="field-group" id="jegNameGroup" style="display:none;">
      <label>Party name</label>
      <input type="text" id="jegPartyName" class="field-input" placeholder="e.g. Suresh">
    </div>
    <button class="btn-primary ripple-surface" id="jegCalcBtn"><i data-lucide="calculator"></i> Calculate &amp; Generate</button>
    <div id="jegCalcResult" style="margin-top:18px;"></div>
  `;
  panel.appendChild(calcCard);

  // --- Calculator mode wiring ---
  let calcState = { txnType: "sale", profitBasis: "cost", paymentMode: "cash" };
  $("#jegTxnSale", calcCard).addEventListener("click", () => {
    calcState.txnType = "sale";
    $("#jegTxnSale", calcCard).classList.add("active"); $("#jegTxnPurchase", calcCard).classList.remove("active");
    $("#jegBaseLabel", calcCard).textContent = "Cost Price (₹)";
    $("#jegProfitGroup", calcCard).style.display = "";
    $("#jegNameGroup", calcCard).style.display = calcState.paymentMode === "credit" || calcState.paymentMode === "part" ? "" : "none";
  });
  $("#jegTxnPurchase", calcCard).addEventListener("click", () => {
    calcState.txnType = "purchase";
    $("#jegTxnPurchase", calcCard).classList.add("active"); $("#jegTxnSale", calcCard).classList.remove("active");
    $("#jegBaseLabel", calcCard).textContent = "List Price (₹)";
    $("#jegProfitGroup", calcCard).style.display = "none";
  });
  $("#jegProfitOnCost", calcCard).addEventListener("click", () => {
    calcState.profitBasis = "cost";
    $("#jegProfitOnCost", calcCard).classList.add("active"); $("#jegProfitOnSP", calcCard).classList.remove("active");
  });
  $("#jegProfitOnSP", calcCard).addEventListener("click", () => {
    calcState.profitBasis = "sp";
    $("#jegProfitOnSP", calcCard).classList.add("active"); $("#jegProfitOnCost", calcCard).classList.remove("active");
  });
  function setPayMode(mode) {
    calcState.paymentMode = mode;
    ["jegPayCash", "jegPayCredit", "jegPayPart"].forEach(id => $("#" + id, calcCard).classList.remove("active"));
    $("#jegPay" + (mode === "cash" ? "Cash" : mode === "credit" ? "Credit" : "Part"), calcCard).classList.add("active");
    $("#jegPartGroup", calcCard).style.display = mode === "part" ? "" : "none";
    $("#jegCashDiscGroup", calcCard).style.display = mode === "credit" ? "none" : "";
    $("#jegNameGroup", calcCard).style.display = (mode === "credit" || mode === "part") ? "" : "none";
  }
  $("#jegPayCash", calcCard).addEventListener("click", () => setPayMode("cash"));
  $("#jegPayCredit", calcCard).addEventListener("click", () => setPayMode("credit"));
  $("#jegPayPart", calcCard).addEventListener("click", () => setPayMode("part"));

  $("#jegCalcBtn", calcCard).addEventListener("click", () => {
    const basePrice = parseFloat($("#jegBasePrice", calcCard).value);
    const resultBox = $("#jegCalcResult", calcCard);
    if (!basePrice || basePrice <= 0) {
      resultBox.innerHTML = `<div class="reveal-block" style="background:var(--flag-soft); border-left-color:var(--flag);"><p style="font-size:0.87rem;">Enter a price to calculate from.</p></div>`;
      playErrorSound();
      return;
    }
    const res = computeGoodsTransaction({
      txnType: calcState.txnType,
      basePrice,
      profitPct: parseFloat($("#jegProfitPct", calcCard).value) || 0,
      profitBasis: calcState.profitBasis,
      tradeDiscountPct: parseFloat($("#jegTradeDisc", calcCard).value) || 0,
      cashDiscountPct: parseFloat($("#jegCashDisc", calcCard).value) || 0,
      paymentMode: calcState.paymentMode,
      partCashPct: parseFloat($("#jegPartPct", calcCard).value) || 0,
      partyName: $("#jegPartyName", calcCard).value
    });
    const rows = res.lines.map((l, i) => {
      const isCredit = l.cr !== undefined;
      const indent = (res.txnType !== "sale" && i > 0) || (res.lines[0] && l !== res.lines[0] && isCredit) ? "padding-left:24px;" : "";
      return `<tr>
        <td style="font-family:var(--font-body); ${l.dr === undefined ? 'padding-left:24px;' : ''}">${l.dr !== undefined ? l.label + " Dr." : "To " + l.label}</td>
        <td class="tnum" style="text-align:right;">${l.dr !== undefined ? fmtINR(l.dr) : ""}</td>
        <td class="tnum" style="text-align:right;">${l.cr !== undefined ? fmtINR(l.cr) : ""}</td>
      </tr>`;
    }).join("");
    resultBox.innerHTML = `
      <div class="reveal-block">
        <h4>Calculated journal entry</h4>
        <table class="ledger-table" style="margin-top:8px;">
          <tbody>${rows}</tbody>
        </table>
        <p style="font-size:0.85rem; color:var(--ink-soft); margin-top:10px; font-style:italic;">${res.narration}</p>
        <div style="margin-top:14px; padding-top:14px; border-top:1px solid var(--line);">
          <p style="font-size:0.78rem; text-transform:uppercase; letter-spacing:0.04em; color:var(--ink-faint); margin-bottom:8px;">Working notes</p>
          ${res.workings.map(w => `<p style="font-size:0.85rem; color:var(--ink-soft); margin:0 0 6px; font-family:var(--font-mono);">${w}</p>`).join("")}
        </div>
      </div>
    `;
    playSuccessSound();
    if (!STATE.solved["jr-calc-used"]) {
      STATE.solved["jr-calc-used"] = { correct: true, attempts: 1 };
      saveState();
      addXP(2, "Calculated a journal entry");
    }
    icons();
  });

  const examples = [
    "Started business with cash ₹1,00,000",
    "Purchased goods on credit from Rakesh ₹20,000",
    "Sold goods to Deepa on credit ₹31,000",
    "Paid rent ₹8,000 in cash",
    "Withdrew cash ₹5,000 for personal use",
    "Received commission ₹4,500 in cash",
    "Deposited cash into bank ₹30,000",
    "Depreciation charged on machinery ₹6,000",
    "Received cash from Naresh, bad debts recovered ₹900",
    "Received a Bills Receivable from Vikram ₹8,000",
    "Bank charges ₹150 as per pass book"
  ];
  const exWrap = $("#jegExamples", textCard);
  examples.forEach(ex => {
    const chip = el("button", "chip", ex.length > 38 ? ex.slice(0, 38) + "…" : ex);
    chip.title = ex;
    chip.addEventListener("click", () => { $("#jegInput", textCard).value = ex; runGenerator(); });
    exWrap.appendChild(chip);
  });

  function runGenerator() {
    const input = $("#jegInput", textCard).value.trim();
    const resultBox = $("#jegResult", textCard);
    if (!input) { resultBox.innerHTML = ""; return; }

    // Try the compound engine first — it's for transaction types that need
    // more than one extracted number (asset sale profit/loss, opening
    // entries, settlements with discount, etc.) and only returns a result
    // when it's confident in every figure.
    const compound = matchCompoundPattern(input);
    if (compound) {
      const rows = compound.lines.map(([label, dr, cr]) => `
        <tr><td style="font-family:var(--font-body); ${dr === null ? "padding-left:24px;" : ""}">${label}${dr !== null ? " Dr." : ""}</td>
        <td class="tnum" style="text-align:right;">${dr !== null ? fmtINR(dr) : ""}</td>
        <td class="tnum" style="text-align:right;">${cr !== null ? fmtINR(cr) : ""}</td></tr>`).join("");
      resultBox.innerHTML = `
        <div class="reveal-block">
          <h4>Suggested journal entry</h4>
          <table class="ledger-table" style="margin-top:8px;"><tbody>${rows}</tbody></table>
          <p style="font-size:0.85rem; color:var(--ink-soft); margin-top:10px; font-style:italic;">(${compound.narration})</p>
          <p style="font-size:0.78rem; color:var(--ink-faint); margin-top:10px;">This is a compound entry — several figures were pulled from your sentence and used together. Double-check it against the theory and Practice Bank before relying on it for an exam answer.</p>
        </div>
      `;
      playSuccessSound();
      if (!STATE.solved["jr-gen-used"]) {
        STATE.solved["jr-gen-used"] = { correct: true, attempts: 1 };
        saveState();
        addXP(2, "Generated a journal entry");
      }
      icons();
      return;
    }

    const pattern = matchJournalPattern(input);
    const amount = extractAmount(input);

    if (!pattern) {
      resultBox.innerHTML = `
        <div class="reveal-block" style="background:var(--flag-soft); border-left-color:var(--flag);">
          <h4>Couldn't confidently match this</h4>
          <p style="font-size:0.87rem;">This tool matches against a library of common transaction patterns rather than truly understanding free text, so unusual phrasing can miss. Try describing it more plainly — for example, name the action clearly ("paid", "purchased", "sold", "received") plus what was involved ("rent", "goods on credit", "furniture") and an amount. For a goods transaction involving profit or discount percentages, switch to the Calculator above — it computes the answer instead of matching text.</p>
        </div>`;
      playErrorSound();
      return;
    }

    const name = pattern.needsName ? extractName(input) : null;
    const debitLine = pattern.debitTemplate ? pattern.debitTemplate.replace("{name}", name) : pattern.debit;
    const creditLine = pattern.creditTemplate ? pattern.creditTemplate.replace("{name}", name) : `To ${pattern.credit}`;
    const amountDisplay = amount !== null ? fmtINR(amount) : "[amount]";

    resultBox.innerHTML = `
      <div class="reveal-block">
        <h4>Suggested journal entry</h4>
        <table class="ledger-table" style="margin-top:8px;">
          <tbody>
            <tr><td style="font-family:var(--font-body);">${debitLine} Dr.</td><td class="tnum" style="text-align:right;">${amountDisplay}</td><td></td></tr>
            <tr><td style="font-family:var(--font-body); padding-left:24px;">${creditLine}</td><td></td><td class="tnum" style="text-align:right;">${amountDisplay}</td></tr>
          </tbody>
        </table>
        <p style="font-size:0.85rem; color:var(--ink-soft); margin-top:10px; font-style:italic;">(${pattern.narration}${name && name !== "the party" ? ` — ${name}` : ""})</p>
        ${amount === null ? `<p style="font-size:0.82rem; color:var(--gold); margin-top:8px;"><i data-lucide="info" style="width:13px;height:13px; vertical-align:-2px;"></i> No amount was detected in your sentence — include a number so it can be filled in.</p>` : ""}
        ${name === "the party" && pattern.needsName ? `<p style="font-size:0.82rem; color:var(--gold); margin-top:4px;"><i data-lucide="info" style="width:13px;height:13px; vertical-align:-2px;"></i> This entry needs a named person or firm — try including one, e.g. "...from Suresh" or "...to Meera".</p>` : ""}
        <p style="font-size:0.78rem; color:var(--ink-faint); margin-top:10px;">Matched pattern: paid/received/purchased-style transaction involving ${pattern.keywords.join(", ")}. Double-check this against the theory and Practice Bank before relying on it for an exam answer.</p>
      </div>
    `;
    playSuccessSound();
    if (!STATE.solved["jr-gen-used"]) {
      STATE.solved["jr-gen-used"] = { correct: true, attempts: 1 };
      saveState();
      addXP(2, "Generated a journal entry");
    }
    icons();
  }

  $("#jegGenerateBtn", textCard).addEventListener("click", runGenerator);
  $("#jegInput", textCard).addEventListener("keydown", (e) => {
    if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) runGenerator();
  });
  icons();
}

/* ---- LEDGER POSTING PRACTICE (new Chapter 3 section) ---- */
function renderLedgerPosting(panel, data) {
  panel.appendChild(sectionTitle("Ledger posting practice"));
  const hint = el("p", "", "Take each journal entry below and see how it's posted into T-accounts — the step that comes right after journalising. Click 'Show T-Accounts' to reveal the posting.");
  hint.style.cssText = "font-size:0.85rem; color:var(--ink-faint); margin:-8px 0 18px;";
  panel.appendChild(hint);

  data.ledgerPostings.forEach((p) => {
    const card = el("div", "card q-card", "");
    card.innerHTML = `
      <div class="q-meta">
        <span class="q-id">Posting Exercise ${p.id}</span>
      </div>
      <div class="q-body tnum" style="font-size:0.9rem; background:var(--line); padding:12px 14px; border-radius:10px;">${p.journalEntry}</div>
      <div class="q-actions">
        <button class="btn-primary sm ripple-surface" data-act="showledger"><i data-lucide="table-2"></i> Show T-Accounts</button>
      </div>
      <div class="reveal-area"></div>
    `;
    const revealArea = $(".reveal-area", card);
    card.addEventListener("click", (e) => {
      const btn = e.target.closest("button[data-act]");
      if (!btn) return;
      // Group postings by account, since one account may need only one T-account box
      // even if (in rarer cases) it appears more than once across a compound entry.
      const byAccount = {};
      p.postings.forEach(post => {
        if (!byAccount[post.account]) byAccount[post.account] = [];
        byAccount[post.account].push(post);
      });
      let html = `<div class="reveal-block"><h4>T-Account posting</h4><div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(220px, 1fr)); gap:14px; margin-top:10px;">`;
      Object.entries(byAccount).forEach(([acct, posts]) => {
        const debitPosts = posts.filter(x => x.side === "Debit");
        const creditPosts = posts.filter(x => x.side === "Credit");
        html += `
          <div style="border:1.5px solid var(--line-strong); border-radius:10px; overflow:hidden;">
            <div style="text-align:center; font-weight:600; font-size:0.85rem; padding:8px; border-bottom:1.5px solid var(--line-strong); background:var(--paper-raised);">${acct}</div>
            <div style="display:grid; grid-template-columns:1fr 1fr;">
              <div style="padding:10px; border-right:1px solid var(--line);">
                <div style="font-size:0.7rem; text-transform:uppercase; color:var(--ink-faint); margin-bottom:6px;">Debit</div>
                ${debitPosts.map(dp => `<div class="tnum" style="font-size:0.8rem; margin-bottom:4px;">${dp.oppositeRef}<br><b>${fmtINR(dp.amount)}</b></div>`).join("") || "<div style='color:var(--ink-faint); font-size:0.78rem;'>—</div>"}
              </div>
              <div style="padding:10px;">
                <div style="font-size:0.7rem; text-transform:uppercase; color:var(--ink-faint); margin-bottom:6px;">Credit</div>
                ${creditPosts.map(cp => `<div class="tnum" style="font-size:0.8rem; margin-bottom:4px;">${cp.oppositeRef}<br><b>${fmtINR(cp.amount)}</b></div>`).join("") || "<div style='color:var(--ink-faint); font-size:0.78rem;'>—</div>"}
              </div>
            </div>
          </div>`;
      });
      html += `</div><p style="font-size:0.87rem; color:var(--ink-soft); margin-top:14px;">${p.explanation}</p></div>`;
      revealArea.innerHTML = html;
      const key = `jr-ledger-${p.id}`;
      if (!STATE.solved[key]) {
        STATE.solved[key] = { correct: true, attempts: 1 };
        saveState();
        addXP(3, `Reviewed ledger posting ${p.id}`);
      }
    });
    panel.appendChild(card);
  });
  icons();
}

function renderJRPracticeBank(panel, data) {
  const filterBar = el("div", "", "");
  filterBar.style.cssText = "display:flex; gap:8px; margin-bottom:18px; flex-wrap:wrap;";
  ["All", "Easy", "Medium", "Hard"].forEach(d => {
    const chip = el("button", `chip ${d === jrFilterDifficulty ? "active" : ""}`, d);
    chip.addEventListener("click", () => { jrFilterDifficulty = d; renderJRPracticeBank(panel, data); });
    filterBar.appendChild(chip);
  });
  panel.innerHTML = "";
  panel.appendChild(filterBar);
  const list = data.numericals.filter(q => jrFilterDifficulty === "All" || q.difficulty === jrFilterDifficulty);
  const countLabel = el("p", "", `Showing ${list.length} of ${data.numericals.length} transactions`);
  countLabel.style.cssText = "font-size:0.83rem; color:var(--ink-faint); margin-bottom:16px;";
  panel.appendChild(countLabel);
  list.forEach(q => panel.appendChild(renderJRQuestionCard(q)));
  applyMobilePager(panel);
  icons();
}

function renderJRQuestionCard(q) {
  const solvedKey = `jr-${q.id}`;
  const alreadySolved = STATE.solved[solvedKey];
  const card = el("div", "card q-card", "");
  card.innerHTML = `
    <div class="q-meta">
      <span class="diff-badge ${q.difficulty}">${q.difficulty}</span>
      <span class="q-id">Q${q.id}</span>
      ${alreadySolved ? `<span style="margin-left:auto; color:var(--c-jr); font-size:0.78rem; display:flex; align-items:center; gap:4px;"><i data-lucide="check-circle" style="width:13px;height:13px;"></i> Solved</span>` : ""}
    </div>
    <div class="q-body">${q.transaction}</div>
    <div class="q-actions">
      <button class="btn-ghost sm ripple-surface" data-act="hint"><i data-lucide="lightbulb"></i> Hint</button>
      <button class="btn-primary sm ripple-surface" data-act="answer"><i data-lucide="eye"></i> Reveal Journal Entry</button>
      <button class="icon-btn sm" data-act="bookmark" title="Bookmark"><i data-lucide="${STATE.bookmarks.includes(solvedKey) ? 'bookmark-check' : 'bookmark'}"></i></button>
      <button class="btn-ghost sm ripple-surface ask-ai-btn" data-act="ask-ai" title="Ask the AI Tutor about this question"><i data-lucide="bot"></i> Ask AI about this</button>
    </div>
    <div class="reveal-area"></div>
  `;
  const revealArea = $(".reveal-area", card);
  card.addEventListener("click", (e) => {
    const btn = e.target.closest("button[data-act]");
    if (!btn) return;
    const act = btn.dataset.act;
    if (act === "ask-ai") {
      askAIAbout(`Why is this Journal entry recorded the way it is: "${q.transaction}"? Please explain which account to debit and credit and why.`, "jr");
      return;
    }
    if (act === "hint") {
      revealArea.innerHTML = `<div class="reveal-block hint-block"><h4>Hint</h4><p style="font-size:0.88rem;">${q.hint}</p></div>`;
    }
    if (act === "answer") {
      const rows = q.entries.map(en => `
        <tr>
          <td>${en.particulars}${en.dr !== null ? " Dr." : ""}</td>
          <td class="tnum">${en.dr !== null ? fmtINR(en.dr).replace("₹","") : ""}</td>
          <td class="tnum">${en.cr !== null ? fmtINR(en.cr).replace("₹","") : ""}</td>
        </tr>`).join("");
      revealArea.innerHTML = `
        <div class="reveal-block">
          <h4>Journal Entry</h4>
          <table class="ledger-table"><thead><tr><th>Particulars</th><th>Debit (₹)</th><th>Credit (₹)</th></tr></thead><tbody>${rows}</tbody></table>
          <p style="font-size:0.83rem; color:var(--ink-faint); margin-top:8px;">${q.narration}</p>
          <p style="font-size:0.87rem; color:var(--ink-soft); margin-top:8px;">${q.explanation}</p>
          <div class="self-check" style="margin-top:14px; display:flex; align-items:center; gap:10px; flex-wrap:wrap;">
            <span style="font-size:0.83rem; color:var(--ink-faint);">Did you journalise this correctly?</span>
            <button class="btn-ghost sm ripple-surface" data-act="self-correct"><i data-lucide="check"></i> Yes, I got it right</button>
            <button class="btn-ghost sm ripple-surface" data-act="self-wrong"><i data-lucide="x"></i> No, I got it wrong</button>
          </div>
        </div>`;
      icons();
    }
    if (act === "self-correct" || act === "self-wrong") {
      const gotItRight = act === "self-correct";
      STATE.solved[solvedKey] = { correct: gotItRight, attempts: (STATE.solved[solvedKey]?.attempts || 0) + 1 };
      if (gotItRight) {
        saveState(); addXP(4, `Journalised Q${q.id}`); logActivity(`Journal Q${q.id} solved (${q.difficulty})`);
        mistakeBookRecordCorrect(solvedKey);
      } else {
        if (!STATE.mistakes.includes(solvedKey)) STATE.mistakes.push(solvedKey);
        saveState();
        const correctEntryText = q.entries.map(en => `${en.particulars}${en.dr !== null ? " Dr." : ""} ${en.dr !== null ? fmtINR(en.dr) : fmtINR(en.cr)}`).join(" | ");
        mistakeBookRecord({
          key: solvedKey, question: q.transaction, chapter: "jr", chapterLabel: "Journal",
          topic: "Journal Entries", type: "Practice Bank (self-assessed)",
          studentAnswer: "Marked as incorrect by student",
          correctAnswer: correctEntryText, explanation: q.explanation
        });
      }
      refreshProgress();
      const selfCheckEl = $(".self-check", revealArea);
      if (selfCheckEl) selfCheckEl.innerHTML = gotItRight
        ? `<span style="font-size:0.83rem; color:var(--c-jr);"><i data-lucide="check-circle" style="width:14px;height:14px; vertical-align:-2px;"></i> Marked correct — nice work!</span>`
        : `<span style="font-size:0.83rem; color:var(--flag);"><i data-lucide="alert-circle" style="width:14px;height:14px; vertical-align:-2px;"></i> Added to your Mistake Book for review.</span>`;
      icons();
    }
    if (act === "bookmark") {
      const idx = STATE.bookmarks.indexOf(solvedKey);
      if (idx >= 0) { STATE.bookmarks.splice(idx, 1); btn.querySelector("i").setAttribute("data-lucide", "bookmark"); }
      else { STATE.bookmarks.push(solvedKey); btn.querySelector("i").setAttribute("data-lucide", "bookmark-check"); }
      saveState(); icons();
    }
    icons();
  });
  return card;
}

/* ---------------------------------------------------------
   6d. CHAPTER 4 — LEDGER
   --------------------------------------------------------- */
function renderLedgerChapter(root) {
  const data = APP_DATA.ledger;
  root.appendChild(el("div", "hero", `
    <span class="hero-eyebrow">Chapter 4</span>
    <h1>Ledger</h1>
    <p>${APP_DATA.chapters[3].tagline} Post real journal entries into T-accounts and learn to balance an account with a fully worked example.</p>
  `));

  const tabs = ["Introduction", "Ledger Format", "Posting Rules", "Journal → Ledger Practice", "Balancing Accounts", "Exam Questions", "Quick Revision"];
  const tabBar = el("div", "", "");
  tabBar.style.cssText = "display:flex; gap:8px; flex-wrap:wrap; margin-bottom:22px;";
  tabs.forEach((t, i) => {
    const chip = el("button", `chip ${i===0?'active':''}`, t);
    chip.dataset.tab = t;
    tabBar.appendChild(chip);
  });
  const journeyEl = renderJourneyStepper(root, "lg");
  root.appendChild(tabBar);
  const panel = el("div", "");
  root.appendChild(panel);

  function showTab(name) {
    $all(".chip", tabBar).forEach(c => c.classList.toggle("active", c.dataset.tab === name));
    panel.innerHTML = "";
    updateJourneyStepper(journeyEl, "lg", name);
    if (name === "Introduction") renderLedgerIntro(panel, data);
    if (name === "Ledger Format") renderLedgerFormat(panel, data);
    if (name === "Posting Rules") renderLedgerPostingRules(panel, data);
    if (name === "Journal → Ledger Practice") renderLedgerPracticeWidget(panel, data);
    if (name === "Balancing Accounts") renderLedgerBalancing(panel, data);
    if (name === "Exam Questions") renderLedgerExamQuestions(panel, data);
    if (name === "Quick Revision") renderLedgerQuickRevision(panel, data);
    icons();
  }
  tabBar.addEventListener("click", e => {
    const chip = e.target.closest(".chip");
    if (chip) showTab(chip.dataset.tab);
  });
  showTab("Introduction");
}

/* ---- 1. INTRODUCTION ---- */
function renderLedgerIntro(panel, data) {
  const accent = "var(--c-lg)";
  const soft = "var(--c-lg-soft)";
  const wrap = el("div", "grid-2");

  const meaningCard = el("div", "card-solid", "");
  meaningCard.style.padding = "26px";
  meaningCard.innerHTML = `
    <h3 style="margin-bottom:14px;"><i data-lucide="book-open" style="width:18px;height:18px;vertical-align:-3px;color:${accent};"></i> Meaning of Ledger</h3>
    <p style="font-size:0.9rem; line-height:1.65; color:var(--ink-soft);">${data.intro.meaning}</p>
    <div class="ledger-rule" style="margin-top:18px;">
      <h4 style="font-size:0.95rem; margin-bottom:8px;">Definition</h4>
      <p style="font-size:0.9rem; line-height:1.65; color:var(--ink-soft);">${data.intro.definition}</p>
    </div>
  `;

  const relCard = el("div", "card-solid", "");
  relCard.style.padding = "26px";
  relCard.innerHTML = `
    <h3 style="margin-bottom:14px;"><i data-lucide="link-2" style="width:18px;height:18px;vertical-align:-3px;color:${accent};"></i> Journal ↔ Ledger</h3>
    <p style="font-size:0.9rem; line-height:1.65; color:var(--ink-soft);">${data.intro.relationship}</p>
    <div class="tnum" style="text-align:center; font-size:0.95rem; font-weight:700; color:${accent}; background:${soft}; padding:12px; border-radius:10px; margin-top:14px;">
      Journal (original entry, by date) → posted → Ledger (final entry, by account)
    </div>
  `;
  wrap.appendChild(meaningCard);
  wrap.appendChild(relCard);
  panel.appendChild(wrap);

  panel.appendChild(sectionTitle("Why the Ledger matters"));
  const grid = el("div", "grid-3");
  data.intro.importance.forEach((point, i) => {
    const card = el("div", "card liftable", "");
    card.style.padding = "20px";
    card.innerHTML = `<div class="ch-icon" style="width:32px;height:32px;background:${soft}; color:${accent}; font-family:var(--font-mono); font-weight:700; display:flex; align-items:center; justify-content:center; border-radius:8px; margin-bottom:10px;">${i+1}</div><p style="font-size:0.86rem; line-height:1.6; color:var(--ink-soft);">${point}</p>`;
    grid.appendChild(card);
  });
  panel.appendChild(grid);
}

/* ---- 2. LEDGER FORMAT ---- */
function renderLedgerFormat(panel, data) {
  panel.appendChild(sectionTitle("Ledger format — a T-shaped account"));
  const hint = el("p", "", "Every ledger account, whichever account it is, is drawn in this same T-shape — Debit side on the left, Credit side on the right, each with its own Date, Particulars, J.F. and Amount columns.");
  hint.style.cssText = "font-size:0.85rem; color:var(--ink-faint); margin:-8px 0 18px;";
  panel.appendChild(hint);

  const card = el("div", "card-solid", "");
  card.style.padding = "22px";
  const scroll = el("div", "table-scroll");
  scroll.innerHTML = `
    <div style="text-align:center; font-weight:700; font-family:var(--font-mono); margin-bottom:10px;">Name of Account</div>
    <table class="t-account-grid" style="width:100%; border-collapse:collapse; min-width:560px;">
      <tr>
        <th colspan="4" style="text-align:center; border:1.5px solid var(--line-strong); background:var(--c-lg-soft); color:var(--c-lg); padding:8px;">Dr.</th>
        <th colspan="4" style="text-align:center; border:1.5px solid var(--line-strong); background:var(--c-lg-soft); color:var(--c-lg); padding:8px;">Cr.</th>
      </tr>
      <tr>
        <th style="border:1px solid var(--line-strong); padding:8px; font-size:0.78rem;">Date</th>
        <th style="border:1px solid var(--line-strong); padding:8px; font-size:0.78rem;">Particulars</th>
        <th style="border:1px solid var(--line-strong); padding:8px; font-size:0.78rem;">J.F.</th>
        <th style="border:1px solid var(--line-strong); padding:8px; font-size:0.78rem;">Amount (₹)</th>
        <th style="border:1px solid var(--line-strong); padding:8px; font-size:0.78rem;">Date</th>
        <th style="border:1px solid var(--line-strong); padding:8px; font-size:0.78rem;">Particulars</th>
        <th style="border:1px solid var(--line-strong); padding:8px; font-size:0.78rem;">J.F.</th>
        <th style="border:1px solid var(--line-strong); padding:8px; font-size:0.78rem;">Amount (₹)</th>
      </tr>
      <tr>
        <td style="border:1px solid var(--line); padding:10px; font-family:var(--font-mono); font-size:0.82rem;">Apr 1</td>
        <td style="border:1px solid var(--line); padding:10px; font-size:0.82rem;">To Capital A/c</td>
        <td style="border:1px solid var(--line); padding:10px; font-family:var(--font-mono); font-size:0.82rem; text-align:center;">1</td>
        <td style="border:1px solid var(--line); padding:10px; font-family:var(--font-mono); font-size:0.82rem; text-align:right;">50,000</td>
        <td style="border:1px solid var(--line); padding:10px; font-family:var(--font-mono); font-size:0.82rem;">Apr 10</td>
        <td style="border:1px solid var(--line); padding:10px; font-size:0.82rem;">By Purchases A/c</td>
        <td style="border:1px solid var(--line); padding:10px; font-family:var(--font-mono); font-size:0.82rem; text-align:center;">3</td>
        <td style="border:1px solid var(--line); padding:10px; font-family:var(--font-mono); font-size:0.82rem; text-align:right;">20,000</td>
      </tr>
      <tr>
        <td style="border:1px solid var(--line); padding:10px;"></td>
        <td style="border:1px solid var(--line); padding:10px; color:var(--ink-faint); font-size:0.78rem; font-style:italic;">...more entries as they occur...</td>
        <td style="border:1px solid var(--line); padding:10px;"></td>
        <td style="border:1px solid var(--line); padding:10px;"></td>
        <td style="border:1px solid var(--line); padding:10px;"></td>
        <td style="border:1px solid var(--line); padding:10px; color:var(--ink-faint); font-size:0.78rem; font-style:italic;">By Balance c/d</td>
        <td style="border:1px solid var(--line); padding:10px;"></td>
        <td style="border:1px solid var(--line); padding:10px;"></td>
      </tr>
    </table>
  `;
  card.appendChild(scroll);
  panel.appendChild(card);

  const noteCard = el("div", "card-solid", "");
  noteCard.style.cssText = "padding:22px; margin-top:18px;";
  noteCard.innerHTML = `
    <h4 style="font-size:0.95rem; margin-bottom:10px;">What each column means</h4>
    <ul style="padding-left:18px;">
      <li style="margin-bottom:8px; font-size:0.88rem;"><b>Date:</b> the date on which the transaction happened, taken straight from the Journal.</li>
      <li style="margin-bottom:8px; font-size:0.88rem;"><b>Particulars:</b> the name of the OTHER account involved in the transaction, prefixed with 'To' (debit side) or 'By' (credit side) — never the account's own name.</li>
      <li style="margin-bottom:8px; font-size:0.88rem;"><b>J.F. (Journal Folio):</b> the page number of the Journal this entry was posted from, filled in only at the time of posting.</li>
      <li style="margin-bottom:8px; font-size:0.88rem;"><b>Amount (₹):</b> the debit or credit figure, copied exactly from the Journal entry.</li>
    </ul>
  `;
  panel.appendChild(noteCard);
}

/* ---- 3. POSTING RULES ---- */
function renderLedgerPostingRules(panel, data) {
  panel.appendChild(sectionTitle("Posting rules"));
  const grid = el("div", "grid-2");
  data.postingRules.forEach((r, i) => {
    const card = el("div", "card liftable", "");
    card.style.padding = "22px";
    card.innerHTML = `
      <div style="display:flex; align-items:center; gap:10px; margin-bottom:10px;">
        <div class="ch-icon" style="width:32px;height:32px;background:var(--c-lg-soft); color:var(--c-lg); font-family:var(--font-mono); font-weight:700; display:flex; align-items:center; justify-content:center; border-radius:8px;">${i+1}</div>
        <h4 style="font-size:0.98rem;">${r.title}</h4>
      </div>
      <p style="font-size:0.87rem; line-height:1.6; color:var(--ink-soft);">${r.body}</p>
    `;
    grid.appendChild(card);
  });
  panel.appendChild(grid);
}

/* ---- 4. JOURNAL → LEDGER PRACTICE (interactive quiz) ----
   Pulls simple two-line transactions from the Journal chapter's
   own numericals bank (plus a couple of goods-return examples
   unique to this chapter), and asks the student to identify the
   debited and credited account for each — instant feedback + XP. */
function getLedgerPracticePool() {
  const fromJournal = APP_DATA.journal.numericals
    .filter(q => q.entries.length === 2)
    .map(q => ({
      id: q.id,
      difficulty: q.difficulty,
      transaction: q.transaction,
      debitAccount: q.entries[0].particulars.trim(),
      creditAccount: q.entries[1].particulars.replace(/^\s*To\s+/, "").trim(),
      explanation: q.explanation
    }));
  const extra = (APP_DATA.ledger.extraPracticeTransactions || []).map(q => ({
    id: 1000 + q.id,
    difficulty: q.difficulty,
    transaction: q.transaction,
    debitAccount: q.entries[0].particulars.trim(),
    creditAccount: q.entries[1].particulars.replace(/^\s*To\s+/, "").trim(),
    explanation: q.explanation
  }));
  return [...fromJournal, ...extra];
}

let lgFilterDifficulty = "All";

function renderLedgerPracticeWidget(panel, data) {
  panel.innerHTML = "";
  panel.appendChild(sectionTitle("Journal → Ledger practice"));
  const hint = el("p", "", `${getLedgerPracticePool().length} built-in transactions. For each one, pick which account gets debited and which gets credited when it's posted from the Journal into the Ledger.`);
  hint.style.cssText = "font-size:0.85rem; color:var(--ink-faint); margin:-8px 0 18px;";
  panel.appendChild(hint);

  const filterBar = el("div", "", "");
  filterBar.style.cssText = "display:flex; gap:8px; margin-bottom:18px; flex-wrap:wrap;";
  ["All", "Easy", "Medium", "Hard"].forEach(d => {
    const chip = el("button", `chip ${d === lgFilterDifficulty ? "active" : ""}`, d);
    chip.addEventListener("click", () => { lgFilterDifficulty = d; renderLedgerPracticeWidget(panel, data); });
    filterBar.appendChild(chip);
  });
  panel.appendChild(filterBar);

  const pool = getLedgerPracticePool();
  const accountPool = [...new Set(pool.flatMap(p => [p.debitAccount, p.creditAccount]))];
  const list = pool.filter(q => lgFilterDifficulty === "All" || q.difficulty === lgFilterDifficulty);
  const countLabel = el("p", "", `Showing ${list.length} of ${pool.length} transactions`);
  countLabel.style.cssText = "font-size:0.83rem; color:var(--ink-faint); margin-bottom:16px;";
  panel.appendChild(countLabel);

  function shuffledOptions(correct) {
    const distractors = accountPool.filter(a => a !== correct);
    for (let i = distractors.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [distractors[i], distractors[j]] = [distractors[j], distractors[i]];
    }
    const opts = [correct, ...distractors.slice(0, 3)];
    for (let i = opts.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [opts[i], opts[j]] = [opts[j], opts[i]];
    }
    return opts;
  }

  list.forEach(q => {
    const solvedKey = `lg-${q.id}`;
    const alreadySolved = STATE.solved[solvedKey];
    const debitOptions = shuffledOptions(q.debitAccount);
    const creditOptions = shuffledOptions(q.creditAccount);
    let picked = { debit: null, credit: null };

    const card = el("div", "card q-card", "");
    card.innerHTML = `
      <div class="q-meta">
        <span class="diff-badge ${q.difficulty}">${q.difficulty}</span>
        <span class="q-id">Q${q.id}</span>
        ${alreadySolved ? `<span style="margin-left:auto; color:var(--c-lg); font-size:0.78rem; display:flex; align-items:center; gap:4px;"><i data-lucide="check-circle" style="width:13px;height:13px;"></i> Solved</span>` : ""}
      </div>
      <div class="q-body">${q.transaction}</div>
      <div style="margin-top:14px;">
        <p style="font-size:0.78rem; text-transform:uppercase; letter-spacing:0.04em; color:var(--ink-faint); margin-bottom:8px;">Which account is debited?</p>
        <div class="opt-group" data-role="debit" style="display:flex; flex-wrap:wrap; gap:8px;">
          ${debitOptions.map(o => `<button class="chip" data-val="${o}">${o}</button>`).join("")}
        </div>
      </div>
      <div style="margin-top:14px;">
        <p style="font-size:0.78rem; text-transform:uppercase; letter-spacing:0.04em; color:var(--ink-faint); margin-bottom:8px;">Which account is credited?</p>
        <div class="opt-group" data-role="credit" style="display:flex; flex-wrap:wrap; gap:8px;">
          ${creditOptions.map(o => `<button class="chip" data-val="${o}">${o}</button>`).join("")}
        </div>
      </div>
      <div class="q-actions" style="margin-top:14px;">
        <button class="btn-primary sm ripple-surface" data-act="check"><i data-lucide="check"></i> Check Answer</button>
      </div>
      <div class="reveal-area"></div>
    `;
    const revealArea = $(".reveal-area", card);

    card.addEventListener("click", (e) => {
      const optBtn = e.target.closest(".opt-group button[data-val]");
      if (optBtn) {
        const group = optBtn.closest(".opt-group");
        $all("button", group).forEach(b => b.classList.remove("active"));
        optBtn.classList.add("active");
        picked[group.dataset.role] = optBtn.dataset.val;
        return;
      }
      const checkBtn = e.target.closest("button[data-act='check']");
      if (checkBtn) {
        if (!picked.debit || !picked.credit) {
          revealArea.innerHTML = `<div class="reveal-block hint-block"><p style="font-size:0.86rem;">Pick one account for each side first.</p></div>`;
          return;
        }
        const correct = picked.debit === q.debitAccount && picked.credit === q.creditAccount;
        if (correct) {
          revealArea.innerHTML = `
            <div class="reveal-block">
              <h4>Correct!</h4>
              <p style="font-size:0.87rem; line-height:1.6; color:var(--ink-soft);">${q.debitAccount} is debited (posted 'To ${q.creditAccount}'); ${q.creditAccount} is credited (posted 'By ${q.debitAccount}'). ${q.explanation}</p>
            </div>`;
          playSuccessSound();
          if (!STATE.solved[solvedKey]) {
            STATE.solved[solvedKey] = { correct: true, attempts: 1 };
            saveState(); addXP(4, `Posted ledger Q${q.id}`); logActivity(`Ledger posting Q${q.id} solved (${q.difficulty})`); refreshProgress();
          }
          mistakeBookRecordCorrect(solvedKey);
        } else {
          revealArea.innerHTML = `
            <div class="reveal-block" style="background:var(--flag-soft); border-left-color:var(--flag);">
              <h4>Not quite</h4>
              <p style="font-size:0.87rem; line-height:1.6; color:var(--ink-soft);">The correct posting is: <b>${q.debitAccount}</b> debited (To ${q.creditAccount}), <b>${q.creditAccount}</b> credited (By ${q.debitAccount}). ${q.explanation}</p>
            </div>`;
          playErrorSound();
          if (!STATE.solved[solvedKey]) {
            STATE.solved[solvedKey] = { correct: false, attempts: 1 };
            if (!STATE.mistakes.includes(solvedKey)) STATE.mistakes.push(solvedKey);
            saveState(); addXP(-XP_WRONG_PENALTY, `Q${q.id} incorrect`); refreshProgress();
          }
          mistakeBookRecord({
            key: solvedKey, question: q.transaction, chapter: "lg", chapterLabel: "Ledger",
            topic: "Journal → Ledger Posting", type: "Ledger Posting",
            studentAnswer: `Debit: ${picked.debit} · Credit: ${picked.credit}`,
            correctAnswer: `Debit: ${q.debitAccount} · Credit: ${q.creditAccount}`,
            explanation: q.explanation
          });
        }
        icons();
      }
    });
    panel.appendChild(card);
  });
  applyMobilePager(panel);
  icons();
}

/* ---- 5. BALANCING ACCOUNTS ---- */
function renderLedgerBalancing(panel, data) {
  panel.appendChild(sectionTitle("Balancing accounts"));
  const stepsCard = el("div", "card-solid", "");
  stepsCard.style.padding = "26px";
  let stepsHtml = `<h3 style="margin-bottom:14px;"><i data-lucide="list-ordered" style="width:18px;height:18px;vertical-align:-3px;color:var(--c-lg);"></i> Steps to balance any ledger account</h3><ol style="padding-left:20px;">`;
  data.balancing.steps.forEach(s => stepsHtml += `<li style="margin-bottom:10px; font-size:0.89rem; line-height:1.6; color:var(--ink-soft);">${s}</li>`);
  stepsHtml += `</ol>`;
  stepsCard.innerHTML = stepsHtml;
  panel.appendChild(stepsCard);

  panel.appendChild(sectionTitle("Solved example"));
  const ex = data.balancing.example;
  const exCard = el("div", "card-solid", "");
  exCard.style.padding = "22px";
  const scroll = el("div", "table-scroll");
  const cellsFor = (r) => r
    ? `<td style="border:1px solid var(--line); padding:8px; font-family:var(--font-mono); font-size:0.8rem;">${r.date}</td><td style="border:1px solid var(--line); padding:8px; font-size:0.82rem;">${r.particulars}</td><td style="border:1px solid var(--line); padding:8px; text-align:center; font-family:var(--font-mono); font-size:0.8rem;">${r.jf}</td><td style="border:1px solid var(--line); padding:8px; text-align:right; font-family:var(--font-mono); font-size:0.8rem;">${r.amount.toLocaleString("en-IN")}</td>`
    : `<td style="border:1px solid var(--line); padding:8px;"></td><td style="border:1px solid var(--line); padding:8px;"></td><td style="border:1px solid var(--line); padding:8px;"></td><td style="border:1px solid var(--line); padding:8px;"></td>`;
  const rowCount = Math.max(ex.debitRows.length, ex.creditRows.length);
  let bodyRowsHtml = "";
  for (let i = 0; i < rowCount; i++) {
    bodyRowsHtml += `<tr>${cellsFor(ex.debitRows[i])}${cellsFor(ex.creditRows[i])}</tr>`;
  }
  scroll.innerHTML = `
    <div style="text-align:center; font-weight:700; font-family:var(--font-mono); margin-bottom:10px;">${ex.accountName} — ${ex.period}</div>
    <table class="t-account-grid" style="width:100%; border-collapse:collapse; min-width:560px;">
      <tr>
        <th colspan="4" style="text-align:center; border:1.5px solid var(--line-strong); background:var(--c-lg-soft); color:var(--c-lg); padding:8px;">Dr.</th>
        <th colspan="4" style="text-align:center; border:1.5px solid var(--line-strong); background:var(--c-lg-soft); color:var(--c-lg); padding:8px;">Cr.</th>
      </tr>
      <tr>
        <th style="border:1px solid var(--line-strong); padding:6px; font-size:0.74rem;">Date</th><th style="border:1px solid var(--line-strong); padding:6px; font-size:0.74rem;">Particulars</th><th style="border:1px solid var(--line-strong); padding:6px; font-size:0.74rem;">J.F.</th><th style="border:1px solid var(--line-strong); padding:6px; font-size:0.74rem;">₹</th>
        <th style="border:1px solid var(--line-strong); padding:6px; font-size:0.74rem;">Date</th><th style="border:1px solid var(--line-strong); padding:6px; font-size:0.74rem;">Particulars</th><th style="border:1px solid var(--line-strong); padding:6px; font-size:0.74rem;">J.F.</th><th style="border:1px solid var(--line-strong); padding:6px; font-size:0.74rem;">₹</th>
      </tr>
      ${bodyRowsHtml}
      <tr>
        <td colspan="4" style="border:1px solid var(--line);"></td>
        <td style="border:1px solid var(--line); padding:8px; font-family:var(--font-mono); font-size:0.8rem;">Apr 30</td>
        <td style="border:1px solid var(--line); padding:8px; font-size:0.82rem; color:var(--c-lg); font-weight:600;">By Balance c/d</td>
        <td style="border:1px solid var(--line); padding:8px;"></td>
        <td style="border:1px solid var(--line); padding:8px; text-align:right; font-family:var(--font-mono); font-size:0.8rem; color:var(--c-lg); font-weight:600;">${ex.balanceCD.toLocaleString("en-IN")}</td>
      </tr>
      <tr style="font-weight:700;">
        <td colspan="3" style="border-top:2px solid var(--line-strong); padding:8px; text-align:right;">Total</td>
        <td style="border-top:2px solid var(--line-strong); padding:8px; text-align:right; font-family:var(--font-mono);">${ex.totalDebit.toLocaleString("en-IN")}</td>
        <td colspan="3" style="border-top:2px solid var(--line-strong); padding:8px; text-align:right;">Total</td>
        <td style="border-top:2px solid var(--line-strong); padding:8px; text-align:right; font-family:var(--font-mono);">${ex.totalDebit.toLocaleString("en-IN")}</td>
      </tr>
      <tr>
        <td style="padding:8px; font-family:var(--font-mono); font-size:0.8rem;">May 1</td>
        <td style="padding:8px; font-size:0.82rem; color:var(--c-lg); font-weight:600;">To Balance b/d</td>
        <td style="padding:8px;"></td>
        <td style="padding:8px; text-align:right; font-family:var(--font-mono); font-size:0.8rem; color:var(--c-lg); font-weight:600;">${ex.balanceCD.toLocaleString("en-IN")}</td>
        <td colspan="4" style="padding:8px;"></td>
      </tr>
    </table>
  `;
  exCard.appendChild(scroll);
  const working = el("div", "reveal-block");
  working.style.marginTop = "16px";
  working.innerHTML = `<h4>Working</h4><p style="font-size:0.87rem; line-height:1.65;">${ex.workingExplanation}</p><p style="font-size:0.85rem; margin-top:8px;">Result: <b>${ex.balanceCDNature} balance of ₹${ex.balanceCD.toLocaleString("en-IN")}</b>, brought down on 1 May.</p>`;
  exCard.appendChild(working);
  panel.appendChild(exCard);
}

/* ---- 6. EXAM-ORIENTED QUESTIONS ---- */
let lgExamTab = "easy";
function renderLedgerExamQuestions(panel, data) {
  panel.innerHTML = "";
  panel.appendChild(sectionTitle("Exam-oriented questions"));
  const tabRow = el("div", "", "");
  tabRow.style.cssText = "display:flex; gap:8px; margin-bottom:18px; flex-wrap:wrap;";
  [["easy", `Easy (${data.examQuestions.easy.length})`], ["medium", `Medium (${data.examQuestions.medium.length})`], ["hard", `Hard (${data.examQuestions.hard.length})`]].forEach(([id, label]) => {
    const chip = el("button", `chip ${lgExamTab === id ? "active" : ""}`, label);
    chip.addEventListener("click", () => { lgExamTab = id; renderLedgerExamQuestions(panel, data); });
    tabRow.appendChild(chip);
  });
  panel.appendChild(tabRow);

  const list = data.examQuestions[lgExamTab];
  list.forEach((q, i) => {
    const key = `lg-exam-${lgExamTab}-${i}`;
    const card = el("div", "card q-card", "");
    card.innerHTML = `
      <div class="q-meta">
        <span class="diff-badge ${lgExamTab === "easy" ? "Easy" : lgExamTab === "medium" ? "Medium" : "Hard"}">${lgExamTab[0].toUpperCase() + lgExamTab.slice(1)}</span>
        <span class="q-id">Q${i + 1}</span>
        <button class="icon-btn sm" data-act="bookmark" style="margin-left:auto;" title="Bookmark"><i data-lucide="${STATE.bookmarks.includes(key) ? 'bookmark-check' : 'bookmark'}"></i></button>
      </div>
      <div class="q-body">${q.q}</div>
      <div class="q-actions">
        <button class="btn-primary sm ripple-surface" data-act="answer"><i data-lucide="eye"></i> Show Answer</button>
      </div>
      <div class="reveal-area"></div>
    `;
    const revealArea = $(".reveal-area", card);
    card.addEventListener("click", (e) => {
      const btn = e.target.closest("button[data-act]");
      if (!btn) return;
      if (btn.dataset.act === "answer") {
        revealArea.innerHTML = `<div class="reveal-block"><h4>Answer</h4><p style="font-size:0.87rem; line-height:1.65;">${q.a}</p></div>`;
        if (!STATE.solved[key]) {
          STATE.solved[key] = { correct: true, attempts: 1 };
          saveState(); addXP(3, `Reviewed a ledger exam question`); logActivity(`Reviewed a ${lgExamTab} Ledger question`); refreshProgress();
        }
      }
      if (btn.dataset.act === "bookmark") {
        const idx = STATE.bookmarks.indexOf(key);
        if (idx >= 0) { STATE.bookmarks.splice(idx, 1); btn.querySelector("i").setAttribute("data-lucide", "bookmark"); }
        else { STATE.bookmarks.push(key); btn.querySelector("i").setAttribute("data-lucide", "bookmark-check"); }
        saveState(); icons();
      }
      icons();
    });
    panel.appendChild(card);
  });
  applyMobilePager(panel);
  icons();
}

/* ---- 7. QUICK REVISION ---- */
function renderLedgerQuickRevision(panel, data) {
  panel.appendChild(sectionTitle("Quick revision"));
  const qr = data.quickRevision;
  const card = el("div", "card-solid", "");
  card.style.padding = "28px";
  card.innerHTML = `
    <div class="ledger-rule">
      <h4 style="font-size:0.95rem; margin-bottom:8px;">Definition</h4>
      <p style="font-size:0.89rem; line-height:1.6; color:var(--ink-soft);">${qr.definition}</p>
    </div>
    <div class="ledger-rule" style="margin-top:18px;">
      <h4 style="font-size:0.95rem; margin-bottom:8px;">Four posting rules</h4>
      <ol style="padding-left:20px;">${qr.rules.map(r => `<li style="margin-bottom:6px; font-size:0.87rem; color:var(--ink-soft);">${r}</li>`).join("")}</ol>
    </div>
    <div class="ledger-rule" style="margin-top:18px;">
      <h4 style="font-size:0.95rem; margin-bottom:8px;">Balancing steps</h4>
      <ol style="padding-left:20px;">${qr.balancingSteps.map(r => `<li style="margin-bottom:6px; font-size:0.87rem; color:var(--ink-soft);">${r}</li>`).join("")}</ol>
    </div>
    <div class="ledger-rule" style="margin-top:18px;">
      <h4 style="font-size:0.95rem; margin-bottom:8px; color:var(--flag);">Common mistakes</h4>
      <ul style="padding-left:20px;">${qr.commonMistakes.map(r => `<li style="margin-bottom:6px; font-size:0.87rem; color:var(--ink-soft);">${r}</li>`).join("")}</ul>
    </div>
    <div class="tnum" style="text-align:center; font-size:0.92rem; font-weight:600; color:var(--c-lg); background:var(--c-lg-soft); padding:14px; border-radius:10px; margin-top:18px;">
      💡 Mnemonic: ${qr.mnemonic}
    </div>
  `;
  panel.appendChild(card);
}

/* ---------------------------------------------------------
   6d-2. CHAPTER 5 — SPECIAL PURPOSE BOOKS 1: CASH BOOK
   Content sourced entirely from the provided chapter PDF
   (APP_DATA.cashBook). Uses a lighter tab set than Ledger's —
   Notes/Illustrations/Quick Revision — since this chapter's
   integration is about Notes, Quiz, Flashcards, Important
   Questions, Revision, Formula Sheet, and Exam Mode, not a
   bespoke interactive simulator.
   --------------------------------------------------------- */
function renderCashBookChapter(root) {
  const data = APP_DATA.cashBook;
  root.appendChild(el("div", "hero", `
    <span class="hero-eyebrow">Chapter 5</span>
    <h1>Special Purpose Books 1 - Cash Book</h1>
    <p>${APP_DATA.chapters[4].tagline} Cash Book, Two-Column Cash Book, contra entries, cheques-in-hand, post-dated cheques, bank overdraft, and Petty Cash Book — all from your textbook chapter.</p>
  `));

  const tabs = ["Introduction", "Format & Rules", "Practice Bank", "Quick Revision"];
  const tabBar = el("div", "", "");
  tabBar.style.cssText = "display:flex; gap:8px; flex-wrap:wrap; margin-bottom:22px;";
  tabs.forEach((t, i) => {
    const chip = el("button", `chip ${i===0?'active':''}`, t);
    chip.dataset.tab = t;
    tabBar.appendChild(chip);
  });
  const journeyEl = renderJourneyStepper(root, "cb");
  root.appendChild(tabBar);
  const panel = el("div", "");
  root.appendChild(panel);

  function showTab(name) {
    $all(".chip", tabBar).forEach(c => c.classList.toggle("active", c.dataset.tab === name));
    panel.innerHTML = "";
    updateJourneyStepper(journeyEl, "cb", name);
    if (name === "Introduction") renderCashBookIntro(panel, data);
    if (name === "Format & Rules") renderCashBookFormatRules(panel, data);
    if (name === "Practice Bank") renderCashBookPracticeBank(panel, data);
    if (name === "Quick Revision") renderCashBookQuickRevision(panel, data);
    icons();
  }
  tabBar.addEventListener("click", e => {
    const chip = e.target.closest(".chip");
    if (chip) showTab(chip.dataset.tab);
  });
  showTab("Introduction");
}

function renderCashBookTheoryBlocks(panel, blocks, accent, soft) {
  blocks.forEach(block => {
    const b = el("div", "ledger-rule card-solid");
    b.style.cssText = "padding:22px; margin-bottom:16px;";
    let html = `<h4 style="font-size:0.98rem; margin-bottom:8px;">${block.h}</h4>`;
    if (block.p) html += `<p style="font-size:0.9rem; line-height:1.65; color:var(--ink-soft); margin-bottom:10px; white-space:pre-line;">${block.p}</p>`;
    if (block.formula) html += `<div class="tnum" style="font-size:0.92rem; font-weight:600; color:${accent}; background:${soft}; padding:12px; border-radius:10px; margin:10px 0; white-space:pre-line; text-align:left;">${block.formula}</div>`;
    if (block.p2) html += `<p style="font-size:0.9rem; line-height:1.65; color:var(--ink-soft);">${block.p2}</p>`;
    if (block.list) {
      html += `<ul style="padding-left:18px; margin-top:8px;">`;
      block.list.forEach(item => html += `<li style="margin-bottom:8px; font-size:0.88rem;"><b>${item.term}:</b> ${item.def}</li>`);
      html += `</ul>`;
    }
    b.innerHTML = html;
    panel.appendChild(b);
  });
}

/* ---- Introduction: subsidiary books, meaning, features, types ---- */
function renderCashBookIntro(panel, data) {
  panel.appendChild(sectionTitle("Meaning, features & types"));
  renderCashBookTheoryBlocks(panel, data.theory.simple, "var(--c-cb)", "var(--c-cb-soft)");
  panel.appendChild(sectionTitle("Key concepts"));
  const grid = el("div", "grid-3");
  data.concepts.forEach(c => {
    const card = el("div", "card liftable", "");
    card.style.padding = "22px";
    card.innerHTML = `<h4 style="font-size:1rem; margin-bottom:8px; color:var(--c-cb);">${c.title}</h4><p style="font-size:0.87rem; line-height:1.6; color:var(--ink-soft);">${c.body}</p>`;
    grid.appendChild(card);
  });
  panel.appendChild(grid);
}

/* ---- Format & Rules: contra entries, cheques & petty cash theory,
   plus the three standard Cash Book formats reproduced exactly as
   shown in the textbook (Single Column, Double Column, Simple
   Petty Cash Book) ---- */
function renderCashBookFormatRules(panel, data) {
  panel.appendChild(sectionTitle("Contra entries, cheques & petty cash"));
  renderCashBookTheoryBlocks(panel, data.theory.advanced, "var(--c-cb)", "var(--c-cb-soft)");
  renderCashBookFormatTemplates(panel);
}

function cbFormatHeaderHTML(title) {
  return `
    <div style="text-align:center; margin-bottom:14px;">
      <div style="display:flex; justify-content:space-between; font-weight:700; font-size:0.85rem;">
        <span>Dr.</span><span>Cr.</span>
      </div>
      <div style="font-family:var(--font-head); font-weight:700; font-size:0.95rem; margin-top:-18px;">
        In the Books of…<br>${title}
      </div>
    </div>`;
}

function renderCashBookFormatTemplates(panel) {
  panel.appendChild(sectionTitle("Cash Book formats"));
  const hint = el("p", "", "The three standard Cash Book layouts, reproduced exactly as they appear in the textbook — a quick visual reference before you attempt the Practice Bank.");
  hint.style.cssText = "font-size:0.85rem; color:var(--ink-faint); margin:-8px 0 18px; line-height:1.6;";
  panel.appendChild(hint);

  // 1. Single (Simple) Column Cash Book — cash only, one amount column each side.
  const card1 = el("div", "card-solid", "");
  card1.style.cssText = "padding:22px; margin-bottom:18px;";
  card1.innerHTML = `
    <h4 style="font-size:0.95rem; margin-bottom:14px; color:var(--c-cb);">1. Single Column (Simple) Cash Book</h4>
    ${cbFormatHeaderHTML("Cash Book")}
    <div class="table-scroll"><table class="ledger-table"><thead><tr>
      <th>Date</th><th>Particulars</th><th>J.F.</th><th>Amount(₹)</th>
      <th>Date</th><th>Particulars</th><th>J.F.</th><th>Amount(₹)</th>
    </tr></thead><tbody>
      <tr><td>Year<br>Month Date</td><td>To Balance b/d</td><td></td><td>XXXX</td><td>Year<br>Month Date</td><td>By All Cash Payments</td><td></td><td>XXXX</td></tr>
      <tr><td></td><td>To All Cash Receipts</td><td></td><td>XXXX</td><td></td><td></td><td></td><td></td></tr>
      <tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
      <tr><td></td><td></td><td></td><td></td><td></td><td>By Balance c/d</td><td></td><td>XXXX</td></tr>
      <tr style="font-weight:700;"><td></td><td></td><td></td><td>XXXX</td><td></td><td></td><td></td><td>XXXX</td></tr>
    </tbody></table></div>
    <p style="font-size:0.83rem; line-height:1.6; color:var(--ink-faint); margin-top:12px;">Only cash transactions are recorded. It works exactly like an ordinary ledger account for cash — always has a debit (or nil) balance, since cash in hand can never go negative.</p>
  `;
  panel.appendChild(card1);

  // 2. Double Column (Two-Column) Cash Book — cash + bank columns each side.
  const card2 = el("div", "card-solid", "");
  card2.style.cssText = "padding:22px; margin-bottom:18px;";
  card2.innerHTML = `
    <h4 style="font-size:0.95rem; margin-bottom:14px; color:var(--c-cb);">2. Double Column (Two-Column) Cash Book</h4>
    ${cbFormatHeaderHTML("Cash Book")}
    <div class="table-scroll"><table class="ledger-table"><thead><tr>
      <th>Date</th><th>Particulars</th><th>J.F.</th><th>Cash(₹)</th><th>Bank(₹)</th>
      <th>Date</th><th>Particulars</th><th>J.F.</th><th>Cash(₹)</th><th>Bank(₹)</th>
    </tr></thead><tbody>
      <tr><td>Year<br>Month Date</td><td>To Balance b/d</td><td></td><td>XXXX</td><td>XXXX</td><td>Year<br>Month Date</td><td>By Balance b/d*</td><td></td><td>-</td><td>XXXX</td></tr>
      <tr><td></td><td>To All Cash Receipts</td><td></td><td>XXXX</td><td>-</td><td></td><td>By All Cash Payments</td><td></td><td>XXXX</td><td>-</td></tr>
      <tr><td></td><td>To All Bank Receipts</td><td></td><td>-</td><td>XXXX</td><td></td><td>By All Bank Payments</td><td></td><td>-</td><td>XXXX</td></tr>
      <tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
      <tr><td></td><td>To Balance c/d*</td><td></td><td>-</td><td>XXXX</td><td></td><td>By Balance c/d</td><td></td><td>XXXX</td><td>XXXX</td></tr>
      <tr style="font-weight:700;"><td></td><td></td><td></td><td>XXXX</td><td>XXXX</td><td></td><td></td><td></td><td>XXXX</td><td>XXXX</td></tr>
    </tbody></table></div>
    <p style="font-size:0.83rem; line-height:1.6; color:var(--ink-faint); margin-top:12px;">* "By Balance b/d" (credit side) and "To Balance c/d" (debit side) in the Bank column appear only when the bank account is overdrawn — an overdraft is a credit balance, the opposite of cash, which is why these two lines sit on the opposite side from where you'd normally expect a balance.</p>
  `;
  panel.appendChild(card2);

  // 3. Simple Petty Cash Book — single amount-paid column, no analysis columns.
  const card3 = el("div", "card-solid", "");
  card3.style.cssText = "padding:22px;";
  card3.innerHTML = `
    <h4 style="font-size:0.95rem; margin-bottom:14px; color:var(--c-cb);">3. Simple Petty Cash Book</h4>
    <div style="text-align:center; font-family:var(--font-head); font-weight:700; font-size:0.95rem; margin-bottom:14px;">
      In the books of……<br>Simple Petty Cash Book
    </div>
    <div class="table-scroll"><table class="ledger-table"><thead><tr>
      <th>Amount Received (₹)</th><th>Cash Book Folio</th><th>Date</th><th>Particulars</th><th>V. No.</th><th>Amount Paid (₹)</th>
    </tr></thead><tbody>
      <tr><td></td><td></td><td></td><td></td><td></td><td></td></tr>
    </tbody></table></div>
    <p style="font-size:0.83rem; line-height:1.6; color:var(--ink-faint); margin-top:12px;">The Petty Cashier records the imprest received on the left, and every small payment (with its voucher number) as it happens on the right — one running column for all expenses, with no separate analysis columns.</p>
  `;
  panel.appendChild(card3);
}

/* ---- Practice Bank: identify which side + column (or "not in the
   Cash Book at all") a transaction belongs to. Scored exactly like the
   other chapters' practice banks (STATE.solved keys prefixed "cb-"),
   so Chapter 5's progress % now has something to compute against. ---- */
const CB_PRACTICE_OPTIONS = [
  "Debit side — Cash column",
  "Credit side — Cash column",
  "Debit side — Bank column",
  "Credit side — Bank column",
  "Contra entry — both sides (Cash & Bank)",
  "Not recorded in the Cash Book (Journal Proper)"
];
let cbFilterDifficulty = "All";

function renderCashBookPracticeBank(panel, data) {
  panel.innerHTML = "";
  panel.appendChild(sectionTitle("Cash Book practice"));
  const hint = el("p", "", `${data.numericals.length} transactions. For each one, decide which side and column of the Cash Book it belongs on — or whether it doesn't belong in the Cash Book at all.`);
  hint.style.cssText = "font-size:0.85rem; color:var(--ink-faint); margin:-8px 0 18px; line-height:1.6;";
  panel.appendChild(hint);

  const filterBar = el("div", "", "");
  filterBar.style.cssText = "display:flex; gap:8px; margin-bottom:18px; flex-wrap:wrap;";
  ["All", "Easy", "Medium", "Hard"].forEach(d => {
    const chip = el("button", `chip ${d === cbFilterDifficulty ? "active" : ""}`, d);
    chip.addEventListener("click", () => { cbFilterDifficulty = d; renderCashBookPracticeBank(panel, data); });
    filterBar.appendChild(chip);
  });
  panel.appendChild(filterBar);

  const list = data.numericals.filter(q => cbFilterDifficulty === "All" || q.difficulty === cbFilterDifficulty);
  const countLabel = el("p", "", `Showing ${list.length} of ${data.numericals.length} transactions`);
  countLabel.style.cssText = "font-size:0.83rem; color:var(--ink-faint); margin-bottom:16px;";
  panel.appendChild(countLabel);

  list.forEach(q => {
    const solvedKey = `cb-${q.id}`;
    const alreadySolved = STATE.solved[solvedKey];
    let picked = null;

    const card = el("div", "card q-card", "");
    card.innerHTML = `
      <div class="q-meta">
        <span class="diff-badge ${q.difficulty}">${q.difficulty}</span>
        <span class="q-id">Q${q.id}</span>
        ${alreadySolved ? `<span style="margin-left:auto; color:var(--c-cb); font-size:0.78rem; display:flex; align-items:center; gap:4px;"><i data-lucide="check-circle" style="width:13px;height:13px;"></i> Solved</span>` : ""}
      </div>
      <div class="q-body">${q.transaction}</div>
      <div style="margin-top:14px;">
        <p style="font-size:0.78rem; text-transform:uppercase; letter-spacing:0.04em; color:var(--ink-faint); margin-bottom:8px;">Where does this belong?</p>
        <div class="opt-group" data-role="answer" style="display:flex; flex-wrap:wrap; gap:8px;">
          ${CB_PRACTICE_OPTIONS.map(o => `<button class="chip" data-val="${o}">${o}</button>`).join("")}
        </div>
      </div>
      <div class="q-actions" style="margin-top:14px;">
        <button class="btn-primary sm ripple-surface" data-act="check"><i data-lucide="check"></i> Check Answer</button>
      </div>
      <div class="reveal-area"></div>
    `;
    const revealArea = $(".reveal-area", card);

    card.addEventListener("click", (e) => {
      const optBtn = e.target.closest(".opt-group button[data-val]");
      if (optBtn) {
        const group = optBtn.closest(".opt-group");
        $all("button", group).forEach(b => b.classList.remove("active"));
        optBtn.classList.add("active");
        picked = optBtn.dataset.val;
        return;
      }
      const checkBtn = e.target.closest("button[data-act='check']");
      if (checkBtn) {
        if (!picked) {
          revealArea.innerHTML = `<div class="reveal-block hint-block"><p style="font-size:0.86rem;">Pick an option first.</p></div>`;
          return;
        }
        const correct = picked === q.answer;
        if (correct) {
          revealArea.innerHTML = `
            <div class="reveal-block">
              <h4>Correct!</h4>
              <p style="font-size:0.87rem; line-height:1.6; color:var(--ink-soft);"><b>${q.posting}</b> — ${q.explanation}</p>
            </div>`;
          playSuccessSound();
          if (!STATE.solved[solvedKey]) {
            STATE.solved[solvedKey] = { correct: true, attempts: 1 };
            saveState(); addXP(4, `Cash Book Q${q.id} solved`); logActivity(`Cash Book Q${q.id} solved (${q.difficulty})`); refreshProgress();
          }
          mistakeBookRecordCorrect(solvedKey);
        } else {
          revealArea.innerHTML = `
            <div class="reveal-block" style="background:var(--flag-soft); border-left-color:var(--flag);">
              <h4>Not quite</h4>
              <p style="font-size:0.87rem; line-height:1.6; color:var(--ink-soft);">The correct answer is: <b>${q.answer}</b>.<br><b>${q.posting}</b> — ${q.explanation}</p>
            </div>`;
          playErrorSound();
          if (!STATE.solved[solvedKey]) {
            STATE.solved[solvedKey] = { correct: false, attempts: 1 };
            if (!STATE.mistakes.includes(solvedKey)) STATE.mistakes.push(solvedKey);
            saveState(); addXP(-XP_WRONG_PENALTY, `Q${q.id} incorrect`); refreshProgress();
          }
          mistakeBookRecord({
            key: solvedKey, question: q.transaction, chapter: "cb", chapterLabel: "Special Purpose Books 1 - Cash Book",
            topic: "Cash Book Recording", type: "Cash Book Placement",
            studentAnswer: picked,
            correctAnswer: q.answer,
            explanation: q.explanation
          });
        }
        icons();
      }
    });
    panel.appendChild(card);
  });
  applyMobilePager(panel);
  icons();
}

function renderCashBookQuickRevision(panel, data) {
  panel.appendChild(sectionTitle("Quick revision"));
  const qr = data.quickRevision;
  const card = el("div", "card-solid", "");
  card.style.padding = "28px";
  card.innerHTML = `
    <div class="ledger-rule">
      <h4 style="font-size:0.95rem; margin-bottom:8px;">Definition</h4>
      <p style="font-size:0.89rem; line-height:1.6; color:var(--ink-soft);">${qr.definition}</p>
    </div>
    <div class="ledger-rule" style="margin-top:18px;">
      <h4 style="font-size:0.95rem; margin-bottom:8px;">Key points</h4>
      <ol style="padding-left:20px;">${qr.keyPoints.map(r => `<li style="margin-bottom:6px; font-size:0.87rem; color:var(--ink-soft);">${r}</li>`).join("")}</ol>
    </div>
    <div class="ledger-rule" style="margin-top:18px;">
      <h4 style="font-size:0.95rem; margin-bottom:8px;">Balancing steps</h4>
      <ol style="padding-left:20px;">${qr.balancingSteps.map(r => `<li style="margin-bottom:6px; font-size:0.87rem; color:var(--ink-soft);">${r}</li>`).join("")}</ol>
    </div>
    <div class="ledger-rule" style="margin-top:18px;">
      <h4 style="font-size:0.95rem; margin-bottom:8px; color:var(--flag);">Common mistakes</h4>
      <ul style="padding-left:20px;">${qr.commonMistakes.map(r => `<li style="margin-bottom:6px; font-size:0.87rem; color:var(--ink-soft);">${r}</li>`).join("")}</ul>
    </div>
    <div class="tnum" style="text-align:center; font-size:0.92rem; font-weight:600; color:var(--c-cb); background:var(--c-cb-soft); padding:14px; border-radius:10px; margin-top:18px;">
      💡 Mnemonic: ${qr.mnemonic}
    </div>
  `;
  panel.appendChild(card);
}

/* ---------------------------------------------------------
   6d-2. CHAPTER 6 — SPECIAL PURPOSE BOOKS 2: OTHER BOOKS
   Purchases Book, Sales Book, Purchases Return Book, Sales
   Return Book, and Journal Proper. Mirrors the Cash Book
   chapter's exact tab structure, UI, and feature wiring.
   --------------------------------------------------------- */
function renderSp2Chapter(root) {
  const data = APP_DATA.specialBooks2;
  root.appendChild(el("div", "hero", `
    <span class="hero-eyebrow">Chapter 6</span>
    <h1>Special Purpose Books 2 - Other Books</h1>
    <p>${APP_DATA.chapters[5].tagline} Sub-division of Journal, Debit &amp; Credit Notes, and the mechanics of posting each book — all from your textbook chapter.</p>
  `));

  const tabs = ["Introduction", "Format & Rules", "Practice Bank", "Quick Revision"];
  const tabBar = el("div", "", "");
  tabBar.style.cssText = "display:flex; gap:8px; flex-wrap:wrap; margin-bottom:22px;";
  tabs.forEach((t, i) => {
    const chip = el("button", `chip ${i===0?'active':''}`, t);
    chip.dataset.tab = t;
    tabBar.appendChild(chip);
  });
  const journeyEl = renderJourneyStepper(root, "sp2");
  root.appendChild(tabBar);
  const panel = el("div", "");
  root.appendChild(panel);

  function showTab(name) {
    $all(".chip", tabBar).forEach(c => c.classList.toggle("active", c.dataset.tab === name));
    panel.innerHTML = "";
    updateJourneyStepper(journeyEl, "sp2", name);
    if (name === "Introduction") renderSp2Intro(panel, data);
    if (name === "Format & Rules") renderSp2FormatRules(panel, data);
    if (name === "Practice Bank") renderSp2PracticeBank(panel, data);
    if (name === "Quick Revision") renderSp2QuickRevision(panel, data);
    icons();
  }
  tabBar.addEventListener("click", e => {
    const chip = e.target.closest(".chip");
    if (chip) showTab(chip.dataset.tab);
  });
  showTab("Introduction");
}

/* ---- Introduction: sub-division of Journal, meaning of each book ---- */
function renderSp2Intro(panel, data) {
  panel.appendChild(sectionTitle("Meaning, features & types"));
  renderCashBookTheoryBlocks(panel, data.theory.simple, "var(--c-sp2)", "var(--c-sp2-soft)");
  panel.appendChild(sectionTitle("Key concepts"));
  const grid = el("div", "grid-3");
  data.concepts.forEach(c => {
    const card = el("div", "card liftable", "");
    card.style.padding = "22px";
    card.innerHTML = `<h4 style="font-size:1rem; margin-bottom:8px; color:var(--c-sp2);">${c.title}</h4><p style="font-size:0.87rem; line-height:1.6; color:var(--ink-soft);">${c.body}</p>`;
    grid.appendChild(card);
  });
  panel.appendChild(grid);
}

/* ---- Format & Rules: rulings, posting mechanics, difference tables,
   plus the five book formats reproduced from the textbook chapter. ---- */
function renderSp2FormatRules(panel, data) {
  panel.appendChild(sectionTitle("Rulings, posting & differences"));
  renderCashBookTheoryBlocks(panel, data.theory.advanced, "var(--c-sp2)", "var(--c-sp2-soft)");
  renderSp2FormatTemplates(panel);
}

function sp2FormatHeaderHTML(title) {
  return `
    <div style="text-align:center; margin-bottom:14px;">
      <div style="display:flex; justify-content:space-between; font-weight:700; font-size:0.85rem;">
        <span>Dr.</span><span>Cr.</span>
      </div>
      <div style="font-family:var(--font-head); font-weight:700; font-size:0.95rem; margin-top:-18px;">
        In the Books of…<br>${title}
      </div>
    </div>`;
}

function renderSp2FormatTemplates(panel) {
  panel.appendChild(sectionTitle("Book formats"));
  const hint = el("p", "", "The rulings of all five books covered in this chapter, reproduced exactly as they appear in the textbook — a quick visual reference before you attempt the Practice Bank.");
  hint.style.cssText = "font-size:0.85rem; color:var(--ink-faint); margin:-8px 0 18px; line-height:1.6;";
  panel.appendChild(hint);

  // 1. Purchases Book
  const card1 = el("div", "card-solid", "");
  card1.style.cssText = "padding:22px; margin-bottom:18px;";
  card1.innerHTML = `
    <h4 style="font-size:0.95rem; margin-bottom:14px; color:var(--c-sp2);">1. Purchases Book or Purchases Journal</h4>
    <div class="table-scroll"><table class="ledger-table"><thead><tr>
      <th>Date</th><th>Particulars</th><th>Invoice No.</th><th>L.F.</th><th>Details (₹)</th><th>Cost (₹)</th><th>Freight/Cartage etc. (₹)</th><th>Total (₹)</th>
    </tr></thead><tbody>
      <tr><td>Year<br>Month Date</td><td>Name of Seller<br>List Price (Qty × Price) …<br>Less: Trade Discount …</td><td>XXXX</td><td></td><td>XXXX</td><td>XXXX</td><td>XXXX</td><td>XXXX</td></tr>
      <tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
      <tr style="font-weight:700;"><td colspan="4">Purchases A/c …Dr.</td><td></td><td>XXXX</td><td>XXXX</td><td>XXXX</td></tr>
    </tbody></table></div>
    <p style="font-size:0.83rem; line-height:1.6; color:var(--ink-faint); margin-top:12px;">Only credit purchases of goods (or raw material) — net of trade discount, based on invoices received. The Cost column total is debited to Purchases A/c; the Freight column total is debited to Freight/Cartage Inwards A/c.</p>
  `;
  panel.appendChild(card1);

  // 2. Sales Book
  const card2 = el("div", "card-solid", "");
  card2.style.cssText = "padding:22px; margin-bottom:18px;";
  card2.innerHTML = `
    <h4 style="font-size:0.95rem; margin-bottom:14px; color:var(--c-sp2);">2. Sales Book or Sales Journal</h4>
    <div class="table-scroll"><table class="ledger-table"><thead><tr>
      <th>Date</th><th>Particulars</th><th>Invoice No.</th><th>L.F.</th><th>Details (₹)</th><th>Sale Value (₹)</th><th>Freight/Carriage etc. (₹)</th><th>Total (₹)</th>
    </tr></thead><tbody>
      <tr><td>Year<br>Month Date</td><td>Name of Purchaser<br>List Price (Qty × Price) …<br>Less: Trade Discount …</td><td>XXXX</td><td></td><td>XXXX</td><td>XXXX</td><td>XXXX</td><td>XXXX</td></tr>
      <tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
      <tr style="font-weight:700;"><td colspan="5">Sales A/c …Cr.</td><td>XXXX</td><td>XXXX</td><td>XXXX</td></tr>
    </tbody></table></div>
    <p style="font-size:0.83rem; line-height:1.6; color:var(--ink-faint); margin-top:12px;">Only credit sales of goods dealt in — net of trade discount, based on invoices issued. The Sale Value column total is credited to Sales A/c; a Packing column total, if any, is credited to Packing Charges A/c.</p>
  `;
  panel.appendChild(card2);

  // 3. Purchases Return Book
  const card3 = el("div", "card-solid", "");
  card3.style.cssText = "padding:22px; margin-bottom:18px;";
  card3.innerHTML = `
    <h4 style="font-size:0.95rem; margin-bottom:14px; color:var(--c-sp2);">3. Purchases Return Book (Returns Outward Book)</h4>
    <div class="table-scroll"><table class="ledger-table"><thead><tr>
      <th>Date</th><th>Particulars</th><th>Debit Note No.</th><th>L.F.</th><th>Details (₹)</th><th>Amount (₹)</th>
    </tr></thead><tbody>
      <tr><td>Year<br>Month Date</td><td>Name of Supplier — goods returned</td><td>XXXX</td><td></td><td>XXXX</td><td>XXXX</td></tr>
      <tr><td></td><td></td><td></td><td></td><td></td><td></td></tr>
      <tr style="font-weight:700;"><td colspan="5">Purchases Return A/c …Cr.</td><td>XXXX</td></tr>
    </tbody></table></div>
    <p style="font-size:0.83rem; line-height:1.6; color:var(--ink-faint); margin-top:12px;">Ruled exactly like the Purchases Book, with "Debit Note No." replacing "Invoice No." Basis of entry: the Debit Note prepared by the purchaser. Total is credited to Purchases Return A/c.</p>
  `;
  panel.appendChild(card3);

  // 4. Sales Return Book
  const card4 = el("div", "card-solid", "");
  card4.style.cssText = "padding:22px; margin-bottom:18px;";
  card4.innerHTML = `
    <h4 style="font-size:0.95rem; margin-bottom:14px; color:var(--c-sp2);">4. Sales Return Book (Returns Inward Book)</h4>
    <div class="table-scroll"><table class="ledger-table"><thead><tr>
      <th>Date</th><th>Particulars</th><th>Credit Note No.</th><th>L.F.</th><th>Details (₹)</th><th>Amount (₹)</th>
    </tr></thead><tbody>
      <tr><td>Year<br>Month Date</td><td>Name of Customer — goods returned</td><td>XXXX</td><td></td><td>XXXX</td><td>XXXX</td></tr>
      <tr><td></td><td></td><td></td><td></td><td></td><td></td></tr>
      <tr style="font-weight:700;"><td colspan="5">Sales Return A/c …Dr.</td><td>XXXX</td></tr>
    </tbody></table></div>
    <p style="font-size:0.83rem; line-height:1.6; color:var(--ink-faint); margin-top:12px;">Ruled exactly like the Sales Book, with "Credit Note No." replacing "Invoice No." Basis of entry: the Credit Note prepared by the seller. Total is debited to Sales Return A/c.</p>
  `;
  panel.appendChild(card4);

  // 5. Journal Proper — pattern, not a fixed ruling (same columns as an ordinary Journal)
  const card5 = el("div", "card-solid", "");
  card5.style.cssText = "padding:22px;";
  card5.innerHTML = `
    <h4 style="font-size:0.95rem; margin-bottom:14px; color:var(--c-sp2);">5. Journal Proper (or General Journal)</h4>
    <div class="table-scroll"><table class="ledger-table"><thead><tr>
      <th>Date</th><th>Particulars</th><th>L.F.</th><th>Dr. (₹)</th><th>Cr. (₹)</th>
    </tr></thead><tbody>
      <tr><td>Year<br>Month Date</td><td>Sundry Assets A/c …Dr.<br>&nbsp;&nbsp;To Sundry Liabilities A/c<br>&nbsp;&nbsp;To Capital A/c<br><i>(Being last year's balances brought forward)</i></td><td></td><td>XXXX</td><td>XXXX<br>XXXX</td></tr>
    </tbody></table></div>
    <p style="font-size:0.83rem; line-height:1.6; color:var(--ink-faint); margin-top:12px;">Same column layout as an ordinary Journal — used for Opening, Closing, Rectification, Transfer, Adjustment, and Miscellaneous entries that don't fit any other book.</p>
  `;
  panel.appendChild(card5);
}

/* ---- Practice Bank: identify which Subsidiary Book (or the Cash
   Book, via "not recorded here") a transaction belongs in. Scored
   exactly like the Cash Book chapter (STATE.solved keys prefixed
   "sp2-"). ---- */
const SP2_PRACTICE_OPTIONS = [
  "Purchases Book",
  "Sales Book",
  "Purchases Return Book (Returns Outward)",
  "Sales Return Book (Returns Inward)",
  "Journal Proper",
  "Not recorded here — recorded in the Cash Book"
];
let sp2FilterDifficulty = "All";

function renderSp2PracticeBank(panel, data) {
  panel.innerHTML = "";
  panel.appendChild(sectionTitle("Other Books practice"));
  const hint = el("p", "", `${data.numericals.length} transactions. For each one, decide which Subsidiary Book it belongs in — or whether it belongs in the Cash Book instead.`);
  hint.style.cssText = "font-size:0.85rem; color:var(--ink-faint); margin:-8px 0 18px; line-height:1.6;";
  panel.appendChild(hint);

  const filterBar = el("div", "", "");
  filterBar.style.cssText = "display:flex; gap:8px; margin-bottom:18px; flex-wrap:wrap;";
  ["All", "Easy", "Medium", "Hard"].forEach(d => {
    const chip = el("button", `chip ${d === sp2FilterDifficulty ? "active" : ""}`, d);
    chip.addEventListener("click", () => { sp2FilterDifficulty = d; renderSp2PracticeBank(panel, data); });
    filterBar.appendChild(chip);
  });
  panel.appendChild(filterBar);

  const list = data.numericals.filter(q => sp2FilterDifficulty === "All" || q.difficulty === sp2FilterDifficulty);
  const countLabel = el("p", "", `Showing ${list.length} of ${data.numericals.length} transactions`);
  countLabel.style.cssText = "font-size:0.83rem; color:var(--ink-faint); margin-bottom:16px;";
  panel.appendChild(countLabel);

  list.forEach(q => {
    const solvedKey = `sp2-${q.id}`;
    const alreadySolved = STATE.solved[solvedKey];
    let picked = null;

    const card = el("div", "card q-card", "");
    card.innerHTML = `
      <div class="q-meta">
        <span class="diff-badge ${q.difficulty}">${q.difficulty}</span>
        <span class="q-id">Q${q.id}</span>
        ${alreadySolved ? `<span style="margin-left:auto; color:var(--c-sp2); font-size:0.78rem; display:flex; align-items:center; gap:4px;"><i data-lucide="check-circle" style="width:13px;height:13px;"></i> Solved</span>` : ""}
      </div>
      <div class="q-body">${q.transaction}</div>
      <div style="margin-top:14px;">
        <p style="font-size:0.78rem; text-transform:uppercase; letter-spacing:0.04em; color:var(--ink-faint); margin-bottom:8px;">Which book does this belong in?</p>
        <div class="opt-group" data-role="answer" style="display:flex; flex-wrap:wrap; gap:8px;">
          ${SP2_PRACTICE_OPTIONS.map(o => `<button class="chip" data-val="${o}">${o}</button>`).join("")}
        </div>
      </div>
      <div class="q-actions" style="margin-top:14px;">
        <button class="btn-primary sm ripple-surface" data-act="check"><i data-lucide="check"></i> Check Answer</button>
      </div>
      <div class="reveal-area"></div>
    `;
    const revealArea = $(".reveal-area", card);

    card.addEventListener("click", (e) => {
      const optBtn = e.target.closest(".opt-group button[data-val]");
      if (optBtn) {
        const group = optBtn.closest(".opt-group");
        $all("button", group).forEach(b => b.classList.remove("active"));
        optBtn.classList.add("active");
        picked = optBtn.dataset.val;
        return;
      }
      const checkBtn = e.target.closest("button[data-act='check']");
      if (checkBtn) {
        if (!picked) {
          revealArea.innerHTML = `<div class="reveal-block hint-block"><p style="font-size:0.86rem;">Pick an option first.</p></div>`;
          return;
        }
        const correct = picked === q.answer;
        if (correct) {
          revealArea.innerHTML = `
            <div class="reveal-block">
              <h4>Correct!</h4>
              <p style="font-size:0.87rem; line-height:1.6; color:var(--ink-soft);"><b>${q.posting}</b> — ${q.explanation}</p>
            </div>`;
          playSuccessSound();
          if (!STATE.solved[solvedKey]) {
            STATE.solved[solvedKey] = { correct: true, attempts: 1 };
            saveState(); addXP(4, `Other Books Q${q.id} solved`); logActivity(`Other Books Q${q.id} solved (${q.difficulty})`); refreshProgress();
          }
          mistakeBookRecordCorrect(solvedKey);
        } else {
          revealArea.innerHTML = `
            <div class="reveal-block" style="background:var(--flag-soft); border-left-color:var(--flag);">
              <h4>Not quite</h4>
              <p style="font-size:0.87rem; line-height:1.6; color:var(--ink-soft);">The correct answer is: <b>${q.answer}</b>.<br><b>${q.posting}</b> — ${q.explanation}</p>
            </div>`;
          playErrorSound();
          if (!STATE.solved[solvedKey]) {
            STATE.solved[solvedKey] = { correct: false, attempts: 1 };
            if (!STATE.mistakes.includes(solvedKey)) STATE.mistakes.push(solvedKey);
            saveState(); addXP(-XP_WRONG_PENALTY, `Q${q.id} incorrect`); refreshProgress();
          }
          mistakeBookRecord({
            key: solvedKey, question: q.transaction, chapter: "sp2", chapterLabel: "Special Purpose Books 2 - Other Books",
            topic: "Other Books Recording", type: "Book Placement",
            studentAnswer: picked,
            correctAnswer: q.answer,
            explanation: q.explanation
          });
        }
        icons();
      }
    });
    panel.appendChild(card);
  });
  applyMobilePager(panel);
  icons();
}

function renderSp2QuickRevision(panel, data) {
  panel.appendChild(sectionTitle("Quick revision"));
  const qr = data.quickRevision;
  const card = el("div", "card-solid", "");
  card.style.padding = "28px";
  card.innerHTML = `
    <div class="ledger-rule">
      <h4 style="font-size:0.95rem; margin-bottom:8px;">Definition</h4>
      <p style="font-size:0.89rem; line-height:1.6; color:var(--ink-soft);">${qr.definition}</p>
    </div>
    <div class="ledger-rule" style="margin-top:18px;">
      <h4 style="font-size:0.95rem; margin-bottom:8px;">Key points</h4>
      <ol style="padding-left:20px;">${qr.keyPoints.map(r => `<li style="margin-bottom:6px; font-size:0.87rem; color:var(--ink-soft);">${r}</li>`).join("")}</ol>
    </div>
    <div class="ledger-rule" style="margin-top:18px;">
      <h4 style="font-size:0.95rem; margin-bottom:8px;">Posting rules</h4>
      <ol style="padding-left:20px;">${qr.postingRules.map(r => `<li style="margin-bottom:6px; font-size:0.87rem; color:var(--ink-soft);">${r}</li>`).join("")}</ol>
    </div>
    <div class="ledger-rule" style="margin-top:18px;">
      <h4 style="font-size:0.95rem; margin-bottom:8px; color:var(--flag);">Common mistakes</h4>
      <ul style="padding-left:20px;">${qr.commonMistakes.map(r => `<li style="margin-bottom:6px; font-size:0.87rem; color:var(--ink-soft);">${r}</li>`).join("")}</ul>
    </div>
    <div class="tnum" style="text-align:center; font-size:0.92rem; font-weight:600; color:var(--c-sp2); background:var(--c-sp2-soft); padding:14px; border-radius:10px; margin-top:18px;">
      💡 Mnemonic: ${qr.mnemonic}
    </div>
  `;
  panel.appendChild(card);
}

/* ---------------------------------------------------------
   6d-3. CHAPTER 7 — BANK RECONCILIATION STATEMENT (BRS)
   Mirrors the Cash Book / Special Purpose Books 2 chapter's
   exact tab structure, UI and feature wiring, with a fifth
   tab — BRS Detective — added for scenario-based practice.
   --------------------------------------------------------- */
function renderBrsChapter(root) {
  const data = APP_DATA.brs;
  root.appendChild(el("div", "hero", `
    <span class="hero-eyebrow">Chapter 7</span>
    <h1>Bank Reconciliation Statement (BRS)</h1>
    <p>${APP_DATA.chapters[6].tagline} Meaning, format, the standard causes of difference, Add/Less logic from either starting balance, and BRS Detective — all at Class 11 level.</p>
  `));

  const tabs = ["Introduction", "Format & Rules", "Practice Bank", "Quick Revision", "BRS Detective"];
  const tabBar = el("div", "", "");
  tabBar.style.cssText = "display:flex; gap:8px; flex-wrap:wrap; margin-bottom:22px;";
  tabs.forEach((t, i) => {
    const chip = el("button", `chip ${i===0?'active':''}`, t);
    chip.dataset.tab = t;
    tabBar.appendChild(chip);
  });
  const journeyEl = renderJourneyStepper(root, "brs");
  root.appendChild(tabBar);
  const panel = el("div", "");
  root.appendChild(panel);

  function showTab(name) {
    $all(".chip", tabBar).forEach(c => c.classList.toggle("active", c.dataset.tab === name));
    panel.innerHTML = "";
    updateJourneyStepper(journeyEl, "brs", name);
    if (name === "Introduction") renderBrsIntro(panel, data);
    if (name === "Format & Rules") renderBrsFormatRules(panel, data);
    if (name === "Practice Bank") renderBrsPracticeBank(panel, data);
    if (name === "Quick Revision") renderBrsQuickRevision(panel, data);
    if (name === "BRS Detective") renderBrsDetective(panel, data);
    icons();
  }
  tabBar.addEventListener("click", e => {
    const chip = e.target.closest(".chip");
    if (chip) showTab(chip.dataset.tab);
  });
  showTab("Introduction");
}

/* ---- Introduction: meaning, why balances differ, purpose ---- */
function renderBrsIntro(panel, data) {
  panel.appendChild(sectionTitle("Meaning, purpose & basic idea"));
  renderCashBookTheoryBlocks(panel, data.theory.simple, "var(--c-brs)", "var(--c-brs-soft)");
  panel.appendChild(sectionTitle("Key concepts"));
  const grid = el("div", "grid-3");
  data.concepts.forEach(c => {
    const card = el("div", "card liftable", "");
    card.style.padding = "22px";
    card.innerHTML = `<h4 style="font-size:1rem; margin-bottom:8px; color:var(--c-brs);">${c.title}</h4><p style="font-size:0.87rem; line-height:1.6; color:var(--ink-soft);">${c.body}</p>`;
    grid.appendChild(card);
  });
  panel.appendChild(grid);
}

/* ---- Format & Rules: the Add/Less rule, both formats, and
   every standard cause of difference with full reasoning ---- */
function renderBrsFormatRules(panel, data) {
  panel.appendChild(sectionTitle("Format, rules & causes of difference"));
  renderCashBookTheoryBlocks(panel, data.theory.advanced, "var(--c-brs)", "var(--c-brs-soft)");
}

const BRS_PRACTICE_OPTIONS = [
  "Add — to arrive at Balance as per Pass Book",
  "Less — to arrive at Balance as per Pass Book",
  "Add — to arrive at Balance as per Cash Book",
  "Less — to arrive at Balance as per Cash Book"
];
let brsFilterDifficulty = "All";

function renderBrsPracticeBank(panel, data) {
  panel.innerHTML = "";
  panel.appendChild(sectionTitle("BRS practice bank"));
  const hint = el("p", "", `${data.numericals.length} questions. Each one states its own starting balance — decide whether the item should be Added or Deducted, and towards which balance.`);
  hint.style.cssText = "font-size:0.85rem; color:var(--ink-faint); margin:-8px 0 18px; line-height:1.6;";
  panel.appendChild(hint);

  const filterBar = el("div", "", "");
  filterBar.style.cssText = "display:flex; gap:8px; margin-bottom:18px; flex-wrap:wrap;";
  ["All", "Easy", "Medium", "Hard"].forEach(d => {
    const chip = el("button", `chip ${d === brsFilterDifficulty ? "active" : ""}`, d);
    chip.addEventListener("click", () => { brsFilterDifficulty = d; renderBrsPracticeBank(panel, data); });
    filterBar.appendChild(chip);
  });
  panel.appendChild(filterBar);

  const list = data.numericals.filter(q => brsFilterDifficulty === "All" || q.difficulty === brsFilterDifficulty);
  const countLabel = el("p", "", `Showing ${list.length} of ${data.numericals.length} questions`);
  countLabel.style.cssText = "font-size:0.83rem; color:var(--ink-faint); margin-bottom:16px;";
  panel.appendChild(countLabel);

  list.forEach(q => {
    const solvedKey = `brs-${q.id}`;
    const alreadySolved = STATE.solved[solvedKey];
    let picked = null;

    const card = el("div", "card q-card", "");
    card.innerHTML = `
      <div class="q-meta">
        <span class="diff-badge ${q.difficulty}">${q.difficulty}</span>
        <span class="q-id">Q${q.id}</span>
        ${alreadySolved ? `<span style="margin-left:auto; color:var(--c-brs); font-size:0.78rem; display:flex; align-items:center; gap:4px;"><i data-lucide="check-circle" style="width:13px;height:13px;"></i> Solved</span>` : ""}
      </div>
      <div class="q-body">${q.transaction}</div>
      <div style="margin-top:14px;">
        <p style="font-size:0.78rem; text-transform:uppercase; letter-spacing:0.04em; color:var(--ink-faint); margin-bottom:8px;">What's the treatment?</p>
        <div class="opt-group" data-role="answer" style="display:flex; flex-wrap:wrap; gap:8px;">
          ${BRS_PRACTICE_OPTIONS.map(o => `<button class="chip" data-val="${o}">${o}</button>`).join("")}
        </div>
      </div>
      <div class="q-actions" style="margin-top:14px;">
        <button class="btn-primary sm ripple-surface" data-act="check"><i data-lucide="check"></i> Check Answer</button>
      </div>
      <div class="reveal-area"></div>
    `;
    const revealArea = $(".reveal-area", card);

    card.addEventListener("click", (e) => {
      const optBtn = e.target.closest(".opt-group button[data-val]");
      if (optBtn) {
        const group = optBtn.closest(".opt-group");
        $all("button", group).forEach(b => b.classList.remove("active"));
        optBtn.classList.add("active");
        picked = optBtn.dataset.val;
        return;
      }
      const checkBtn = e.target.closest("button[data-act='check']");
      if (checkBtn) {
        if (!picked) {
          revealArea.innerHTML = `<div class="reveal-block hint-block"><p style="font-size:0.86rem;">Pick an option first.</p></div>`;
          return;
        }
        const correct = picked === q.answer;
        if (correct) {
          revealArea.innerHTML = `
            <div class="reveal-block">
              <h4>Correct!</h4>
              <p style="font-size:0.87rem; line-height:1.6; color:var(--ink-soft);"><b>${q.posting}</b> — ${q.explanation}</p>
            </div>`;
          playSuccessSound();
          if (!STATE.solved[solvedKey]) {
            STATE.solved[solvedKey] = { correct: true, attempts: 1 };
            saveState(); addXP(4, `BRS Q${q.id} solved`); logActivity(`BRS Q${q.id} solved (${q.difficulty})`); refreshProgress();
          }
          mistakeBookRecordCorrect(solvedKey);
        } else {
          revealArea.innerHTML = `
            <div class="reveal-block" style="background:var(--flag-soft); border-left-color:var(--flag);">
              <h4>Not quite</h4>
              <p style="font-size:0.87rem; line-height:1.6; color:var(--ink-soft);">The correct answer is: <b>${q.answer}</b>.<br><b>${q.posting}</b> — ${q.explanation}</p>
            </div>`;
          playErrorSound();
          if (!STATE.solved[solvedKey]) {
            STATE.solved[solvedKey] = { correct: false, attempts: 1 };
            if (!STATE.mistakes.includes(solvedKey)) STATE.mistakes.push(solvedKey);
            saveState(); addXP(-XP_WRONG_PENALTY, `Q${q.id} incorrect`); refreshProgress();
          }
          mistakeBookRecord({
            key: solvedKey, question: q.transaction, chapter: "brs", chapterLabel: "Bank Reconciliation Statement (BRS)",
            topic: "BRS Add/Less Treatment", type: "BRS Classification",
            studentAnswer: picked,
            correctAnswer: q.answer,
            explanation: q.explanation
          });
        }
        icons();
      }
    });
    panel.appendChild(card);
  });
  applyMobilePager(panel);
  icons();
}

function renderBrsQuickRevision(panel, data) {
  panel.appendChild(sectionTitle("Quick revision"));
  const qr = data.quickRevision;
  const card = el("div", "card-solid", "");
  card.style.padding = "28px";
  card.innerHTML = `
    <div class="ledger-rule">
      <h4 style="font-size:0.95rem; margin-bottom:8px;">Definition</h4>
      <p style="font-size:0.89rem; line-height:1.6; color:var(--ink-soft);">${qr.definition}</p>
    </div>
    <div class="ledger-rule" style="margin-top:18px;">
      <h4 style="font-size:0.95rem; margin-bottom:8px;">Key points</h4>
      <ol style="padding-left:20px;">${qr.keyPoints.map(r => `<li style="margin-bottom:6px; font-size:0.87rem; color:var(--ink-soft);">${r}</li>`).join("")}</ol>
    </div>
    <div class="ledger-rule" style="margin-top:18px;">
      <h4 style="font-size:0.95rem; margin-bottom:8px;">Add/Less logic</h4>
      <ol style="padding-left:20px;">${qr.addLessLogic.map(r => `<li style="margin-bottom:6px; font-size:0.87rem; color:var(--ink-soft);">${r}</li>`).join("")}</ol>
    </div>
    <div class="ledger-rule" style="margin-top:18px;">
      <h4 style="font-size:0.95rem; margin-bottom:8px; color:var(--flag);">Common mistakes</h4>
      <ul style="padding-left:20px;">${qr.commonMistakes.map(r => `<li style="margin-bottom:6px; font-size:0.87rem; color:var(--ink-soft);">${r}</li>`).join("")}</ul>
    </div>
    <div class="tnum" style="text-align:center; font-size:0.92rem; font-weight:600; color:var(--c-brs); background:var(--c-brs-soft); padding:14px; border-radius:10px; margin-top:18px;">
      💡 Mnemonic: ${qr.mnemonic}
    </div>
  `;
  panel.appendChild(card);
}

/* ---- BRS Detective: 102 cases across timing differences, bank
   entries, Cash Book errors, bank errors, starting-balance /
   overdraft variants, and mixed multi-item cases. Every core cause
   has an explicit Pass-Book-start twin alongside its Cash-Book-start
   original, so the deck is never Cash-Book-only. The deck is
   shuffled once per visit to this tab; cases don't repeat until
   the whole deck has been seen. Each case may contain multiple
   items — every item must be identified (Add/Less) separately
   before the combined reconciled balance is revealed. ---- */
let brsDetectiveOrder = null;
let brsDetectiveIndex = 0;
let brsDetectiveScore = { correct: 0, attempted: 0 };
let brsDetectivePicks = {};

function fmtBrsBalance(n) {
  const abs = Math.abs(n).toLocaleString("en-IN");
  return n < 0 ? `₹${abs} (Overdraft)` : `₹${abs}`;
}

function renderBrsDetective(panel, data) {
  panel.appendChild(sectionTitle("BRS Detective 🕵️"));
  const cases = data.detective;
  const hint = el("p", "", `${cases.length} cases — starting from BOTH the Cash Book and the Pass Book, covering favourable balances and overdrafts, timing differences, bank entries, Cash Book errors, bank errors, starting-balance variations, and mixed cases with several differences at once. Always check which balance you're starting from — the same situation can require the opposite treatment depending on it. Identify every item separately, then reveal the reasoning.`);
  hint.style.cssText = "font-size:0.85rem; color:var(--ink-faint); margin:-8px 0 18px; line-height:1.6;";
  panel.appendChild(hint);

  if (!brsDetectiveOrder || brsDetectiveOrder.length !== cases.length) {
    brsDetectiveOrder = fisherYatesShuffle(cases.map((_, i) => i));
    brsDetectiveIndex = 0;
    brsDetectiveScore = { correct: 0, attempted: 0 };
  }
  if (brsDetectiveIndex >= brsDetectiveOrder.length) brsDetectiveIndex = 0;
  if (brsDetectiveIndex < 0) brsDetectiveIndex = brsDetectiveOrder.length - 1;

  const topBar = el("div", "", "");
  topBar.style.cssText = "display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:14px;";
  topBar.innerHTML = `
    <p style="font-size:0.83rem; color:var(--ink-faint); margin:0;">Case ${brsDetectiveIndex + 1} of ${cases.length}</p>
    <p style="font-size:0.83rem; color:var(--c-brs); margin:0; font-weight:600;">Detective Score: ${brsDetectiveScore.correct}/${brsDetectiveScore.attempted}</p>
  `;
  panel.appendChild(topBar);

  const c = cases[brsDetectiveOrder[brsDetectiveIndex]];
  if (!brsDetectivePicks[c.id]) brsDetectivePicks[c.id] = {};
  const picks = brsDetectivePicks[c.id];
  let revealed = false;

  const card = el("div", "card-solid q-card", "");
  card.style.cssText = "padding:26px;";

  const itemsHTML = c.items.map((it, idx) => `
    <div class="brsdet-item" data-idx="${idx}" style="margin-top:${c.items.length > 1 ? "16px" : "0"}; padding:${c.items.length > 1 ? "14px" : "0"}; ${c.items.length > 1 ? "border:1px solid var(--line); border-radius:10px;" : ""}">
      ${c.items.length > 1 ? `<p style="font-size:0.8rem; font-weight:600; color:var(--c-brs); margin-bottom:8px;">Item ${idx + 1}: ${it.label}</p>` : `<p style="font-size:0.78rem; text-transform:uppercase; letter-spacing:0.04em; color:var(--ink-faint); margin-bottom:8px;">${it.label} — Add or Deduct, starting from the ${c.startingPoint}?</p>`}
      <div class="opt-group" data-role="answer" data-idx="${idx}" style="display:flex; flex-wrap:wrap; gap:8px;">
        <button class="chip" data-val="Add">Add</button>
        <button class="chip" data-val="Less">Less (Deduct)</button>
      </div>
      <div class="brsdet-item-reveal" data-idx="${idx}"></div>
    </div>
  `).join("");

  card.innerHTML = `
    <div class="q-meta">
      <span class="diff-badge ${c.difficulty}">${c.difficulty}</span>
      <span class="q-id">Case ${c.id}</span>
      <span style="margin-left:auto; font-size:0.74rem; color:var(--ink-faint); text-transform:uppercase; letter-spacing:0.03em;">${c.category}</span>
    </div>
    <div class="tnum" style="font-size:0.92rem; font-weight:600; color:var(--c-brs); background:var(--c-brs-soft); padding:12px; border-radius:10px; margin:14px 0;">
      Balance as per ${c.startingPoint} = ${fmtBrsBalance(c.startingBalance)}
    </div>
    <p style="font-size:0.92rem; line-height:1.7; color:var(--ink-soft); margin-bottom:14px;"><b>Situation:</b> ${c.situation}</p>
    ${itemsHTML}
    <div class="q-actions" style="margin-top:14px; display:flex; gap:10px; flex-wrap:wrap;">
      <button class="btn-primary sm ripple-surface" data-act="check"><i data-lucide="search"></i> Reveal Reasoning</button>
      <button class="btn-ghost sm ripple-surface" data-act="prev"><i data-lucide="arrow-left"></i> Previous Case</button>
      <button class="btn-ghost sm ripple-surface" data-act="next"><i data-lucide="arrow-right"></i> Next Case</button>
    </div>
    <div class="reveal-area"></div>
  `;
  const revealArea = $(".reveal-area", card);

  card.addEventListener("click", (e) => {
    const optBtn = e.target.closest(".opt-group button[data-val]");
    if (optBtn) {
      const group = optBtn.closest(".opt-group");
      $all("button", group).forEach(b => b.classList.remove("active"));
      optBtn.classList.add("active");
      picks[group.dataset.idx] = optBtn.dataset.val;
      return;
    }
    const prevBtn = e.target.closest("button[data-act='prev']");
    if (prevBtn) {
      brsDetectiveIndex = (brsDetectiveIndex - 1 + brsDetectiveOrder.length) % brsDetectiveOrder.length;
      panel.innerHTML = "";
      renderBrsDetective(panel, data);
      return;
    }
    const nextBtn = e.target.closest("button[data-act='next']");
    if (nextBtn) {
      brsDetectiveIndex = (brsDetectiveIndex + 1) % brsDetectiveOrder.length;
      panel.innerHTML = "";
      renderBrsDetective(panel, data);
      return;
    }
    const checkBtn = e.target.closest("button[data-act='check']");
    if (checkBtn) {
      if (revealed) return;
      const unanswered = c.items.some((_, idx) => !picks[idx]);
      if (unanswered) {
        revealArea.innerHTML = `<div class="reveal-block hint-block"><p style="font-size:0.86rem;">Pick Add or Less for every item first.</p></div>`;
        return;
      }
      revealed = true;
      const solvedKey = `brsdet-${c.id}`;
      let allCorrect = true;
      c.items.forEach((it, idx) => {
        const itemCorrect = picks[idx] === it.correctAnswer;
        if (!itemCorrect) allCorrect = false;
        const itemRevealEl = $(`.brsdet-item-reveal[data-idx="${idx}"]`, card);
        itemRevealEl.innerHTML = itemCorrect
          ? `<div class="reveal-block" style="margin-top:10px;"><h4 style="font-size:0.88rem;">Correct — ${it.correctAnswer === "Add" ? "Added" : "Deducted"} ₹${it.amount.toLocaleString("en-IN")}</h4><p style="font-size:0.85rem; line-height:1.6; color:var(--ink-soft);">${it.reasoning}</p></div>`
          : `<div class="reveal-block" style="margin-top:10px; background:var(--flag-soft); border-left-color:var(--flag);"><h4 style="font-size:0.88rem;">Not quite — correct answer is ${it.correctAnswer === "Add" ? "Add" : "Less (Deduct)"} ₹${it.amount.toLocaleString("en-IN")}</h4><p style="font-size:0.85rem; line-height:1.6; color:var(--ink-soft);">${it.reasoning}</p></div>`;
      });

      const breakdown = c.items.map(it => `${it.correctAnswer === "Add" ? "+" : "−"} ₹${it.amount.toLocaleString("en-IN")} (${it.label})`).join("<br>");
      revealArea.innerHTML = `
        <div class="reveal-block" style="${allCorrect ? "" : "background:var(--flag-soft); border-left-color:var(--flag);"} margin-top:16px;">
          <h4>${allCorrect ? "All items correct!" : "Combined reconciliation"}</h4>
          <p style="font-size:0.85rem; line-height:1.7; color:var(--ink-soft);">
            Balance as per ${c.startingPoint} = ${fmtBrsBalance(c.startingBalance)}<br>
            ${breakdown}<br>
            <b>${c.targetLabel} = ${fmtBrsBalance(c.finalBalance)}</b>
          </p>
        </div>`;

      if (allCorrect) playSuccessSound(); else playErrorSound();
      brsDetectiveScore.attempted++;
      if (allCorrect) brsDetectiveScore.correct++;
      const scoreEl = $("p:nth-child(2)", topBar);
      if (scoreEl) scoreEl.textContent = `Detective Score: ${brsDetectiveScore.correct}/${brsDetectiveScore.attempted}`;

      if (!STATE.solved[solvedKey]) {
        STATE.solved[solvedKey] = { correct: allCorrect, attempts: 1 };
        saveState();
        if (allCorrect) { addXP(4, `BRS Detective case ${c.id} solved`); logActivity(`BRS Detective case ${c.id} solved (${c.difficulty})`); mistakeBookRecordCorrect(solvedKey); }
        else {
          if (!STATE.mistakes.includes(solvedKey)) STATE.mistakes.push(solvedKey);
          saveState(); addXP(-XP_WRONG_PENALTY, `BRS Detective case ${c.id} incorrect`);
          mistakeBookRecord({
            key: solvedKey, question: c.situation, chapter: "brs", chapterLabel: "Bank Reconciliation Statement (BRS)",
            topic: "BRS Detective", type: "BRS Detective",
            studentAnswer: c.items.map((it, idx) => `${it.label}: ${picks[idx]}`).join(" | "),
            correctAnswer: c.items.map(it => `${it.label}: ${it.correctAnswer}`).join(" | "),
            explanation: c.items.map(it => it.reasoning).join(" ")
          });
        }
        refreshProgress();
      }
      icons();
    }
  });
  panel.appendChild(card);
  icons();
}

/* ---------------------------------------------------------
   6d-4. CHAPTER 8 — ACCOUNTING OF GST
   Mirrors the BRS chapter's tab structure and UI, but uses a
   numeric multiple-choice interaction (not Add/Less chips) for
   Practice Bank and GST Bill Detective, since GST answers are
   calculated amounts rather than a binary treatment choice.
   --------------------------------------------------------- */
function renderGstChapter(root) {
  const data = APP_DATA.gst;
  root.appendChild(el("div", "hero", `
    <span class="hero-eyebrow">Chapter 8</span>
    <h1>Accounting of GST</h1>
    <p>${APP_DATA.chapters[7].tagline} Meaning, characteristics, advantages, and simple GST calculations — trade discount, freight, CGST/SGST/IGST, and journal entries — all at Class 11 level.</p>
  `));

  const tabs = ["Introduction", "Format & Rules", "Practice Bank", "Quick Revision", "GST Bill Detective"];
  const tabBar = el("div", "", "");
  tabBar.style.cssText = "display:flex; gap:8px; flex-wrap:wrap; margin-bottom:22px;";
  tabs.forEach((t, i) => {
    const chip = el("button", `chip ${i===0?'active':''}`, t);
    chip.dataset.tab = t;
    tabBar.appendChild(chip);
  });
  const journeyEl = renderJourneyStepper(root, "gst");
  root.appendChild(tabBar);
  const panel = el("div", "");
  root.appendChild(panel);

  function showTab(name) {
    $all(".chip", tabBar).forEach(c => c.classList.toggle("active", c.dataset.tab === name));
    panel.innerHTML = "";
    updateJourneyStepper(journeyEl, "gst", name);
    if (name === "Introduction") renderGstIntro(panel, data);
    if (name === "Format & Rules") renderGstFormatRules(panel, data);
    if (name === "Practice Bank") renderGstPracticeBank(panel, data);
    if (name === "Quick Revision") renderGstQuickRevision(panel, data);
    if (name === "GST Bill Detective") renderGstDetective(panel, data);
    icons();
  }
  tabBar.addEventListener("click", e => {
    const chip = e.target.closest(".chip");
    if (chip) showTab(chip.dataset.tab);
  });
  showTab("Introduction");
}

/* ---- Introduction: meaning, characteristics, advantages ---- */
function renderGstIntro(panel, data) {
  panel.appendChild(sectionTitle("Meaning, characteristics & advantages"));
  renderCashBookTheoryBlocks(panel, data.theory.simple, "var(--c-gst)", "var(--c-gst-soft)");
  panel.appendChild(sectionTitle("Key concepts"));
  const grid = el("div", "grid-3");
  data.concepts.forEach(c => {
    const card = el("div", "card liftable", "");
    card.style.padding = "22px";
    card.innerHTML = `<h4 style="font-size:1rem; margin-bottom:8px; color:var(--c-gst);">${c.title}</h4><p style="font-size:0.87rem; line-height:1.6; color:var(--ink-soft);">${c.body}</p>`;
    grid.appendChild(card);
  });
  panel.appendChild(grid);
}

/* ---- Format & Rules: calculation formulas, trade discount,
   freight, CGST/SGST/IGST, journal entries ---- */
function renderGstFormatRules(panel, data) {
  panel.appendChild(sectionTitle("Format, calculation rules & journal entries"));
  renderCashBookTheoryBlocks(panel, data.theory.advanced, "var(--c-gst)", "var(--c-gst-soft)");
}

let gstFilterDifficulty = "All";

function renderGstPracticeBank(panel, data) {
  panel.innerHTML = "";
  panel.appendChild(sectionTitle("GST practice bank"));
  const hint = el("p", "", `${data.numericals.length} questions — calculations, concepts, and journal entries. Pick the correct option, then check your answer for a full worked explanation.`);
  hint.style.cssText = "font-size:0.85rem; color:var(--ink-faint); margin:-8px 0 18px; line-height:1.6;";
  panel.appendChild(hint);

  const filterBar = el("div", "", "");
  filterBar.style.cssText = "display:flex; gap:8px; margin-bottom:18px; flex-wrap:wrap;";
  ["All", "Easy", "Medium", "Hard"].forEach(d => {
    const chip = el("button", `chip ${d === gstFilterDifficulty ? "active" : ""}`, d);
    chip.addEventListener("click", () => { gstFilterDifficulty = d; renderGstPracticeBank(panel, data); });
    filterBar.appendChild(chip);
  });
  panel.appendChild(filterBar);

  const list = data.numericals.filter(q => gstFilterDifficulty === "All" || q.difficulty === gstFilterDifficulty);
  const countLabel = el("p", "", `Showing ${list.length} of ${data.numericals.length} questions`);
  countLabel.style.cssText = "font-size:0.83rem; color:var(--ink-faint); margin-bottom:16px;";
  panel.appendChild(countLabel);

  list.forEach(q => {
    const solvedKey = `gst-${q.id}`;
    const alreadySolved = STATE.solved[solvedKey];
    let picked = null;
    const shuffledOrder = fisherYatesShuffle(q.options.map((_, i) => i));

    const card = el("div", "card q-card", "");
    card.innerHTML = `
      <div class="q-meta">
        <span class="diff-badge ${q.difficulty}">${q.difficulty}</span>
        <span class="q-id">Q${q.id}</span>
        ${alreadySolved ? `<span style="margin-left:auto; color:var(--c-gst); font-size:0.78rem; display:flex; align-items:center; gap:4px;"><i data-lucide="check-circle" style="width:13px;height:13px;"></i> Solved</span>` : ""}
      </div>
      <div class="q-body">${q.question}</div>
      <div style="margin-top:14px;">
        <div class="opt-group" data-role="answer" style="display:flex; flex-wrap:wrap; gap:8px;">
          ${shuffledOrder.map(i => `<button class="chip" data-val="${i}">${q.options[i]}</button>`).join("")}
        </div>
      </div>
      <div class="q-actions" style="margin-top:14px;">
        <button class="btn-primary sm ripple-surface" data-act="check"><i data-lucide="check"></i> Check Answer</button>
      </div>
      <div class="reveal-area"></div>
    `;
    const revealArea = $(".reveal-area", card);

    card.addEventListener("click", (e) => {
      const optBtn = e.target.closest(".opt-group button[data-val]");
      if (optBtn) {
        const group = optBtn.closest(".opt-group");
        $all("button", group).forEach(b => b.classList.remove("active"));
        optBtn.classList.add("active");
        picked = parseInt(optBtn.dataset.val, 10);
        return;
      }
      const checkBtn = e.target.closest("button[data-act='check']");
      if (checkBtn) {
        if (picked === null) {
          revealArea.innerHTML = `<div class="reveal-block hint-block"><p style="font-size:0.86rem;">Pick an option first.</p></div>`;
          return;
        }
        const correct = picked === q.answerIndex;
        if (correct) {
          revealArea.innerHTML = `
            <div class="reveal-block">
              <h4>Correct!</h4>
              <p style="font-size:0.87rem; line-height:1.6; color:var(--ink-soft);">${q.explanation}</p>
            </div>`;
          playSuccessSound();
          if (!STATE.solved[solvedKey]) {
            STATE.solved[solvedKey] = { correct: true, attempts: 1 };
            saveState(); addXP(4, `GST Q${q.id} solved`); logActivity(`GST Q${q.id} solved (${q.difficulty})`); refreshProgress();
          }
          mistakeBookRecordCorrect(solvedKey);
        } else {
          revealArea.innerHTML = `
            <div class="reveal-block" style="background:var(--flag-soft); border-left-color:var(--flag);">
              <h4>Not quite</h4>
              <p style="font-size:0.87rem; line-height:1.6; color:var(--ink-soft);">The correct answer is: <b>${q.options[q.answerIndex]}</b>.<br>${q.explanation}</p>
            </div>`;
          playErrorSound();
          if (!STATE.solved[solvedKey]) {
            STATE.solved[solvedKey] = { correct: false, attempts: 1 };
            if (!STATE.mistakes.includes(solvedKey)) STATE.mistakes.push(solvedKey);
            saveState(); addXP(-XP_WRONG_PENALTY, `Q${q.id} incorrect`); refreshProgress();
          }
          mistakeBookRecord({
            key: solvedKey, question: q.question, chapter: "gst", chapterLabel: "Accounting of GST",
            topic: "GST Calculation", type: "GST Practice",
            studentAnswer: q.options[picked],
            correctAnswer: q.options[q.answerIndex],
            explanation: q.explanation
          });
        }
        icons();
      }
    });
    panel.appendChild(card);
  });
  applyMobilePager(panel);
  icons();
}

function renderGstQuickRevision(panel, data) {
  panel.appendChild(sectionTitle("Quick revision"));
  const qr = data.quickRevision;
  const card = el("div", "card-solid", "");
  card.style.padding = "28px";
  card.innerHTML = `
    <div class="ledger-rule">
      <h4 style="font-size:0.95rem; margin-bottom:8px;">Definition</h4>
      <p style="font-size:0.89rem; line-height:1.6; color:var(--ink-soft);">${qr.definition}</p>
    </div>
    <div class="ledger-rule" style="margin-top:18px;">
      <h4 style="font-size:0.95rem; margin-bottom:8px;">Key points</h4>
      <ol style="padding-left:20px;">${qr.keyPoints.map(r => `<li style="margin-bottom:6px; font-size:0.87rem; color:var(--ink-soft);">${r}</li>`).join("")}</ol>
    </div>
    <div class="ledger-rule" style="margin-top:18px;">
      <h4 style="font-size:0.95rem; margin-bottom:8px;">Calculation steps</h4>
      <ol style="padding-left:20px;">${qr.calculationSteps.map(r => `<li style="margin-bottom:6px; font-size:0.87rem; color:var(--ink-soft);">${r}</li>`).join("")}</ol>
    </div>
    <div class="ledger-rule" style="margin-top:18px;">
      <h4 style="font-size:0.95rem; margin-bottom:8px; color:var(--flag);">Common mistakes</h4>
      <ul style="padding-left:20px;">${qr.commonMistakes.map(r => `<li style="margin-bottom:6px; font-size:0.87rem; color:var(--ink-soft);">${r}</li>`).join("")}</ul>
    </div>
    <div class="tnum" style="text-align:center; font-size:0.92rem; font-weight:600; color:var(--c-gst); background:var(--c-gst-soft); padding:14px; border-radius:10px; margin-top:18px;">
      💡 Mnemonic: ${qr.mnemonic}
    </div>
  `;
  panel.appendChild(card);
}

/* ---- GST Bill Detective: a simple bill scenario — the student
   picks the final invoice value from four options, then reveals
   the full step-by-step calculation. ---- */
let gstDetectiveOrder = null;
let gstDetectiveIndex = 0;
let gstDetectiveScore = { correct: 0, attempted: 0 };

function renderGstDetective(panel, data) {
  panel.appendChild(sectionTitle("GST Bill Detective 🧾"));
  const cases = data.detective;
  const hint = el("p", "", `${cases.length} bill cases — work out the taxable value, GST amount, and final invoice value, then reveal the step-by-step breakdown.`);
  hint.style.cssText = "font-size:0.85rem; color:var(--ink-faint); margin:-8px 0 18px; line-height:1.6;";
  panel.appendChild(hint);

  if (!gstDetectiveOrder || gstDetectiveOrder.length !== cases.length) {
    gstDetectiveOrder = fisherYatesShuffle(cases.map((_, i) => i));
    gstDetectiveIndex = 0;
    gstDetectiveScore = { correct: 0, attempted: 0 };
  }
  if (gstDetectiveIndex >= gstDetectiveOrder.length) gstDetectiveIndex = 0;
  if (gstDetectiveIndex < 0) gstDetectiveIndex = gstDetectiveOrder.length - 1;

  const topBar = el("div", "", "");
  topBar.style.cssText = "display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:14px;";
  topBar.innerHTML = `
    <p style="font-size:0.83rem; color:var(--ink-faint); margin:0;">Case ${gstDetectiveIndex + 1} of ${cases.length}</p>
    <p style="font-size:0.83rem; color:var(--c-gst); margin:0; font-weight:600;">Detective Score: ${gstDetectiveScore.correct}/${gstDetectiveScore.attempted}</p>
  `;
  panel.appendChild(topBar);

  const c = cases[gstDetectiveOrder[gstDetectiveIndex]];
  let picked = null;
  const shuffledOptOrder = fisherYatesShuffle(c.options.map((_, i) => i));

  const card = el("div", "card-solid q-card", "");
  card.style.cssText = "padding:26px;";
  card.innerHTML = `
    <div class="q-meta">
      <span class="diff-badge ${c.difficulty}">${c.difficulty}</span>
      <span class="q-id">Case ${c.id}</span>
    </div>
    <div class="tnum" style="font-size:0.9rem; color:var(--c-gst); background:var(--c-gst-soft); padding:14px; border-radius:10px; margin:14px 0; line-height:1.8;">
      🧾 Goods: <b>${c.billText.goods}</b><br>
      Trade Discount: <b>${c.billText.discount}</b><br>
      GST Rate: <b>${c.billText.gstRate}</b><br>
      Freight: <b>${c.billText.freight}</b>
    </div>
    <p style="font-size:0.92rem; line-height:1.7; color:var(--ink-soft); margin-bottom:14px;">What should be the <b>final invoice value</b>?</p>
    <div class="opt-group" data-role="answer" style="display:flex; flex-wrap:wrap; gap:8px;">
      ${shuffledOptOrder.map(i => `<button class="chip" data-val="${c.options[i]}">₹${c.options[i].toLocaleString("en-IN")}</button>`).join("")}
    </div>
    <div class="q-actions" style="margin-top:14px; display:flex; gap:10px; flex-wrap:wrap;">
      <button class="btn-primary sm ripple-surface" data-act="check"><i data-lucide="search"></i> Reveal Calculation</button>
      <button class="btn-ghost sm ripple-surface" data-act="prev"><i data-lucide="arrow-left"></i> Previous Case</button>
      <button class="btn-ghost sm ripple-surface" data-act="next"><i data-lucide="arrow-right"></i> Next Case</button>
    </div>
    <div class="reveal-area"></div>
  `;
  const revealArea = $(".reveal-area", card);
  let revealed = false;

  card.addEventListener("click", (e) => {
    const optBtn = e.target.closest(".opt-group button[data-val]");
    if (optBtn) {
      const group = optBtn.closest(".opt-group");
      $all("button", group).forEach(b => b.classList.remove("active"));
      optBtn.classList.add("active");
      picked = parseInt(optBtn.dataset.val, 10);
      return;
    }
    const prevBtn = e.target.closest("button[data-act='prev']");
    if (prevBtn) {
      gstDetectiveIndex = (gstDetectiveIndex - 1 + gstDetectiveOrder.length) % gstDetectiveOrder.length;
      panel.innerHTML = "";
      renderGstDetective(panel, data);
      return;
    }
    const nextBtn = e.target.closest("button[data-act='next']");
    if (nextBtn) {
      gstDetectiveIndex = (gstDetectiveIndex + 1) % gstDetectiveOrder.length;
      panel.innerHTML = "";
      renderGstDetective(panel, data);
      return;
    }
    const checkBtn = e.target.closest("button[data-act='check']");
    if (checkBtn) {
      if (revealed) return;
      if (picked === null) {
        revealArea.innerHTML = `<div class="reveal-block hint-block"><p style="font-size:0.86rem;">Pick an option first.</p></div>`;
        return;
      }
      revealed = true;
      const solvedKey = `gstdet-${c.id}`;
      const correct = picked === c.answerValue;
      const stepsHtml = c.steps.map(s => `<div>${s}</div>`).join("");
      revealArea.innerHTML = `
        <div class="reveal-block ${correct ? "" : "hint-block"}" style="${correct ? "" : "background:var(--flag-soft); border-left-color:var(--flag);"}">
          <h4>${correct ? "Correct!" : `Not quite — the correct final invoice value is ₹${c.answerValue.toLocaleString("en-IN")}`}</h4>
          <div style="font-size:0.86rem; line-height:1.9; color:var(--ink-soft); margin-top:6px;">${stepsHtml}</div>
        </div>`;
      if (correct) playSuccessSound(); else playErrorSound();
      gstDetectiveScore.attempted++;
      if (correct) gstDetectiveScore.correct++;
      const scoreEl = $("p:nth-child(2)", topBar);
      if (scoreEl) scoreEl.textContent = `Detective Score: ${gstDetectiveScore.correct}/${gstDetectiveScore.attempted}`;

      if (!STATE.solved[solvedKey]) {
        STATE.solved[solvedKey] = { correct: correct, attempts: 1 };
        saveState();
        if (correct) { addXP(4, `GST Detective case ${c.id} solved`); logActivity(`GST Detective case ${c.id} solved (${c.difficulty})`); mistakeBookRecordCorrect(solvedKey); }
        else {
          if (!STATE.mistakes.includes(solvedKey)) STATE.mistakes.push(solvedKey);
          saveState(); addXP(-XP_WRONG_PENALTY, `GST Detective case ${c.id} incorrect`);
          mistakeBookRecord({
            key: solvedKey, question: `Goods: ${c.billText.goods}, Trade Discount: ${c.billText.discount}, GST Rate: ${c.billText.gstRate}, Freight: ${c.billText.freight}`,
            chapter: "gst", chapterLabel: "Accounting of GST", topic: "GST Bill Detective", type: "GST Bill Detective",
            studentAnswer: `₹${picked.toLocaleString("en-IN")}`,
            correctAnswer: `₹${c.answerValue.toLocaleString("en-IN")}`,
            explanation: c.steps.join(" ")
          });
        }
        refreshProgress();
      }
      icons();
    }
  });
  panel.appendChild(card);
  icons();
}

/* ---------------------------------------------------------
   6f. CHAPTER 9 — TRIAL BALANCE
   Mirrors the established chapter tab structure. The interactive
   "Trial Balance Checkpoint" section supports two case types:
   "classify" (pick Debit or Credit for a given ledger balance,
   two-button style like BRS Detective) and "balance-check" (a
   small "Does it Balance?" numeric multiple-choice challenge,
   like GST Bill Detective) — both share one render function.
   --------------------------------------------------------- */
function renderTbChapter(root) {
  const data = APP_DATA.tb;
  root.appendChild(el("div", "hero", `
    <span class="hero-eyebrow">Chapter 9</span>
    <h1>Trial Balance</h1>
    <p>${APP_DATA.chapters[8].tagline} Meaning, objectives, the Balance Method, format, common mistakes, and limitations — all at Class 11 level.</p>
  `));

  const tabs = ["Introduction", "Format & Rules", "Practice Bank", "Quick Revision", "Trial Balance Checkpoint"];
  const tabBar = el("div", "", "");
  tabBar.style.cssText = "display:flex; gap:8px; flex-wrap:wrap; margin-bottom:22px;";
  tabs.forEach((t, i) => {
    const chip = el("button", `chip ${i===0?'active':''}`, t);
    chip.dataset.tab = t;
    tabBar.appendChild(chip);
  });
  const journeyEl = renderJourneyStepper(root, "tb");
  root.appendChild(tabBar);
  const panel = el("div", "");
  root.appendChild(panel);

  function showTab(name) {
    $all(".chip", tabBar).forEach(c => c.classList.toggle("active", c.dataset.tab === name));
    panel.innerHTML = "";
    updateJourneyStepper(journeyEl, "tb", name);
    if (name === "Introduction") renderTbIntro(panel, data);
    if (name === "Format & Rules") renderTbFormatRules(panel, data);
    if (name === "Practice Bank") renderTbPracticeBank(panel, data);
    if (name === "Quick Revision") renderTbQuickRevision(panel, data);
    if (name === "Trial Balance Checkpoint") renderTbCheckpoint(panel, data);
    icons();
  }
  tabBar.addEventListener("click", e => {
    const chip = e.target.closest(".chip");
    if (chip) showTab(chip.dataset.tab);
  });
  showTab("Introduction");
}

function renderTbIntro(panel, data) {
  panel.appendChild(sectionTitle("Meaning, purpose & objectives"));
  renderCashBookTheoryBlocks(panel, data.theory.simple, "var(--c-tb)", "var(--c-tb-soft)");
  panel.appendChild(sectionTitle("Key concepts"));
  const grid = el("div", "grid-3");
  data.concepts.forEach(c => {
    const card = el("div", "card liftable", "");
    card.style.padding = "22px";
    card.innerHTML = `<h4 style="font-size:1rem; margin-bottom:8px; color:var(--c-tb);">${c.title}</h4><p style="font-size:0.87rem; line-height:1.6; color:var(--ink-soft);">${c.body}</p>`;
    grid.appendChild(card);
  });
  panel.appendChild(grid);
}

function renderTbFormatRules(panel, data) {
  panel.appendChild(sectionTitle("Format, preparation & limitations"));
  renderCashBookTheoryBlocks(panel, data.theory.advanced, "var(--c-tb)", "var(--c-tb-soft)");
}

let tbFilterDifficulty = "All";

function renderTbPracticeBank(panel, data) {
  panel.innerHTML = "";
  panel.appendChild(sectionTitle("Trial Balance practice bank"));
  const hint = el("p", "", `${data.numericals.length} questions — classification, preparation, totals, and common errors. Pick the correct option, then check your answer for a full explanation.`);
  hint.style.cssText = "font-size:0.85rem; color:var(--ink-faint); margin:-8px 0 18px; line-height:1.6;";
  panel.appendChild(hint);

  const filterBar = el("div", "", "");
  filterBar.style.cssText = "display:flex; gap:8px; margin-bottom:18px; flex-wrap:wrap;";
  ["All", "Easy", "Medium", "Hard"].forEach(d => {
    const chip = el("button", `chip ${d === tbFilterDifficulty ? "active" : ""}`, d);
    chip.addEventListener("click", () => { tbFilterDifficulty = d; renderTbPracticeBank(panel, data); });
    filterBar.appendChild(chip);
  });
  panel.appendChild(filterBar);

  const list = data.numericals.filter(q => tbFilterDifficulty === "All" || q.difficulty === tbFilterDifficulty);
  const countLabel = el("p", "", `Showing ${list.length} of ${data.numericals.length} questions`);
  countLabel.style.cssText = "font-size:0.83rem; color:var(--ink-faint); margin-bottom:16px;";
  panel.appendChild(countLabel);

  list.forEach(q => {
    const solvedKey = `tb-${q.id}`;
    const alreadySolved = STATE.solved[solvedKey];
    let picked = null;
    const shuffledOrder = fisherYatesShuffle(q.options.map((_, i) => i));

    const card = el("div", "card q-card", "");
    card.innerHTML = `
      <div class="q-meta">
        <span class="diff-badge ${q.difficulty}">${q.difficulty}</span>
        <span class="q-id">Q${q.id}</span>
        ${alreadySolved ? `<span style="margin-left:auto; color:var(--c-tb); font-size:0.78rem; display:flex; align-items:center; gap:4px;"><i data-lucide="check-circle" style="width:13px;height:13px;"></i> Solved</span>` : ""}
      </div>
      <div class="q-body">${q.question}</div>
      <div style="margin-top:14px;">
        <div class="opt-group" data-role="answer" style="display:flex; flex-wrap:wrap; gap:8px;">
          ${shuffledOrder.map(i => `<button class="chip" data-val="${i}">${q.options[i]}</button>`).join("")}
        </div>
      </div>
      <div class="q-actions" style="margin-top:14px;">
        <button class="btn-primary sm ripple-surface" data-act="check"><i data-lucide="check"></i> Check Answer</button>
      </div>
      <div class="reveal-area"></div>
    `;
    const revealArea = $(".reveal-area", card);

    card.addEventListener("click", (e) => {
      const optBtn = e.target.closest(".opt-group button[data-val]");
      if (optBtn) {
        const group = optBtn.closest(".opt-group");
        $all("button", group).forEach(b => b.classList.remove("active"));
        optBtn.classList.add("active");
        picked = parseInt(optBtn.dataset.val, 10);
        return;
      }
      const checkBtn = e.target.closest("button[data-act='check']");
      if (checkBtn) {
        if (picked === null) {
          revealArea.innerHTML = `<div class="reveal-block hint-block"><p style="font-size:0.86rem;">Pick an option first.</p></div>`;
          return;
        }
        const correct = picked === q.answerIndex;
        if (correct) {
          revealArea.innerHTML = `
            <div class="reveal-block">
              <h4>Correct!</h4>
              <p style="font-size:0.87rem; line-height:1.6; color:var(--ink-soft);">${q.explanation}</p>
            </div>`;
          playSuccessSound();
          if (!STATE.solved[solvedKey]) {
            STATE.solved[solvedKey] = { correct: true, attempts: 1 };
            saveState(); addXP(4, `Trial Balance Q${q.id} solved`); logActivity(`Trial Balance Q${q.id} solved (${q.difficulty})`); refreshProgress();
          }
          mistakeBookRecordCorrect(solvedKey);
        } else {
          revealArea.innerHTML = `
            <div class="reveal-block" style="background:var(--flag-soft); border-left-color:var(--flag);">
              <h4>Not quite</h4>
              <p style="font-size:0.87rem; line-height:1.6; color:var(--ink-soft);">The correct answer is: <b>${q.options[q.answerIndex]}</b>.<br>${q.explanation}</p>
            </div>`;
          playErrorSound();
          if (!STATE.solved[solvedKey]) {
            STATE.solved[solvedKey] = { correct: false, attempts: 1 };
            if (!STATE.mistakes.includes(solvedKey)) STATE.mistakes.push(solvedKey);
            saveState(); addXP(-XP_WRONG_PENALTY, `Q${q.id} incorrect`); refreshProgress();
          }
          mistakeBookRecord({
            key: solvedKey, question: q.question, chapter: "tb", chapterLabel: "Trial Balance",
            topic: "Trial Balance", type: "Trial Balance Practice",
            studentAnswer: q.options[picked],
            correctAnswer: q.options[q.answerIndex],
            explanation: q.explanation
          });
        }
        icons();
      }
    });
    panel.appendChild(card);
  });
  applyMobilePager(panel);
  icons();
}

function renderTbQuickRevision(panel, data) {
  panel.appendChild(sectionTitle("Quick revision"));
  const qr = data.quickRevision;
  const card = el("div", "card-solid", "");
  card.style.padding = "28px";
  card.innerHTML = `
    <div class="ledger-rule">
      <h4 style="font-size:0.95rem; margin-bottom:8px;">Definition</h4>
      <p style="font-size:0.89rem; line-height:1.6; color:var(--ink-soft);">${qr.definition}</p>
    </div>
    <div class="ledger-rule" style="margin-top:18px;">
      <h4 style="font-size:0.95rem; margin-bottom:8px;">Key points</h4>
      <ol style="padding-left:20px;">${qr.keyPoints.map(r => `<li style="margin-bottom:6px; font-size:0.87rem; color:var(--ink-soft);">${r}</li>`).join("")}</ol>
    </div>
    <div class="ledger-rule" style="margin-top:18px;">
      <h4 style="font-size:0.95rem; margin-bottom:8px;">Preparation steps</h4>
      <ol style="padding-left:20px;">${qr.calculationSteps.map(r => `<li style="margin-bottom:6px; font-size:0.87rem; color:var(--ink-soft);">${r}</li>`).join("")}</ol>
    </div>
    <div class="ledger-rule" style="margin-top:18px;">
      <h4 style="font-size:0.95rem; margin-bottom:8px; color:var(--flag);">Common mistakes</h4>
      <ul style="padding-left:20px;">${qr.commonMistakes.map(r => `<li style="margin-bottom:6px; font-size:0.87rem; color:var(--ink-soft);">${r}</li>`).join("")}</ul>
    </div>
    <div class="tnum" style="text-align:center; font-size:0.92rem; font-weight:600; color:var(--c-tb); background:var(--c-tb-soft); padding:14px; border-radius:10px; margin-top:18px;">
      💡 Mnemonic: ${qr.mnemonic}
    </div>
  `;
  panel.appendChild(card);
}

/* ---- Trial Balance Checkpoint: two case types sharing one flow —
   "classify" (Debit or Credit?) and "balance-check" (Does it
   Balance?, numeric multiple choice). Shuffles once per visit,
   doesn't repeat until the deck cycles, tracks a running score. ---- */
let tbCheckpointOrder = null;
let tbCheckpointIndex = 0;
let tbCheckpointScore = { correct: 0, attempted: 0 };

function renderTbCheckpoint(panel, data) {
  panel.appendChild(sectionTitle("Trial Balance Checkpoint ⚖️"));
  const cases = data.checkpoint;
  const hint = el("p", "", `${cases.length} cases — classify ledger balances as Debit or Credit and explain why, plus short "Does it Balance?" challenges.`);
  hint.style.cssText = "font-size:0.85rem; color:var(--ink-faint); margin:-8px 0 18px; line-height:1.6;";
  panel.appendChild(hint);

  if (!tbCheckpointOrder || tbCheckpointOrder.length !== cases.length) {
    tbCheckpointOrder = fisherYatesShuffle(cases.map((_, i) => i));
    tbCheckpointIndex = 0;
    tbCheckpointScore = { correct: 0, attempted: 0 };
  }
  if (tbCheckpointIndex >= tbCheckpointOrder.length) tbCheckpointIndex = 0;
  if (tbCheckpointIndex < 0) tbCheckpointIndex = tbCheckpointOrder.length - 1;

  const topBar = el("div", "", "");
  topBar.style.cssText = "display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:14px;";
  topBar.innerHTML = `
    <p style="font-size:0.83rem; color:var(--ink-faint); margin:0;">Case ${tbCheckpointIndex + 1} of ${cases.length}</p>
    <p style="font-size:0.83rem; color:var(--c-tb); margin:0; font-weight:600;">Checkpoint Score: ${tbCheckpointScore.correct}/${tbCheckpointScore.attempted}</p>
  `;
  panel.appendChild(topBar);

  const c = cases[tbCheckpointOrder[tbCheckpointIndex]];
  let picked = null;
  const shuffledOptOrder = fisherYatesShuffle(c.options.map((_, i) => i));
  const isClassify = c.type === "classify";

  const card = el("div", "card-solid q-card", "");
  card.style.cssText = "padding:26px;";
  card.innerHTML = `
    <div class="q-meta">
      <span class="diff-badge ${c.difficulty}">${c.difficulty}</span>
      <span class="q-id">Case ${c.id}</span>
      <span style="margin-left:auto; font-size:0.74rem; color:var(--ink-faint); text-transform:uppercase; letter-spacing:0.03em;">${isClassify ? "Classify" : "Does it Balance?"}</span>
    </div>
    ${isClassify
      ? `<div class="tnum" style="font-size:0.95rem; font-weight:600; color:var(--c-tb); background:var(--c-tb-soft); padding:14px; border-radius:10px; margin:14px 0;">
           ${c.prompt} — ₹${(c.amount || 0).toLocaleString("en-IN")}
         </div>
         <p style="font-size:0.92rem; line-height:1.7; color:var(--ink-soft); margin-bottom:14px;">Is this a Debit balance or a Credit balance in the Trial Balance?</p>`
      : `<p style="font-size:0.92rem; line-height:1.7; color:var(--ink-soft); margin-bottom:14px;">${c.prompt}</p>`
    }
    <div class="opt-group" data-role="answer" style="display:flex; flex-wrap:wrap; gap:8px;">
      ${shuffledOptOrder.map(i => `<button class="chip" data-val="${i}">${c.options[i]}</button>`).join("")}
    </div>
    <div class="q-actions" style="margin-top:14px; display:flex; gap:10px; flex-wrap:wrap;">
      <button class="btn-primary sm ripple-surface" data-act="check"><i data-lucide="search"></i> Reveal Reasoning</button>
      <button class="btn-ghost sm ripple-surface" data-act="prev"><i data-lucide="arrow-left"></i> Previous Case</button>
      <button class="btn-ghost sm ripple-surface" data-act="next"><i data-lucide="arrow-right"></i> Next Case</button>
    </div>
    <div class="reveal-area"></div>
  `;
  const revealArea = $(".reveal-area", card);
  let revealed = false;

  card.addEventListener("click", (e) => {
    const optBtn = e.target.closest(".opt-group button[data-val]");
    if (optBtn) {
      const group = optBtn.closest(".opt-group");
      $all("button", group).forEach(b => b.classList.remove("active"));
      optBtn.classList.add("active");
      picked = parseInt(optBtn.dataset.val, 10);
      return;
    }
    const prevBtn = e.target.closest("button[data-act='prev']");
    if (prevBtn) {
      tbCheckpointIndex = (tbCheckpointIndex - 1 + tbCheckpointOrder.length) % tbCheckpointOrder.length;
      panel.innerHTML = "";
      renderTbCheckpoint(panel, data);
      return;
    }
    const nextBtn = e.target.closest("button[data-act='next']");
    if (nextBtn) {
      tbCheckpointIndex = (tbCheckpointIndex + 1) % tbCheckpointOrder.length;
      panel.innerHTML = "";
      renderTbCheckpoint(panel, data);
      return;
    }
    const checkBtn = e.target.closest("button[data-act='check']");
    if (checkBtn) {
      if (revealed) return;
      if (picked === null) {
        revealArea.innerHTML = `<div class="reveal-block hint-block"><p style="font-size:0.86rem;">Pick an option first.</p></div>`;
        return;
      }
      revealed = true;
      const solvedKey = `tbcheck-${c.id}`;
      const correct = picked === c.correctIndex;
      const whereLine = isClassify && c.whereInTB ? `<p style="font-size:0.85rem; color:var(--ink-faint); margin-top:6px;"><b>Where it belongs:</b> ${c.whereInTB}</p>` : "";
      revealArea.innerHTML = `
        <div class="reveal-block ${correct ? "" : "hint-block"}" style="${correct ? "" : "background:var(--flag-soft); border-left-color:var(--flag);"}">
          <h4>${correct ? "Correct!" : `Not quite — the correct answer is ${c.options[c.correctIndex]}`}</h4>
          <p style="font-size:0.86rem; line-height:1.7; color:var(--ink-soft); margin-top:6px;">${c.reasoning}</p>
          ${whereLine}
        </div>`;
      if (correct) playSuccessSound(); else playErrorSound();
      tbCheckpointScore.attempted++;
      if (correct) tbCheckpointScore.correct++;
      const scoreEl = $("p:nth-child(2)", topBar);
      if (scoreEl) scoreEl.textContent = `Checkpoint Score: ${tbCheckpointScore.correct}/${tbCheckpointScore.attempted}`;

      if (!STATE.solved[solvedKey]) {
        STATE.solved[solvedKey] = { correct: correct, attempts: 1 };
        saveState();
        if (correct) { addXP(4, `Trial Balance Checkpoint case ${c.id} solved`); logActivity(`Trial Balance Checkpoint case ${c.id} solved (${c.difficulty})`); mistakeBookRecordCorrect(solvedKey); }
        else {
          if (!STATE.mistakes.includes(solvedKey)) STATE.mistakes.push(solvedKey);
          saveState(); addXP(-XP_WRONG_PENALTY, `Trial Balance Checkpoint case ${c.id} incorrect`);
          mistakeBookRecord({
            key: solvedKey, question: c.prompt, chapter: "tb", chapterLabel: "Trial Balance",
            topic: "Trial Balance Checkpoint", type: "Trial Balance Checkpoint",
            studentAnswer: c.options[picked],
            correctAnswer: c.options[c.correctIndex],
            explanation: c.reasoning
          });
        }
        refreshProgress();
      }
      icons();
    }
  });
  panel.appendChild(card);
  icons();
}

/* ---------------------------------------------------------
   6g. CHAPTER 10 — DEPRECIATION
   --------------------------------------------------------- */
function renderDepChapter(root) {
  const data = APP_DATA.dep;
  root.appendChild(el("div", "hero", `
    <span class="hero-eyebrow">Chapter 10</span>
    <h1>Depreciation</h1>
    <p>${APP_DATA.chapters[9].tagline} Meaning, causes, SLM, WDV, recording methods, and disposal of assets — all at Class 11 level.</p>
  `));

  const tabs = ["Introduction", "Format & Rules", "Depreciation Lab", "Practice Bank", "Quick Revision"];
  const tabBar = el("div", "", "");
  tabBar.style.cssText = "display:flex; gap:8px; flex-wrap:wrap; margin-bottom:22px;";
  tabs.forEach((t, i) => {
    const chip = el("button", `chip ${i===0?'active':''}`, t);
    chip.dataset.tab = t;
    tabBar.appendChild(chip);
  });
  const journeyEl = renderJourneyStepper(root, "dep");
  root.appendChild(tabBar);
  const panel = el("div", "");
  root.appendChild(panel);

  function showTab(name) {
    $all(".chip", tabBar).forEach(c => c.classList.toggle("active", c.dataset.tab === name));
    panel.innerHTML = "";
    updateJourneyStepper(journeyEl, "dep", name);
    if (name === "Introduction") renderDepIntro(panel, data);
    if (name === "Format & Rules") renderDepFormatRules(panel, data);
    if (name === "Depreciation Lab") renderDepLab(panel, data);
    if (name === "Practice Bank") renderDepPracticeBank(panel, data);
    if (name === "Quick Revision") renderDepQuickRevision(panel, data);
    icons();
  }
  tabBar.addEventListener("click", e => {
    const chip = e.target.closest(".chip");
    if (chip) showTab(chip.dataset.tab);
  });
  showTab("Introduction");
}

/* ---- Introduction: meaning, features, causes, factors, depletion, amortisation ---- */
function renderDepIntro(panel, data) {
  panel.appendChild(sectionTitle("Meaning, causes & related terms"));
  renderCashBookTheoryBlocks(panel, data.theory.simple, "var(--c-dep)", "var(--c-dep-soft)");
  panel.appendChild(sectionTitle("Key concepts"));
  const grid = el("div", "grid-3");
  data.concepts.forEach(c => {
    const card = el("div", "card liftable", "");
    card.style.padding = "22px";
    card.innerHTML = `<h4 style="font-size:1rem; margin-bottom:8px; color:var(--c-dep);">${c.title}</h4><p style="font-size:0.87rem; line-height:1.6; color:var(--ink-soft);">${c.body}</p>`;
    grid.appendChild(card);
  });
  panel.appendChild(grid);
}

/* ---- Format & Rules: SLM, WDV, part-year, recording methods, disposal ---- */
function renderDepFormatRules(panel, data) {
  panel.appendChild(sectionTitle("SLM, WDV, recording methods & disposal of assets"));
  renderCashBookTheoryBlocks(panel, data.theory.advanced, "var(--c-dep)", "var(--c-dep-soft)");
}

/* ---- Depreciation Lab: a live calculator — change the cost, rate,
   residual value, and number of years, and instantly see the SLM
   flow (Original Cost → Depreciation → Book Value) plus a year-by-year
   SLM vs WDV comparison table. ---- */
function renderDepLab(panel, data) {
  panel.appendChild(sectionTitle("Depreciation Lab 🧮"));
  const hint = el("p", "", "Change the numbers below and watch the depreciation and book value update instantly — see exactly how SLM and WDV diverge, year after year.");
  hint.style.cssText = "font-size:0.85rem; color:var(--ink-faint); margin:-8px 0 18px; line-height:1.6;";
  panel.appendChild(hint);

  const card = el("div", "card-solid", "");
  card.style.padding = "26px";
  card.innerHTML = `
    <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(160px,1fr)); gap:14px; margin-bottom:6px;">
      <div class="field-group" style="margin-bottom:0;">
        <label>Asset Cost (₹)</label>
        <input type="number" id="depLabCost" class="field-input" value="100000" min="1000" step="1000">
      </div>
      <div class="field-group" style="margin-bottom:0;">
        <label>Residual Value (₹) <span style="opacity:0.6;">— used by SLM</span></label>
        <input type="number" id="depLabResidual" class="field-input" value="10000" min="0" step="500">
      </div>
      <div class="field-group" style="margin-bottom:0;">
        <label>Rate of Depreciation (%)</label>
        <input type="number" id="depLabRate" class="field-input" value="10" min="1" max="100" step="1">
      </div>
      <div class="field-group" style="margin-bottom:0;">
        <label>Years to Display</label>
        <input type="number" id="depLabYears" class="field-input" value="5" min="2" max="10" step="1">
      </div>
    </div>
    <p style="font-size:0.78rem; color:var(--ink-faint); margin:6px 0 20px;">SLM uses the Residual Value shown above (Depreciation = (Cost − Residual) × Rate ÷ 100, same every year). WDV ignores Residual Value and instead applies the Rate to each year's opening book value.</p>
    <div id="depLabFlow" style="margin-bottom:24px;"></div>
    <div id="depLabTables"></div>
  `;
  panel.appendChild(card);

  function computeAndRender() {
    const cost = Math.max(1, parseFloat($("#depLabCost", card).value) || 0);
    const residual = Math.min(cost, Math.max(0, parseFloat($("#depLabResidual", card).value) || 0));
    const rate = Math.max(0.01, Math.min(100, parseFloat($("#depLabRate", card).value) || 0));
    const years = Math.min(10, Math.max(2, parseInt($("#depLabYears", card).value, 10) || 5));

    const slmDep = (cost - residual) * rate / 100;
    const slmRows = [];
    let slmBv = cost;
    for (let y = 1; y <= years; y++) {
      const remainingBeforeFloor = Math.max(0, slmBv - residual);
      const depThisYear = Math.min(slmDep, remainingBeforeFloor);
      slmBv = Math.max(residual, slmBv - depThisYear);
      slmRows.push({ y, dep: depThisYear, bv: slmBv });
    }

    const wdvRows = [];
    let wdvBv = cost;
    for (let y = 1; y <= years; y++) {
      const dep = wdvBv * rate / 100;
      wdvBv = wdvBv - dep;
      wdvRows.push({ y, dep, bv: wdvBv });
    }

    const flowEl = $("#depLabFlow", card);
    flowEl.innerHTML = `
      <div style="display:flex; align-items:center; justify-content:center; gap:12px; flex-wrap:wrap; text-align:center;">
        <div class="tnum" style="background:var(--c-dep-soft); color:var(--c-dep); padding:14px 18px; border-radius:10px; min-width:140px;">
          <div style="font-size:0.72rem; opacity:0.85;">Original Cost</div>
          <div style="font-size:1.1rem; font-weight:700;">${fmtINR(Math.round(cost))}</div>
        </div>
        <i data-lucide="arrow-right"></i>
        <div class="tnum" style="background:var(--flag-soft); color:var(--flag); padding:14px 18px; border-radius:10px; min-width:140px;">
          <div style="font-size:0.72rem; opacity:0.85;">Year 1 Depreciation (SLM)</div>
          <div style="font-size:1.1rem; font-weight:700;">${fmtINR(Math.round(slmRows[0].dep))}</div>
        </div>
        <i data-lucide="arrow-right"></i>
        <div class="tnum" style="background:var(--c-eq-soft); color:var(--c-eq); padding:14px 18px; border-radius:10px; min-width:140px;">
          <div style="font-size:0.72rem; opacity:0.85;">Book Value after Year 1</div>
          <div style="font-size:1.1rem; font-weight:700;">${fmtINR(Math.round(slmRows[0].bv))}</div>
        </div>
      </div>
    `;

    const tablesEl = $("#depLabTables", card);
    tablesEl.innerHTML = `
      <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(260px,1fr)); gap:20px;">
        <div>
          <h4 style="font-size:0.92rem; margin-bottom:10px; color:var(--c-eq);">Straight Line Method (SLM)</h4>
          <table style="width:100%; border-collapse:collapse; font-size:0.84rem;">
            <thead><tr style="border-bottom:1px solid var(--line);"><th style="text-align:left; padding:6px 4px;">Year</th><th style="text-align:right; padding:6px 4px;">Depreciation</th><th style="text-align:right; padding:6px 4px;">Book Value</th></tr></thead>
            <tbody>${slmRows.map(r => `<tr style="border-bottom:1px solid var(--line);"><td style="padding:6px 4px;">${r.y}</td><td style="text-align:right; padding:6px 4px;">${fmtINR(Math.round(r.dep))}</td><td style="text-align:right; padding:6px 4px; font-weight:600;">${fmtINR(Math.round(r.bv))}</td></tr>`).join("")}</tbody>
          </table>
        </div>
        <div>
          <h4 style="font-size:0.92rem; margin-bottom:10px; color:var(--c-dep);">Written Down Value (WDV)</h4>
          <table style="width:100%; border-collapse:collapse; font-size:0.84rem;">
            <thead><tr style="border-bottom:1px solid var(--line);"><th style="text-align:left; padding:6px 4px;">Year</th><th style="text-align:right; padding:6px 4px;">Depreciation</th><th style="text-align:right; padding:6px 4px;">Book Value</th></tr></thead>
            <tbody>${wdvRows.map(r => `<tr style="border-bottom:1px solid var(--line);"><td style="padding:6px 4px;">${r.y}</td><td style="text-align:right; padding:6px 4px;">${fmtINR(Math.round(r.dep))}</td><td style="text-align:right; padding:6px 4px; font-weight:600;">${fmtINR(Math.round(r.bv))}</td></tr>`).join("")}</tbody>
          </table>
        </div>
      </div>
      <p style="font-size:0.82rem; color:var(--ink-soft); margin-top:18px; line-height:1.7; background:var(--c-dep-soft); padding:12px 14px; border-radius:10px;">
        <b>SLM vs WDV:</b> under SLM the depreciation charge (${fmtINR(Math.round(slmDep))}) stays exactly the same every year, and book value can reach the residual value exactly. Under WDV the charge keeps shrinking (${fmtINR(Math.round(wdvRows[0].dep))} in Year 1 → ${fmtINR(Math.round(wdvRows[wdvRows.length-1].dep))} in Year ${years}), and book value keeps falling but never quite reaches zero.
      </p>
    `;
    icons();
  }

  card.addEventListener("input", computeAndRender);
  computeAndRender();
}

let depFilterDifficulty = "All";

function renderDepPracticeBank(panel, data) {
  panel.innerHTML = "";
  panel.appendChild(sectionTitle("Depreciation practice bank"));
  const hint = el("p", "", `${data.numericals.length} questions — meaning, causes, SLM, WDV, part-year, provision accounts, and disposal. Pick the correct option, then check your answer for a full worked explanation.`);
  hint.style.cssText = "font-size:0.85rem; color:var(--ink-faint); margin:-8px 0 18px; line-height:1.6;";
  panel.appendChild(hint);

  const filterBar = el("div", "", "");
  filterBar.style.cssText = "display:flex; gap:8px; margin-bottom:18px; flex-wrap:wrap;";
  ["All", "Easy", "Medium", "Hard"].forEach(d => {
    const chip = el("button", `chip ${d === depFilterDifficulty ? "active" : ""}`, d);
    chip.addEventListener("click", () => { depFilterDifficulty = d; renderDepPracticeBank(panel, data); });
    filterBar.appendChild(chip);
  });
  panel.appendChild(filterBar);

  const list = data.numericals.filter(q => depFilterDifficulty === "All" || q.difficulty === depFilterDifficulty);
  const countLabel = el("p", "", `Showing ${list.length} of ${data.numericals.length} questions`);
  countLabel.style.cssText = "font-size:0.83rem; color:var(--ink-faint); margin-bottom:16px;";
  panel.appendChild(countLabel);

  list.forEach(q => {
    const solvedKey = `dep-${q.id}`;
    const alreadySolved = STATE.solved[solvedKey];
    let picked = null;
    const shuffledOrder = fisherYatesShuffle(q.options.map((_, i) => i));

    const card = el("div", "card q-card", "");
    card.innerHTML = `
      <div class="q-meta">
        <span class="diff-badge ${q.difficulty}">${q.difficulty}</span>
        <span class="q-id">Q${q.id}</span>
        ${alreadySolved ? `<span style="margin-left:auto; color:var(--c-dep); font-size:0.78rem; display:flex; align-items:center; gap:4px;"><i data-lucide="check-circle" style="width:13px;height:13px;"></i> Solved</span>` : ""}
      </div>
      <div class="q-body">${q.question}</div>
      <div style="margin-top:14px;">
        <div class="opt-group" data-role="answer" style="display:flex; flex-wrap:wrap; gap:8px;">
          ${shuffledOrder.map(i => `<button class="chip" data-val="${i}">${q.options[i]}</button>`).join("")}
        </div>
      </div>
      <div class="q-actions" style="margin-top:14px;">
        <button class="btn-primary sm ripple-surface" data-act="check"><i data-lucide="check"></i> Check Answer</button>
      </div>
      <div class="reveal-area"></div>
    `;
    const revealArea = $(".reveal-area", card);

    card.addEventListener("click", (e) => {
      const optBtn = e.target.closest(".opt-group button[data-val]");
      if (optBtn) {
        const group = optBtn.closest(".opt-group");
        $all("button", group).forEach(b => b.classList.remove("active"));
        optBtn.classList.add("active");
        picked = parseInt(optBtn.dataset.val, 10);
        return;
      }
      const checkBtn = e.target.closest("button[data-act='check']");
      if (checkBtn) {
        if (picked === null) {
          revealArea.innerHTML = `<div class="reveal-block hint-block"><p style="font-size:0.86rem;">Pick an option first.</p></div>`;
          return;
        }
        const correct = picked === q.answerIndex;
        if (correct) {
          revealArea.innerHTML = `
            <div class="reveal-block">
              <h4>Correct!</h4>
              <p style="font-size:0.87rem; line-height:1.6; color:var(--ink-soft);">${q.explanation}</p>
            </div>`;
          playSuccessSound();
          if (!STATE.solved[solvedKey]) {
            STATE.solved[solvedKey] = { correct: true, attempts: 1 };
            saveState(); addXP(4, `Depreciation Q${q.id} solved`); logActivity(`Depreciation Q${q.id} solved (${q.difficulty})`); refreshProgress();
          }
          mistakeBookRecordCorrect(solvedKey);
        } else {
          revealArea.innerHTML = `
            <div class="reveal-block" style="background:var(--flag-soft); border-left-color:var(--flag);">
              <h4>Not quite</h4>
              <p style="font-size:0.87rem; line-height:1.6; color:var(--ink-soft);">The correct answer is: <b>${q.options[q.answerIndex]}</b>.<br>${q.explanation}</p>
            </div>`;
          playErrorSound();
          if (!STATE.solved[solvedKey]) {
            STATE.solved[solvedKey] = { correct: false, attempts: 1 };
            if (!STATE.mistakes.includes(solvedKey)) STATE.mistakes.push(solvedKey);
            saveState(); addXP(-XP_WRONG_PENALTY, `Q${q.id} incorrect`); refreshProgress();
          }
          mistakeBookRecord({
            key: solvedKey, question: q.question, chapter: "dep", chapterLabel: "Depreciation",
            topic: "Depreciation Calculation", type: "Depreciation Practice",
            studentAnswer: q.options[picked],
            correctAnswer: q.options[q.answerIndex],
            explanation: q.explanation
          });
        }
        icons();
      }
    });
    panel.appendChild(card);
  });
  applyMobilePager(panel);
  icons();
}

function renderDepQuickRevision(panel, data) {
  panel.appendChild(sectionTitle("Quick revision"));
  const qr = data.quickRevision;
  const card = el("div", "card-solid", "");
  card.style.padding = "28px";
  card.innerHTML = `
    <div class="ledger-rule">
      <h4 style="font-size:0.95rem; margin-bottom:8px;">Definition</h4>
      <p style="font-size:0.89rem; line-height:1.6; color:var(--ink-soft);">${qr.definition}</p>
    </div>
    <div class="ledger-rule" style="margin-top:18px;">
      <h4 style="font-size:0.95rem; margin-bottom:8px;">Key points</h4>
      <ol style="padding-left:20px;">${qr.keyPoints.map(r => `<li style="margin-bottom:6px; font-size:0.87rem; color:var(--ink-soft);">${r}</li>`).join("")}</ol>
    </div>
    <div class="ledger-rule" style="margin-top:18px;">
      <h4 style="font-size:0.95rem; margin-bottom:8px;">Calculation steps</h4>
      <ol style="padding-left:20px;">${qr.calculationSteps.map(r => `<li style="margin-bottom:6px; font-size:0.87rem; color:var(--ink-soft);">${r}</li>`).join("")}</ol>
    </div>
    <div class="ledger-rule" style="margin-top:18px;">
      <h4 style="font-size:0.95rem; margin-bottom:8px; color:var(--flag);">Common mistakes</h4>
      <ul style="padding-left:20px;">${qr.commonMistakes.map(r => `<li style="margin-bottom:6px; font-size:0.87rem; color:var(--ink-soft);">${r}</li>`).join("")}</ul>
    </div>
    <div class="tnum" style="text-align:center; font-size:0.92rem; font-weight:600; color:var(--c-dep); background:var(--c-dep-soft); padding:14px; border-radius:10px; margin-top:18px;">
      💡 Mnemonic: ${qr.mnemonic}
    </div>
  `;
  panel.appendChild(card);
}

/* ---------------------------------------------------------
   6e. SHARED THEORY / CONCEPTS RENDERER (used by Ch.2 & Ch.3)
   --------------------------------------------------------- */
function renderGenericTheory(panel, data, chId) {
  const accent = chId === "dc" ? "var(--c-dc)" : "var(--c-jr)";
  const soft = chId === "dc" ? "var(--c-dc-soft)" : "var(--c-jr-soft)";
  const wrap = el("div", "grid-2");

  const simpleCard = el("div", "card-solid", "");
  simpleCard.style.padding = "26px";
  simpleCard.innerHTML = `<h3 style="margin-bottom:14px;"><i data-lucide="book-open" style="width:18px;height:18px;vertical-align:-3px;color:${accent};"></i> Simple Explanation</h3>`;
  data.theory.simple.forEach(block => {
    const b = el("div", "ledger-rule");
    b.style.marginTop = "16px";
    let html = `<h4 style="font-size:0.95rem; margin-bottom:8px;">${block.h}</h4>`;
    if (block.p) html += `<p style="font-size:0.9rem; line-height:1.65; color:var(--ink-soft); margin-bottom:10px;">${block.p}</p>`;
    if (block.formula) html += `<div class="tnum" style="text-align:center; font-size:1.05rem; font-weight:700; color:${accent}; background:${soft}; padding:12px; border-radius:10px; margin:10px 0;">${block.formula}</div>`;
    if (block.p2) html += `<p style="font-size:0.9rem; line-height:1.65; color:var(--ink-soft);">${block.p2}</p>`;
    if (block.list) {
      html += `<ul style="padding-left:18px; margin-top:8px;">`;
      block.list.forEach(item => html += `<li style="margin-bottom:8px; font-size:0.88rem;"><b>${item.term}:</b> ${item.def}</li>`);
      html += `</ul>`;
    }
    b.innerHTML = html;
    simpleCard.appendChild(b);
  });

  const advCard = el("div", "card-solid", "");
  advCard.style.padding = "26px";
  advCard.innerHTML = `<h3 style="margin-bottom:14px;"><i data-lucide="brain" style="width:18px;height:18px;vertical-align:-3px;color:${accent};"></i> Advanced Explanation</h3>`;
  data.theory.advanced.forEach(block => {
    const b = el("div", "ledger-rule");
    b.style.marginTop = "16px";
    let html = `<h4 style="font-size:0.95rem; margin-bottom:8px;">${block.h}</h4>`;
    if (block.p) html += `<p style="font-size:0.9rem; line-height:1.65; color:var(--ink-soft); margin-bottom:10px;">${block.p}</p>`;
    if (block.formula) html += `<div class="tnum" style="text-align:center; font-size:1.02rem; font-weight:700; color:${accent}; background:${soft}; padding:12px; border-radius:10px; margin:10px 0;">${block.formula}</div>`;
    if (block.p2) html += `<p style="font-size:0.9rem; line-height:1.65; color:var(--ink-soft);">${block.p2}</p>`;
    if (block.list) {
      html += `<ul style="padding-left:18px; margin-top:8px;">`;
      block.list.forEach(item => html += `<li style="margin-bottom:8px; font-size:0.88rem;"><b>${item.term}:</b> ${item.def}</li>`);
      html += `</ul>`;
    }
    b.innerHTML = html;
    advCard.appendChild(b);
  });

  wrap.appendChild(simpleCard);
  wrap.appendChild(advCard);
  panel.appendChild(wrap);
}

function renderGenericConcepts(panel, data, chId) {
  const accent = chId === "dc" ? "var(--c-dc)" : "var(--c-jr)";
  panel.appendChild(sectionTitle("Key concepts"));
  const grid = el("div", "grid-3");
  data.concepts.forEach(c => {
    const card = el("div", "card liftable", "");
    card.style.padding = "22px";
    card.innerHTML = `<h4 style="font-size:1rem; margin-bottom:8px; color:${accent};">${c.title}</h4><p style="font-size:0.87rem; line-height:1.6; color:var(--ink-soft);">${c.body}</p>`;
    grid.appendChild(card);
  });
  panel.appendChild(grid);
}

/* ---------------------------------------------------------
   6e. FLASHCARDS — flip cards across all three chapters
   --------------------------------------------------------- */
let flashState = { chapter: "all", deck: [], index: 0, flipped: false, knownCount: 0 };

function renderFlashcards(root) {
  root.appendChild(el("div", "hero", `
    <span class="hero-eyebrow">Practice</span>
    <h1>Flashcards</h1>
    <p>Tap a card to flip it, then mark whether you knew it. Filter by chapter to focus your drilling.</p>
  `));

  const filterBar = el("div", "", "");
  filterBar.style.cssText = "display:flex; gap:8px; flex-wrap:wrap; margin-bottom:22px;";
  const chFilters = [["all","All Chapters"],["eq","Ch.1 Equation"],["dc","Ch.2 Debit & Credit"],["jr","Ch.3 Journal"],["lg","Ch.4 Ledger"],["cb","Ch.5 Cash Book"],["sp2","Ch.6 Other Books"],["brs","Ch.7 BRS"],["gst","Ch.8 GST"],["tb","Ch.9 Trial Balance"],["dep","Ch.10 Depreciation"]];
  chFilters.forEach(([id,label]) => {
    const chip = el("button", `chip ${flashState.chapter === id ? "active" : ""}`, label);
    chip.addEventListener("click", () => { flashState.chapter = id; startFlashDeck(); renderFlashArea(area); });
    filterBar.appendChild(chip);
  });
  root.appendChild(filterBar);

  const area = el("div", "");
  root.appendChild(area);
  startFlashDeck();
  renderFlashArea(area);
}

function startFlashDeck() {
  const pool = APP_DATA.flashcards.filter(c => flashState.chapter === "all" || c.chapter === flashState.chapter);
  flashState.deck = fisherYatesShuffle(pool);
  flashState.index = 0;
  flashState.flipped = false;
  flashState.knownCount = 0;
  flashState.xpAwarded = false;
  flashState.history = [];   // stack of "known" | "learning" per completed card, so Back can undo correctly
}

function renderFlashArea(area) {
  const deck = flashState.deck;
  if (!deck.length) { area.innerHTML = `<p style="color:var(--ink-faint);">No cards in this set.</p>`; return; }
  if (flashState.index >= deck.length) {
    area.innerHTML = `
      <div class="card-solid" style="padding:40px; text-align:center;">
        <i data-lucide="party-popper" style="width:32px;height:32px;color:var(--gold);"></i>
        <h3 style="margin:12px 0 6px;">Deck complete</h3>
        <p style="color:var(--ink-soft); font-size:0.9rem; margin-bottom:18px;">You marked ${flashState.knownCount} of ${deck.length} as known.</p>
        <button class="btn-primary ripple-surface" id="flashRestart"><i data-lucide="rotate-ccw"></i> Restart deck</button>
      </div>`;
    icons();
    $("#flashRestart").addEventListener("click", () => { startFlashDeck(); renderFlashArea(area); });
    if (flashState.knownCount > 0 && !flashState.xpAwarded) {
      flashState.xpAwarded = true;
      addXP(Math.min(20, flashState.knownCount), "Flashcard deck completed");
    }
    return;
  }
  const card = deck[flashState.index];
  const chLabel = { eq: "Ch.1 Equation", dc: "Ch.2 Debit & Credit", jr: "Ch.3 Journal", lg: "Ch.4 Ledger", cb: "Ch.5 Cash Book", sp2: "Ch.6 Other Books", brs: "Ch.7 BRS", gst: "Ch.8 GST", tb: "Ch.9 Trial Balance", dep: "Ch.10 Depreciation" }[card.chapter];
  const chColor = { eq: "var(--c-eq)", dc: "var(--c-dc)", jr: "var(--c-jr)", lg: "var(--c-lg)", cb: "var(--c-cb)", sp2: "var(--c-sp2)", brs: "var(--c-brs)", gst: "var(--c-gst)", tb: "var(--c-tb)", dep: "var(--c-dep)" }[card.chapter];
  area.innerHTML = `
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:14px; font-size:0.83rem; color:var(--ink-faint);">
      <span>Card ${flashState.index + 1} of ${deck.length}</span>
      <span style="color:${chColor}; font-weight:600;">${chLabel}</span>
    </div>
    <div class="flashcard-wrap">
      <div class="flashcard ${flashState.flipped ? "is-flipped" : ""}" id="flashCardEl">
        <div class="flashcard-face flashcard-front"><p>${card.front}</p><span class="flash-hint">Tap to flip</span></div>
        <div class="flashcard-face flashcard-back"><p>${card.back}</p><span class="flash-hint">Tap to flip back</span></div>
      </div>
    </div>
    <div style="display:flex; gap:10px; justify-content:center; margin-top:20px; flex-wrap:wrap;">
      <button class="btn-ghost ripple-surface" id="flashBackBtn" ${flashState.index === 0 ? "disabled" : ""}><i data-lucide="arrow-left"></i> Previous</button>
      <button class="btn-ghost ripple-surface" id="flashDontKnow"><i data-lucide="rotate-ccw"></i> Still learning</button>
      <button class="btn-primary ripple-surface" id="flashKnow"><i data-lucide="check"></i> I knew this</button>
    </div>
  `;
  icons();
  $("#flashCardEl").addEventListener("click", () => { flashState.flipped = !flashState.flipped; renderFlashArea(area); });
  $("#flashKnow").addEventListener("click", (e) => {
    e.stopPropagation(); playSuccessSound();
    flashState.knownCount++; flashState.history.push("known");
    flashState.index++; flashState.flipped = false; renderFlashArea(area);
  });
  $("#flashDontKnow").addEventListener("click", (e) => {
    e.stopPropagation();
    flashState.history.push("learning");
    flashState.index++; flashState.flipped = false; renderFlashArea(area);
  });
  $("#flashBackBtn").addEventListener("click", (e) => {
    e.stopPropagation();
    if (flashState.index === 0) return;
    const last = flashState.history.pop();
    if (last === "known") flashState.knownCount = Math.max(0, flashState.knownCount - 1);
    flashState.index--; flashState.flipped = false; renderFlashArea(area);
  });
}

/* ---------------------------------------------------------
   6f. QUIZ — MCQ engine across all three chapters
   --------------------------------------------------------- */
let quizState = { chapter: "all", pool: [], index: 0, score: 0, answered: false, selected: null, answers: [] };

/* Genuine Fisher–Yates shuffle — unlike Array.sort(() => Math.random()-0.5),
   this gives every permutation equal probability. Used for both question
   order and (below) each question's own option order, so the correct
   answer is never biased toward any one position. */
function fisherYatesShuffle(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/* BUG FIX: quiz/exam options used to be shown in the exact order stored
   in data.js, where the correct answer happened to sit at index 1
   ("B") far more often than any other position — so the visible
   pattern looked hard-coded even though it wasn't intentional. This
   independently reshuffles ONE question's options (and remaps
   answerIndex to match) every time it's called, so the correct
   option lands in a genuinely random position on every attempt,
   without ever changing which option text is actually correct. */
function shuffleQuizOptions(q) {
  const order = fisherYatesShuffle(q.options.map((_, i) => i));
  return {
    ...q,
    options: order.map(i => q.options[i]),
    answerIndex: order.indexOf(q.answerIndex)
  };
}

function renderQuiz(root) {
  root.appendChild(el("div", "hero", `
    <span class="hero-eyebrow">Practice</span>
    <h1>Quiz</h1>
    <p>Multiple-choice questions drawing on all ten chapters, with instant feedback and a running score.</p>
  `));

  const filterBar = el("div", "", "");
  filterBar.style.cssText = "display:flex; gap:8px; flex-wrap:wrap; margin-bottom:22px;";
  const chFilters = [["all","All Chapters"],["eq","Ch.1 Equation"],["dc","Ch.2 Debit & Credit"],["jr","Ch.3 Journal"],["lg","Ch.4 Ledger"],["cb","Ch.5 Cash Book"],["sp2","Ch.6 Other Books"],["brs","Ch.7 BRS"],["gst","Ch.8 GST"],["tb","Ch.9 Trial Balance"],["dep","Ch.10 Depreciation"]];
  chFilters.forEach(([id,label]) => {
    const chip = el("button", `chip ${quizState.chapter === id ? "active" : ""}`, label);
    chip.addEventListener("click", () => { quizState.chapter = id; startQuiz(); renderQuizArea(area); });
    filterBar.appendChild(chip);
  });
  root.appendChild(filterBar);

  const area = el("div", "");
  root.appendChild(area);
  startQuiz();
  renderQuizArea(area);
}

function startQuiz() {
  const pool = APP_DATA.quiz.filter(qq => quizState.chapter === "all" || qq.chapter === quizState.chapter);
  quizState.pool = fisherYatesShuffle(pool).map(shuffleQuizOptions);
  quizState.index = 0; quizState.score = 0; quizState.answered = false; quizState.selected = null;
  quizState.answers = new Array(quizState.pool.length).fill(null); // each slot: null (unanswered) or the selected option index
  quizState.xpAwarded = false;
  quizState.completionSoundPlayed = false;
}

/* Recompute score from the answers array — the single source of truth,
   so navigating back and forth (and possibly changing an answer's
   underlying question via re-filter) never double-counts or drifts. */
function recomputeQuizScore() {
  quizState.score = quizState.pool.reduce((sum, q, i) => {
    return sum + (quizState.answers[i] !== null && quizState.answers[i] === q.answerIndex ? 1 : 0);
  }, 0);
}

function renderQuizArea(area) {
  const pool = quizState.pool;
  if (!pool.length) { area.innerHTML = `<p style="color:var(--ink-faint);">No questions in this set.</p>`; return; }
  if (quizState.index >= pool.length) {
    const pct = Math.round((quizState.score / pool.length) * 100);
    area.innerHTML = `
      <div class="card-solid" style="padding:40px; text-align:center;">
        <i data-lucide="trophy" style="width:32px;height:32px;color:var(--gold);"></i>
        <h3 style="margin:12px 0 6px;">Quiz complete</h3>
        <p style="color:var(--ink-soft); font-size:0.9rem; margin-bottom:18px;">You scored ${quizState.score} out of ${pool.length} (${pct}%).</p>
        <div style="display:flex; gap:10px; justify-content:center; flex-wrap:wrap;">
          <button class="btn-ghost ripple-surface" id="quizReview"><i data-lucide="arrow-left"></i> Review answers</button>
          <button class="btn-primary ripple-surface" id="quizRestart"><i data-lucide="rotate-ccw"></i> Try again</button>
        </div>
      </div>`;
    icons();
    $("#quizRestart").addEventListener("click", () => { startQuiz(); renderQuizArea(area); });
    $("#quizReview").addEventListener("click", () => { quizState.index = pool.length - 1; renderQuizArea(area); });
    if (pct >= 70) launchConfetti();
    if (!quizState.completionSoundPlayed) {
      playCompletionSound();
      quizState.completionSoundPlayed = true;
    }
    if (!quizState.xpAwarded) {
      addXP(quizState.score * 2, "Quiz answers correct");
      quizState.xpAwarded = true;
    }
    STATE.bestScores.quiz = Math.max(STATE.bestScores.quiz || 0, pct);
    saveState();
    return;
  }
  const q = pool[quizState.index];
  const priorAnswer = quizState.answers[quizState.index];   // null if not yet answered, else the chosen option index
  const chColor = { eq: "var(--c-eq)", dc: "var(--c-dc)", jr: "var(--c-jr)", lg: "var(--c-lg)", cb: "var(--c-cb)", sp2: "var(--c-sp2)", brs: "var(--c-brs)", gst: "var(--c-gst)", tb: "var(--c-tb)", dep: "var(--c-dep)" }[q.chapter];
  area.innerHTML = `
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:14px; font-size:0.83rem; color:var(--ink-faint);">
      <span>Question ${quizState.index + 1} of ${pool.length}</span>
      <span class="tnum">Score: <b>${quizState.score}</b></span>
    </div>
    <div class="card-solid" style="padding:26px;">
      <span class="diff-badge ${q.difficulty}" style="margin-bottom:10px; display:inline-block;">${q.difficulty}</span>
      <h3 style="font-size:1.02rem; margin-bottom:18px; line-height:1.5;">${q.q}</h3>
      <div id="quizOptions"></div>
      <div id="quizFeedback" style="margin-top:14px;"></div>
      <div style="display:flex; justify-content:space-between; margin-top:16px; gap:10px;">
        <button class="btn-ghost ripple-surface" id="quizPrevBtn" ${quizState.index === 0 ? "disabled" : ""}><i data-lucide="arrow-left"></i> Previous</button>
        <button class="btn-primary ripple-surface" id="quizNextBtn" ${priorAnswer === null ? "hidden" : ""}>${quizState.index === pool.length - 1 ? "Finish" : "Next question"} <i data-lucide="arrow-right"></i></button>
      </div>
    </div>
  `;
  const optWrap = $("#quizOptions");

  function showFeedbackFor(selectedIndex) {
    const correct = selectedIndex === q.answerIndex;
    $all("#quizOptions .chip").forEach((el2, idx) => {
      el2.disabled = true;
      if (idx === q.answerIndex) {
        el2.style.borderColor = "var(--c-eq)"; el2.style.background = "var(--c-eq-soft)"; el2.style.color = "var(--c-eq)";
        if (idx === selectedIndex && !STATE.reduceMotion) el2.classList.add("fb-correct");
      }
      else if (idx === selectedIndex) {
        el2.style.borderColor = "var(--flag)"; el2.style.background = "var(--flag-soft)"; el2.style.color = "var(--flag)";
        if (!STATE.reduceMotion) el2.classList.add("fb-wrong");
      }
    });
    $("#quizFeedback").innerHTML = `<div class="reveal-block" style="${correct ? "" : "background:var(--flag-soft); border-left-color:var(--flag);"}"><h4>${correct ? "Correct" : "Not quite"}</h4><p style="font-size:0.87rem;">${q.explanation}</p></div>`;
    $("#quizNextBtn").hidden = false;
  }

  q.options.forEach((opt, i) => {
    const b = el("button", "chip ripple-surface", opt);
    b.style.cssText = "display:block; width:100%; text-align:left; margin-bottom:8px; padding:12px 14px; border-radius:12px;";
    b.addEventListener("click", () => {
      if (quizState.answers[quizState.index] !== null) return; // already answered this question — locked
      quizState.answers[quizState.index] = i;
      const correct = i === q.answerIndex;
      if (correct) {
        addXP(2, "Quiz question correct"); playSuccessSound();
        mistakeBookRecordCorrect(`quiz-${q.id}`);
      } else {
        addXP(-XP_WRONG_PENALTY, "Quiz question incorrect"); playErrorSound();
        mistakeBookRecord({
          key: `quiz-${q.id}`, question: q.q, chapter: q.chapter, chapterLabel: CH_FULL_NAME[q.chapter] || q.chapter,
          topic: CH_FULL_NAME[q.chapter] || q.chapter, type: "Quiz MCQ",
          studentAnswer: q.options[i], correctAnswer: q.options[q.answerIndex], explanation: q.explanation
        });
      }
      recomputeQuizScore();
      showFeedbackFor(i);
      icons();
    });
    optWrap.appendChild(b);
  });

  // If this question was already answered earlier (navigated back to it), restore that state immediately.
  if (priorAnswer !== null) {
    showFeedbackFor(priorAnswer);
  }

  icons();
  $("#quizNextBtn").addEventListener("click", () => {
    quizState.index++; renderQuizArea(area);
  });
  $("#quizPrevBtn").addEventListener("click", () => {
    if (quizState.index === 0) return;
    quizState.index--; renderQuizArea(area);
  });
}

/* ---------------------------------------------------------
   7. NUMERICAL SOLVER (standalone, cross-chapter — currently
      powered by Chapter 1's bank; expands as more chapters ship)
   --------------------------------------------------------- */
function renderNumericalSolver(root) {
  root.appendChild(el("div", "hero", `
    <span class="hero-eyebrow">Practice</span>
    <h1>Numerical Solver</h1>
    <p>Unlimited generated problems with instant checking, live scoring, and a running timer.</p>
  `));
  renderEqGenerator(root);
}

/* ---------------------------------------------------------
   8. FORMULA SHEET (built now — genuinely quick to ship well)
   --------------------------------------------------------- */
function renderFormulaSheet(root) {
  root.appendChild(el("div", "hero", `
    <span class="hero-eyebrow">Revision</span>
    <h1>Formula Sheet</h1>
    <p>Core relationships and rules across all ten chapters, ready to scan or print.</p>
    <button class="btn-primary ripple-surface" id="printBtn" style="margin-top:10px;"><i data-lucide="printer"></i> Print / Save as PDF</button>
  `));
  const card = el("div", "card-solid", "");
  card.style.padding = "26px";
  card.innerHTML = `
    <h3 style="margin-bottom:12px; color:var(--c-eq);">Chapter 1 — Accounting Equation</h3>
    <table class="ledger-table">
      <thead><tr><th>To find</th><th>Formula</th></tr></thead>
      <tbody>
        <tr><td>Assets</td><td class="tnum">Capital + Liabilities</td></tr>
        <tr><td>Capital</td><td class="tnum">Assets − Liabilities</td></tr>
        <tr><td>Liabilities</td><td class="tnum">Assets − Capital</td></tr>
        <tr><td>Effective Capital</td><td class="tnum">Opening Capital + Profit + Additional Capital − Drawings − Loss</td></tr>
        <tr><td>Profit on a transaction</td><td class="tnum">Selling Price − Cost</td></tr>
      </tbody>
    </table>

    <h3 style="margin:28px 0 12px; color:var(--c-dc);">Chapter 2 — Rules of Debit &amp; Credit</h3>
    <table class="ledger-table">
      <thead><tr><th>Account type</th><th>Rule</th></tr></thead>
      <tbody>
        <tr><td>Personal (Golden Rule)</td><td>Debit the Receiver, Credit the Giver</td></tr>
        <tr><td>Real (Golden Rule)</td><td>Debit what comes in, Credit what goes out</td></tr>
        <tr><td>Nominal (Golden Rule)</td><td>Debit all expenses/losses, Credit all incomes/gains</td></tr>
        <tr><td>Assets / Expenses (Modern Rule)</td><td>Increase = Debit, Decrease = Credit</td></tr>
        <tr><td>Liabilities / Capital / Revenue (Modern Rule)</td><td>Increase = Credit, Decrease = Debit</td></tr>
      </tbody>
    </table>

    <h3 style="margin:28px 0 12px; color:var(--c-jr);">Chapter 3 — Journal</h3>
    <table class="ledger-table">
      <thead><tr><th>Element</th><th>Detail</th></tr></thead>
      <tbody>
        <tr><td>Journal columns</td><td>Date · Particulars · L.F. · Debit ₹ · Credit ₹</td></tr>
        <tr><td>Format</td><td>Debit account first (with "Dr."), credit account indented below (with "To")</td></tr>
        <tr><td>Narration</td><td>Written in brackets below every entry, starting with "Being…"</td></tr>
        <tr><td>Compound entry rule</td><td>Total Debits = Total Credits, even across multiple lines</td></tr>
        <tr><td>Trade discount</td><td>Never recorded — only the net billed value is journalised</td></tr>
        <tr><td>Cash discount</td><td>Recorded via Discount Allowed A/c (expense) or Discount Received A/c (income)</td></tr>
      </tbody>
    </table>

    <h3 style="margin:28px 0 12px; color:var(--c-lg);">Chapter 4 — Ledger</h3>
    <table class="ledger-table">
      <thead><tr><th>Element</th><th>Detail</th></tr></thead>
      <tbody>
        <tr><td>Definition</td><td>Principal book of accounts where all Journal transactions are posted, classified by account</td></tr>
        <tr><td>Format</td><td>T-shaped account — Debit (Dr.) on the left, Credit (Cr.) on the right, with Date · Particulars · J.F. · Amount on each side</td></tr>
        <tr><td>J.F. column</td><td>Journal Folio — the page number of the Journal the entry was posted from</td></tr>
        <tr><td>Posting rule — debit</td><td>Journal debit → Ledger debit (same account, same amount)</td></tr>
        <tr><td>Posting rule — credit</td><td>Journal credit → Ledger credit (same account, same amount)</td></tr>
        <tr><td>Debit side wording</td><td>Prefix with "To" — e.g. "To Sales A/c"</td></tr>
        <tr><td>Credit side wording</td><td>Prefix with "By" — e.g. "By Cash A/c"</td></tr>
        <tr><td>Balancing — Step 1</td><td>Total (foot) both sides separately</td></tr>
        <tr><td>Balancing — Step 2</td><td>Write the difference as "Balance c/d" on the smaller side, so both sides tally</td></tr>
        <tr><td>Balancing — Step 3</td><td>Bring the same figure down as "Balance b/d" on the opposite side, next period</td></tr>
        <tr><td>Debit balance</td><td>Balance b/d appears on the debit side — typical of Assets and Expenses</td></tr>
        <tr><td>Credit balance</td><td>Balance b/d appears on the credit side — typical of Liabilities, Capital, and Income</td></tr>
        <tr><td>Nil balance</td><td>Both sides total exactly the same — common for Nominal accounts closed to Profit &amp; Loss A/c</td></tr>
        <tr><td>Mnemonic</td><td>"Debit — To; Credit — By" — say it as one phrase to recall instantly</td></tr>
      </tbody>
    </table>

    <h3 style="margin:28px 0 12px; color:var(--c-cb);">Chapter 5 — Special Purpose Books 1: Cash Book</h3>
    <table class="ledger-table">
      <thead><tr><th>Element</th><th>Detail</th></tr></thead>
      <tbody>
        <tr><td>Cash Book</td><td>Records only cash and bank transactions, in chronological order — receipts on debit (left), payments on credit (right)</td></tr>
        <tr><td>Dual nature</td><td>Both a Subsidiary Book (original entry) AND a Principal Book (it IS the Cash/Bank Account — balances go straight to the Trial Balance)</td></tr>
        <tr><td>Simple Cash Book</td><td>One amount column each side — cash transactions only; never shows a credit balance</td></tr>
        <tr><td>Two-Column Cash Book</td><td>Cash column + Bank column each side — represents Cash A/c and Bank A/c together</td></tr>
        <tr><td>Contra Entry</td><td>Cash ↔ Bank transfer — marked 'C' in the L.F. column on both sides; never posted to any Ledger account</td></tr>
        <tr><td>Cash Discount</td><td>Never entered in the Cash Book — always via Journal Proper: Discount Allowed A/c Dr./To Party (allowed); Party Dr./To Discount Received A/c (received)</td></tr>
        <tr><td>Cheques-in-Hand A/c</td><td>Used only when a cheque received is NOT deposited the same day — Dr. on receipt, credited on deposit</td></tr>
        <tr><td>Post-dated cheque</td><td>Entered on the date actually deposited/issued, never on the future date printed on the cheque</td></tr>
        <tr><td>Discounting charges</td><td class="tnum">Amount × Rate% p.a. × Remaining period / 12</td></tr>
        <tr><td>Bank Overdraft</td><td>Amount withdrawn in excess of balance — a liability; shows as a credit balance in the bank column</td></tr>
        <tr><td>Petty Cash Book</td><td>Records small/petty payments only, kept by the Petty Cashier, usually under the Imprest System</td></tr>
        <tr><td>Imprest System</td><td>Fixed estimated amount given at period start; exact amount spent is reimbursed at period end</td></tr>
        <tr><td>Posting Petty Cash</td><td>Advance: Petty Cash A/c Dr./To Cash A/c. Submission: each Expense A/c Dr./To Petty Cash A/c</td></tr>
      </tbody>
    </table>

    <h3 style="margin:28px 0 12px; color:var(--c-sp2);">Chapter 6 — Special Purpose Books 2: Other Books</h3>
    <table class="ledger-table">
      <thead><tr><th>Element</th><th>Detail</th></tr></thead>
      <tbody>
        <tr><td>Purchases Book</td><td>Records only CREDIT purchases of goods dealt in or used for manufacturing — net of trade discount</td></tr>
        <tr><td>Sales Book</td><td>Records only CREDIT sales of goods dealt in — net of trade discount</td></tr>
        <tr><td>Purchases Return Book</td><td>Records return of goods purchased on credit — basis: Debit Note (prepared by the purchaser)</td></tr>
        <tr><td>Sales Return Book</td><td>Records return of goods sold on credit — basis: Credit Note (prepared by the seller)</td></tr>
        <tr><td>Journal Proper</td><td>Records everything that fits none of the other five books — Opening, Closing, Rectification, Transfer, Adjustment, and Miscellaneous entries</td></tr>
        <tr><td>Trade Discount treatment</td><td class="tnum">Net amount recorded = List Price − Trade Discount (never entered as its own figure)</td></tr>
        <tr><td>Freight/Packing on Purchases</td><td class="tnum">Cost column → Purchases A/c (Dr.); Freight/Packing column → own account (Dr.); Total → Seller's A/c (Cr.)</td></tr>
        <tr><td>Freight/Packing on Sales</td><td class="tnum">Sale Value column → Sales A/c (Cr.); Packing column → Packing Charges A/c (Cr.); Total → Buyer's A/c (Dr.)</td></tr>
        <tr><td>Purchases Book posting</td><td>Each supplier credited individually; periodic total debited to Purchases A/c</td></tr>
        <tr><td>Sales Book posting</td><td>Each customer debited individually; periodic total credited to Sales A/c</td></tr>
        <tr><td>Debit Note vs Credit Note</td><td>Debit Note — by purchaser, for Purchases Return Book. Credit Note — by seller, for Sales Return Book</td></tr>
        <tr><td>Return Books' ruling</td><td>Identical to Purchases/Sales Book, except "Invoice No." is replaced by "Debit/Credit Note No."</td></tr>
        <tr><td>Opening Entry pattern</td><td>Sundry Assets A/c Dr.; To Sundry Liabilities A/c; To Capital A/c</td></tr>
        <tr><td>Rule of thumb</td><td>What matters is what the RECORDING firm deals in — not what the counterparty intends to do with the goods</td></tr>
      </tbody>
    </table>

    <h3 style="margin:28px 0 12px; color:var(--c-brs);">Chapter 7 — Bank Reconciliation Statement (BRS)</h3>
    <table class="ledger-table">
      <thead><tr><th>Element</th><th>Detail</th></tr></thead>
      <tbody>
        <tr><td>BRS</td><td>A statement explaining, item by item, the difference between Balance as per Cash Book and Balance as per Pass Book, proving they agree once adjusted</td></tr>
        <tr><td>The one Add/Less rule</td><td class="tnum">Starting balance SHORT of target → Add. Starting balance AHEAD of target → Less.</td></tr>
        <tr><td>Format (from Cash Book)</td><td class="tnum">Balance as per Cash Book ± Items = Balance as per Pass Book</td></tr>
        <tr><td>Format (from Pass Book)</td><td class="tnum">Balance as per Pass Book ± Items = Balance as per Cash Book</td></tr>
        <tr><td>Opposite-direction rule</td><td>Every item's Add/Less treatment reverses when the starting balance is switched</td></tr>
        <tr><td>Cheque issued, not presented</td><td>Add (from Cash Book) / Less (from Pass Book)</td></tr>
        <tr><td>Cheque deposited, not collected</td><td>Less (from Cash Book) / Add (from Pass Book)</td></tr>
        <tr><td>Bank charges, not in Cash Book</td><td>Less (from Cash Book) / Add (from Pass Book)</td></tr>
        <tr><td>Interest allowed, not in Cash Book</td><td>Add (from Cash Book) / Less (from Pass Book)</td></tr>
        <tr><td>Direct collection by bank</td><td>Add (from Cash Book) / Less (from Pass Book)</td></tr>
        <tr><td>Direct payment by bank</td><td>Less (from Cash Book) / Add (from Pass Book)</td></tr>
        <tr><td>Dishonoured cheque, not in Cash Book</td><td>Less (from Cash Book) / Add (from Pass Book)</td></tr>
        <tr><td>Direct deposit by customer</td><td>Add (from Cash Book) / Less (from Pass Book)</td></tr>
        <tr><td>Receipts side undercast (Cash Book)</td><td>Add the shortfall (balance was understated)</td></tr>
        <tr><td>Payments side overcast (Cash Book)</td><td>Add the excess (balance was understated)</td></tr>
        <tr><td>Balance as per Pass Book, sign convention</td><td>Written from the bank's point of view — a favourable firm balance is a CREDIT there, the reverse of the Cash Book</td></tr>
      </tbody>
    </table>

    <h3 style="margin:28px 0 12px; color:var(--c-gst);">Chapter 8 — Accounting of GST</h3>
    <table class="ledger-table">
      <thead><tr><th>Element</th><th>Detail</th></tr></thead>
      <tbody>
        <tr><td>GST</td><td>Goods and Services Tax — a single, comprehensive, indirect, multi-stage, destination-based tax on the supply of goods and services</td></tr>
        <tr><td>GST Amount</td><td class="tnum">Taxable Value × GST Rate / 100</td></tr>
        <tr><td>Invoice Value</td><td class="tnum">Taxable Value + GST Amount</td></tr>
        <tr><td>Taxable Value (with trade discount)</td><td class="tnum">List Price − Trade Discount</td></tr>
        <tr><td>Trade discount rule</td><td>Always deducted from the list price BEFORE calculating GST — never calculate GST on the gross list price</td></tr>
        <tr><td>Freight — GST applicable</td><td>Add freight to the taxable value FIRST, then calculate GST on goods + freight together</td></tr>
        <tr><td>Freight — GST not applicable</td><td>Calculate GST on goods only; add freight to the invoice value afterwards</td></tr>
        <tr><td>Intra-state sale (same state)</td><td>CGST + SGST, split equally (e.g. 18% total = 9% CGST + 9% SGST)</td></tr>
        <tr><td>Inter-state sale (different states)</td><td>IGST — the full GST rate as a single tax, no CGST/SGST split</td></tr>
        <tr><td>Input GST</td><td>GST paid on purchases — claimable as credit</td></tr>
        <tr><td>Output GST</td><td>GST collected on sales — payable to the government</td></tr>
        <tr><td>Net GST Payable</td><td class="tnum">Output GST − Input GST</td></tr>
        <tr><td>Purchase entry (simple)</td><td class="tnum">Purchases A/c Dr., Input GST A/c Dr. → To Cash/Creditor's A/c</td></tr>
        <tr><td>Sale entry (simple)</td><td class="tnum">Cash/Debtor's A/c Dr. → To Sales A/c, To Output GST A/c</td></tr>
      </tbody>
    </table>

    <h3 style="margin:28px 0 12px; color:var(--c-tb);">Chapter 9 — Trial Balance</h3>
    <table class="ledger-table">
      <thead><tr><th>Element</th><th>Detail</th></tr></thead>
      <tbody>
        <tr><td>Trial Balance</td><td>A statement listing the balance of every ledger account as on a particular date, to check arithmetical accuracy</td></tr>
        <tr><td>Core rule</td><td class="tnum">Total Debit Balances = Total Credit Balances</td></tr>
        <tr><td>Balance Method — steps</td><td>Balance every ledger account → list each account's balance in the correct column → total both columns → compare</td></tr>
        <tr><td>Normally Debit balances</td><td>Assets, Expenses/Losses, Drawings (e.g. Cash, Machinery, Purchases, Wages, Bad Debts)</td></tr>
        <tr><td>Normally Credit balances</td><td>Liabilities, Capital, Incomes/Gains (e.g. Creditors, Capital, Sales, Commission Received)</td></tr>
        <tr><td>Errors NOT affecting agreement</td><td>Errors of omission, errors of principle, compensating errors, and certain errors of commission</td></tr>
        <tr><td>Errors that DO affect agreement</td><td>One-sided errors — wrong side posting, casting (totalling) errors, wrong balance carried forward</td></tr>
        <tr><td>Trial Balance agrees ≠</td><td>Conclusive proof of error-free books — it only confirms arithmetical accuracy, not complete correctness</td></tr>
      </tbody>
    </table>

    <h3 style="margin:28px 0 12px; color:var(--c-dep);">Chapter 10 — Depreciation</h3>
    <table class="ledger-table">
      <thead><tr><th>To find</th><th>Formula / Rule</th></tr></thead>
      <tbody>
        <tr><td>Depreciation (SLM)</td><td class="tnum">(Cost − Residual Value) ÷ Useful Life  —  or  —  (Cost − Residual Value) × Rate ÷ 100</td></tr>
        <tr><td>Depreciation (WDV) — for a year</td><td class="tnum">Opening Book Value × Rate ÷ 100</td></tr>
        <tr><td>Closing Book Value (WDV)</td><td class="tnum">Opening Book Value − Depreciation for the year</td></tr>
        <tr><td>Part-year depreciation</td><td class="tnum">Full-year Depreciation × (Months Used ÷ 12)</td></tr>
        <tr><td>Book Value (either method)</td><td class="tnum">Original Cost − Accumulated Depreciation to date</td></tr>
        <tr><td>Rate of Depreciation (from amount)</td><td class="tnum">(Annual Depreciation ÷ Cost or Opening Book Value) × 100</td></tr>
        <tr><td>Profit on Sale of Asset</td><td class="tnum">Sale Proceeds − Book Value  (when Sale Proceeds &gt; Book Value)</td></tr>
        <tr><td>Loss on Sale of Asset</td><td class="tnum">Book Value − Sale Proceeds  (when Book Value &gt; Sale Proceeds)</td></tr>
        <tr><td>Direct method — year-end entry</td><td class="tnum">Depreciation A/c Dr. → To Asset A/c</td></tr>
        <tr><td>Provision method — year-end entry</td><td class="tnum">Depreciation A/c Dr. → To Provision for Depreciation A/c</td></tr>
        <tr><td>Closing Depreciation A/c</td><td class="tnum">Profit &amp; Loss A/c Dr. → To Depreciation A/c</td></tr>
        <tr><td>Disposal — step 1 (transfer cost out)</td><td class="tnum">Asset Disposal A/c Dr. → To Asset A/c [Original Cost]</td></tr>
        <tr><td>Disposal — step 2 (transfer acc. depreciation out)</td><td class="tnum">Provision for Depreciation A/c Dr. → To Asset Disposal A/c [Accumulated Depreciation]</td></tr>
        <tr><td>Disposal — step 3 (record sale proceeds)</td><td class="tnum">Bank/Cash A/c Dr. → To Asset Disposal A/c [Sale Proceeds]</td></tr>
        <tr><td>Disposal — step 4 (profit)</td><td class="tnum">Asset Disposal A/c Dr. → To Profit on Sale of Asset A/c [Profit]</td></tr>
        <tr><td>Disposal — step 4 (loss)</td><td class="tnum">Loss on Sale of Asset A/c Dr. → To Asset Disposal A/c [Loss]</td></tr>
      </tbody>
    </table>
  `;
  root.appendChild(card);
  attachRipple(root);
  $("#printBtn").addEventListener("click", () => window.print());
}

/* ---------------------------------------------------------
   9. PERFORMANCE DASHBOARD
   --------------------------------------------------------- */
function renderPerformance(root) {
  const solved = Object.values(STATE.solved);
  const total = solved.length;
  const correct = solved.filter(s => s.correct).length;
  const accuracy = total ? Math.round((correct/total)*100) : 0;

  root.appendChild(el("div", "hero", `
    <span class="hero-eyebrow">You</span>
    <h1>Performance Dashboard</h1>
    <p>A running picture of how your practice is going, stored locally on this device.</p>
  `));

  const grid = el("div", "grid-4");
  grid.appendChild(statCard("check-circle", "Questions Solved", total, "All chapters"));
  grid.appendChild(statCard("percent", "Accuracy", accuracy + "%", "Correct on reveal"));
  grid.appendChild(statCard("flame", "Streak", STATE.streak + " days", "Consecutive"));
  grid.appendChild(statCard("sparkles", "Total XP", STATE.xp, "Current balance"));
  root.appendChild(grid);

  const xpGrid = el("div", "grid-3");
  xpGrid.style.marginTop = "14px";
  xpGrid.appendChild(statCard("trending-up", "XP Gained", STATE.xpGained || 0, "Lifetime, from correct answers"));
  xpGrid.appendChild(statCard("trending-down", "XP Deducted", STATE.xpDeducted || 0, "Lifetime, from incorrect answers"));
  xpGrid.appendChild(statCard("target", "Best Exam Score", (STATE.bestScores.exam || 0) + "%", "Exam Mode"));
  root.appendChild(xpGrid);

  root.appendChild(sectionTitle("Chapter progress"));
  const chCard = el("div", "card-solid", "");
  chCard.style.padding = "22px";
  APP_DATA.chapters.forEach(ch => {
    const pct = STATE.chapterProgress[ch.id] || 0;
    const row = el("div", "");
    row.style.cssText = "margin-bottom:16px;";
    row.innerHTML = `<div style="display:flex; justify-content:space-between; font-size:0.87rem; margin-bottom:6px;"><span>${ch.name}</span><span class="tnum">${pct}%</span></div><div class="progress-track"><div class="progress-fill" data-target="${pct}" style="width:0%"></div></div>`;
    chCard.appendChild(row);
  });
  root.appendChild(chCard);

  root.appendChild(sectionTitle("Badges earned"));
  const badgeGrid = el("div", "grid-4");
  const allBadges = { "first-solve":"First Solve", "ten-solved":"Ledger Apprentice", "fifty-solved":"Balance Keeper", "streak-3":"3-Day Streak", "xp-100":"Century Club", "mastered-eq":"Equation Mastered", "mastered-dc":"Debit & Credit Mastered", "mastered-jr":"Journal Mastered", "mastered-lg":"Ledger Mastered" };
  Object.entries(allBadges).forEach(([id, label]) => {
    const earned = STATE.badges.includes(id);
    const b = el("div", "card", "");
    b.style.cssText = `padding:18px; text-align:center; opacity:${earned ? 1 : 0.35};`;
    b.innerHTML = `<i data-lucide="award" style="width:24px;height:24px; color:var(--gold);"></i><p style="font-size:0.82rem; margin-top:8px; font-weight:600;">${label}</p>`;
    badgeGrid.appendChild(b);
  });
  root.appendChild(badgeGrid);

  renderMyCertificatesSection(root);
}

/* ---------------------------------------------------------
   10. SETTINGS
   --------------------------------------------------------- */
function renderNotifSettingsHTML() {
  const HOURS = [6, 7, 8, 9, 10, 16, 17, 18, 19, 20, 21];
  const hourLabel = (h) => { const period = h < 12 ? "AM" : "PM"; const h12 = h % 12 === 0 ? 12 : h % 12; return `${h12}:00 ${period}`; };

  if (!pushSupported()) {
    return `
      <label>Daily Learning Notifications</label>
      <p style="font-size:0.82rem; color:var(--ink-faint); margin:6px 0 0;">This browser doesn't support push notifications. Try a recent Chrome, Edge, or Safari (16.4+) on your phone or desktop.</p>
    `;
  }
  if (Notification.permission === "denied") {
    return `
      <label>Daily Learning Notifications</label>
      <p style="font-size:0.85rem; color:var(--flag); margin:6px 0 0;">Notifications are blocked for this site in your browser settings.</p>
      <p style="font-size:0.78rem; color:var(--ink-faint); margin:6px 0 0;">To re-enable: open your browser's site settings for this page (tap the lock/info icon in the address bar, or Site settings on mobile) and set Notifications to Allow, then reload.</p>
    `;
  }
  return `
    <label>Daily Learning Notifications</label>
    <div style="display:flex; align-items:center; gap:10px; flex-wrap:wrap; margin-top:2px;">
      <button class="chip ${STATE.notificationsEnabled ? 'active' : ''}" id="notifToggleBtn">
        <i data-lucide="${STATE.notificationsEnabled ? 'bell-ring' : 'bell-off'}" style="width:14px;height:14px;"></i>
        ${STATE.notificationsEnabled ? "On" : "Off"}
      </button>
      ${STATE.notificationsEnabled ? `
        <select id="notifHourSelect" style="padding:8px 10px; border-radius:var(--radius-sm); border:1.5px solid var(--line-strong); background:var(--paper); color:var(--ink); font-family:var(--font-body); font-size:0.85rem;">
          ${HOURS.map(h => `<option value="${h}" ${STATE.notifyHour === h ? "selected" : ""}>${hourLabel(h)}</option>`).join("")}
        </select>
        <button class="btn-ghost sm ripple-surface" id="notifTestBtn" type="button"><i data-lucide="send"></i> Send Test Notification</button>
      ` : ""}
    </div>
    <p style="font-size:0.78rem; color:var(--ink-faint); margin:8px 0 0;">One short reminder a day, delivered even if the site is closed — arrives within the hour you choose (times shown in your device's local time zone). Turn off any time.</p>
  `;
}

function renderSettings(root) {
  root.appendChild(el("div", "hero", `
    <span class="hero-eyebrow">You</span>
    <h1>Settings</h1>
    <p>Control theme, accessibility, sound, and your saved progress.</p>
  `));

  const card = el("div", "card-solid", "");
  card.style.padding = "26px";
  card.innerHTML = `
    <div class="field-group">
      <label>Profile</label>
      <div class="profile-name-row">
        <input type="text" id="profileNameInput" maxlength="40" placeholder="Your name" value="${STATE.userName ? escapeHtml(STATE.userName) : ''}">
        <button class="btn-primary sm ripple-surface" id="saveNameBtn"><i data-lucide="check"></i> Save</button>
        <button class="btn-ghost sm ripple-surface" id="clearNameBtn"><i data-lucide="user-x"></i> Clear profile</button>
      </div>
      <p style="font-size:0.78rem; color:var(--ink-faint); margin:8px 0 0;">Your name only personalizes greetings — it never leaves this device. Changing or clearing it does not touch your XP, streak, or progress.</p>
    </div>
    <div class="field-group" id="notifFieldGroup">
      ${renderNotifSettingsHTML()}
    </div>
    <div class="field-group">
      <label>Theme</label>
      <div style="display:flex; gap:8px;">
        <button class="chip ${STATE.theme==='light'?'active':''}" data-set="theme-light">Light</button>
        <button class="chip ${STATE.theme==='dark'?'active':''}" data-set="theme-dark">Dark</button>
      </div>
    </div>
    <div class="field-group">
      <label>Color theme</label>
      <div class="theme-swatch-row" id="themeSwatchRow">
        ${["classic","ocean","forest","sunset","slate","rose"].map(ct => `
          <button class="theme-swatch swatch-${ct} ${STATE.colorTheme===ct?'active':''}" data-ctheme="${ct}" title="${ct.charAt(0).toUpperCase()+ct.slice(1)}"></button>
        `).join("")}
      </div>
    </div>
    <div class="field-group">
      <label>Font size</label>
      <div style="display:flex; gap:8px;">
        <button class="chip ${STATE.fontScale===0.9?'active':''}" data-set="font-0.9">Small</button>
        <button class="chip ${STATE.fontScale===1?'active':''}" data-set="font-1">Default</button>
        <button class="chip ${STATE.fontScale===1.15?'active':''}" data-set="font-1.15">Large</button>
      </div>
    </div>
    <div class="field-group">
      <label>Accessibility</label>
      <div style="display:flex; gap:8px; flex-wrap:wrap;">
        <button class="chip ${STATE.highContrast?'active':''}" data-set="contrast">High contrast</button>
        <button class="chip ${STATE.colorblind?'active':''}" data-set="colorblind">Color-blind mode</button>
        <button class="chip ${STATE.reduceMotion?'active':''}" data-set="motion">Reduce motion</button>
      </div>
    </div>
    <div class="field-group">
      <label>Sound</label>
      <div style="display:flex; gap:8px; align-items:center;">
        <button class="chip ${STATE.soundOn?'active':''}" data-set="sound">${STATE.soundOn?'On':'Off'}</button>
        <button class="btn-ghost sm" id="testSoundBtn" type="button"><i data-lucide="volume-2"></i> Test sound</button>
      </div>
      <p style="font-size:0.78rem; color:var(--ink-faint); margin:6px 0 0;">Plays a short click on every button and chip, plus a chime when the app opens. Off by default the first time this device visits the site.</p>
    </div>
    <div class="ledger-rule" style="margin-top:20px;">
      <label style="font-size:0.82rem; font-weight:600; color:var(--ink-soft); display:block; margin-bottom:10px;">Progress data</label>
      <div style="display:flex; gap:10px; flex-wrap:wrap;">
        <button class="btn-ghost sm" id="exportBtn"><i data-lucide="download"></i> Export progress</button>
        <button class="btn-ghost sm" id="importBtn"><i data-lucide="upload"></i> Import progress</button>
        <button class="btn-danger sm" id="resetProgressBtn"><i data-lucide="trash-2"></i> Reset progress</button>
      </div>
      <p style="font-size:0.78rem; color:var(--ink-faint); margin:8px 0 0;">Clears XP, streak, chapter progress, quiz/exam history, bookmarks, and AI Tutor chats — but keeps your name, theme, font size, and accessibility settings.</p>
      <input type="file" id="importFile" hidden accept="application/json">
    </div>
    <div class="ledger-rule" style="margin-top:16px;">
      <label style="font-size:0.82rem; font-weight:600; color:var(--ink-soft); display:block; margin-bottom:10px;">Preferences</label>
      <div style="display:flex; gap:10px; flex-wrap:wrap;">
        <button class="btn-danger sm" id="resetSettingsBtn"><i data-lucide="rotate-ccw"></i> Reset settings to default</button>
      </div>
      <p style="font-size:0.78rem; color:var(--ink-faint); margin:8px 0 0;">Restores theme, color theme, font size, accessibility, and sound to their defaults — your name, XP, progress, and AI chats are untouched.</p>
    </div>
    <div class="ledger-rule" style="margin-top:16px;">
      <label style="font-size:0.82rem; font-weight:600; color:var(--flag); display:block; margin-bottom:10px;">Danger zone</label>
      <div style="display:flex; gap:10px; flex-wrap:wrap;">
        <button class="btn-danger sm" id="resetAllBtn"><i data-lucide="alert-triangle"></i> Reset all data</button>
      </div>
      <p style="font-size:0.78rem; color:var(--ink-faint); margin:8px 0 0;">Deletes everything this site has stored on this device — your name, progress, and settings — and shows the welcome screen again next visit.</p>
    </div>
  `;
  root.appendChild(card);

  $("#saveNameBtn").addEventListener("click", () => {
    const val = $("#profileNameInput").value.trim();
    STATE.userName = val ? val.slice(0, 40) : null;
    if (!STATE.onboardedAt) STATE.onboardedAt = Date.now();
    saveState();
    toast(val ? `Saved — hi, ${firstName()}!` : "Name cleared", "success", "user-check");
  });
  $("#clearNameBtn").addEventListener("click", () => {
    if (!confirm("Clear your saved name? Your progress will not be affected.")) return;
    STATE.userName = null;
    saveState();
    $("#profileNameInput").value = "";
    toast("Profile name cleared", "success", "user-x");
  });

  function refreshNotifUI() {
    $("#notifFieldGroup").innerHTML = renderNotifSettingsHTML();
    icons();
    wireNotifUI();
  }
  function wireNotifUI() {
    const toggleBtn = $("#notifToggleBtn");
    if (toggleBtn) toggleBtn.addEventListener("click", async () => {
      toggleBtn.disabled = true;
      if (STATE.notificationsEnabled) {
        await unsubscribeFromPush();
        toast("Daily notifications turned off", "success", "bell-off");
      } else {
        const ok = await subscribeToPush();
        if (ok) toast("Daily reminders are on 🔔", "success", "bell-ring");
      }
      refreshNotifUI();
    });
    const hourSelect = $("#notifHourSelect");
    if (hourSelect) hourSelect.addEventListener("change", async () => {
      STATE.notifyHour = parseInt(hourSelect.value, 10);
      saveState();
      if (STATE.notificationsEnabled) await subscribeToPush(); // re-save with new hour
      toast("Notification time updated", "success", "clock");
    });
    const testBtn = $("#notifTestBtn");
    if (testBtn) testBtn.addEventListener("click", () => sendTestPush());
  }
  wireNotifUI();

  card.addEventListener("click", e => {
    const swatch = e.target.closest("button[data-ctheme]");
    if (swatch) {
      STATE.colorTheme = swatch.dataset.ctheme;
      saveState(); applyTheme();
      $all(".theme-swatch", $("#themeSwatchRow")).forEach(s => s.classList.toggle("active", s.dataset.ctheme === STATE.colorTheme));
      toast(`Theme set to ${STATE.colorTheme}`, "success", "palette");
      return;
    }
    const btn = e.target.closest("button[data-set]");
    if (!btn) return;
    const [key, val] = btn.dataset.set.split("-");
    if (key === "theme") STATE.theme = val;
    if (key === "font") STATE.fontScale = parseFloat(val);
    if (btn.dataset.set === "contrast") STATE.highContrast = !STATE.highContrast;
    if (btn.dataset.set === "colorblind") STATE.colorblind = !STATE.colorblind;
    if (btn.dataset.set === "motion") STATE.reduceMotion = !STATE.reduceMotion;
    if (btn.dataset.set === "sound") STATE.soundOn = !STATE.soundOn;
    saveState(); applyTheme(); renderSettings(root.parentElement ? root : root);
    renderRoute();
  });

  $("#testSoundBtn").addEventListener("click", () => {
    if (!STATE.soundOn) { toast("Turn sound on first", "error", "volume-x"); return; }
    playSuccessSound();
  });

  $("#exportBtn").addEventListener("click", () => {
    const blob = new Blob([JSON.stringify(STATE, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "accountancy-progress.json"; a.click();
    URL.revokeObjectURL(url);
    toast("Progress exported", "success", "download");
  });
  $("#importBtn").addEventListener("click", () => $("#importFile").click());
  $("#importFile").addEventListener("change", e => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(reader.result);
        STATE = Object.assign(structuredClone(defaultState), parsed);
        saveState(); applyTheme(); renderRoute();
        toast("Progress imported", "success", "upload");
      } catch (err) { toast("Invalid file", "error", "alert-triangle"); }
    };
    reader.readAsText(file);
  });
  $("#resetProgressBtn").addEventListener("click", () => {
    if (!confirm("Reset all progress? This clears XP, streak, chapter progress, quiz/exam history, bookmarks, and AI Tutor chats. This cannot be undone.")) return;
    const keepSettings = {
      theme: STATE.theme, colorTheme: STATE.colorTheme, fontScale: STATE.fontScale,
      colorblind: STATE.colorblind, highContrast: STATE.highContrast, reduceMotion: STATE.reduceMotion, soundOn: STATE.soundOn,
      userName: STATE.userName, onboardedAt: STATE.onboardedAt,
      notificationsEnabled: STATE.notificationsEnabled, notifyHour: STATE.notifyHour, notificationsPromptDismissed: STATE.notificationsPromptDismissed
    };
    STATE = Object.assign(structuredClone(defaultState), keepSettings);
    saveState(); applyTheme(); renderRoute();
    toast("Progress reset", "success", "trash-2");
  });

  $("#resetAllBtn").addEventListener("click", async () => {
    if (!confirm("Reset ALL data on this device? This deletes your name, progress, and settings, and cannot be undone.")) return;
    await unsubscribeFromPush();
    STATE = structuredClone(defaultState);
    saveState(); applyTheme(); renderRoute();
    toast("All data reset", "success", "alert-triangle");
    showWelcomeModal();
  });

  $("#resetSettingsBtn").addEventListener("click", () => {
    if (!confirm("Reset theme, font size, accessibility, and sound to defaults? Your progress and AI chats will not be affected.")) return;
    STATE.theme = defaultState.theme;
    STATE.colorTheme = defaultState.colorTheme;
    STATE.fontScale = defaultState.fontScale;
    STATE.colorblind = defaultState.colorblind;
    STATE.highContrast = defaultState.highContrast;
    STATE.reduceMotion = defaultState.reduceMotion;
    STATE.soundOn = defaultState.soundOn;
    saveState(); applyTheme(); renderRoute();
    toast("Settings reset to default", "success", "rotate-ccw");
  });
}

/* ---------------------------------------------------------
   11. STUB VIEWS — Chapters 2 & 3 and remaining practice
       modes are architected (routes, nav, data schema) but
       content is not yet fully populated in this pass.
   --------------------------------------------------------- */
function comingSoonView(root, title, eyebrow, desc) {
  root.appendChild(el("div", "hero", `
    <span class="hero-eyebrow">${eyebrow}</span>
    <h1>${title}</h1>
    <p>${desc}</p>
  `));
  const card = el("div", "card-solid", "");
  card.style.cssText = "padding:40px; text-align:center;";
  card.innerHTML = `
    <i data-lucide="construction" style="width:36px;height:36px; color:var(--gold); margin-bottom:14px;"></i>
    <h3 style="margin-bottom:8px;">Being built next</h3>
    <p style="color:var(--ink-soft); font-size:0.9rem; max-width:440px; margin:0 auto 18px;">
      All ten chapters — Accounting Equation, Rules of Debit &amp; Credit, Journal, Ledger, Special Purpose Books 1 - Cash Book, Special Purpose Books 2 - Other Books, Bank Reconciliation Statement (BRS), Accounting of GST, Trial Balance, and Depreciation — are fully live with theory, concepts, and practice banks, plus cross-chapter Flashcards and Quiz.
      This section follows the same structure and is next in line to be filled in.
    </p>
    <button class="btn-primary ripple-surface" onclick="navigate('ch-eq')"><i data-lucide="arrow-left"></i> Go to Chapter 1</button>
  `;
  root.appendChild(card);
  attachRipple(root);
}

/* ---------------------------------------------------------
   11b. IMPORTANT QUESTIONS — board-pattern practice
   --------------------------------------------------------- */
let iqState = { chapter: "all", type: "All" };

function renderImportantQuestions(root) {
  root.appendChild(el("div", "hero", `
    <span class="hero-eyebrow">Revision</span>
    <h1>Important Questions</h1>
    <p>Board-pattern questions across Short Answer, Long Answer, Case-Based, and Assertion-Reason formats, drawn from all ten chapters.</p>
    <button class="btn-primary ripple-surface" id="iqPrintBtn" style="margin-top:10px;"><i data-lucide="printer"></i> Print / Save as PDF</button>
  `));

  const chFilterBar = el("div", "", "");
  chFilterBar.style.cssText = "display:flex; gap:8px; flex-wrap:wrap; margin-bottom:10px;";
  [["all","All Chapters"],["eq","Ch.1 Equation"],["dc","Ch.2 Debit & Credit"],["jr","Ch.3 Journal"],["lg","Ch.4 Ledger"],["cb","Ch.5 Cash Book"],["sp2","Ch.6 Other Books"],["brs","Ch.7 BRS"],["gst","Ch.8 GST"],["tb","Ch.9 Trial Balance"],["dep","Ch.10 Depreciation"]].forEach(([id,label]) => {
    const chip = el("button", `chip ${iqState.chapter === id ? "active" : ""}`, label);
    chip.addEventListener("click", () => { iqState.chapter = id; renderIQList(list); });
    chFilterBar.appendChild(chip);
  });
  root.appendChild(chFilterBar);

  const typeFilterBar = el("div", "", "");
  typeFilterBar.style.cssText = "display:flex; gap:8px; flex-wrap:wrap; margin-bottom:20px;";
  ["All", "Short Answer", "Long Answer", "Case-Based", "Assertion-Reason"].forEach(t => {
    const chip = el("button", `chip ${iqState.type === t ? "active" : ""}`, t);
    chip.addEventListener("click", () => { iqState.type = t; renderIQList(list); });
    typeFilterBar.appendChild(chip);
  });
  root.appendChild(typeFilterBar);

  const list = el("div", "");
  root.appendChild(list);
  renderIQList(list);

  attachRipple(root);
  $("#iqPrintBtn").addEventListener("click", () => window.print());
}

function renderIQList(list) {
  list.innerHTML = "";
  const chLabel = { eq: "Ch.1 Equation", dc: "Ch.2 Debit & Credit", jr: "Ch.3 Journal", lg: "Ch.4 Ledger", cb: "Ch.5 Cash Book", sp2: "Ch.6 Other Books", brs: "Ch.7 BRS", gst: "Ch.8 GST", tb: "Ch.9 Trial Balance", dep: "Ch.10 Depreciation" };
  const chColor = { eq: "var(--c-eq)", dc: "var(--c-dc)", jr: "var(--c-jr)", lg: "var(--c-lg)", cb: "var(--c-cb)", sp2: "var(--c-sp2)", brs: "var(--c-brs)", gst: "var(--c-gst)", tb: "var(--c-tb)", dep: "var(--c-dep)" };
  const chapters = iqState.chapter === "all" ? ["eq", "dc", "jr", "lg", "cb", "sp2", "brs", "gst", "tb", "dep"] : [iqState.chapter];

  let items = [];
  chapters.forEach(ch => {
    (APP_DATA.importantQuestions[ch] || []).forEach((q, i) => items.push({ ...q, chapter: ch, idx: i }));
  });
  if (iqState.type !== "All") items = items.filter(q => q.type === iqState.type);

  const countLabel = el("p", "", `Showing ${items.length} question${items.length === 1 ? "" : "s"}`);
  countLabel.style.cssText = "font-size:0.83rem; color:var(--ink-faint); margin-bottom:16px;";
  list.appendChild(countLabel);

  if (!items.length) {
    list.appendChild(el("p", "", `<span style="color:var(--ink-faint);">No questions match this filter.</span>`));
    return;
  }

  items.forEach(q => {
    const key = `iq-${q.chapter}-${q.idx}`;
    const card = el("div", "card q-card", "");
    card.innerHTML = `
      <div class="q-meta">
        <span class="diff-badge" style="background:${chColor[q.chapter]}22; color:${chColor[q.chapter]};">${chLabel[q.chapter]}</span>
        <span class="diff-badge" style="background:var(--gold-soft); color:var(--gold);">${q.type}</span>
        <span class="q-id">${q.marks} mark${q.marks === 1 ? "" : "s"}</span>
        <button class="icon-btn sm" data-act="bookmark" style="margin-left:auto;" title="Bookmark"><i data-lucide="${STATE.bookmarks.includes(key) ? 'bookmark-check' : 'bookmark'}"></i></button>
      </div>
      <div class="q-body">${q.q}</div>
      <div class="q-actions">
        <button class="btn-primary sm ripple-surface" data-act="answer"><i data-lucide="eye"></i> Show Answer</button>
      </div>
      <div class="reveal-area"></div>
    `;
    const revealArea = $(".reveal-area", card);
    card.addEventListener("click", (e) => {
      const btn = e.target.closest("button[data-act]");
      if (!btn) return;
      if (btn.dataset.act === "answer") {
        revealArea.innerHTML = `<div class="reveal-block"><h4>Model answer</h4><p style="font-size:0.88rem; line-height:1.65;">${q.answer}</p></div>`;
        if (!STATE.solved[key]) {
          STATE.solved[key] = { correct: true, attempts: 1 };
          saveState();
          addXP(3, `Reviewed an important question`);
          logActivity(`Reviewed a ${q.type} question (${chLabel[q.chapter]})`);
        }
      }
      if (btn.dataset.act === "bookmark") {
        const idx = STATE.bookmarks.indexOf(key);
        if (idx >= 0) { STATE.bookmarks.splice(idx, 1); btn.querySelector("i").setAttribute("data-lucide", "bookmark"); }
        else { STATE.bookmarks.push(key); btn.querySelector("i").setAttribute("data-lucide", "bookmark-check"); }
        saveState(); icons();
      }
      icons();
    });
    list.appendChild(card);
  });
  applyMobilePager(list);
  icons();
}

/* ---------------------------------------------------------
   11c. EXAM MODE — a timed, distraction-free mixed paper
   --------------------------------------------------------- */
let examState = { active: false, config: null, questions: [], index: 0, answers: [], startTime: null, secondsLeft: 0, timerId: null, submitted: false };

const EXAM_DURATIONS = { 15: 15 * 60, 30: 30 * 60, 60: 60 * 60 };
// Human-readable coverage labels reused by the Google Sheet sync
// payload so the "chapters" field matches what the student actually
// picked in Exam Setup, without recomputing anything.
const EXAM_COVERAGE_LABELS = {
  all: "All Chapters (Ch.1–Ch.10)",
  eq: "Ch.1 — Accounting Equation",
  dc: "Ch.2 — Debit & Credit",
  jr: "Ch.3 — Journal",
  lg: "Ch.4 — Ledger",
  cb: "Ch.5 — Special Purpose Books 1 - Cash Book",
  sp2: "Ch.6 — Special Purpose Books 2 - Other Books",
  brs: "Ch.7 — Bank Reconciliation Statement (BRS)",
  gst: "Ch.8 — Accounting of GST",
  tb: "Ch.9 — Trial Balance",
  dep: "Ch.10 — Depreciation",
};

function renderExamMode(root) {
  if (examState.active) { renderExamActive(root); return; }
  if (examState.submitted) { renderExamResults(root); return; }
  renderExamSetup(root);
}

function renderExamSetup(root) {
  root.appendChild(el("div", "hero", `
    <span class="hero-eyebrow">Revision</span>
    <h1>Exam Mode</h1>
    <p>A timed, distraction-free run through a mixed paper drawn from the quiz and numerical banks across all ten chapters. The sidebar and topbar stay out of the way while you work.</p>
  `));

  // Highlighted, hard-to-miss callout: completing a Full Syllabus
  // ("All chapters") paper is what actually unlocks the certificate —
  // students should see this before they even pick their settings.
  const certBanner = el("div", "", "");
  certBanner.style.cssText = "display:flex; align-items:flex-start; gap:14px; padding:18px 20px; margin-bottom:20px; border-radius:14px; background:linear-gradient(135deg, var(--gold-soft), var(--paper-raised)); border:1.5px solid var(--gold);";
  certBanner.innerHTML = `
    <i data-lucide="award" style="width:26px; height:26px; color:var(--gold); flex-shrink:0; margin-top:2px;"></i>
    <div>
      <div style="font-family:var(--font-head); font-weight:700; font-size:1rem; color:var(--gold-ink, var(--ink)); margin-bottom:4px;">Earn a Digital Certificate</div>
      <p style="font-size:0.88rem; line-height:1.6; color:var(--ink-soft); margin:0;">Take the exam with <b>All chapters</b> selected below, and completing it unlocks a personal <b>Digital Certificate of Achievement</b> — printed with your own name, your grade, and your score — ready to download, print, or share.</p>
    </div>
  `;
  root.appendChild(certBanner);

  const card = el("div", "card-solid", "");
  card.style.padding = "28px";
  card.innerHTML = `
    <div class="field-group">
      <label>Duration</label>
      <div style="display:flex; gap:8px;">
        <button class="chip" data-dur="15">15 minutes</button>
        <button class="chip active" data-dur="30">30 minutes</button>
        <button class="chip" data-dur="60">60 minutes</button>
      </div>
    </div>
    <div class="field-group">
      <label>Coverage</label>
      <div style="display:flex; gap:8px; flex-wrap:wrap;">
        <button class="chip active" data-cov="all">All chapters</button>
        <button class="chip" data-cov="eq">Ch.1 only</button>
        <button class="chip" data-cov="dc">Ch.2 only</button>
        <button class="chip" data-cov="jr">Ch.3 only</button>
        <button class="chip" data-cov="lg">Ch.4 only</button>
        <button class="chip" data-cov="cb">Ch.5 only</button>
        <button class="chip" data-cov="sp2">Ch.6 only</button>
        <button class="chip" data-cov="brs">Ch.7 only</button>
        <button class="chip" data-cov="gst">Ch.8 only</button>
        <button class="chip" data-cov="tb">Ch.9 only</button>
        <button class="chip" data-cov="dep">Ch.10 only</button>
      </div>
      <p id="examCertEligibilityNote" style="font-size:0.8rem; margin-top:10px; display:flex; align-items:center; gap:6px;"></p>
    </div>
    <div class="field-group">
      <label>Question count</label>
      <div style="display:flex; gap:8px;">
        <button class="chip" data-count="10">10 questions</button>
        <button class="chip active" data-count="20">20 questions</button>
        <button class="chip" data-count="30">30 questions</button>
      </div>
    </div>
    <button class="btn-primary ripple-surface" id="examStartBtn" style="width:100%; margin-top:10px; padding:14px;"><i data-lucide="play"></i> Start Exam</button>
    <p style="font-size:0.8rem; color:var(--ink-faint); margin-top:12px;">Questions are drawn from the Quiz bank (multiple choice), spread evenly across all ten chapters. The exam ends automatically when time runs out — whatever's answered by then is submitted.</p>
  `;
  root.appendChild(card);

  let cfg = { duration: 30, coverage: "all", count: 20 };
  function updateCertEligibilityNote() {
    const note = $("#examCertEligibilityNote", card);
    if (!note) return;
    if (cfg.coverage === "all") {
      note.style.color = "var(--gold-ink, var(--gold))";
      note.innerHTML = `<i data-lucide="check-circle" style="width:14px;height:14px;"></i> This paper qualifies for a Digital Certificate.`;
    } else {
      note.style.color = "var(--ink-faint)";
      note.innerHTML = `<i data-lucide="info" style="width:14px;height:14px;"></i> Single-chapter practice papers don't earn a certificate — choose "All chapters" to qualify.`;
    }
    icons();
  }
  card.addEventListener("click", (e) => {
    const durBtn = e.target.closest("[data-dur]");
    const covBtn = e.target.closest("[data-cov]");
    const countBtn = e.target.closest("[data-count]");
    if (durBtn) { cfg.duration = parseInt(durBtn.dataset.dur); $all("[data-dur]", card).forEach(b => b.classList.toggle("active", b === durBtn)); }
    if (covBtn) { cfg.coverage = covBtn.dataset.cov; $all("[data-cov]", card).forEach(b => b.classList.toggle("active", b === covBtn)); updateCertEligibilityNote(); }
    if (countBtn) { cfg.count = parseInt(countBtn.dataset.count); $all("[data-count]", card).forEach(b => b.classList.toggle("active", b === countBtn)); }
  });
  updateCertEligibilityNote();

  $("#examStartBtn").addEventListener("click", () => startExam(cfg));
  attachRipple(root);
}

// For "All chapters" coverage, drawing a straight random slice from the
// combined quiz bank would skew heavily toward whichever chapters happen
// to have the most questions (Cash Book and Journal currently have far
// more than Accounting Equation, Debit & Credit, or Ledger). This draws
// round-robin across all five chapters instead, so every chapter gets a
// fair share of the paper regardless of how large its own question bank
// is — falling back to whatever's left if a chapter's pool runs dry
// before the target count is reached.
function buildExamQuestionPool(coverage, count) {
  if (coverage !== "all") {
    const pool = APP_DATA.quiz.filter(q => q.chapter === coverage);
    return fisherYatesShuffle(pool).slice(0, Math.min(count, pool.length));
  }
  const chapters = ["eq", "dc", "jr", "lg", "cb", "sp2", "brs", "gst", "tb", "dep"];
  const perChapterPools = {};
  chapters.forEach(ch => { perChapterPools[ch] = fisherYatesShuffle(APP_DATA.quiz.filter(q => q.chapter === ch)); });
  const picked = [];
  let round = 0;
  while (picked.length < count) {
    let tookAny = false;
    for (let k = 0; k < chapters.length && picked.length < count; k++) {
      const ch = chapters[(round + k) % chapters.length];
      if (perChapterPools[ch].length) { picked.push(perChapterPools[ch].shift()); tookAny = true; }
    }
    round++;
    if (!tookAny) break; // every chapter's pool is exhausted
  }
  return fisherYatesShuffle(picked); // re-shuffle so the round-robin draw order isn't visible
}

function startExam(cfg) {
  const picked = buildExamQuestionPool(cfg.coverage, cfg.count);
  examState.questions = picked.map(shuffleQuizOptions);
  examState.answers = new Array(examState.questions.length).fill(null);
  examState.index = 0;
  examState.active = true;
  examState.submitted = false;
  examState.config = cfg;
  examState.secondsLeft = EXAM_DURATIONS[cfg.duration];
  examState.startTime = Date.now();
  clearInterval(examState.timerId);
  examState.timerId = setInterval(() => {
    examState.secondsLeft--;
    const t = $("#examTimerDisplay");
    if (t) t.textContent = formatExamTime(examState.secondsLeft);
    if (examState.secondsLeft <= 0) { submitExam(); }
  }, 1000);
  renderRoute();
}

function formatExamTime(s) {
  const m = String(Math.floor(Math.max(0, s) / 60)).padStart(2, "0");
  const sec = String(Math.max(0, s) % 60).padStart(2, "0");
  return `${m}:${sec}`;
}

function renderExamActive(root) {
  const q = examState.questions[examState.index];
  if (!q) { submitExam(); return; }

  const bar = el("div", "", "");
  bar.style.cssText = "display:flex; justify-content:space-between; align-items:center; margin-bottom:18px; flex-wrap:wrap; gap:10px;";
  bar.innerHTML = `
    <div style="display:flex; align-items:center; gap:10px;">
      <span style="font-family:var(--font-head); font-weight:700; font-size:1.1rem;">Exam Mode</span>
      <span class="diff-badge" style="background:var(--flag-soft); color:var(--flag);"><i data-lucide="timer" style="width:12px;height:12px; vertical-align:-1px;"></i> <span id="examTimerDisplay" class="tnum">${formatExamTime(examState.secondsLeft)}</span></span>
    </div>
    <button class="btn-danger sm" id="examQuitBtn"><i data-lucide="log-out"></i> End exam</button>
  `;
  root.appendChild(bar);

  // Question palette for jumping between questions — this is the
  // "back to previous question" affordance for Exam Mode specifically.
  const palette = el("div", "", "");
  palette.style.cssText = "display:flex; gap:6px; flex-wrap:wrap; margin-bottom:20px;";
  examState.questions.forEach((_, i) => {
    const answered = examState.answers[i] !== null;
    const b = el("button", "", String(i + 1));
    b.style.cssText = `width:32px; height:32px; border-radius:8px; border:1.5px solid ${i === examState.index ? "var(--gold)" : "var(--line-strong)"}; background:${answered ? "var(--c-eq-soft)" : "var(--paper-raised)"}; color:${answered ? "var(--c-eq)" : "var(--ink-soft)"}; font-family:var(--font-mono); font-size:0.78rem; cursor:pointer;`;
    b.addEventListener("click", () => { examState.index = i; renderRoute(); });
    palette.appendChild(b);
  });
  root.appendChild(palette);

  const card = el("div", "card-solid", "");
  card.style.padding = "26px";
  const priorAnswer = examState.answers[examState.index];
  const chColor = { eq: "var(--c-eq)", dc: "var(--c-dc)", jr: "var(--c-jr)", lg: "var(--c-lg)", cb: "var(--c-cb)", sp2: "var(--c-sp2)", brs: "var(--c-brs)", gst: "var(--c-gst)", tb: "var(--c-tb)", dep: "var(--c-dep)" }[q.chapter];
  card.innerHTML = `
    <div style="display:flex; justify-content:space-between; margin-bottom:14px;">
      <span class="diff-badge ${q.difficulty}">${q.difficulty}</span>
      <span style="font-size:0.83rem; color:var(--ink-faint);">Question ${examState.index + 1} of ${examState.questions.length}</span>
    </div>
    <h3 style="font-size:1.02rem; margin-bottom:18px; line-height:1.5;">${q.q}</h3>
    <div id="examOptions"></div>
    <div style="display:flex; justify-content:space-between; margin-top:20px; gap:10px;">
      <button class="btn-ghost ripple-surface" id="examPrevBtn" ${examState.index === 0 ? "disabled" : ""}><i data-lucide="arrow-left"></i> Previous</button>
      <button class="btn-primary ripple-surface" id="examNextBtn">${examState.index === examState.questions.length - 1 ? "Review & Submit" : "Next"} <i data-lucide="arrow-right"></i></button>
    </div>
  `;
  root.appendChild(card);

  const optWrap = $("#examOptions", card);
  q.options.forEach((opt, i) => {
    const b = el("button", "chip ripple-surface", opt);
    b.style.cssText = `display:block; width:100%; text-align:left; margin-bottom:8px; padding:12px 14px; border-radius:12px; ${priorAnswer === i ? "border-color:var(--gold); background:var(--gold-soft);" : ""}`;
    b.addEventListener("click", () => {
      // Guard against a rapid double-click firing this twice and
      // auto-advancing two questions at once.
      if (optWrap.dataset.locked === "1") return;
      optWrap.dataset.locked = "1";
      examState.answers[examState.index] = i;
      const isLastQuestion = examState.index === examState.questions.length - 1;
      $all("#examOptions .chip", card).forEach((el2, idx) => {
        el2.style.borderColor = idx === i ? "var(--gold)" : "var(--line-strong)";
        el2.style.background = idx === i ? "var(--gold-soft)" : "var(--paper-raised)";
        el2.style.opacity = idx === i ? "1" : "0.55";
        el2.disabled = true;
      });
      // On every question except the last, move on automatically —
      // no separate "Next" click needed. The last question stays put
      // so the student can still use the palette/Previous to double-check
      // earlier answers before hitting "Review & Submit" themselves.
      if (!isLastQuestion) {
        setTimeout(() => { examState.index++; renderRoute(); }, 380);
      }
    });
    optWrap.appendChild(b);
  });

  icons();
  $("#examPrevBtn").addEventListener("click", () => { if (examState.index > 0) { examState.index--; renderRoute(); } });
  $("#examNextBtn").addEventListener("click", () => {
    if (examState.index < examState.questions.length - 1) { examState.index++; renderRoute(); }
    else { submitExam(); }
  });
  $("#examQuitBtn").addEventListener("click", () => {
    if (confirm("End the exam now? Your answers so far will be submitted.")) submitExam();
  });
}

function submitExam() {
  clearInterval(examState.timerId);
  examState.active = false;
  examState.submitted = true;
  renderRoute();
}

// Reflects the REAL state of the Google Sheet sync — never claims
// "saved" while the request is still in flight or after it failed.
// "sent" only means the request was dispatched without a network
// error; Apps Script Web Apps don't expose a readable response
// without CORS, so this is the most this page can honestly confirm.
function renderSyncStatusLine(lineEl, status) {
  if (status === "pending") lineEl.textContent = "Saving result to your records…";
  else if (status === "sent") lineEl.textContent = "Result sent to your records.";
  else if (status === "already-synced" || status === "queued") lineEl.textContent = "";
  else if (status === "failed") lineEl.textContent = "Couldn't reach your records right now — your result is still safe here, and this will retry automatically.";
  else lineEl.textContent = "";
}

function renderExamResults(root) {
  const questions = examState.questions;
  const answers = examState.answers;
  const score = questions.reduce((sum, q, i) => sum + (answers[i] === q.answerIndex ? 1 : 0), 0);
  const attempted = answers.filter(a => a !== null).length;
  const pct = questions.length ? Math.round((score / questions.length) * 100) : 0;
  const timeTaken = examState.config ? EXAM_DURATIONS[examState.config.duration] - examState.secondsLeft : 0;

  root.appendChild(el("div", "hero", `
    <span class="hero-eyebrow">Revision</span>
    <h1>Exam results</h1>
    <p>Here's how this timed paper went. Review each question below, or start a fresh paper.</p>
  `));

  const grid = el("div", "grid-4");
  grid.appendChild(statCard("check-circle", "Score", `${score}/${questions.length}`, `${pct}%`));
  grid.appendChild(statCard("target", "Attempted", `${attempted}/${questions.length}`, "questions answered"));
  grid.appendChild(statCard("clock", "Time taken", formatExamTime(timeTaken).replace(":", "m ") + "s", "of the allotted time"));
  grid.appendChild(statCard("award", "Result", pct >= 60 ? "Pass" : "Needs work", pct >= 60 ? "60%+ threshold" : "below 60%"));
  root.appendChild(grid);

  if (pct >= 60 && questions.length) { launchConfetti(); }
  if (!examState.completionSoundPlayed && questions.length) {
    playCompletionSound();
    examState.completionSoundPlayed = true;
  }
  if (!examState.xpAwarded && questions.length) {
    addXP(score * 3, "Exam Mode paper completed");
    STATE.bestScores.exam = Math.max(STATE.bestScores.exam || 0, pct);
    saveState();
    examState.xpAwarded = true;
  }

  // Certificate: only for a completed, submitted, All-Chapters paper —
  // certHandleExamCompletion() itself re-checks eligibility and returns
  // null for any chapter-specific coverage, so this is the single call
  // site and it's safe even if this function re-renders more than once.
  if (questions.length && !examState.certGenerated) {
    const cert = certHandleExamCompletion(
      { questions, answers, config: examState.config }, score, pct, timeTaken
    );
    examState.certGenerated = true;
    examState.certId = cert ? cert.id : null;
  }
  if (examState.certId) {
    const cert = certFindById(examState.certId);
    if (cert) {
      renderCertificateEarnedBanner(root, cert);
      const certNote = el("p", "", "You will get your certificate in your Performance Board, below certificate.");
      certNote.style.cssText = "font-size:0.83rem; color:var(--ink-faint); text-align:center; margin:-6px 0 18px;";
      root.appendChild(certNote);
    }
  }

  // Google Sheets sync: fires once per finished result (guarded by
  // sheetSyncAttempted so a re-render of this same results page never
  // resends it), using the exact values already calculated above and
  // the same certificate ID already generated, if any. This is a
  // synchronization layer only — it never recalculates the result,
  // never blocks the page, and never generates a second certificate.
  const syncStatusLine = el("p", "", "");
  syncStatusLine.style.cssText = "font-size:0.78rem; color:var(--ink-faint); margin-top:10px;";
  root.appendChild(syncStatusLine);
  if (questions.length) {
    if (!examState.sheetSyncAttempted) {
      examState.sheetSyncAttempted = true;
      const certRecord = examState.certId ? certFindById(examState.certId) : null;
      examState.sheetSyncResult = {
        studentName: STATE.userName || "Student",
        examType: "Exam Mode",
        chapters: EXAM_COVERAGE_LABELS[examState.config.coverage] || examState.config.coverage,
        totalQuestions: questions.length,
        correctAnswers: score,
        wrongAnswers: attempted - score,
        marks: score,
        percentage: pct,
        certificateId: examState.certId || "",
        dateIssued: certRecord ? certRecord.issuedAt : "",
        examDate: new Date().toISOString(),
        passFail: pct >= 60 ? "Pass" : "Fail",
        grade: certGrade(pct),
        timeTaken: timeTaken,
        examMode: `${examState.config.duration}-Minute Timed Paper`,
        _examStartTime: examState.startTime || null,
      };
      examState.sheetSyncPromise = sheetSyncExamResult(examState.sheetSyncResult)
        .then((r) => { examState.sheetSyncStatus = r.status; renderSyncStatusLine(syncStatusLine, r.status); })
        .catch(() => { examState.sheetSyncStatus = "failed"; renderSyncStatusLine(syncStatusLine, "failed"); });
      renderSyncStatusLine(syncStatusLine, "pending");
    } else {
      renderSyncStatusLine(syncStatusLine, examState.sheetSyncStatus || "pending");
    }
  }

  if (!examState.mistakesRecorded && questions.length) {
    questions.forEach((q, i) => {
      const given = answers[i];
      if (given !== null && given !== q.answerIndex) {
        mistakeBookRecord({
          key: `exam-${examState.startTime || Date.now()}-${q.id}`,
          question: q.q, chapter: q.chapter, chapterLabel: CH_FULL_NAME[q.chapter] || q.chapter,
          topic: CH_FULL_NAME[q.chapter] || q.chapter, type: "Exam Mode",
          studentAnswer: q.options[given], correctAnswer: q.options[q.answerIndex], explanation: q.explanation
        });
      }
    });
    examState.mistakesRecorded = true;
  }

  root.appendChild(sectionTitle("Review"));
  questions.forEach((q, i) => {
    const given = answers[i];
    const correct = given === q.answerIndex;
    const card = el("div", "card q-card", "");
    card.innerHTML = `
      <div class="q-meta">
        <span class="diff-badge ${q.difficulty}">${q.difficulty}</span>
        <span style="margin-left:auto; color:${given === null ? "var(--ink-faint)" : correct ? "var(--c-eq)" : "var(--flag)"}; font-size:0.78rem; font-weight:600;">
          ${given === null ? "Not attempted" : correct ? "Correct" : "Incorrect"}
        </span>
      </div>
      <div class="q-body">${q.q}</div>
      <div class="reveal-block" style="${correct || given === null ? "" : "background:var(--flag-soft); border-left-color:var(--flag);"}">
        <p style="font-size:0.87rem;"><b>Correct answer:</b> ${q.options[q.answerIndex]}</p>
        ${given !== null && !correct ? `<p style="font-size:0.87rem; margin-top:6px;"><b>Your answer:</b> ${q.options[given]}</p>` : ""}
        <p style="font-size:0.85rem; color:var(--ink-soft); margin-top:8px;">${q.explanation}</p>
      </div>
    `;
    root.appendChild(card);
  });

  const restartBtn = el("button", "btn-primary ripple-surface", `<i data-lucide="rotate-ccw"></i> Start a new exam`);
  restartBtn.style.marginTop = "16px";
  restartBtn.addEventListener("click", () => {
    examState = { active: false, config: null, questions: [], index: 0, answers: [], startTime: null, secondsLeft: 0, timerId: null, submitted: false };
    renderRoute();
  });
  root.appendChild(restartBtn);
  attachRipple(root);
  icons();
}

/* ---------------------------------------------------------
   12. GLOBAL SEARCH
   --------------------------------------------------------- */
/* ---------------------------------------------------------
   12b. GLOBAL SEARCH — pages, chapters, concepts and tools.
   Search is intentionally local: it indexes the site's own
   navigation and APP_DATA, so results are instant and work
   offline. Results can navigate to routes or open floating tools.
   --------------------------------------------------------- */
function buildSearchIndex() {
  const idx = [];
  const add = (kind, title, route, aliases = [], extra = {}) => {
    idx.push({ kind, title, route, aliases, ...extra });
  };

  // Top-level pages / tabs. Aliases make natural searches such as
  // "progress", "certificate", "revision" and "chapters" work.
  [
    ["Home", "home", ["dashboard", "main"]],
    ["About This Website", "about", ["about", "website", "guide"]],
    ["AI Tutor", "ai-tutor", ["ai", "tutor", "ask ai", "doubt"]],
    ["Chapters", "chapters-list", ["chapter", "lessons", "topics"]],
    ["Practice", "practice-hub", ["practice", "questions", "problems"]],
    ["Revision", "revision", ["revision", "revise", "quick revision"]],
    ["Performance Dashboard", "performance", ["performance", "progress", "score", "stats", "results"]],
    ["Bookmarks", "bookmarks", ["bookmark", "saved", "save"]],
    ["Settings", "settings", ["setting", "preferences", "options"]],
    ["Formula Sheet", "formula-sheet", ["formulas", "formula", "rules"]],
    ["Important Questions", "important-questions", ["important", "important questions", "most important"]],
    ["Exam Mode", "exam-mode", ["exam", "test", "mock test", "paper", "timed exam"]],
    ["Quiz", "quiz", ["mcq", "mcqs", "quiz questions"]],
    ["Flashcards", "flashcards", ["flash card", "revision cards", "cards"]],
    ["Numerical Solver", "numerical-solver", ["numerical", "solver", "solve"]],
    ["Mistake Book", "mistake-book", ["mistakes", "wrong answers", "errors"]],
    ["Accounting Cycle", "accounting-cycle", ["cycle", "accounting cycle"]],
    ["Certificate", "certificate-view", ["certificate", "certificates", "achievement", "award"]],
  ].forEach(([title, route, aliases]) => add("Page", title, route, aliases));

  // Chapters are explicit top-priority destinations.
  APP_DATA.chapters.forEach(ch => {
    add("Chapter", ch.name, `ch-${ch.id}`, [
      ch.name.toLowerCase(),
      `chapter ${ch.num}`,
      ch.tagline || "",
      ch.id === "cb" ? "cash book" : "",
      ch.id === "dc" ? "debit credit" : "",
      ch.id === "sp2" ? "other books" : "",
      ch.id === "sp2" ? "special purpose books 2" : "",
      ch.id === "sp2" ? "special purpose books" : "",
      ch.id === "brs" ? "bank reconciliation" : "",
      ch.id === "brs" ? "bank reconciliation statement" : "",
      ch.id === "brs" ? "pass book" : "",
    ]);
  });

  // Study tools open immediately instead of navigating to another page.
  add("Tool", "Calculator", null, ["calculator", "calc", "math"], { action: "openTool", toolId: "floatingCalcToggle" });
  add("Tool", "Scratch Pad", null, ["scratch", "scratchpad", "scratch pad", "note", "notes", "notepad", "write notes"], { action: "openTool", toolId: "scratchPadToggle" });
  add("Tool", "Pomodoro Timer", null, ["timer", "pomodoro", "pomodoro timer", "focus timer", "25 minute timer"], { action: "openTool", toolId: "pomodoroToggle" });
  add("Tool", "Whiteboard", null, ["whiteboard", "board", "drawing board", "write on board"], { action: "openTool", toolId: "whiteboardToggle" });
  add("Tool", "Fullscreen Study Mode", null, ["fullscreen", "full screen", "focus mode", "study mode"], { action: "openTool", toolId: "fullscreenToggle" });

  // Searchable content inside each chapter.
  APP_DATA.equation.numericals.forEach(q => add("Numerical", `Q${q.id}: ${(q.transaction || "Direct calculation").slice(0, 90)}`, "ch-eq", [q.transaction || ""]));
  APP_DATA.equation.theory.simple.forEach(t => add("Concept", t.h, "ch-eq", ["accounting equation"]));
  APP_DATA.equation.theory.advanced.forEach(t => add("Concept", t.h, "ch-eq", ["accounting equation"]));
  add("Tool", "Balance Verifier", "ch-eq", ["balance verifier", "equation checker"]);
  add("Tool", "Random Problem Generator", "ch-eq", ["random problem", "generator"]);

  APP_DATA.debitCredit.numericals.forEach(q => add("Classification", `Q${q.id}: ${q.transaction.slice(0, 90)}`, "ch-dc", [q.transaction || ""]));
  (APP_DATA.debitCredit.balanceSheetQuestions || []).forEach(q => add("Balance Sheet", `Q${q.id}: ${(q.transaction || "Balance sheet figure").slice(0, 90)}`, "ch-dc", [q.transaction || "", "balance sheet"]));
  APP_DATA.debitCredit.theory.simple.forEach(t => add("Concept", t.h, "ch-dc", ["debit credit", "rules"]));
  APP_DATA.debitCredit.theory.advanced.forEach(t => add("Concept", t.h, "ch-dc", ["debit credit", "rules"]));

  APP_DATA.journal.numericals.forEach(q => add("Journal Entry", `Q${q.id}: ${q.transaction.slice(0, 90)}`, "ch-jr", [q.transaction || ""]));
  APP_DATA.journal.theory.simple.forEach(t => add("Concept", t.h, "ch-jr", ["journal"]));
  APP_DATA.journal.theory.advanced.forEach(t => add("Concept", t.h, "ch-jr", ["journal"]));

  getLedgerPracticePool().forEach(q => add("Ledger Posting", `Q${q.id}: ${q.transaction.slice(0, 90)}`, "ch-lg", [q.transaction || ""]));
  ["Meaning of Ledger", "Ledger Format (T-account)", "Posting Rules", "Balancing a Ledger Account"].forEach(t => add("Concept", t, "ch-lg", ["ledger"]));
  [["easy", APP_DATA.ledger.examQuestions.easy], ["medium", APP_DATA.ledger.examQuestions.medium], ["hard", APP_DATA.ledger.examQuestions.hard]].forEach(([, arr]) => arr.forEach(q => add("Exam Question", q.q.slice(0, 90), "ch-lg", [q.q || ""] )));

  APP_DATA.cashBook.theory.simple.forEach(t => add("Concept", t.h, "ch-cb", ["cash book", "special purpose books"]));
  APP_DATA.cashBook.theory.advanced.forEach(t => add("Concept", t.h, "ch-cb", ["cash book", "special purpose books"]));
  APP_DATA.cashBook.numericals.forEach(q => add("Cash Book", `Q${q.id}: ${q.transaction.slice(0, 90)}`, "ch-cb", [q.transaction || "", "cash book"]));

  APP_DATA.specialBooks2.theory.simple.forEach(t => add("Concept", t.h, "ch-sp2", ["special purpose books", "other books", "special purpose books 2"]));
  APP_DATA.specialBooks2.theory.advanced.forEach(t => add("Concept", t.h, "ch-sp2", ["special purpose books", "other books", "special purpose books 2"]));
  APP_DATA.specialBooks2.numericals.forEach(q => add("Other Books", `Q${q.id}: ${q.transaction.slice(0, 90)}`, "ch-sp2", [q.transaction || "", "other books"]));
  add("Concept", "Purchases Book or Purchases Journal", "ch-sp2", ["purchases book", "purchases journal"]);
  add("Concept", "Sales Book or Sales Journal", "ch-sp2", ["sales book", "sales journal"]);
  add("Concept", "Purchases Return Book (Returns Outward Book)", "ch-sp2", ["purchase return", "purchases return", "returns outward", "returns outward book"]);
  add("Concept", "Sales Return Book (Returns Inward Book)", "ch-sp2", ["sales return", "returns inward", "returns inward book"]);
  add("Concept", "Journal Proper or General Journal", "ch-sp2", ["journal proper", "general journal"]);

  APP_DATA.brs.theory.simple.forEach(t => add("Concept", t.h, "ch-brs", ["bank reconciliation", "brs", "cash book", "pass book"]));
  APP_DATA.brs.theory.advanced.forEach(t => add("Concept", t.h, "ch-brs", ["bank reconciliation", "brs", "cash book", "pass book"]));
  APP_DATA.brs.numericals.forEach(q => add("BRS", `Q${q.id}: ${q.transaction.slice(0, 90)}`, "ch-brs", [q.transaction || "", "bank reconciliation"]));
  add("Concept", "Bank Reconciliation Statement (BRS)", "ch-brs", ["brs", "bank reconciliation statement"]);
  add("Concept", "Balance as per Cash Book", "ch-brs", ["cash book balance"]);
  add("Concept", "Balance as per Pass Book", "ch-brs", ["pass book balance", "bank statement"]);
  add("Concept", "Causes of difference between Cash Book and Pass Book", "ch-brs", ["unpresented cheque", "uncollected cheque", "bank charges", "dishonoured cheque"]);

  APP_DATA.gst.theory.simple.forEach(t => add("Concept", t.h, "ch-gst", ["gst", "goods and services tax"]));
  APP_DATA.gst.theory.advanced.forEach(t => add("Concept", t.h, "ch-gst", ["gst", "goods and services tax", "cgst", "sgst", "igst"]));
  APP_DATA.gst.numericals.forEach(q => add("GST", `Q${q.id}: ${q.question.slice(0, 90)}`, "ch-gst", [q.question || "", "gst calculation"]));
  add("Concept", "Accounting of GST", "ch-gst", ["gst", "goods and services tax"]);
  add("Concept", "GST Amount Formula", "ch-gst", ["taxable value", "gst rate"]);
  add("Concept", "Trade Discount and GST", "ch-gst", ["trade discount", "taxable value"]);
  add("Concept", "CGST SGST IGST", "ch-gst", ["intra-state", "inter-state", "cgst", "sgst", "igst"]);

  APP_DATA.tb.theory.simple.forEach(t => add("Concept", t.h, "ch-tb", ["trial balance", "balance method"]));
  APP_DATA.tb.theory.advanced.forEach(t => add("Concept", t.h, "ch-tb", ["trial balance", "debit balance", "credit balance", "format"]));
  APP_DATA.tb.numericals.forEach(q => add("Trial Balance", `Q${q.id}: ${q.question.slice(0, 90)}`, "ch-tb", [q.question || "", "trial balance calculation"]));
  add("Concept", "Trial Balance", "ch-tb", ["trial balance", "meaning of trial balance"]);
  add("Concept", "Balance Method", "ch-tb", ["balance method", "trial balance preparation"]);
  add("Concept", "Agreement of Trial Balance", "ch-tb", ["trial balance agrees", "tally"]);
  add("Concept", "Errors of Omission, Principle, and Compensating Errors", "ch-tb", ["error of omission", "error of principle", "compensating errors"]);
  add("Tool", "Trial Balance Checkpoint", "ch-tb", ["trial balance checkpoint", "does it balance"]);

  APP_DATA.dep.theory.simple.forEach(t => add("Concept", t.h, "ch-dep", ["depreciation", "depletion", "amortisation"]));
  APP_DATA.dep.theory.advanced.forEach(t => add("Concept", t.h, "ch-dep", ["depreciation", "slm", "wdv", "straight line method", "written down value"]));
  APP_DATA.dep.numericals.forEach(q => add("Depreciation", `Q${q.id}: ${q.question.slice(0, 90)}`, "ch-dep", [q.question || "", "depreciation calculation"]));
  add("Concept", "Depreciation", "ch-dep", ["depreciation", "meaning of depreciation"]);
  add("Concept", "Straight Line Method (SLM)", "ch-dep", ["slm", "straight line method", "fixed instalment method"]);
  add("Concept", "Written Down Value Method (WDV)", "ch-dep", ["wdv", "written down value", "diminishing balance"]);
  add("Concept", "Depletion", "ch-dep", ["depletion", "natural resources", "mines"]);
  add("Concept", "Amortisation", "ch-dep", ["amortisation", "intangible assets", "patents"]);
  add("Concept", "Provision for Depreciation Account", "ch-dep", ["provision for depreciation", "accumulated depreciation"]);
  add("Concept", "Disposal of Assets", "ch-dep", ["asset disposal", "sale of asset", "profit on sale", "loss on sale"]);
  add("Tool", "Depreciation Lab", "ch-dep", ["depreciation lab", "depreciation calculator", "slm vs wdv"]);

  return idx;
}
const SEARCH_INDEX = buildSearchIndex();

const searchInput = $("#globalSearch");
const searchResults = $("#searchResults");
let searchActiveIndex = -1;
let lastSearchMatches = [];

function normalizeSearchText(value) {
  return String(value || "").toLowerCase().replace(/&/g, "and").replace(/[^a-z0-9]+/g, " ").trim();
}

function scoreSearchResult(item, query) {
  const q = normalizeSearchText(query);
  if (!q) return 0;
  const hay = normalizeSearchText([item.title, ...(item.aliases || [])].join(" "));
  const title = normalizeSearchText(item.title);
  const compactQ = q.replace(/\s+/g, "");
  const compactTitle = title.replace(/\s+/g, "");
  let score = 0;
  if (title === q) score += 1000;
  if (compactTitle === compactQ) score += 950;
  if (title.startsWith(q)) score += 500;
  if (hay.startsWith(q)) score += 350;
  if (title.includes(q)) score += 250;
  if (hay.includes(q)) score += 150;
  q.split(/\s+/).forEach(token => {
    if (token.length < 2) return;
    if (title.split(/\s+/).some(w => w.startsWith(token))) score += 80;
    if (hay.includes(token)) score += 25;
  });
  return score;
}

function openSearchResult(item) {
  if (!item) return;
  searchResults.hidden = true;
  searchInput.value = "";
  searchActiveIndex = -1;
  if (item.action === "openTool") {
    const sourceButton = document.getElementById(item.toolId);
    if (sourceButton) sourceButton.click();
    return;
  }
  if (item.route) navigate(item.route);
}

function renderSearchResults(query) {
  const q = query.trim();
  if (!q) {
    searchResults.hidden = true;
    searchActiveIndex = -1;
    lastSearchMatches = [];
    searchResults.innerHTML = "";
    return;
  }

  lastSearchMatches = SEARCH_INDEX
    .map((item, originalIndex) => ({ item, originalIndex, score: scoreSearchResult(item, q) }))
    .filter(x => x.score > 0)
    .sort((a, b) => b.score - a.score || a.item.title.localeCompare(b.item.title))
    .slice(0, 12)
    .map(x => x.item);

  searchActiveIndex = lastSearchMatches.length ? 0 : -1;
  searchResults.innerHTML = "";
  if (!lastSearchMatches.length) {
    searchResults.innerHTML = `<div class="search-empty"><strong>No matches</strong><span>Try a chapter, page, topic or tool — e.g. <b>cash book</b>, <b>performance</b> or <b>whiteboard</b>.</span></div>`;
  } else {
    lastSearchMatches.forEach((m, i) => {
      const item = el("div", "search-result-item", `
        <span class="search-result-kind">${m.kind}</span>
        <span class="search-result-title">${m.title}</span>
        <span class="search-result-action">${m.action === "openTool" ? "Open tool" : "Go to " + (ROUTE_TITLES[m.route] || m.route || "page")}</span>
      `);
      item.dataset.searchIndex = i;
      item.setAttribute("role", "option");
      item.addEventListener("mouseenter", () => setSearchActiveIndex(i));
      item.addEventListener("click", () => openSearchResult(m));
      searchResults.appendChild(item);
    });
  }
  updateSearchActiveItem();
  searchResults.hidden = false;
}

function setSearchActiveIndex(index) {
  if (!lastSearchMatches.length) return;
  searchActiveIndex = (index + lastSearchMatches.length) % lastSearchMatches.length;
  updateSearchActiveItem();
}

function updateSearchActiveItem() {
  $all(".search-result-item", searchResults).forEach((node, i) => {
    const active = i === searchActiveIndex;
    node.classList.toggle("active", active);
    node.setAttribute("aria-selected", active ? "true" : "false");
    if (active) node.scrollIntoView({ block: "nearest" });
  });
}

searchInput.addEventListener("input", () => renderSearchResults(searchInput.value));
searchInput.addEventListener("keydown", (e) => {
  if (e.key === "ArrowDown" && lastSearchMatches.length) { e.preventDefault(); setSearchActiveIndex(searchActiveIndex + 1); }
  else if (e.key === "ArrowUp" && lastSearchMatches.length) { e.preventDefault(); setSearchActiveIndex(searchActiveIndex - 1); }
  else if (e.key === "Enter" && lastSearchMatches.length) { e.preventDefault(); openSearchResult(lastSearchMatches[searchActiveIndex] || lastSearchMatches[0]); }
  else if (e.key === "Escape") { searchResults.hidden = true; searchActiveIndex = -1; }
});
document.addEventListener("click", (e) => { if (!e.target.closest(".topbar-search")) searchResults.hidden = true; });
document.addEventListener("keydown", (e) => {
  if (e.key === "/" && document.activeElement !== searchInput) { e.preventDefault(); searchInput.focus(); searchInput.select(); }
});

/* ---------------------------------------------------------
   13. SIDEBAR TOGGLE (mobile) + SEARCH TOGGLE
   --------------------------------------------------------- */
$("#sidebarToggle").addEventListener("click", () => {
  if ($("#sidebar").classList.contains("open")) closeSidebar(); else openSidebar();
});
$("#sidebarClose").addEventListener("click", closeSidebar);
$("#sidebarOverlay").addEventListener("click", closeSidebar);
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    if ($("#sidebar").classList.contains("open")) closeSidebar();
    if ($(".topbar").classList.contains("search-open")) { $(".topbar").classList.remove("search-open"); }
  }
});
const mobileSearchBtn = $("#mobileSearchToggle");
if (mobileSearchBtn) {
  mobileSearchBtn.addEventListener("click", () => {
    $(".topbar").classList.toggle("search-open");
    if ($(".topbar").classList.contains("search-open")) setTimeout(() => $("#globalSearch").focus(), 50);
  });
}

/* ---------------------------------------------------------
   14. FLOATING TOOLS — calculator, scratch pad, pomodoro
       Now draggable: each panel can be repositioned by its
       header, remembers where it was left (per device, via
       STATE.panelPositions), and panels can be open at the
       same time rather than force-closing each other, since
       dragging means they no longer have to collide.
   --------------------------------------------------------- */
const PANEL_IDS = ["floatingCalc", "scratchPad", "pomodoroPanel", "whiteboardPanel"];
let topZIndex = 400;

// Staggered fallback positions (used the first time a panel is opened,
// before the person has ever dragged it) so multiple panels opened at
// once don't land exactly on top of one another.
const PANEL_DEFAULT_OFFSETS = {
  floatingCalc: { right: 24, bottom: 24 },
  scratchPad: { right: 340, bottom: 24 },
  pomodoroPanel: { right: 656, bottom: 24 },
  whiteboardPanel: { right: 40, bottom: 40 }
};

function bringPanelToFront(panel) {
  topZIndex += 1;
  panel.style.zIndex = topZIndex;
}

function applyPanelPosition(panel, id) {
  const saved = STATE.panelPositions[id];
  if (saved && typeof saved.top === "number" && typeof saved.left === "number") {
    panel.style.top = saved.top + "px";
    panel.style.left = saved.left + "px";
    panel.style.right = "auto";
    panel.style.bottom = "auto";
  } else {
    const fallback = PANEL_DEFAULT_OFFSETS[id] || { right: 24, bottom: 24 };
    panel.style.right = fallback.right + "px";
    panel.style.bottom = fallback.bottom + "px";
    panel.style.top = "auto";
    panel.style.left = "auto";
  }
}

function clampPanelToViewport(panel) {
  const rect = panel.getBoundingClientRect();
  const maxLeft = window.innerWidth - rect.width - 8;
  const maxTop = window.innerHeight - 40; // keep at least the header visible
  let left = rect.left, top = rect.top;
  if (left > maxLeft) left = Math.max(8, maxLeft);
  if (left < 8) left = 8;
  if (top > maxTop) top = Math.max(8, maxTop);
  if (top < 8) top = 8;
  panel.style.left = left + "px";
  panel.style.top = top + "px";
  panel.style.right = "auto";
  panel.style.bottom = "auto";
}

function makePanelDraggable(panel, id) {
  const head = $(".floating-panel-head", panel);
  if (!head) return;
  let dragging = false, startX = 0, startY = 0, startLeft = 0, startTop = 0;

  function isMobileLayout() { return window.innerWidth <= 640 && id !== "whiteboardPanel"; }

  function onPointerDown(e) {
    if (isMobileLayout()) return; // panels stay fixed on small screens
    if (e.target.closest("button")) return; // don't start a drag from the close button
    dragging = true;
    panel.classList.add("is-dragging");
    bringPanelToFront(panel);
    const rect = panel.getBoundingClientRect();
    startLeft = rect.left; startTop = rect.top;
    const point = e.touches ? e.touches[0] : e;
    startX = point.clientX; startY = point.clientY;
    // Switch from right/bottom-anchored to left/top-anchored the moment a drag begins
    panel.style.left = startLeft + "px";
    panel.style.top = startTop + "px";
    panel.style.right = "auto";
    panel.style.bottom = "auto";
    document.addEventListener("mousemove", onPointerMove);
    document.addEventListener("mouseup", onPointerUp);
    document.addEventListener("touchmove", onPointerMove, { passive: false });
    document.addEventListener("touchend", onPointerUp);
    e.preventDefault();
  }

  function onPointerMove(e) {
    if (!dragging) return;
    const point = e.touches ? e.touches[0] : e;
    const dx = point.clientX - startX;
    const dy = point.clientY - startY;
    let newLeft = startLeft + dx;
    let newTop = startTop + dy;
    // Keep within the viewport while dragging, not just after release
    const rect = panel.getBoundingClientRect();
    newLeft = Math.min(Math.max(8, newLeft), window.innerWidth - rect.width - 8);
    newTop = Math.min(Math.max(8, newTop), window.innerHeight - 40);
    panel.style.left = newLeft + "px";
    panel.style.top = newTop + "px";
    if (e.cancelable) e.preventDefault();
  }

  function onPointerUp() {
    if (!dragging) return;
    dragging = false;
    panel.classList.remove("is-dragging");
    document.removeEventListener("mousemove", onPointerMove);
    document.removeEventListener("mouseup", onPointerUp);
    document.removeEventListener("touchmove", onPointerMove);
    document.removeEventListener("touchend", onPointerUp);
    const rect = panel.getBoundingClientRect();
    STATE.panelPositions[id] = { top: rect.top, left: rect.left };
    saveState();
  }

  head.addEventListener("mousedown", onPointerDown);
  head.addEventListener("touchstart", onPointerDown, { passive: false });
}

function openPanel(id) {
  const panel = $("#" + id);
  applyPanelPosition(panel, id);
  panel.hidden = false;
  panel.classList.remove("is-closing");
  bringPanelToFront(panel);
  // Re-clamp shortly after becoming visible, in case a saved position
  // is now off-screen (e.g. window was resized since it was last placed).
  requestAnimationFrame(() => clampPanelToViewport(panel));
  icons();
}

function closePanel(id) {
  const panel = $("#" + id);
  panel.classList.add("is-closing");
  setTimeout(() => { panel.hidden = true; panel.classList.remove("is-closing"); }, 200);
}

function togglePanel(id) {
  const p = $("#" + id);
  if (p.hidden) openPanel(id); else closePanel(id);
}

PANEL_IDS.forEach(id => makePanelDraggable($("#" + id), id));
window.addEventListener("resize", () => {
  PANEL_IDS.forEach(id => { const p = $("#" + id); if (!p.hidden) clampPanelToViewport(p); });
});

$("#floatingCalcToggle").addEventListener("click", () => togglePanel("floatingCalc"));
$("#scratchPadToggle").addEventListener("click", () => togglePanel("scratchPad"));
$("#pomodoroToggle").addEventListener("click", () => togglePanel("pomodoroPanel"));
$all("[data-close]").forEach(b => b.addEventListener("click", () => closePanel(b.dataset.close)));
$("#fullscreenToggle").addEventListener("click", () => {
  if (!document.fullscreenElement) document.documentElement.requestFullscreen().catch(()=>{});
  else document.exitFullscreen();
});

// Build calculator grid
(function buildCalc() {
  const keys = ["7","8","9","÷","4","5","6","×","1","2","3","−","0",".","=","+"];
  const grid = $("#calcGrid");
  let expr = "";
  keys.forEach(k => {
    const b = el("button", k === "=" ? "eq" : (["÷","×","−","+"].includes(k) ? "op" : ""), k);
    b.addEventListener("click", () => {
      if (k === "=") {
        try {
          const safe = expr.replace(/×/g, "*").replace(/÷/g, "/").replace(/−/g, "-");
          const result = Function(`"use strict"; return (${safe})`)();
          expr = String(result);
        } catch (e) { expr = "Error"; }
      } else {
        expr += k;
      }
      $("#calcDisplay").value = expr || "0";
    });
    grid.appendChild(b);
  });
  const clearBtn = el("button", "", "C");
  clearBtn.addEventListener("click", () => { expr = ""; $("#calcDisplay").value = "0"; });
  grid.appendChild(clearBtn);
})();

// Scratch pad persistence
const scratchArea = $("#scratchArea");
scratchArea.value = localStorage.getItem("abhinash_scratch") || "";
scratchArea.addEventListener("input", () => localStorage.setItem("abhinash_scratch", scratchArea.value));

// Pomodoro
let pomodoroSeconds = 25 * 60, pomodoroInterval = null, pomodoroRunning = false;
function updatePomodoroDisplay() {
  const m = String(Math.floor(pomodoroSeconds/60)).padStart(2,"0");
  const s = String(pomodoroSeconds%60).padStart(2,"0");
  $("#pomodoroDisplay").textContent = `${m}:${s}`;
}
$("#pomodoroStart").addEventListener("click", () => {
  if (pomodoroRunning) {
    clearInterval(pomodoroInterval); pomodoroRunning = false; $("#pomodoroStart").textContent = "Start";
  } else {
    pomodoroRunning = true; $("#pomodoroStart").textContent = "Pause";
    pomodoroInterval = setInterval(() => {
      if (pomodoroSeconds > 0) { pomodoroSeconds--; STATE.studySeconds++; updatePomodoroDisplay(); }
      else { clearInterval(pomodoroInterval); pomodoroRunning = false; $("#pomodoroStart").textContent = "Start"; toast("Pomodoro session complete", "success", "check-circle"); launchConfetti(); }
    }, 1000);
  }
});
$("#pomodoroReset").addEventListener("click", () => {
  clearInterval(pomodoroInterval); pomodoroRunning = false; pomodoroSeconds = 25*60;
  $("#pomodoroStart").textContent = "Start"; updatePomodoroDisplay();
});
$all(".pomodoro-modes .chip").forEach(c => c.addEventListener("click", () => {
  pomodoroSeconds = parseInt(c.dataset.mins) * 60; updatePomodoroDisplay();
}));

/* ---------------------------------------------------------
   14b. WHITEBOARD
   A vector object-model canvas (not a flat bitmap) so that
   selection, move, resize, undo/redo, and crisp zoom all work
   correctly. Persists to its own localStorage key (kept out of
   the main STATE blob since drawings can get large and don't
   need to round-trip through every saveState() call).
   --------------------------------------------------------- */
const WB_STORE_KEY = "abhinash_whiteboard_v1";
const WB_PRESET_COLORS = [
  "#14110F","#4A453E","#8A8377","#FFFFFF","#C0392B","#E74C3C","#E67E22","#F1C40F",
  "#F39C12","#27AE60","#2ECC71","#16A085","#1ABC9C","#2980B9","#3498DB","#8E44AD",
  "#9B59B6","#D35400","#7F8C8D","#2C3E50"
];
const WB_TOOL_DEFAULTS = {
  pen:         { width: 3,  alpha: 1,    composite: "source-over" },
  pencil:      { width: 1.5,alpha: 0.75, composite: "source-over" },
  marker:      { width: 8,  alpha: 1,    composite: "source-over" },
  highlighter: { width: 22, alpha: 0.35, composite: "multiply" }
};

function wbBlankPage(name) {
  return { id: wbPageIdCounter++, name: name || "Page 1", objects: [], background: "graph", panX: 0, panY: 0, zoom: 1 };
}
let wbPageIdCounter = 1;
function wbLoad() {
  try {
    const raw = localStorage.getItem(WB_STORE_KEY);
    if (!raw) return { pages: [wbBlankPage("Page 1")], activePage: 0 };
    const parsed = JSON.parse(raw);
    if (parsed.pages && Array.isArray(parsed.pages) && parsed.pages.length) {
      wbPageIdCounter = Math.max(1, ...parsed.pages.map(p => (p.id||0)+1));
      return { pages: parsed.pages, activePage: Math.min(parsed.activePage||0, parsed.pages.length-1) };
    }
    // Migrate an old (pre-multi-page) single-board save so existing work isn't lost.
    if (parsed.objects) {
      const page = wbBlankPage("Page 1");
      page.objects = parsed.objects; page.panX = parsed.panX||0; page.panY = parsed.panY||0; page.zoom = parsed.zoom||1;
      return { pages: [page], activePage: 0 };
    }
    return { pages: [wbBlankPage("Page 1")], activePage: 0 };
  } catch (e) { return { pages: [wbBlankPage("Page 1")], activePage: 0 }; }
}
let wbPages, wbActivePage, wb;
(function wbBoot() {
  const loaded = wbLoad();
  wbPages = loaded.pages;
  wbActivePage = loaded.activePage;
  wb = wbPages[wbActivePage]; // `wb` is always an alias for the current page — every
                              // existing wb.objects / wb.panX / wb.zoom reference in this
                              // file keeps working unchanged; switching pages just
                              // reassigns which page object `wb` points to.
})();

// --- multi-page management ---
function wbSwitchPage(index) {
  if (index < 0 || index >= wbPages.length || index === wbActivePage) return;
  wbActivePage = index;
  wb = wbPages[wbActivePage];
  wbSelectedIds = [];
  wbHistory = []; wbRedo = []; // undo history is scoped per editing session on a page, not carried across pages
  wbRenderPageTabs();
  wbSyncBackgroundButton();
  wbResizeCanvas();
  wbSaveSoon();
}
function wbSyncBackgroundButton() {
  const bg = (wb && wb.background) || "blank";
  $all(".wb-bg-option").forEach(b => b.classList.toggle("active", b.dataset.bg === bg));
}
function wbCreatePage() {
  const page = wbBlankPage("Page " + (wbPages.length + 1));
  wbPages.push(page);
  wbSwitchPage(wbPages.length - 1);
}
function wbDuplicatePage() {
  const copy = JSON.parse(JSON.stringify(wb));
  copy.id = wbPageIdCounter++;
  copy.name = wb.name + " copy";
  wbPages.splice(wbActivePage + 1, 0, copy);
  wbSwitchPage(wbActivePage + 1);
}
function wbDeletePage(index) {
  if (wbPages.length <= 1) { toast("At least one page is required", "info", "info"); return; }
  if (!confirm(`Delete "${wbPages[index].name}"? This can't be undone.`)) return;
  wbPages.splice(index, 1);
  wbActivePage = Math.min(wbActivePage, wbPages.length - 1);
  wb = wbPages[wbActivePage];
  wbSelectedIds = [];
  wbRenderPageTabs(); wbResizeCanvas(); wbSaveSoon();
}
function wbRenamePage(index) {
  const name = prompt("Page name:", wbPages[index].name);
  if (name && name.trim()) { wbPages[index].name = name.trim(); wbRenderPageTabs(); wbSaveSoon(); }
}
function wbReorderPage(from, to) {
  if (to < 0 || to >= wbPages.length) return;
  const [moved] = wbPages.splice(from, 1);
  wbPages.splice(to, 0, moved);
  if (wbActivePage === from) wbActivePage = to;
  else if (from < wbActivePage && to >= wbActivePage) wbActivePage--;
  else if (from > wbActivePage && to <= wbActivePage) wbActivePage++;
  wbRenderPageTabs(); wbSaveSoon();
}
function wbRenderPageTabs() {
  const bar = $("#wbPageTabs");
  if (!bar) return;
  bar.innerHTML = "";
  wbPages.forEach((p, i) => {
    const tab = el("div", "wb-page-tab" + (i === wbActivePage ? " active" : ""), "");
    const label = el("span", "", p.name);
    label.addEventListener("click", () => wbSwitchPage(i));
    label.addEventListener("dblclick", () => wbRenamePage(i));
    tab.appendChild(label);
    if (wbPages.length > 1) {
      const closeBtn = el("button", "wb-page-close", '<i data-lucide="x"></i>');
      closeBtn.addEventListener("click", (e) => { e.stopPropagation(); wbDeletePage(i); });
      tab.appendChild(closeBtn);
    }
    bar.appendChild(tab);
  });
  const addBtn = el("button", "wb-page-add", '<i data-lucide="plus"></i>');
  addBtn.title = "New page";
  addBtn.addEventListener("click", wbCreatePage);
  bar.appendChild(addBtn);
  const dupBtn = el("button", "wb-page-add", '<i data-lucide="copy"></i>');
  dupBtn.title = "Duplicate current page";
  dupBtn.addEventListener("click", wbDuplicatePage);
  bar.appendChild(dupBtn);
  icons();
}
function wbSetBackground(bg) {
  wb.background = bg;
  $all(".wb-bg-option").forEach(b => b.classList.toggle("active", b.dataset.bg === bg));
  wbRender(); wbSaveSoon();
}

// --- accounting table templates ---
const WB_TABLE_TEMPLATES = [
  { id: "journal", name: "Journal", headers: ["Date","Particulars","L.F.","Dr. (₹)","Cr. (₹)"], widths: [70,180,50,80,80], rows: 6 },
  { id: "ledger", name: "Ledger", headers: ["Date","Particulars","J.F.","Amount","Date","Particulars","J.F.","Amount"], widths: [60,120,40,70,60,120,40,70], rows: 6 },
  { id: "cashbook", name: "Cash Book", headers: ["Date","Particulars","L.F.","Cash","Bank","Date","Particulars","L.F.","Cash","Bank"], widths: [55,100,35,60,60,55,100,35,60,60], rows: 6 },
  { id: "trialbalance", name: "Trial Balance", headers: ["Particulars","L.F.","Debit (₹)","Credit (₹)"], widths: [200,50,90,90], rows: 8 },
  { id: "trading", name: "Trading Account", headers: ["Particulars (Dr.)","Amount","Particulars (Cr.)","Amount"], widths: [160,80,160,80], rows: 6 },
  { id: "pnl", name: "Profit & Loss Account", headers: ["Particulars (Dr.)","Amount","Particulars (Cr.)","Amount"], widths: [160,80,160,80], rows: 6 },
  { id: "balancesheet", name: "Balance Sheet", headers: ["Liabilities","Amount","Assets","Amount"], widths: [160,80,160,80], rows: 6 },
  { id: "brs", name: "Bank Reconciliation Statement", headers: ["Particulars","Amount (+)","Amount (−)"], widths: [220,100,100], rows: 6 },
  { id: "gst", name: "GST Invoice", headers: ["Particulars","Amount (₹)"], widths: [220,120], rows: 6 },
  { id: "tb", name: "Trial Balance", headers: ["Particulars","Debit (₹)","Credit (₹)"], widths: [220,110,110], rows: 8 },
  { id: "depreciation", name: "Depreciation Table", headers: ["Year","Opening Balance","Depreciation","Closing Balance"], widths: [70,120,110,120], rows: 6 },
  { id: "billsreceivable", name: "Bills Receivable", headers: ["Date","Drawer","Acceptor","Term","Due Date","Amount"], widths: [70,100,100,60,90,80], rows: 5 },
  { id: "billspayable", name: "Bills Payable", headers: ["Date","Drawee","Payee","Term","Due Date","Amount"], widths: [70,100,100,60,90,80], rows: 5 },
  { id: "taccount", name: "T Account", headers: ["Particulars (Dr.)","Amount","Particulars (Cr.)","Amount"], widths: [160,80,160,80], rows: 5 },
  { id: "accountingequation", name: "Accounting Equation Table", headers: ["Transaction","Assets","Liabilities","Capital"], widths: [160,110,110,110], rows: 6 },
  { id: "inventory", name: "Inventory Table", headers: ["Date","Receipt Qty","Receipt Amt","Issue Qty","Issue Amt","Balance Qty","Balance Amt"], widths: [65,80,85,75,80,85,90], rows: 6 }
];
function wbInsertTable(templateId) {
  let headers, widths, rows;
  if (templateId === "custom") {
    const c = parseInt(prompt("Number of columns:", "4"));
    const r = parseInt(prompt("Number of rows (including header):", "5"));
    if (!c || !r || c < 1 || r < 1) return;
    headers = Array.from({length: c}, (_, i) => "Column " + (i+1));
    widths = Array.from({length: c}, () => 90);
    rows = r;
  } else {
    const t = WB_TABLE_TEMPLATES.find(x => x.id === templateId);
    if (!t) return;
    headers = t.headers; widths = t.widths; rows = t.rows;
  }
  const world = wbToWorld(wbCanvas.getBoundingClientRect().left + 60, wbCanvas.getBoundingClientRect().top + 60);
  const cells = [headers.slice()];
  for (let r = 1; r < rows; r++) cells.push(new Array(headers.length).fill(""));
  wbPushHistory();
  const table = { id: wbNextId++, type: "table", x: world.x, y: world.y, rows, cols: headers.length, colWidths: widths.slice(), rowHeight: 30, headerRows: 1, cells, color: "#14110F", borderColor: null, cellBg: null, headerBg: null, textColor: null };
  wb.objects.push(table);
  wbSelectedIds = [table.id];
  wbSetTool("select");
  wbRender(); wbSaveSoon();
  $("#wbTablePanel").hidden = true;
}
function wbEditTableCell(table, screenX, screenY) {
  const rect = wbCanvas.getBoundingClientRect();
  const world = wbToWorld(screenX, screenY);
  const colX = [table.x]; table.colWidths.forEach(w => colX.push(colX[colX.length-1]+w));
  let col = -1;
  for (let c = 0; c < table.cols; c++) if (world.x >= colX[c] && world.x < colX[c+1]) { col = c; break; }
  const row = Math.floor((world.y - table.y) / table.rowHeight);
  if (col === -1 || row < 0 || row >= table.rows) return false;
  const cellScreenX = rect.left + (colX[col] * wb.zoom + wb.panX) / wbDPR;
  const cellScreenY = rect.top + ((table.y + row*table.rowHeight) * wb.zoom + wb.panY) / wbDPR;
  const cellW = table.colWidths[col] * wb.zoom / wbDPR, cellH = table.rowHeight * wb.zoom / wbDPR;
  const input = document.createElement("input");
  input.type = "text";
  input.className = "wb-cell-editor";
  input.value = (table.cells[row] && table.cells[row][col]) || "";
  input.style.cssText = `position:fixed; left:${cellScreenX}px; top:${cellScreenY}px; width:${cellW}px; height:${cellH}px; font-size:${12*wb.zoom/wbDPR}px; z-index:2000; border:1.5px solid #2563EB; outline:none; padding:0 4px; font-family:inherit;`;
  document.body.appendChild(input);
  input.focus(); input.select();
  function finish() {
    wbPushHistory();
    if (!table.cells[row]) table.cells[row] = new Array(table.cols).fill("");
    table.cells[row][col] = input.value;
    document.body.removeChild(input);
    wbRender(); wbSaveSoon();
  }
  input.addEventListener("blur", finish);
  input.addEventListener("keydown", (e) => { if (e.key === "Enter") input.blur(); if (e.key === "Escape") { input.value = (table.cells[row]||[])[col] || ""; input.blur(); } });
  return true;
}
function wbTableAddRow(table) {
  wbPushHistory();
  table.rows++;
  table.cells.push(new Array(table.cols).fill(""));
  wbRender(); wbSaveSoon();
}
function wbTableDeleteRow(table) {
  if (table.rows <= table.headerRows + 1) return;
  wbPushHistory();
  table.rows--;
  table.cells.pop();
  wbRender(); wbSaveSoon();
}

let wbTool = "select";
let wbColor = "#14110F";
let wbWidth = 3;
let wbSelectedIds = [];
let wbRecentColors = JSON.parse(localStorage.getItem("abhinash_wb_recent") || "[]");
let wbHistory = [];
let wbRedo = [];
let wbSaveTimer = null;
let wbNextId = 1;

function wbSaveSoon() {
  clearTimeout(wbSaveTimer);
  wbSaveTimer = setTimeout(() => {
    try { localStorage.setItem(WB_STORE_KEY, JSON.stringify({ pages: wbPages, activePage: wbActivePage })); } catch (e) { /* storage full/blocked */ }
  }, 800); // "auto-save every few seconds" — debounced so rapid strokes don't thrash storage
}
function wbPushHistory() {
  wbHistory.push(JSON.stringify(wb.objects));
  if (wbHistory.length > 200) wbHistory.shift(); // generous but not literally unbounded memory
  wbRedo = [];
}
function wbUndo() {
  if (!wbHistory.length) return;
  wbRedo.push(JSON.stringify(wb.objects));
  wb.objects = JSON.parse(wbHistory.pop());
  wbSelectedIds = [];
  wbRender(); wbSaveSoon();
}
function wbRedoFn() {
  if (!wbRedo.length) return;
  wbHistory.push(JSON.stringify(wb.objects));
  wb.objects = JSON.parse(wbRedo.pop());
  wbSelectedIds = [];
  wbRender(); wbSaveSoon();
}

let wbCanvas, wbCtx, wbWrap;
let wbDPR = 1;

let wbStaticCanvas, wbStaticCtx;
function wbResizeCanvas() {
  if (!wbCanvas) return;
  const rect = wbWrap.getBoundingClientRect();
  wbDPR = window.devicePixelRatio || 1;
  wbCanvas.width = Math.max(1, Math.round(rect.width * wbDPR));
  wbCanvas.height = Math.max(1, Math.round(rect.height * wbDPR));
  if (!wbStaticCanvas) { wbStaticCanvas = document.createElement("canvas"); wbStaticCtx = wbStaticCanvas.getContext("2d"); }
  wbStaticCanvas.width = wbCanvas.width;
  wbStaticCanvas.height = wbCanvas.height;
  wbRender();
}
// Renders the board (background + objects, optionally skipping a set of
// IDs) into the offscreen static canvas. Used so a drag/shape-preview loop
// can cheaply blit this once-computed snapshot each frame instead of
// re-walking every object on the board on every pointermove.
function wbRenderStatic(excludeIds) {
  if (!wbStaticCtx) return;
  const ctx = wbStaticCtx;
  ctx.setTransform(1,0,0,1,0,0);
  ctx.clearRect(0, 0, wbStaticCanvas.width, wbStaticCanvas.height);
  ctx.fillStyle = "#FFFFFF";
  ctx.fillRect(0, 0, wbStaticCanvas.width, wbStaticCanvas.height);
  ctx.setTransform(wb.zoom, 0, 0, wb.zoom, wb.panX, wb.panY);
  wbDrawBackgroundPattern(ctx);
  wb.objects.forEach(o => { if (!excludeIds || !excludeIds.includes(o.id)) wbDrawObject(ctx, o); });
}
function wbBlitStatic() {
  if (!wbStaticCanvas) { wbRender(); return; }
  const ctx = wbCtx;
  ctx.setTransform(1,0,0,1,0,0);
  ctx.clearRect(0, 0, wbCanvas.width, wbCanvas.height);
  ctx.drawImage(wbStaticCanvas, 0, 0);
  ctx.setTransform(wb.zoom, 0, 0, wb.zoom, wb.panX, wb.panY);
}

// screen (client) coords -> world coords, accounting for pan/zoom
function wbToWorld(clientX, clientY) {
  const rect = wbCanvas.getBoundingClientRect();
  const sx = (clientX - rect.left) * wbDPR;
  const sy = (clientY - rect.top) * wbDPR;
  return { x: (sx - wb.panX) / wb.zoom, y: (sy - wb.panY) / wb.zoom };
}

function wbBounds(o) {
  if (o.type === "stroke") {
    const xs = o.points.map(p => p.x), ys = o.points.map(p => p.y);
    return { x1: Math.min(...xs), y1: Math.min(...ys), x2: Math.max(...xs), y2: Math.max(...ys) };
  }
  if (o.type === "text") {
    const w = (o.text.length || 1) * o.fontSize * 0.56, h = o.fontSize * 1.3;
    return { x1: o.x, y1: o.y - h, x2: o.x + w, y2: o.y };
  }
  if (o.type === "table") {
    const w = o.colWidths.reduce((a,b) => a+b, 0);
    return { x1: o.x, y1: o.y, x2: o.x + w, y2: o.y + o.rows * o.rowHeight };
  }
  return { x1: Math.min(o.x1, o.x2), y1: Math.min(o.y1, o.y2), x2: Math.max(o.x1, o.x2), y2: Math.max(o.y1, o.y2) };
}

function wbDrawObject(ctx, o) {
  ctx.save();
  ctx.strokeStyle = o.color; ctx.fillStyle = o.color;
  ctx.lineWidth = o.width; ctx.lineCap = "round"; ctx.lineJoin = "round";
  ctx.globalAlpha = o.alpha != null ? o.alpha : 1;
  ctx.globalCompositeOperation = o.composite || "source-over";
  if (o.dashed) ctx.setLineDash([o.width * 2.5, o.width * 2]);

  if (o.type === "stroke") {
    if (o.points.length < 2) { ctx.restore(); return; }
    const hasPressure = o.points.some(p => p.pressure != null && p.pressure !== 1);
    if (!hasPressure) {
      // Quadratic-curve-through-midpoints smoothing: turns a polyline of
      // raw sampled points into a smooth curve, which is what actually
      // fixes jagged/angular handwriting — lineTo alone just connects
      // dots, however jittery the sampling was.
      const pts = o.points;
      ctx.beginPath();
      ctx.moveTo(pts[0].x, pts[0].y);
      if (pts.length === 2) {
        ctx.lineTo(pts[1].x, pts[1].y);
      } else {
        for (let i = 1; i < pts.length - 1; i++) {
          const midX = (pts[i].x + pts[i + 1].x) / 2;
          const midY = (pts[i].y + pts[i + 1].y) / 2;
          ctx.quadraticCurveTo(pts[i].x, pts[i].y, midX, midY);
        }
        const last = pts[pts.length - 1];
        ctx.lineTo(last.x, last.y);
      }
      ctx.stroke();
    } else {
      // Pressure-sensitive strokes are drawn segment-by-segment so the
      // width can vary along the stroke, matching how it looked live.
      for (let i = 1; i < o.points.length; i++) {
        const a = o.points[i-1], b = o.points[i];
        const avgPressure = ((a.pressure||1) + (b.pressure||1)) / 2;
        ctx.lineWidth = o.width * (0.55 + avgPressure * 0.9);
        ctx.beginPath();
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(b.x, b.y);
        ctx.stroke();
      }
    }
  } else if (o.type === "rect") {
    ctx.strokeRect(Math.min(o.x1,o.x2), Math.min(o.y1,o.y2), Math.abs(o.x2-o.x1), Math.abs(o.y2-o.y1));
  } else if (o.type === "ellipse") {
    const cx = (o.x1+o.x2)/2, cy = (o.y1+o.y2)/2, rx = Math.abs(o.x2-o.x1)/2, ry = Math.abs(o.y2-o.y1)/2;
    ctx.beginPath(); ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI*2); ctx.stroke();
  } else if (o.type === "line") {
    ctx.beginPath(); ctx.moveTo(o.x1,o.y1); ctx.lineTo(o.x2,o.y2); ctx.stroke();
  } else if (o.type === "arrow") {
    ctx.beginPath(); ctx.moveTo(o.x1,o.y1); ctx.lineTo(o.x2,o.y2); ctx.stroke();
    const ang = Math.atan2(o.y2-o.y1, o.x2-o.x1), headLen = Math.max(10, o.width*3);
    ctx.beginPath();
    ctx.moveTo(o.x2, o.y2);
    ctx.lineTo(o.x2 - headLen*Math.cos(ang-Math.PI/7), o.y2 - headLen*Math.sin(ang-Math.PI/7));
    ctx.moveTo(o.x2, o.y2);
    ctx.lineTo(o.x2 - headLen*Math.cos(ang+Math.PI/7), o.y2 - headLen*Math.sin(ang+Math.PI/7));
    ctx.stroke();
  } else if (o.type === "text") {
    ctx.font = `${o.fontSize}px ${getComputedStyle(document.body).fontFamily}`;
    ctx.textBaseline = "alphabetic";
    ctx.fillText(o.text, o.x, o.y);
  } else if (o.type === "table") {
    ctx.setLineDash([]);
    const colX = [o.x];
    o.colWidths.forEach(w => colX.push(colX[colX.length-1] + w));
    const totalW = colX[colX.length-1] - o.x;
    const totalH = o.rows * o.rowHeight;
    const borderColor = o.borderColor || o.color || "#4A453E";
    const textColor = o.textColor || o.color || "#14110F";
    // cell background (custom, or transparent/default)
    if (o.cellBg) { ctx.fillStyle = o.cellBg; ctx.fillRect(o.x, o.y, totalW, totalH); }
    // header row fill
    if (o.headerRows) {
      ctx.fillStyle = o.headerBg || "rgba(20,17,15,0.06)";
      ctx.fillRect(o.x, o.y, totalW, o.headerRows * o.rowHeight);
    }
    // grid lines
    ctx.strokeStyle = borderColor; ctx.lineWidth = 1;
    ctx.beginPath();
    for (let r = 0; r <= o.rows; r++) { const y = o.y + r*o.rowHeight; ctx.moveTo(o.x, y); ctx.lineTo(o.x+totalW, y); }
    for (let c = 0; c <= o.cols; c++) { ctx.moveTo(colX[c], o.y); ctx.lineTo(colX[c], o.y + o.rows*o.rowHeight); }
    ctx.stroke();
    // cell text
    ctx.fillStyle = textColor;
    ctx.font = `${o.headerRows ? "600 " : ""}12px ${getComputedStyle(document.body).fontFamily}`;
    ctx.textBaseline = "middle";
    for (let r = 0; r < o.rows; r++) {
      for (let c = 0; c < o.cols; c++) {
        const text = (o.cells[r] && o.cells[r][c]) || "";
        if (!text) continue;
        ctx.font = `${r < o.headerRows ? "600 " : ""}12px ${getComputedStyle(document.body).fontFamily}`;
        ctx.save();
        ctx.beginPath();
        ctx.rect(colX[c], o.y + r*o.rowHeight, o.colWidths[c], o.rowHeight);
        ctx.clip();
        ctx.fillText(text, colX[c] + 6, o.y + r*o.rowHeight + o.rowHeight/2);
        ctx.restore();
      }
    }
  }
  ctx.restore();
}

function wbDrawBackgroundPattern(ctx) {
  const bg = wb.background || "blank";
  if (bg === "blank") return;
  // Draw enough of the pattern to cover the visible viewport in world space.
  const topLeft = { x: -wb.panX / wb.zoom, y: -wb.panY / wb.zoom };
  const bottomRight = { x: (wbCanvas.width - wb.panX) / wb.zoom, y: (wbCanvas.height - wb.panY) / wb.zoom };
  ctx.save();
  if (bg === "dot") {
    const spacing = 28;
    ctx.fillStyle = "rgba(20,17,15,0.22)";
    const startX = Math.floor(topLeft.x / spacing) * spacing, startY = Math.floor(topLeft.y / spacing) * spacing;
    for (let x = startX; x < bottomRight.x; x += spacing) {
      for (let y = startY; y < bottomRight.y; y += spacing) {
        ctx.beginPath(); ctx.arc(x, y, 1.4, 0, Math.PI*2); ctx.fill();
      }
    }
  } else if (bg === "grid" || bg === "graph") {
    const spacing = bg === "graph" ? 22 : 34;
    ctx.strokeStyle = bg === "graph" ? "rgba(37,99,235,0.14)" : "rgba(20,17,15,0.10)";
    ctx.lineWidth = 1 / wb.zoom;
    const startX = Math.floor(topLeft.x / spacing) * spacing, startY = Math.floor(topLeft.y / spacing) * spacing;
    ctx.beginPath();
    for (let x = startX; x < bottomRight.x; x += spacing) { ctx.moveTo(x, topLeft.y); ctx.lineTo(x, bottomRight.y); }
    for (let y = startY; y < bottomRight.y; y += spacing) { ctx.moveTo(topLeft.x, y); ctx.lineTo(bottomRight.x, y); }
    ctx.stroke();
  } else if (bg === "lines") {
    const spacing = 34;
    ctx.strokeStyle = "rgba(37,99,235,0.16)"; ctx.lineWidth = 1 / wb.zoom;
    const startY = Math.floor(topLeft.y / spacing) * spacing;
    ctx.beginPath();
    for (let y = startY; y < bottomRight.y; y += spacing) { ctx.moveTo(topLeft.x, y); ctx.lineTo(bottomRight.x, y); }
    ctx.stroke();
  }
  ctx.restore();
}
function wbTableHandleRadius() { return 9 / wb.zoom; } // fixed screen-size handle regardless of zoom
function wbTableResizeHandle(o) {
  const b = wbBounds(o);
  return { x: b.x2, y: b.y2 };
}
function wbHitTestResizeHandle(worldX, worldY) {
  if (wbSelectedIds.length !== 1) return null;
  const o = wb.objects.find(x => x.id === wbSelectedIds[0]);
  if (!o || o.type !== "table") return null;
  const h = wbTableResizeHandle(o);
  const r = wbTableHandleRadius() * 1.6; // slightly generous hit area for touch
  if (Math.abs(worldX - h.x) <= r && Math.abs(worldY - h.y) <= r) return o;
  return null;
}

function wbRender() {
  if (!wbCtx) return;
  const ctx = wbCtx;
  ctx.setTransform(1,0,0,1,0,0);
  ctx.clearRect(0, 0, wbCanvas.width, wbCanvas.height);
  ctx.fillStyle = "#FFFFFF";
  ctx.fillRect(0, 0, wbCanvas.width, wbCanvas.height);
  ctx.setTransform(wb.zoom, 0, 0, wb.zoom, wb.panX, wb.panY);
  wbDrawBackgroundPattern(ctx);
  wb.objects.forEach(o => wbDrawObject(ctx, o));
  // selection outlines
  wbSelectedIds.forEach(id => {
    const o = wb.objects.find(x => x.id === id);
    if (!o) return;
    const b = wbBounds(o);
    ctx.save();
    ctx.strokeStyle = "#2563EB"; ctx.lineWidth = 1.5 / wb.zoom; ctx.setLineDash([5/wb.zoom, 4/wb.zoom]);
    ctx.strokeRect(b.x1-4, b.y1-4, (b.x2-b.x1)+8, (b.y2-b.y1)+8);
    ctx.restore();
    // a single selected table gets a draggable resize handle at its bottom-right corner
    if (o.type === "table" && wbSelectedIds.length === 1) {
      const h = wbTableResizeHandle(o);
      const r = wbTableHandleRadius();
      ctx.save();
      ctx.setLineDash([]);
      ctx.fillStyle = "#2563EB";
      ctx.strokeStyle = "#FFFFFF"; ctx.lineWidth = 1.5 / wb.zoom;
      ctx.beginPath(); ctx.arc(h.x, h.y, r, 0, Math.PI*2); ctx.fill(); ctx.stroke();
      ctx.restore();
    }
  });
  const zoomLabel = $("#wbZoomLabel"); if (zoomLabel) zoomLabel.textContent = Math.round(wb.zoom*100) + "%";
}

function wbHitTest(worldX, worldY) {
  for (let i = wb.objects.length - 1; i >= 0; i--) {
    const o = wb.objects[i];
    const b = wbBounds(o);
    const pad = Math.max(6, (o.width||2)) / wb.zoom;
    if (worldX >= b.x1-pad && worldX <= b.x2+pad && worldY >= b.y1-pad && worldY <= b.y2+pad) return o;
  }
  return null;
}
// Same as wbHitTest but never returns a table — the eraser tool should only
// ever remove handwritten strokes/shapes/text, never a table object. Tables
// are removed only via the explicit "Delete Table" button.
function wbHitTestErasable(worldX, worldY) {
  for (let i = wb.objects.length - 1; i >= 0; i--) {
    const o = wb.objects[i];
    if (o.type === "table") continue;
    const b = wbBounds(o);
    const pad = Math.max(6, (o.width||2)) / wb.zoom;
    if (worldX >= b.x1-pad && worldX <= b.x2+pad && worldY >= b.y1-pad && worldY <= b.y2+pad) return o;
  }
  return null;
}

function wbSetColor(hex, opts) {
  wbColor = hex;
  const dot = $("#wbColorDot"); if (dot) dot.style.background = hex;
  const picker = $("#wbColorPicker"); if (picker) picker.value = hex;
  const hexInput = $("#wbHexInput"); if (hexInput) hexInput.value = hex;
  if (!opts || !opts.skipRecent) {
    wbRecentColors = [hex, ...wbRecentColors.filter(c => c !== hex)].slice(0, 8);
    localStorage.setItem("abhinash_wb_recent", JSON.stringify(wbRecentColors));
    wbRenderRecentSwatches();
  }
  // recolor any current selection, like most drawing apps
  if (wbSelectedIds.length) {
    wbPushHistory();
    wb.objects.forEach(o => { if (wbSelectedIds.includes(o.id)) o.color = hex; });
    wbRender(); wbSaveSoon();
  }
}
function wbRenderSwatches() {
  const grid = $("#wbSwatches"); if (!grid) return;
  grid.innerHTML = "";
  WB_PRESET_COLORS.forEach(c => {
    const b = el("button", "", "");
    b.style.background = c;
    if (c === "#FFFFFF") b.style.border = "1px solid var(--line)";
    b.addEventListener("click", () => wbSetColor(c));
    grid.appendChild(b);
  });
}
function wbRenderRecentSwatches() {
  const grid = $("#wbRecentSwatches"); if (!grid) return;
  grid.innerHTML = "";
  wbRecentColors.forEach(c => {
    const b = el("button", "", "");
    b.style.background = c;
    b.addEventListener("click", () => wbSetColor(c, { skipRecent: true }));
    grid.appendChild(b);
  });
}

function wbSetTool(tool) {
  wbTool = tool;
  $all(".wb-tool[data-tool]").forEach(b => b.classList.toggle("active", b.dataset.tool === tool));
  if (tool !== "select") { wbSelectedIds = []; wbRender(); }
  const wrap = wbWrap;
  if (wrap) wrap.querySelector("canvas").style.cursor = tool === "select" ? "default" : (tool === "eraser" ? "cell" : (tool === "text" ? "text" : "crosshair"));
}

function wbZoomAt(factor, clientX, clientY) {
  const rect = wbCanvas.getBoundingClientRect();
  const sx = (clientX - rect.left) * wbDPR, sy = (clientY - rect.top) * wbDPR;
  const worldX = (sx - wb.panX) / wb.zoom, worldY = (sy - wb.panY) / wb.zoom;
  wb.zoom = Math.min(8, Math.max(0.1, wb.zoom * factor));
  wb.panX = sx - worldX * wb.zoom;
  wb.panY = sy - worldY * wb.zoom;
  wbRender(); wbSaveSoon();
}

function wbInitCanvas() {
  wbCanvas = $("#wbCanvas");
  wbWrap = $("#wbCanvasWrap");
  if (!wbCanvas || wbCanvas.dataset.wbInit) return;
  wbCanvas.dataset.wbInit = "1";
  wbCtx = wbCanvas.getContext("2d");
  wbRenderSwatches();
  wbRenderRecentSwatches();
  wbSetColor(wbColor, { skipRecent: true });
  wbSyncBackgroundButton();

  let drawing = null;        // in-progress stroke/shape object
  let dragging = null;       // { mode: 'move'|'pan'|'marquee', ... }
  let spaceHeld = false;
  let lastPan = null;
  const activePointers = new Map(); // for pinch-to-zoom

  function commitObject(obj) {
    wbPushHistory();
    obj.id = wbNextId++;
    wb.objects.push(obj);
    wbRender(); wbSaveSoon();
  }

  let activePenPointerId = null; // while a stylus stroke is in progress, a
  // simultaneous "touch" pointer (a resting palm) is rejected outright
  // instead of starting its own drag/stroke/erase.
  let activeDrawPointerId = null; // the single pointer currently driving
  // dragging/drawing — pointermove only acts on events from this exact
  // pointer, so a second finger (or a palm) touching the canvas mid-stroke
  // can never inject points into someone else's stroke.
  wbCanvas.addEventListener("pointerdown", (e) => {
    if (e.pointerType === "touch" && activePenPointerId !== null && activePenPointerId !== e.pointerId) {
      e.preventDefault();
      return; // palm rejection: ignore touch input while a pen is actively writing
    }
    if (e.pointerType === "pen") activePenPointerId = e.pointerId;
    wbCanvas.setPointerCapture(e.pointerId);
    activePointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (activePointers.size === 2) { dragging = null; drawing = null; activeDrawPointerId = null; return; } // pinch takes over
    activeDrawPointerId = e.pointerId;
    const world = wbToWorld(e.clientX, e.clientY);
    const isPanGesture = spaceHeld || e.button === 1;
    if (isPanGesture) {
      dragging = { mode: "pan", startX: e.clientX, startY: e.clientY, panX0: wb.panX, panY0: wb.panY };
      wbWrap.classList.add("wb-pan-active");
      return;
    }
    if (wbTool === "select") {
      const handleHit = wbHitTestResizeHandle(world.x, world.y);
      if (handleHit) {
        wbPushHistory();
        dragging = {
          mode: "resize-table", table: handleHit,
          startX: world.x, startY: world.y,
          origColWidths: handleHit.colWidths.slice(), origRowHeight: handleHit.rowHeight,
          origTotalW: handleHit.colWidths.reduce((a,b) => a+b, 0), origTotalH: handleHit.rows * handleHit.rowHeight
        };
        wbRenderStatic([handleHit.id]);
        return;
      }
      const hit = wbHitTest(world.x, world.y);
      if (hit) {
        if (!wbSelectedIds.includes(hit.id)) wbSelectedIds = e.shiftKey ? [...wbSelectedIds, hit.id] : [hit.id];
        dragging = { mode: "move", lastX: world.x, lastY: world.y, moved: false };
        wbRenderStatic(wbSelectedIds);
      } else {
        if (!e.shiftKey) wbSelectedIds = [];
        dragging = { mode: "marquee", x0: world.x, y0: world.y, x1: world.x, y1: world.y };
      }
      wbRender();
    } else if (wbTool === "eraser") {
      const hit = wbHitTestErasable(world.x, world.y);
      if (hit) { wbPushHistory(); wb.objects = wb.objects.filter(o => o.id !== hit.id); wbRender(); wbSaveSoon(); }
      dragging = { mode: "erase" };
    } else if (["pen","pencil","marker","highlighter"].includes(wbTool)) {
      const d = WB_TOOL_DEFAULTS[wbTool];
      const p0Pressure = (e.pressure && e.pressure > 0 && e.pressure !== 0.5) ? e.pressure : 1;
      drawing = { type: "stroke", tool: wbTool, points: [{x: world.x, y: world.y, pressure: p0Pressure}], color: wbColor, width: wbWidth || d.width, alpha: d.alpha, composite: d.composite };
    } else if (["rect","ellipse","line","arrow"].includes(wbTool)) {
      drawing = { type: wbTool, x1: world.x, y1: world.y, x2: world.x, y2: world.y, color: wbColor, width: wbWidth };
      wbRenderStatic();
    } else if (wbTool === "text") {
      wbStartTextEdit(world.x, world.y);
    }
  });

  wbCanvas.addEventListener("pointermove", (e) => {
    if (activePointers.has(e.pointerId)) activePointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (activePointers.size === 2) {
      const pts = Array.from(activePointers.values());
      const dist = Math.hypot(pts[0].x-pts[1].x, pts[0].y-pts[1].y);
      const midX = (pts[0].x+pts[1].x)/2, midY = (pts[0].y+pts[1].y)/2;
      // Pinch (zoom, anchored at the two-finger midpoint) and two-finger
      // drag (pan) are independent deltas computed from the same frame,
      // then applied together in one render — so a finger drag pans
      // smoothly even mid-pinch instead of fighting the zoom anchor.
      if (wbCanvas._wbLastPinchDist) {
        const factor = dist / wbCanvas._wbLastPinchDist;
        const rect = wbCanvas.getBoundingClientRect();
        const sx = (midX - rect.left) * wbDPR, sy = (midY - rect.top) * wbDPR;
        const worldX = (sx - wb.panX) / wb.zoom, worldY = (sy - wb.panY) / wb.zoom;
        wb.zoom = Math.min(8, Math.max(0.1, wb.zoom * factor));
        wb.panX = sx - worldX * wb.zoom;
        wb.panY = sy - worldY * wb.zoom;
      }
      if (wbCanvas._wbLastMid) {
        wb.panX += (midX - wbCanvas._wbLastMid.x) * wbDPR;
        wb.panY += (midY - wbCanvas._wbLastMid.y) * wbDPR;
      }
      wbCanvas._wbLastPinchDist = dist;
      wbCanvas._wbLastMid = { x: midX, y: midY };
      wbRender(); wbSaveSoon();
      return;
    }
    if (e.pointerId !== activeDrawPointerId) return; // not the pointer driving the current interaction — ignore (this is what makes palm rejection actually stick, not just at pointerdown)
    if (dragging && dragging.mode === "pan") {
      wb.panX = dragging.panX0 + (e.clientX - dragging.startX) * wbDPR;
      wb.panY = dragging.panY0 + (e.clientY - dragging.startY) * wbDPR;
      wbRender();
      return;
    }
    const world = wbToWorld(e.clientX, e.clientY);
    if (dragging && dragging.mode === "move") {
      const dx = world.x - dragging.lastX, dy = world.y - dragging.lastY;
      if (Math.abs(dx) > 0.01 || Math.abs(dy) > 0.01) {
        dragging.moved = true;
        wb.objects.forEach(o => {
          if (!wbSelectedIds.includes(o.id)) return;
          if (o.type === "stroke") o.points.forEach(p => { p.x += dx; p.y += dy; });
          else if (o.type === "text" || o.type === "table") { o.x += dx; o.y += dy; }
          else { o.x1 += dx; o.y1 += dy; o.x2 += dx; o.y2 += dy; }
        });
        dragging.lastX = world.x; dragging.lastY = world.y;
        wbBlitStatic();
        wb.objects.forEach(o => { if (wbSelectedIds.includes(o.id)) wbDrawObject(wbCtx, o); });
      }
    } else if (dragging && dragging.mode === "marquee") {
      dragging.x1 = world.x; dragging.y1 = world.y;
      wbBlitStatic();
      const ctx = wbCtx;
      ctx.save();
      ctx.strokeStyle = "#2563EB"; ctx.fillStyle = "rgba(37,99,235,0.08)"; ctx.lineWidth = 1/wb.zoom;
      const rx = Math.min(dragging.x0,dragging.x1), ry = Math.min(dragging.y0,dragging.y1);
      const rw = Math.abs(dragging.x1-dragging.x0), rh = Math.abs(dragging.y1-dragging.y0);
      ctx.fillRect(rx,ry,rw,rh); ctx.strokeRect(rx,ry,rw,rh);
      ctx.restore();
    } else if (dragging && dragging.mode === "erase") {
      const hit = wbHitTestErasable(world.x, world.y);
      if (hit) { wb.objects = wb.objects.filter(o => o.id !== hit.id); wbRender(); wbSaveSoon(); }
    } else if (dragging && dragging.mode === "resize-table") {
      const t = dragging.table;
      const dx = world.x - dragging.startX, dy = world.y - dragging.startY;
      const newW = Math.max(60, dragging.origTotalW + dx);
      const newH = Math.max(t.rows * 14, dragging.origTotalH + dy);
      const scaleX = newW / dragging.origTotalW, scaleY = newH / dragging.origTotalH;
      t.colWidths = dragging.origColWidths.map(w => Math.max(20, w * scaleX));
      t.rowHeight = Math.max(14, dragging.origRowHeight * scaleY);
      // incremental redraw — blit the cached static layer, then draw only
      // the live-resizing table + its handle on top, same pattern as "move"
      wbBlitStatic();
      wbDrawObject(wbCtx, t);
      const b = wbBounds(t);
      wbCtx.save();
      wbCtx.strokeStyle = "#2563EB"; wbCtx.lineWidth = 1.5 / wb.zoom; wbCtx.setLineDash([5/wb.zoom, 4/wb.zoom]);
      wbCtx.strokeRect(b.x1-4, b.y1-4, (b.x2-b.x1)+8, (b.y2-b.y1)+8);
      wbCtx.setLineDash([]);
      wbCtx.fillStyle = "#2563EB"; wbCtx.strokeStyle = "#FFFFFF"; wbCtx.lineWidth = 1.5 / wb.zoom;
      wbCtx.beginPath(); wbCtx.arc(b.x2, b.y2, wbTableHandleRadius(), 0, Math.PI*2); wbCtx.fill(); wbCtx.stroke();
      wbCtx.restore();
    } else if (drawing) {
      if (drawing.type === "stroke") {
        const rawPressure = e.pressure;
        // Most browsers report a flat 0.5 for mouse/touch (no real pressure
        // hardware) — treat that as "no pressure info" rather than a real
        // half-press, so mouse/finger strokes stay a normal constant width.
        const pressure = (rawPressure && rawPressure > 0 && rawPressure !== 0.5) ? rawPressure : 1;
        const prev = drawing.points[drawing.points.length - 1];
        const prev2 = drawing.points.length > 1 ? drawing.points[drawing.points.length - 2] : null;
        drawing.points.push({ x: world.x, y: world.y, pressure });
        // Incremental draw: only the new segment, not the whole board —
        // this is the fix for lag on boards with many existing objects.
        const ctx = wbCtx;
        ctx.save();
        ctx.strokeStyle = drawing.color;
        ctx.lineCap = "round"; ctx.lineJoin = "round";
        ctx.globalAlpha = drawing.alpha;
        ctx.globalCompositeOperation = drawing.composite;
        const avgPressure = ((prev.pressure || 1) + pressure) / 2;
        ctx.lineWidth = drawing.width * (0.55 + avgPressure * 0.9);
        ctx.beginPath();
        if (prev2) {
          // Quadratic through the previous point, from the midpoint of
          // the last two sampled points to the midpoint of this one and
          // the last — the same smoothing curve the final render uses,
          // so what you see while writing already matches what gets
          // committed, instead of a straight segment that gets replaced
          // by a curve only after lifting the pen.
          const midPrev = { x: (prev2.x + prev.x) / 2, y: (prev2.y + prev.y) / 2 };
          const midNew = { x: (prev.x + world.x) / 2, y: (prev.y + world.y) / 2 };
          ctx.moveTo(midPrev.x, midPrev.y);
          ctx.quadraticCurveTo(prev.x, prev.y, midNew.x, midNew.y);
        } else {
          ctx.moveTo(prev.x, prev.y);
          ctx.lineTo(world.x, world.y);
        }
        ctx.stroke();
        ctx.restore();
      } else {
        drawing.x2 = world.x; drawing.y2 = world.y;
        wbBlitStatic();
        wbDrawObject(wbCtx, drawing); // preview on top while dragging
      }
    }
  });

  function endGesture(e) {
    activePointers.delete(e.pointerId);
    if (activePointers.size < 2) { wbCanvas._wbLastPinchDist = null; wbCanvas._wbLastMid = null; }
    // A pointer that wasn't driving the current stroke/drag (a rejected
    // palm, or a stray second finger) lifting off must never end
    // someone else's in-progress interaction.
    if (e.pointerId !== activeDrawPointerId) return;
    if (activePenPointerId === e.pointerId) activePenPointerId = null;
    activeDrawPointerId = null;
    if (dragging && dragging.mode === "pan") { wbWrap.classList.remove("wb-pan-active"); dragging = null; wbSaveSoon(); return; }
    if (dragging && dragging.mode === "move") { if (dragging.moved) { wbPushHistory(); wbSaveSoon(); } dragging = null; return; }
    if (dragging && dragging.mode === "resize-table") { dragging = null; wbRender(); wbSaveSoon(); return; }
    if (dragging && dragging.mode === "marquee") {
      const b = { x1: Math.min(dragging.x0,dragging.x1), y1: Math.min(dragging.y0,dragging.y1), x2: Math.max(dragging.x0,dragging.x1), y2: Math.max(dragging.y0,dragging.y1) };
      wbSelectedIds = wb.objects.filter(o => { const ob = wbBounds(o); return ob.x1 < b.x2 && ob.x2 > b.x1 && ob.y1 < b.y2 && ob.y2 > b.y1; }).map(o => o.id);
      dragging = null; wbRender();
      return;
    }
    dragging = null;
    if (drawing) {
      if (drawing.type === "stroke" && drawing.points.length < 2) { drawing = null; return; }
      if (drawing.type !== "stroke" && Math.hypot(drawing.x2-drawing.x1, drawing.y2-drawing.y1) < 2/wb.zoom) { drawing = null; wbRender(); return; }
      commitObject(drawing);
      drawing = null;
    }
  }
  wbCanvas.addEventListener("pointerup", endGesture);
  wbCanvas.addEventListener("pointercancel", endGesture);
  wbCanvas.addEventListener("dblclick", (e) => {
    if (wbTool !== "select") return;
    const world = wbToWorld(e.clientX, e.clientY);
    const hit = wbHitTest(world.x, world.y);
    if (hit && hit.type === "table") wbEditTableCell(hit, e.clientX, e.clientY);
  });

  wbCanvas.addEventListener("wheel", (e) => {
    e.preventDefault();
    if (e.ctrlKey || e.metaKey) {
      wbZoomAt(e.deltaY < 0 ? 1.08 : 0.93, e.clientX, e.clientY);
    } else {
      wb.panX -= e.deltaX; wb.panY -= e.deltaY;
      wbRender(); wbSaveSoon();
    }
  }, { passive: false });

  window.addEventListener("keydown", (e) => {
    const panel = $("#whiteboardPanel");
    if (!panel || panel.hidden) return;
    const typing = document.activeElement && ["INPUT","TEXTAREA"].includes(document.activeElement.tagName);
    if (e.code === "Space" && !typing) { spaceHeld = true; wbWrap.classList.add("wb-panning"); }
  });
  window.addEventListener("keyup", (e) => {
    if (e.code === "Space") { spaceHeld = false; wbWrap.classList.remove("wb-panning"); }
  });
}

function wbStartTextEdit(worldX, worldY) {
  const rect = wbCanvas.getBoundingClientRect();
  const screenX = rect.left + (worldX * wb.zoom + wb.panX) / wbDPR;
  const screenY = rect.top + (worldY * wb.zoom + wb.panY) / wbDPR;
  const input = document.createElement("textarea");
  input.className = "wb-text-editor";
  input.style.cssText = `position:fixed; left:${screenX}px; top:${screenY - 10}px; font-size:${16*wb.zoom}px; color:${wbColor}; background:transparent; border:1px dashed #2563EB; outline:none; resize:none; z-index:2000; min-width:60px; font-family:inherit; padding:2px;`;
  document.body.appendChild(input);
  input.focus();
  function finish() {
    const text = input.value.trim();
    document.body.removeChild(input);
    if (text) commitTextObject(worldX, worldY + 14, text);
    wbSetTool("select");
  }
  input.addEventListener("blur", finish);
  input.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); input.blur(); } if (e.key === "Escape") { input.value=""; input.blur(); } });
}
function commitTextObject(x, y, text) {
  wbPushHistory();
  wb.objects.push({ id: wbNextId++, type: "text", x, y, text, color: wbColor, fontSize: 16, width: 1 });
  wbRender(); wbSaveSoon();
}

function wbDeleteSelection() {
  if (!wbSelectedIds.length) return;
  wbPushHistory();
  wb.objects = wb.objects.filter(o => !wbSelectedIds.includes(o.id));
  wbSelectedIds = [];
  wbRender(); wbSaveSoon();
}
function wbDuplicateSelection() {
  if (!wbSelectedIds.length) return;
  wbPushHistory();
  const copies = [];
  wb.objects.forEach(o => {
    if (!wbSelectedIds.includes(o.id)) return;
    const c = JSON.parse(JSON.stringify(o));
    c.id = wbNextId++;
    if (c.type === "stroke") c.points.forEach(p => { p.x += 16; p.y += 16; });
    else if (c.type === "text" || c.type === "table") { c.x += 16; c.y += 16; }
    else { c.x1 += 16; c.y1 += 16; c.x2 += 16; c.y2 += 16; }
    copies.push(c);
  });
  wb.objects.push(...copies);
  wbSelectedIds = copies.map(c => c.id);
  wbRender(); wbSaveSoon();
}
function wbClearBoard() {
  if (!wb.objects.length) return;
  if (!confirm("Clear the whole whiteboard? This can be undone with Ctrl+Z until you close the panel.")) return;
  wbPushHistory();
  wb.objects = []; wbSelectedIds = [];
  wbRender(); wbSaveSoon();
}
function wbExportPNG() {
  if (!wb.objects.length) { toast("Nothing to export yet", "info", "info"); return; }
  const xs = [], ys = [];
  wb.objects.forEach(o => { const b = wbBounds(o); xs.push(b.x1,b.x2); ys.push(b.y1,b.y2); });
  const pad = 40;
  const minX = Math.min(...xs)-pad, minY = Math.min(...ys)-pad, maxX = Math.max(...xs)+pad, maxY = Math.max(...ys)+pad;
  const w = Math.max(1, maxX-minX), h = Math.max(1, maxY-minY);
  const off = document.createElement("canvas");
  off.width = w; off.height = h;
  const octx = off.getContext("2d");
  octx.fillStyle = "#FFFFFF"; octx.fillRect(0,0,w,h);
  octx.translate(-minX, -minY);
  wb.objects.forEach(o => wbDrawObject(octx, o));
  off.toBlob(blob => {
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "whiteboard.png"; a.click();
    URL.revokeObjectURL(url);
  });
}

// --- window chrome: minimize / maximize / resize ---
function wbSetupChrome() {
  const panel = $("#whiteboardPanel");
  $("#wbMinimize").addEventListener("click", () => {
    panel.classList.toggle("wb-minimized");
  });
  $("#wbMaximize").addEventListener("click", () => {
    panel.classList.toggle("wb-maximized");
    panel.classList.remove("wb-minimized");
    requestAnimationFrame(wbResizeCanvas);
  });
  $all(".wb-resize").forEach(handle => {
    let active = false, dir = handle.dataset.dir, start = null;
    function down(e) {
      if (panel.classList.contains("wb-maximized") || panel.classList.contains("wb-minimized")) return;
      active = true;
      const rect = panel.getBoundingClientRect();
      const p = e.touches ? e.touches[0] : e;
      start = { x: p.clientX, y: p.clientY, w: rect.width, h: rect.height, left: rect.left, top: rect.top };
      panel.style.left = rect.left + "px"; panel.style.top = rect.top + "px";
      panel.style.right = "auto"; panel.style.bottom = "auto";
      document.addEventListener("mousemove", move); document.addEventListener("mouseup", up);
      document.addEventListener("touchmove", move, { passive:false }); document.addEventListener("touchend", up);
      e.preventDefault();
    }
    function move(e) {
      if (!active) return;
      const p = e.touches ? e.touches[0] : e;
      const dx = p.clientX - start.x, dy = p.clientY - start.y;
      let { w, h, left, top } = start;
      if (dir.includes("e")) w = start.w + dx;
      if (dir.includes("s")) h = start.h + dy;
      if (dir.includes("w")) { w = start.w - dx; left = start.left + dx; }
      if (dir.includes("n")) { h = start.h - dy; top = start.top + dy; }
      w = Math.max(420, w); h = Math.max(320, h);
      panel.style.width = w + "px"; panel.style.height = h + "px";
      panel.style.left = left + "px"; panel.style.top = top + "px";
      wbResizeCanvas();
      if (e.cancelable) e.preventDefault();
    }
    function up() {
      active = false;
      document.removeEventListener("mousemove", move); document.removeEventListener("mouseup", up);
      document.removeEventListener("touchmove", move); document.removeEventListener("touchend", up);
    }
    handle.addEventListener("mousedown", down);
    handle.addEventListener("touchstart", down, { passive:false });
  });
}

let wbInitialized = false;
function wbInit() {
  wbInitCanvas(); // itself idempotent, always safe to call (needed to (re)size on reopen)
  if (wbInitialized) return;
  wbInitialized = true;
  wbSetupChrome();
  $all(".wb-tool[data-tool]").forEach(b => b.addEventListener("click", () => wbSetTool(b.dataset.tool)));
  $("#wbUndo").addEventListener("click", wbUndo);
  $("#wbRedo").addEventListener("click", wbRedoFn);
  $("#wbClear").addEventListener("click", wbClearBoard);
  $("#wbExport").addEventListener("click", wbExportPNG);
  $("#wbZoomIn").addEventListener("click", () => wbZoomAt(1.2, wbCanvas.getBoundingClientRect().left + wbCanvas.clientWidth/2, wbCanvas.getBoundingClientRect().top + wbCanvas.clientHeight/2));
  $("#wbZoomOut").addEventListener("click", () => wbZoomAt(0.83, wbCanvas.getBoundingClientRect().left + wbCanvas.clientWidth/2, wbCanvas.getBoundingClientRect().top + wbCanvas.clientHeight/2));
  $("#wbZoomReset").addEventListener("click", () => { wb.zoom = 1; wb.panX = 0; wb.panY = 0; wbRender(); wbSaveSoon(); });
  $("#wbWidth").addEventListener("input", (e) => { wbWidth = parseInt(e.target.value); $("#wbWidthLabel").textContent = wbWidth + "px"; });
  $("#wbColorToggle").addEventListener("click", () => { $("#wbColorPanel").hidden = !$("#wbColorPanel").hidden; $("#wbTablePanel").hidden = true; $("#wbBgPanel").hidden = true; $("#wbTableColorPanel").hidden = true; });
  document.addEventListener("click", (e) => {
    const cp = $("#wbColorPanel"), toggle = $("#wbColorToggle");
    if (cp && !cp.hidden && !cp.contains(e.target) && e.target !== toggle && !toggle.contains(e.target)) cp.hidden = true;
  });
  $("#wbColorPicker").addEventListener("input", (e) => wbSetColor(e.target.value));
  $("#wbHexInput").addEventListener("change", (e) => { if (/^#[0-9A-Fa-f]{6}$/.test(e.target.value)) wbSetColor(e.target.value); });

  // table templates
  const tableList = $("#wbTableList");
  WB_TABLE_TEMPLATES.forEach(t => {
    const item = el("button", "wb-table-item", `<i data-lucide="table-2"></i><span>${t.name}</span>`);
    item.addEventListener("click", () => wbInsertTable(t.id));
    tableList.appendChild(item);
  });
  const customItem = el("button", "wb-table-item", `<i data-lucide="plus-square"></i><span>Custom Table</span>`);
  customItem.addEventListener("click", () => wbInsertTable("custom"));
  tableList.appendChild(customItem);
  $("#wbTableBtn").addEventListener("click", () => { $("#wbTablePanel").hidden = !$("#wbTablePanel").hidden; $("#wbBgPanel").hidden = true; $("#wbColorPanel").hidden = true; $("#wbTableColorPanel").hidden = true; });
  $("#wbBgBtn").addEventListener("click", () => { $("#wbBgPanel").hidden = !$("#wbBgPanel").hidden; $("#wbTablePanel").hidden = true; $("#wbColorPanel").hidden = true; $("#wbTableColorPanel").hidden = true; });
  $all(".wb-bg-option").forEach(b => b.addEventListener("click", () => wbSetBackground(b.dataset.bg)));
  document.addEventListener("click", (e) => {
    const tp = $("#wbTablePanel"), tt = $("#wbTableBtn");
    if (tp && !tp.hidden && !tp.contains(e.target) && e.target !== tt && !tt.contains(e.target)) tp.hidden = true;
    const bp = $("#wbBgPanel"), bt = $("#wbBgBtn");
    if (bp && !bp.hidden && !bp.contains(e.target) && e.target !== bt && !bt.contains(e.target)) bp.hidden = true;
    const tcp = $("#wbTableColorPanel"), tct = $("#wbTableColorBtn");
    if (tcp && !tcp.hidden && !tcp.contains(e.target) && e.target !== tct && !tct.contains(e.target)) tcp.hidden = true;
  });
  $("#wbAddRow").addEventListener("click", () => {
    const t = wb.objects.find(o => wbSelectedIds.includes(o.id) && o.type === "table");
    if (!t) { toast("Select a table first", "info", "info"); return; }
    wbTableAddRow(t);
  });
  $("#wbDelRow").addEventListener("click", () => {
    const t = wb.objects.find(o => wbSelectedIds.includes(o.id) && o.type === "table");
    if (!t) { toast("Select a table first", "info", "info"); return; }
    wbTableDeleteRow(t);
  });
  $("#wbDelTable").addEventListener("click", () => {
    const t = wb.objects.find(o => wbSelectedIds.includes(o.id) && o.type === "table");
    if (!t) { toast("Select a table first", "info", "info"); return; }
    wbPushHistory();
    wb.objects = wb.objects.filter(o => o.id !== t.id);
    wbSelectedIds = [];
    wbRender(); wbSaveSoon();
    toast("Table deleted", "success", "check-circle");
  });

  // --- table colours ---
  const WB_TABLE_COLOR_DEFAULTS = { borderColor: "#4A453E", cellBg: "#FFFFFF", headerBg: "#EDEAE3", textColor: "#14110F" };
  function wbSelectedTable() { return wb.objects.find(o => wbSelectedIds.includes(o.id) && o.type === "table"); }
  function wbOpenTableColorPanel() {
    const panel = $("#wbTableColorPanel");
    const t = wbSelectedTable();
    if (!t) { toast("Select a table first", "info", "info"); return; }
    $("#wbTcBorder").value = t.borderColor || WB_TABLE_COLOR_DEFAULTS.borderColor;
    $("#wbTcCellBg").value = t.cellBg || WB_TABLE_COLOR_DEFAULTS.cellBg;
    $("#wbTcHeaderBg").value = t.headerBg || WB_TABLE_COLOR_DEFAULTS.headerBg;
    $("#wbTcText").value = t.textColor || WB_TABLE_COLOR_DEFAULTS.textColor;
    panel.hidden = false;
    $("#wbTablePanel").hidden = true; $("#wbBgPanel").hidden = true; $("#wbColorPanel").hidden = true;
  }
  $("#wbTableColorBtn").addEventListener("click", () => {
    const panel = $("#wbTableColorPanel");
    if (!panel.hidden) { panel.hidden = true; return; }
    wbOpenTableColorPanel();
  });
  function wbApplyTableColor(field, value) {
    const t = wbSelectedTable();
    if (!t) return;
    if (!wbApplyTableColor._pushed) { wbPushHistory(); wbApplyTableColor._pushed = true; }
    t[field] = value;
    wbRender();
  }
  ["wbTcBorder","wbTcCellBg","wbTcHeaderBg","wbTcText"].forEach(id => {
    const field = { wbTcBorder: "borderColor", wbTcCellBg: "cellBg", wbTcHeaderBg: "headerBg", wbTcText: "textColor" }[id];
    $("#" + id).addEventListener("input", (e) => wbApplyTableColor(field, e.target.value));
    $("#" + id).addEventListener("change", () => { wbApplyTableColor._pushed = false; wbSaveSoon(); });
  });
  $("#wbTcReset").addEventListener("click", () => {
    const t = wbSelectedTable();
    if (!t) { toast("Select a table first", "info", "info"); return; }
    wbPushHistory();
    t.borderColor = null; t.cellBg = null; t.headerBg = null; t.textColor = null;
    wbRender(); wbSaveSoon();
    wbOpenTableColorPanel();
  });

  wbRenderPageTabs();

  window.addEventListener("resize", () => { const p = $("#whiteboardPanel"); if (p && !p.hidden) wbResizeCanvas(); });

  window.addEventListener("keydown", (e) => {
    const panel = $("#whiteboardPanel");
    if (!panel || panel.hidden) return;
    const typing = document.activeElement && ["INPUT","TEXTAREA"].includes(document.activeElement.tagName);
    if (typing) return;
    const mod = e.ctrlKey || e.metaKey;
    if (mod && e.key.toLowerCase() === "z" && e.shiftKey) { e.preventDefault(); wbRedoFn(); }
    else if (mod && e.key.toLowerCase() === "z") { e.preventDefault(); wbUndo(); }
    else if (mod && e.key.toLowerCase() === "y") { e.preventDefault(); wbRedoFn(); }
    else if (mod && e.key.toLowerCase() === "d") { e.preventDefault(); wbDuplicateSelection(); }
    else if (mod && e.key.toLowerCase() === "a") { e.preventDefault(); wbSelectedIds = wb.objects.map(o => o.id); wbRender(); }
    else if (e.key === "Delete" || e.key === "Backspace") { e.preventDefault(); wbDeleteSelection(); }
    else if (e.key.toLowerCase() === "v") wbSetTool("select");
    else if (e.key.toLowerCase() === "p") wbSetTool("pen");
    else if (e.key.toLowerCase() === "e") wbSetTool("eraser");
    else if (e.key.toLowerCase() === "r") wbSetTool("rect");
    else if (e.key.toLowerCase() === "o") wbSetTool("ellipse");
    else if (e.key.toLowerCase() === "l") wbSetTool("line");
    else if (e.key.toLowerCase() === "t") wbSetTool("text");
  });
}

$("#whiteboardToggle").addEventListener("click", () => {
  const wasHidden = $("#whiteboardPanel").hidden;
  togglePanel("whiteboardPanel");
  if (wasHidden) {
    requestAnimationFrame(() => {
      wbResizeCanvas(); // sizing needs real layout, which only exists once the panel is actually visible
      setTimeout(wbResizeCanvas, 350); // re-measure once the entrance animation settles
      const h = $("#wbHint"); if (h) setTimeout(() => h.classList.add("wb-hint-hide"), 4000);
    });
  }
});
wbInit(); // wire up every whiteboard button at script-load time, not lazily on
          // first toggle click — this position is safely after every let/const
          // the whiteboard code depends on, so no temporal-dead-zone issue

/* ---------------------------------------------------------
   14c. AI TUTOR
   A ChatGPT-style chat interface for Class 11 Accountancy.
   It tries a secure backend function first (see
   netlify/functions/ai-tutor.js at the project root) and,
   if that isn't deployed/configured, falls back to a local
   knowledge engine built entirely from this site's own
   journal patterns, theory, concepts, and question banks —
   so the feature works immediately with zero setup, and
   upgrades automatically once a real backend is connected.
   --------------------------------------------------------- */
const AI_CHAT_KEY_PREFIX = "";
// Holds a prompt queued by an "Ask AI about this" contextual button
// elsewhere in the app (a question card, a mistake review, etc.) until
// the AI Tutor view mounts and can send it.
let PENDING_AI_PROMPT = null;
function askAIAbout(promptText, chapterId) {
  PENDING_AI_PROMPT = promptText;
  aiNewChat(chapterId || null);
  navigate("ai-tutor");
}
function aiGetChats() { return STATE.aiChats || (STATE.aiChats = []); }
function aiGetActiveChat() { return aiGetChats().find(c => c.id === STATE.aiActiveChatId) || null; }
function aiNewChat(chapterContext) {
  const chat = { id: Date.now() + "-" + Math.random().toString(36).slice(2, 8), title: "New chat", messages: [], updatedAt: Date.now(), chapterContext: chapterContext || null, lastPattern: null };
  aiGetChats().unshift(chat);
  STATE.aiActiveChatId = chat.id;
  saveState();
  return chat;
}
function aiDeleteChat(id) {
  STATE.aiChats = aiGetChats().filter(c => c.id !== id);
  if (STATE.aiActiveChatId === id) STATE.aiActiveChatId = STATE.aiChats[0] ? STATE.aiChats[0].id : null;
  saveState();
}
function aiTitleFromText(text) {
  const clean = text.trim().replace(/\s+/g, " ");
  return clean.length > 42 ? clean.slice(0, 42) + "…" : (clean || "New chat");
}

/* ---- Tiny markdown-lite formatter for AI messages ---- */
function mdLite(text) {
  const esc = s => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const lines = text.split("\n");
  let html = "", inList = false, inOList = false;
  lines.forEach(line => {
    const trimmed = line.trim();
    const bullet = /^[-•]\s+(.*)/.exec(trimmed);
    const numbered = /^\d+[.)]\s+(.*)/.exec(trimmed);
    if (bullet) {
      if (inOList) { html += "</ol>"; inOList = false; }
      if (!inList) { html += "<ul>"; inList = true; }
      html += `<li>${inlineMd(esc(bullet[1]))}</li>`;
      return;
    }
    if (numbered) {
      if (inList) { html += "</ul>"; inList = false; }
      if (!inOList) { html += "<ol>"; inOList = true; }
      html += `<li>${inlineMd(esc(numbered[1]))}</li>`;
      return;
    }
    if (inList) { html += "</ul>"; inList = false; }
    if (inOList) { html += "</ol>"; inOList = false; }
    if (!trimmed) { html += "<br>"; return; }
    if (/^#{1,4}\s+/.test(trimmed)) { html += `<h4>${inlineMd(esc(trimmed.replace(/^#{1,4}\s+/, "")))}</h4>`; return; }
    html += `<p>${inlineMd(esc(trimmed))}</p>`;
  });
  if (inList) html += "</ul>";
  if (inOList) html += "</ol>";
  return html;
}
function inlineMd(s) {
  return s.replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/`(.+?)`/g, "<code>$1</code>");
}

/* ---- Local knowledge engine ---- */
const AI_CHAPTER_KEYWORDS = {
  eq: ["equation", "accounting equation", "assets", "liabilities", "capital"],
  dc: ["debit", "credit", "golden rule", "personal account", "real account", "nominal account", "balance sheet"],
  jr: ["journal", "journal entry", "narration", "compound entry"],
  lg: ["ledger", "posting", "balancing", "t-account", "t account", "balance c/d", "balance b/d"],
  cb: ["cash book", "petty cash", "contra entry", "imprest", "bank overdraft", "cheques-in-hand", "post-dated cheque", "subsidiary book"],
  sp2: ["purchases book", "sales book", "purchases return", "sales return", "returns outward", "returns inward", "journal proper", "debit note", "credit note", "other books"],
  brs: ["bank reconciliation", "brs", "cash book balance", "pass book balance", "unpresented cheque", "uncollected cheque", "dishonoured cheque", "bank charges", "bank interest"],
  gst: ["gst", "goods and services tax", "cgst", "sgst", "igst", "input gst", "output gst", "taxable value", "trade discount", "invoice value"],
  dep: ["depreciation", "depletion", "amortisation", "slm", "wdv", "straight line method", "written down value", "residual value", "scrap value", "asset disposal", "provision for depreciation"],
  tb: ["trial balance", "balance method", "debit balance", "credit balance", "agree", "tally", "error of omission", "error of principle", "compensating error", "casting error"]
};
function aiDetectChapter(text) {
  const lower = text.toLowerCase();
  for (const ch of ["tb", "dep", "gst", "brs", "cb", "sp2", "lg", "jr", "dc", "eq"]) {
    if (AI_CHAPTER_KEYWORDS[ch].some(k => lower.includes(k))) return ch;
  }
  return null;
}
function aiFindTheoryMatch(text) {
  const lower = text.toLowerCase();
  const stop = new Set(["what", "is", "the", "a", "an", "explain", "why", "how", "does", "do", "of", "in", "to", "for", "and", "me", "about"]);
  const words = lower.replace(/[^a-z0-9\s]/g, " ").split(/\s+/).filter(w => w.length > 2 && !stop.has(w));
  if (!words.length) return null;
  const CH_NAME = { eq: "Accounting Equation", dc: "Rules of Debit & Credit", jr: "Journal", lg: "Ledger", cb: "Special Purpose Books 1 - Cash Book", sp2: "Special Purpose Books 2 - Other Books", brs: "Bank Reconciliation Statement (BRS)", gst: "Accounting of GST", tb: "Trial Balance", dep: "Depreciation" };
  const CH_DATA_KEY = { eq: "equation", dc: "debitCredit", jr: "journal", lg: "ledger", cb: "cashBook", sp2: "specialBooks2", brs: "brs", gst: "gst", tb: "tb", dep: "dep" };
  let best = null, bestScore = 0;
  ["eq", "dc", "jr", "lg", "cb", "sp2", "brs", "gst", "tb", "dep"].forEach(ch => {
    const data = APP_DATA[CH_DATA_KEY[ch]];
    if (!data || !data.theory) return;
    [...(data.theory.simple || []), ...(data.theory.advanced || [])].forEach(block => {
      const hay = (block.h + " " + (block.p || "") + " " + (block.p2 || "")).toLowerCase();
      const score = words.filter(w => hay.includes(w)).length;
      if (score > bestScore) { bestScore = score; best = { block, ch: CH_NAME[ch], route: `ch-${ch}` }; }
    });
    (data.concepts || []).forEach(c => {
      const hay = (c.title + " " + c.body).toLowerCase();
      const score = words.filter(w => hay.includes(w)).length;
      if (score > bestScore) { bestScore = score; best = { block: { h: c.title, p: c.body }, ch: CH_NAME[ch], route: `ch-${ch}` }; }
    });
  });
  return bestScore >= 2 ? best : null;
}
function aiRandomPractice(chapterId, difficulty) {
  const pools = {
    eq: APP_DATA.equation.numericals, dc: APP_DATA.debitCredit.numericals,
    jr: APP_DATA.journal.numericals, lg: (typeof getLedgerPracticePool === "function" ? getLedgerPracticePool() : []),
    cb: APP_DATA.cashBook.numericals, sp2: APP_DATA.specialBooks2.numericals, brs: APP_DATA.brs.numericals, gst: APP_DATA.gst.numericals, tb: APP_DATA.tb.numericals, dep: APP_DATA.dep.numericals
  };
  let pool = pools[chapterId] || [...pools.eq, ...pools.dc, ...pools.jr, ...pools.lg, ...pools.cb, ...pools.sp2, ...pools.brs, ...pools.gst, ...pools.tb, ...pools.dep];
  if (difficulty) pool = pool.filter(q => (q.difficulty || "").toLowerCase() === difficulty);
  if (!pool.length) pool = pools[chapterId] || pools.eq;
  return pool[Math.floor(Math.random() * pool.length)] || null;
}
function aiCheckStudentAnswer(text, pattern) {
  if (!pattern || pattern.compound) return null;
  const lower = text.toLowerCase();
  const cleanAcct = s => (s || "").replace(/\{name\}/gi, "").replace(/a\/c|dr\.?|to\b/gi, "").trim().toLowerCase();
  const debitAcct = cleanAcct(pattern.debitTemplate || pattern.debit);
  const creditAcct = cleanAcct(pattern.creditTemplate || pattern.credit);
  if (!debitAcct || !creditAcct) return null;
  const hasDebit = lower.includes(debitAcct.split(" ")[0]);
  const hasCredit = lower.includes(creditAcct.split(" ")[0]);
  const debitMarkedCredit = new RegExp(debitAcct.split(" ")[0] + "[^.]*(cr\\.|credit)", "i").test(text);
  const creditMarkedDebit = new RegExp(creditAcct.split(" ")[0] + "[^.]*(dr\\.|debit)", "i").test(text);
  if (hasDebit && hasCredit && !debitMarkedCredit && !creditMarkedDebit) {
    return `✅ **That's correct!** ${aiFormatPatternEntry(pattern)}`;
  }
  if (debitMarkedCredit || creditMarkedDebit) {
    return `❌ **There's a mix-up in your entry.** It looks like the debit and credit sides may be swapped.\n\n**Correct reasoning:** ${pattern.narration}.\n\n${aiFormatPatternEntry(pattern)}`;
  }
  return `Here's how I'd check that:\n\n**Correct reasoning:** ${pattern.narration}.\n\n${aiFormatPatternEntry(pattern)}\n\nCompare that against what you wrote — if an account name or side doesn't match, that's the fix needed.`;
}
function aiFormatPatternEntry(pattern) {
  if (pattern.compound) {
    const partLabel = pattern.parts.map(p => p.template.replace("{name}", "the party")).join(" and ");
    const totalLabel = pattern.totalTemplate.replace("{name}", "the party");
    return pattern.partsSide === "debit"
      ? `**${partLabel} Dr.**\n**${totalLabel}**`
      : `**${totalLabel} Dr.**\n**${partLabel.split(" and ").map(p => "To " + p).join("\n")}**`;
  }
  const debit = (pattern.debitTemplate || pattern.debit || "").replace("{name}", "the party");
  const credit = (pattern.creditTemplate || pattern.credit || "").replace("{name}", "the party");
  return `**${debit} Dr.**\n**To ${credit.replace(/^To\s+/i, "")}**\n\n*(${pattern.narration})*`;
}
function aiExplainWhy(pattern) {
  if (!pattern) return "Ask me about a specific transaction first (e.g. \"Paid rent ₹5,000 in cash\"), and I'll walk through exactly why each account is debited or credited.";
  const debit = (pattern.debitTemplate || pattern.debit || "").replace("{name}", "the party").replace(/A\/c.*/i, "A/c").trim();
  const credit = (pattern.creditTemplate || pattern.credit || "").replace("{name}", "the party").replace(/^To\s+/i, "").trim();
  return `Here's the reasoning behind it:\n\n1. **Accounts involved:** ${debit} and ${credit.replace(/A\/c.*/i, "A/c")}\n2. **What's happening:** ${pattern.narration}.\n3. **Rule applied:** in the traditional system this comes down to whether each account is Personal, Real, or Nominal — Personal accounts debit the receiver and credit the giver, Real accounts debit what comes in and credit what goes out, and Nominal accounts debit expenses/losses and credit incomes/gains.\n4. **Result:** ${debit} is debited, and ${credit} is credited.\n\nIf you want the account-type breakdown for this exact transaction, check the Practice Bank in Chapter 2 — Rules of Debit & Credit.`;
}
function aiSimplify(prevText) {
  const stripped = prevText.replace(/<[^>]+>/g, "");
  const firstSentence = stripped.split(/[.\n]/)[0];
  return `In plain words: ${firstSentence ? firstSentence.trim() + "." : "let's break that down further."}\n\nThink of it step by step — figure out what actually moved (cash, goods, a person owing money), decide if that thing increased or decreased, and then apply the matching rule. If you tell me the specific transaction again, I can walk through it slowly, one small piece at a time.`;
}

const AI_WELCOME_PROMPTS = [
  { icon: "book-open", label: "Learn a Concept", text: "Explain Debit and Credit in simple words" },
  { icon: "calculator", label: "Solve a Problem", text: "Help me solve this Journal Entry: Started business with cash ₹50,000" },
  { icon: "search", label: "Understand the Reason", text: "Why is Cash Account debited?" },
  { icon: "pencil", label: "Practice", text: "Give me a Class 11 Accountancy question" },
  { icon: "target", label: "Exam Preparation", text: "Test me on the Accounting Equation" }
];

function aiLocalBrain(text, chat) {
  const lower = text.toLowerCase().trim();

  if (/^why\??$/.test(lower) || (lower.includes("why") && lower.length < 20)) {
    return { text: aiExplainWhy(chat.lastPattern), quick: ["explain-simply", "practice"] };
  }
  if (lower.includes("explain simply") || lower.includes("explain simpler") || lower.includes("simple words") && lower.length < 30) {
    const lastBot = [...chat.messages].reverse().find(m => m.role === "assistant");
    return { text: aiSimplify(lastBot ? lastBot.text : "that concept"), quick: ["why", "practice"] };
  }
  if (lower.includes("hint")) {
    if (chat.pendingPractice) {
      return { text: `💡 **Hint:** ${chat.pendingPractice.hint || "Think about which accounts are affected and whether each one increases or decreases."}`, quick: ["show-solution"] };
    }
    return { text: "Ask me for a practice question first (\"give me a practice question\"), and I'll give you hints on that one before showing the full solution.", quick: ["practice"] };
  }
  if (lower.includes("show") && lower.includes("solution") && chat.pendingPractice) {
    const q = chat.pendingPractice;
    const answer = q.explanation || q.answer || q.narration || "Check the matching chapter's Practice Bank for the full worked solution.";
    chat.pendingPractice = null;
    return { text: `✅ **Full solution:**\n\n${answer}`, quick: ["practice", "another-example"] };
  }
  if (lower.includes("practice question") || lower.includes("give me a question") || lower.includes("test me") || (lower.includes("practice") && lower.length < 25)) {
    const ch = aiDetectChapter(text) || chat.chapterContext || "eq";
    const diff = lower.includes("hard") ? "hard" : lower.includes("easy") ? "easy" : lower.includes("medium") ? "medium" : null;
    const q = aiRandomPractice(ch, diff);
    if (!q) return { text: "I couldn't find a practice question for that right now — try asking for a different chapter.", quick: [] };
    chat.pendingPractice = q;
    const qText = q.transaction || q.q || q.question || "Practice question";
    return { text: `Here's one for you (${(q.difficulty || "").toLowerCase() || "medium"} difficulty):\n\n**${qText}**\n\nTry working it out, then ask me for a **hint** or say **"show solution"**.`, quick: ["hint", "show-solution"] };
  }
  if ((lower.includes(" dr.") || lower.includes(" dr ") || /\bto\s+\w+\s*a\/c/i.test(text)) && chat.lastPattern) {
    const check = aiCheckStudentAnswer(text, chat.lastPattern);
    if (check) return { text: check, quick: ["why", "practice"] };
  }

  const pattern = matchJournalPattern(text);
  if (pattern) {
    chat.lastPattern = pattern;
    const debit = (pattern.debitTemplate || pattern.debit || "").replace("{name}", extractName(text)).trim();
    const credit = (pattern.creditTemplate || pattern.credit || "").replace("{name}", extractName(text)).trim();
    let reply = `Let's work through this one:\n\n**Accounts involved:** ${debit.replace(/A\/c.*/i,"A/c")} and ${credit.replace(/^To\s+/i,"").replace(/A\/c.*/i,"A/c")}\n\n${pattern.narration}.\n\n**Journal entry:**\n${aiFormatPatternEntry({ ...pattern, debitTemplate: debit, creditTemplate: credit })}`;
    if (pattern.compound) reply = `This is a **compound entry** — more than two accounts are involved.\n\n${pattern.narration}.\n\n${aiFormatPatternEntry(pattern)}\n\nMake sure you mention every amount in order when asking me to fill one of these in.`;
    return { text: reply, quick: ["why", "explain-simply", "practice"] };
  }

  const theoryMatch = aiFindTheoryMatch(text);
  if (theoryMatch) {
    const b = theoryMatch.block;
    let reply = `**${b.h}**\n\n${b.p || ""}`;
    if (b.formula) reply += `\n\n${b.formula}`;
    if (b.p2) reply += `\n\n${b.p2}`;
    reply += `\n\n*(From ${theoryMatch.ch} — open that chapter's Theory tab for the full picture.)*`;
    return { text: reply, quick: ["explain-simply", "practice"], route: theoryMatch.route };
  }

  return {
    text: `I couldn't confidently match that to something in the Class 11 syllabus covered here. I'm best with:\n\n- Specific transactions — try *"Paid rent ₹5,000 in cash"* or *"Sold goods on credit to Meera ₹20,000"*\n- Concept questions — try *"What is a Real Account?"* or *"Explain the Accounting Equation"*\n- **"Give me a practice question"** for a random problem\n\nWant to try rephrasing, or pick one of the suggestions below?`,
    quick: ["practice", "why"]
  };
}

const AI_QUICK_ACTION_LABELS = {
  "explain-simply": { icon: "baby", label: "Explain Simply", text: "Explain that more simply" },
  "why": { icon: "help-circle", label: "Why?", text: "Why?" },
  "hint": { icon: "lightbulb", label: "Give me a Hint", text: "Give me a hint" },
  "show-solution": { icon: "eye", label: "Show Full Solution", text: "Show solution" },
  "practice": { icon: "target", label: "Give Me Practice", text: "Give me a practice question" },
  "another-example": { icon: "refresh-cw", label: "Another Example", text: "Give me another example" },
  "try-yourself": { icon: "pencil", label: "Try It Myself", text: "I'll try it myself" },
  "mode-hint": { icon: "lightbulb", label: "Hint", text: "hint mode" },
  "mode-steps": { icon: "list-ordered", label: "Steps", text: "show steps mode" },
  "mode-final": { icon: "flag", label: "Final Answer", text: "final answer mode" },
  "check-answer": { icon: "check-circle", label: "Check My Answer", text: "check my answer" }
};

/* ---- Backend hook: tries a real AI function first, falls back to
   the local engine above if it's not deployed/configured/reachable. ---- */
async function aiRespond(text, chat, image) {
  try {
    const controller = new AbortController();
    // Image requests genuinely take longer (upload + vision processing),
    // so give those extra time before falling back.
    const timeout = setTimeout(() => controller.abort(), image ? 20000 : 8000);
    const res = await fetch("/.netlify/functions/ai-tutor", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message: text,
        history: chat.messages.slice(0, -1).slice(-10),
        chapterContext: chat.chapterContext,
        answerMode: chat.answerMode || "steps",
        image: image || undefined
      }),
      signal: controller.signal
    });
    clearTimeout(timeout);
    if (res.ok) {
      const data = await res.json();
      if (data && data.reply) return { text: data.reply, quick: data.quick || ["why", "explain-simply", "practice"] };
    }
    throw new Error("backend unavailable");
  } catch (e) {
    if (image) {
      // Be honest: the local rule-based engine has no vision capability at
      // all, unlike text questions where it can still be genuinely useful.
      return {
        text: "I couldn't reach the AI vision backend to read that image right now (it may not be configured, or the connection timed out). This site's offline fallback tutor can't read photos — but if you type out the transaction or question in words, I can walk through it with you step by step.",
        quick: ["practice"]
      };
    }
    // Try the richer conversational/calculation engine first (greetings,
    // Hint/Steps/Final modes, calculations, multi-transaction, answer
    // checking); it returns null for anything outside its scope, in which
    // case the original local brain (pattern + theory matching) handles it.
    if (typeof TutorEngine !== "undefined") {
      try {
        const engineResult = TutorEngine.respond(text, chat);
        if (engineResult) return engineResult;
      } catch (engineErr) { /* fall through to the older local brain */ }
    }
    return aiLocalBrain(text, chat);
  }
}

function renderAITutor(root) {
  root.classList.add("ai-route-root");
  const shell = el("div", "ai-tutor-shell");
  shell.innerHTML = `
    <div class="ai-tutor-header">
      <button id="aiHistoryToggle" class="icon-btn sm" title="Chat history"><i data-lucide="panel-left"></i></button>
      <div class="ai-header-title">
        <span><i data-lucide="bot" style="width:16px;height:16px;vertical-align:-3px;"></i> AI Tutor</span>
        <span class="ai-context-badge" id="aiContextBadge" hidden></span>
      </div>
      <div class="ai-mode-switch" id="aiModeSwitch" title="How much detail should answers show?">
        <button class="ai-mode-btn" data-mode="hint">Hint</button>
        <button class="ai-mode-btn is-active" data-mode="steps">Steps</button>
        <button class="ai-mode-btn" data-mode="final">Final</button>
      </div>
      <button id="aiNewChatBtn" class="btn-ghost sm ripple-surface"><i data-lucide="plus"></i> New Chat</button>
    </div>
    <div class="ai-tutor-body">
      <div class="ai-history-overlay" id="aiHistoryOverlay" hidden></div>
      <aside class="ai-history-drawer" id="aiHistoryDrawer">
        <div class="ai-history-head">
          <span>Chats</span>
          <button class="icon-btn sm" id="aiHistoryClose"><i data-lucide="x"></i></button>
        </div>
        <div class="ai-history-list" id="aiHistoryList"></div>
      </aside>
      <div class="ai-chat-main">
        <div class="ai-messages" id="aiMessages"></div>
        <div class="ai-input-bar">
          <div class="ai-image-preview" id="aiImagePreview" hidden>
            <img id="aiImagePreviewImg" alt="Attached question">
            <button id="aiImageRemove" class="icon-btn sm" title="Remove image"><i data-lucide="x"></i></button>
          </div>
          <div class="ai-input-row">
            <button id="aiImageBtn" class="icon-btn sm" title="Upload a photo of your question"><i data-lucide="image-plus"></i></button>
            <textarea id="aiInput" placeholder="Ask about any Class 11 Accountancy topic…" rows="1"></textarea>
            <button id="aiSendBtn" class="btn-primary sm ripple-surface" title="Send"><i data-lucide="send"></i></button>
          </div>
          <input type="file" id="aiImageInput" accept="image/*" hidden>
          <p class="ai-disclaimer">Answers are generated from this site's own Class 11 content — always double-check against your textbook before an exam.</p>
        </div>
      </div>
    </div>
  `;
  root.appendChild(shell);
  icons();

  let pendingImage = null;

  function scrollToBottom() {
    const m = $("#aiMessages");
    m.scrollTop = m.scrollHeight;
  }

  function renderHistoryList() {
    const list = $("#aiHistoryList");
    const chats = aiGetChats();
    if (!chats.length) { list.innerHTML = `<p style="font-size:0.82rem; color:var(--ink-faint); padding:14px;">No chats yet — start one below.</p>`; return; }
    list.innerHTML = chats.map(c => `
      <div class="ai-history-item ${c.id === STATE.aiActiveChatId ? "active" : ""}" data-chat="${c.id}">
        <i data-lucide="message-square" style="width:14px;height:14px; flex-shrink:0;"></i>
        <span class="ai-history-item-title">${c.title}</span>
        <button class="ai-history-delete" data-delete="${c.id}" title="Delete chat"><i data-lucide="trash-2"></i></button>
      </div>
    `).join("");
    icons();
    $all(".ai-history-item", list).forEach(item => {
      item.addEventListener("click", (e) => {
        if (e.target.closest("[data-delete]")) return;
        STATE.aiActiveChatId = item.dataset.chat;
        saveState();
        renderAll();
        closeHistoryDrawer();
      });
    });
    $all("[data-delete]", list).forEach(btn => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        if (!confirm("Delete this chat? This can't be undone.")) return;
        aiDeleteChat(btn.dataset.delete);
        renderAll();
      });
    });
  }

  function renderContextBadge() {
    const chat = aiGetActiveChat();
    const badge = $("#aiContextBadge");
    if (chat && chat.chapterContext) {
      const CH_NAME = { eq: "Accounting Equation", dc: "Debit & Credit", jr: "Journal", lg: "Ledger", cb: "Special Purpose Books 1 - Cash Book", sp2: "Special Purpose Books 2 - Other Books", brs: "Bank Reconciliation Statement (BRS)", gst: "Accounting of GST" };
      badge.hidden = false;
      badge.textContent = `Studying: ${CH_NAME[chat.chapterContext] || chat.chapterContext}`;
    } else {
      badge.hidden = true;
    }
    const mode = (chat && chat.answerMode) || "steps";
    $all(".ai-mode-btn", $("#aiModeSwitch")).forEach(b => b.classList.toggle("is-active", b.dataset.mode === mode));
  }

  function messageBubble(msg, msgIndex) {
    const bubble = el("div", `ai-msg ai-msg-${msg.role}`);
    let inner = "";
    if (msg.role === "user") {
      inner = `<div class="ai-msg-bubble">${msg.image ? `<img src="${msg.image}" class="ai-msg-image" alt="Uploaded question">` : ""}${msg.text ? `<p>${msg.text.replace(/</g,"&lt;")}</p>` : ""}</div>`;
      bubble.innerHTML = inner;
      return bubble;
    }
    inner = `<div class="ai-msg-avatar"><i data-lucide="bot"></i></div><div class="ai-msg-col"><div class="ai-msg-bubble">${mdLite(msg.text)}${msg.journalHTML || ""}${msg.sectionsHTML || ""}</div><div class="ai-msg-actions">
      <button class="ai-msg-action" data-act="copy" title="Copy"><i data-lucide="copy"></i></button>
      <button class="ai-msg-action" data-act="regenerate" title="Regenerate"><i data-lucide="refresh-cw"></i></button>
      <button class="ai-msg-action ${msg.feedback === 'up' ? 'active-good' : ''}" data-act="up" title="Helpful"><i data-lucide="thumbs-up"></i></button>
      <button class="ai-msg-action ${msg.feedback === 'down' ? 'active-bad' : ''}" data-act="down" title="Not helpful"><i data-lucide="thumbs-down"></i></button>
    </div></div>`;
    bubble.innerHTML = inner;

    const act = (name) => $(`[data-act="${name}"]`, bubble);
    act("copy").addEventListener("click", () => {
      const plain = msg.text.replace(/\*\*(.+?)\*\*/g, "$1").replace(/`(.+?)`/g, "$1");
      navigator.clipboard.writeText(plain).then(() => toast("Copied to clipboard", "success", "copy")).catch(() => toast("Couldn't copy", "error", "alert-circle"));
    });
    act("regenerate").addEventListener("click", async () => {
      const chat = aiGetActiveChat();
      if (!chat) return;
      // Find the user message that immediately precedes this assistant reply.
      let userMsg = null;
      for (let i = msgIndex - 1; i >= 0; i--) {
        if (chat.messages[i].role === "user") { userMsg = chat.messages[i]; break; }
      }
      if (!userMsg) { toast("Nothing to regenerate from", "error", "alert-circle"); return; }
      chat.messages.splice(msgIndex, 1);
      saveState();
      renderMessages();
      const typingEl = showTyping();
      const replyObj = await aiRespond(userMsg.text, chat, userMsg.image || null);
      typingEl.remove();
      chat.messages.push({ role: "assistant", text: replyObj.text, quick: replyObj.quick, journalHTML: replyObj.journalHTML, sectionsHTML: replyObj.sectionsHTML, ts: Date.now() });
      chat.updatedAt = Date.now();
      saveState();
      renderMessages();
    });
    act("up").addEventListener("click", () => {
      const chat = aiGetActiveChat();
      if (!chat) return;
      msg.feedback = msg.feedback === "up" ? null : "up";
      saveState(); renderMessages();
      if (msg.feedback === "up") toast("Thanks for the feedback!", "success", "thumbs-up");
    });
    act("down").addEventListener("click", () => {
      const chat = aiGetActiveChat();
      if (!chat) return;
      msg.feedback = msg.feedback === "down" ? null : "down";
      saveState(); renderMessages();
      if (msg.feedback === "down") toast("Thanks — noted for improvement", "success", "thumbs-down");
    });
    return bubble;
  }

  function renderQuickActions(container, keys) {
    if (!keys || !keys.length) return;
    const bar = el("div", "ai-quick-actions");
    keys.forEach(k => {
      const meta = AI_QUICK_ACTION_LABELS[k];
      if (!meta) return;
      const b = el("button", "chip ripple-surface ai-quick-chip", `<i data-lucide="${meta.icon}"></i> ${meta.label}`);
      b.addEventListener("click", () => sendMessage(meta.text));
      bar.appendChild(b);
    });
    container.appendChild(bar);
    icons();
  }

  function renderMessages() {
    const wrap = $("#aiMessages");
    wrap.innerHTML = "";
    const chat = aiGetActiveChat();
    if (!chat || !chat.messages.length) {
      const welcome = el("div", "ai-welcome");
      welcome.innerHTML = `
        <div class="ai-welcome-icon"><i data-lucide="bot"></i></div>
        <h2>Hi! I'm your Accountancy AI Tutor 👋</h2>
        <p class="ai-welcome-sub">Ask me anything about Class 11 Accountancy.</p>
        <p class="ai-welcome-desc">I can explain concepts, solve numerical problems, check your answers, give hints, and help you prepare for exams.</p>
        <div class="ai-prompt-grid" id="aiPromptGrid"></div>
      `;
      wrap.appendChild(welcome);
      const grid = $("#aiPromptGrid");
      AI_WELCOME_PROMPTS.forEach(p => {
        const card = el("button", "ai-prompt-card ripple-surface", `<i data-lucide="${p.icon}"></i><span class="ai-prompt-label">${p.label}</span><span class="ai-prompt-text">"${p.text}"</span>`);
        card.addEventListener("click", () => sendMessage(p.text));
        grid.appendChild(card);
      });
      icons();
      return;
    }
    chat.messages.forEach((msg, i) => wrap.appendChild(messageBubble(msg, i)));
    const lastMsg = chat.messages[chat.messages.length - 1];
    if (lastMsg && lastMsg.role === "assistant" && lastMsg.quick) renderQuickActions(wrap, lastMsg.quick);
    icons();
    scrollToBottom();
  }

  function showTyping() {
    const wrap = $("#aiMessages");
    const t = el("div", "ai-msg ai-msg-assistant ai-typing-msg");
    t.innerHTML = `<div class="ai-msg-avatar"><i data-lucide="bot"></i></div><div class="ai-msg-bubble ai-typing"><span>AI Tutor is thinking</span><span class="ai-typing-dots"><i></i><i></i><i></i></span></div>`;
    wrap.appendChild(t);
    icons();
    scrollToBottom();
    return t;
  }

  async function sendMessage(textArg) {
    const input = $("#aiInput");
    const text = (textArg !== undefined ? textArg : input.value).trim();
    if (!text && !pendingImage) return;
    let chat = aiGetActiveChat();
    if (!chat) chat = aiNewChat(aiDetectChapter(text));
    if (!chat.chapterContext) chat.chapterContext = aiDetectChapter(text);

    chat.messages.push({ role: "user", text, image: pendingImage, ts: Date.now() });
    if (chat.messages.length === 1) chat.title = aiTitleFromText(text || "Image question");
    chat.updatedAt = Date.now();
    saveState();
    input.value = ""; input.style.height = "auto";
    const hadImage = !!pendingImage;
    pendingImage = null;
    $("#aiImagePreview").hidden = true;
    renderMessages();
    renderHistoryList();
    renderContextBadge();

    const typingEl = showTyping();
    const replyObj = await aiRespond(text, chat, hadImage ? chat.messages[chat.messages.length - 1].image : null);
    typingEl.remove();
    chat.messages.push({ role: "assistant", text: replyObj.text, quick: replyObj.quick, journalHTML: replyObj.journalHTML, sectionsHTML: replyObj.sectionsHTML, ts: Date.now() });
    chat.updatedAt = Date.now();
    saveState();
    renderMessages();
    renderHistoryList();
    renderContextBadge();
    addXP(1, "Asked the AI Tutor");
    playSuccessSound();
  }

  function renderAll() {
    renderContextBadge();
    renderHistoryList();
    renderMessages();
  }

  function openHistoryDrawer() { $("#aiHistoryDrawer").classList.add("open"); $("#aiHistoryOverlay").hidden = false; }
  function closeHistoryDrawer() { $("#aiHistoryDrawer").classList.remove("open"); $("#aiHistoryOverlay").hidden = true; }
  $("#aiHistoryToggle").addEventListener("click", openHistoryDrawer);
  $("#aiHistoryClose").addEventListener("click", closeHistoryDrawer);
  $("#aiHistoryOverlay").addEventListener("click", closeHistoryDrawer);

  $("#aiNewChatBtn").addEventListener("click", () => {
    aiNewChat(aiDetectChapter(window.location.hash.replace("#", "")));
    renderAll();
    closeHistoryDrawer();
  });

  $all(".ai-mode-btn", $("#aiModeSwitch")).forEach(btn => {
    btn.addEventListener("click", () => {
      const chat = aiGetActiveChat() || aiNewChat();
      chat.answerMode = btn.dataset.mode;
      saveState();
      renderContextBadge();
      const modePhrase = { hint: "hint mode", steps: "show steps mode", final: "final answer mode" }[btn.dataset.mode];
      sendMessage(modePhrase);
    });
  });

  const input = $("#aiInput");
  input.addEventListener("input", () => { input.style.height = "auto"; input.style.height = Math.min(input.scrollHeight, 140) + "px"; });
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  });
  $("#aiSendBtn").addEventListener("click", () => sendMessage());

  $("#aiImageBtn").addEventListener("click", () => $("#aiImageInput").click());
  $("#aiImageInput").addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (file.size > 8 * 1024 * 1024) { toast("Image is too large — please use one under 8MB", "error", "alert-circle"); return; }
    const reader = new FileReader();
    reader.onload = () => {
      pendingImage = reader.result;
      $("#aiImagePreviewImg").src = pendingImage;
      $("#aiImagePreview").hidden = false;
    };
    reader.readAsDataURL(file);
  });
  $("#aiImageRemove").addEventListener("click", () => { pendingImage = null; $("#aiImagePreview").hidden = true; $("#aiImageInput").value = ""; });

  // Auto-detect chapter context from wherever the user came from (e.g. a
  // chapter page), so a brand-new chat can greet them appropriately.
  if (!aiGetActiveChat()) {
    const lastChapter = STATE.lastChapterViewed;
    if (aiGetChats().length === 0 && lastChapter) {
      // Don't auto-create a chat — just remember context for the next one sent.
    }
  }

  renderAll();

  // If the student arrived here via an "Ask AI about this" contextual
  // button (from a question card, a mistake, etc.), send that prompt
  // automatically so the AI Tutor feels like part of the page they came
  // from, not a separate cold-start chatbot.
  if (PENDING_AI_PROMPT) {
    const prompt = PENDING_AI_PROMPT;
    PENDING_AI_PROMPT = null;
    setTimeout(() => sendMessage(prompt), 120);
  }
}

// Track the last chapter a person viewed, so a fresh AI Tutor chat can
// greet them with the right context ("You're currently studying Journal…").
(function trackLastChapter() {
  window.addEventListener("hashchange", () => {
    const route = window.location.hash.replace("#", "");
    const map = { "ch-eq": "eq", "ch-dc": "dc", "ch-jr": "jr", "ch-lg": "lg", "ch-cb": "cb", "ch-sp2": "sp2", "ch-brs": "brs", "ch-gst": "gst", "ch-tb": "tb", "ch-dep": "dep" };
    if (map[route]) STATE.lastChapterViewed = map[route];
  });
})();

/* ---------------------------------------------------------
   15. STUDY-TIME TRACKER (background, saves periodically)
   --------------------------------------------------------- */
setInterval(() => { STATE.studySeconds++; }, 1000);
setInterval(saveState, 15000);
window.addEventListener("beforeunload", saveState);

/* ---------------------------------------------------------
   16. INIT
   --------------------------------------------------------- */
function init() {
  applyTheme();
  $("#xpCount").textContent = STATE.xp;
  $("#streakCount").textContent = STATE.streak;
  refreshProgress();
  touchStreak();
  attachRipple(document.body);
  attachClickSound(document.body);
  renderRoute();
  // Intro sound needs a user gesture on some browsers to unlock audio;
  // we attempt it immediately, and it will simply be silent (no error)
  // if the browser blocks autoplay-without-interaction — the very next
  // click anywhere re-attempts context resume via getAudioCtx().
  playIntroSound();
  setTimeout(() => $("#preloader").classList.add("hide"), 3500);
  if (!STATE.userName) {
    setTimeout(() => showWelcomeModal(), STATE.reduceMotion ? 400 : 900);
  }
}
document.addEventListener("DOMContentLoaded", init);
if (document.readyState !== "loading") init();
