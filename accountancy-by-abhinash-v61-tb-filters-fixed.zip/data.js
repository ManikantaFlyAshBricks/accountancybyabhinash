/* ============================================================
   ACCOUNTANCY MASTER — DATA LAYER
   All content below is original: written fresh for this app,
   not copied from any textbook or third-party site.
   ============================================================ */

const APP_DATA = {

  chapters: [
    {
      id: "eq",
      num: 1,
      name: "Accounting Equation",
      tagline: "The one rule the entire subject is built on",
      icon: "scale",
      color: "var(--c-eq)"
    },
    {
      id: "dc",
      num: 2,
      name: "Rules of Debit & Credit",
      tagline: "Three account types, two rule systems, zero guessing",
      icon: "arrow-left-right",
      color: "var(--c-dc)"
    },
    {
      id: "jr",
      num: 3,
      name: "Journal",
      tagline: "Where every transaction gets its first, permanent record",
      icon: "book-text",
      color: "var(--c-jr)"
    },
    {
      id: "lg",
      num: 4,
      name: "Ledger",
      tagline: "Learn posting from journal to ledger, T-accounts, balancing accounts, and ledger preparation.",
      icon: "book-marked",
      color: "var(--c-lg)"
    },
    {
      id: "cb",
      num: 5,
      name: "Special Purpose Books 1 - Cash Book",
      tagline: "Cash and bank in one book — features, types, contra entries, and Petty Cash Book.",
      icon: "wallet",
      color: "var(--c-cb)"
    },
    {
      id: "sp2",
      num: 6,
      name: "Special Purpose Books 2 - Other Books",
      tagline: "Purchases Book, Sales Book, Purchases Return Book, Sales Return Book, and Journal Proper.",
      icon: "receipt",
      color: "var(--c-sp2)"
    },
    {
      id: "brs",
      num: 7,
      name: "Bank Reconciliation Statement (BRS)",
      tagline: "Why Cash Book and Pass Book balances differ — and how to reconcile them, step by step.",
      icon: "landmark",
      color: "var(--c-brs)"
    },
    {
      id: "gst",
      num: 8,
      name: "Accounting of GST",
      tagline: "Meaning, characteristics, and advantages of GST — plus simple GST calculations in everyday business transactions.",
      icon: "indian-rupee",
      color: "var(--c-gst)"
    },
    {
      id: "tb",
      num: 9,
      name: "Trial Balance",
      tagline: "Listing every ledger balance to check arithmetical accuracy — preparation, format, and its real limitations.",
      icon: "scale",
      color: "var(--c-tb)"
    },
    {
      id: "dep",
      num: 10,
      name: "Depreciation",
      tagline: "Why asset values fall over time — SLM, WDV, provision accounts, and disposal of assets.",
      icon: "trending-down",
      color: "var(--c-dep)"
    }
  ],

  /* ============================================================
     MIND MAPS — one radial map per chapter, rendered by the
     Visual Mind Map tool. Each map has a central idea and a
     small number of primary branches, each carrying its own
     short sub-nodes — a genuine hierarchy of the chapter's
     structure, not a flat list of cards.
     ============================================================ */
  mindmaps: {
    eq: {
      center: "Accounting\nEquation",
      branches: [
        {
          label: "The Core Formula",
          color: "var(--c-eq)",
          children: ["Assets = Capital + Liabilities", "Always balances — no exceptions", "Rearranges to find any one variable"]
        },
        {
          label: "The Three Elements",
          color: "var(--c-dc)",
          children: ["Assets — what the business owns", "Liabilities — owed to outsiders", "Capital — owed to the owner"]
        },
        {
          label: "What Moves Capital",
          color: "var(--gold)",
          children: ["Profit — increases it", "Loss — decreases it", "Drawings — decreases it", "Fresh capital introduced — increases it"]
        },
        {
          label: "Transaction Patterns",
          color: "var(--c-jr)",
          children: ["Asset ↔ Asset — no net change", "Asset ↑ with Liability ↑", "Asset ↑ with Capital ↑ (income)", "Asset ↓ with Capital ↓ (expense)"]
        },
        {
          label: "Concepts Behind It",
          color: "var(--flag)",
          children: ["Dual Aspect — two effects per transaction", "Business Entity — owner ≠ business", "Money Measurement — only rupee-value events"]
        }
      ]
    },
    dc: {
      center: "Rules of\nDebit & Credit",
      branches: [
        {
          label: "Personal Accounts",
          color: "var(--c-dc)",
          children: ["Debit the receiver", "Credit the giver", "Includes representative accounts (Outstanding, Prepaid)"]
        },
        {
          label: "Real Accounts",
          color: "var(--c-eq)",
          children: ["Debit what comes in", "Credit what goes out", "Covers tangible & intangible assets"]
        },
        {
          label: "Nominal Accounts",
          color: "var(--flag)",
          children: ["Debit expenses & losses", "Credit incomes & gains", "Reset to zero each year"]
        },
        {
          label: "Modern (American) Rules",
          color: "var(--c-jr)",
          children: ["Assets & Expenses ↑ = Debit", "Liabilities, Capital, Revenue ↑ = Credit", "Same answer, different route"]
        },
        {
          label: "Classification Steps",
          color: "var(--gold)",
          children: ["1. Is it a person?", "2. Is it an asset?", "3. Otherwise — expense, loss, income, or gain"]
        }
      ]
    },
    jr: {
      center: "The\nJournal",
      branches: [
        {
          label: "What It Is",
          color: "var(--c-jr)",
          children: ["Book of Original Entry", "First place a transaction is recorded", "Chronological order"]
        },
        {
          label: "Entry Format",
          color: "var(--c-eq)",
          children: ["Date, Particulars, L.F., Debit, Credit", "Debit account first, then 'To' credit account", "Narration explains the transaction"]
        },
        {
          label: "Entry Types",
          color: "var(--gold)",
          children: ["Simple — one debit, one credit", "Compound — multiple debits or credits", "Split payments (part cash, part credit)"]
        },
        {
          label: "Posting Logic",
          color: "var(--c-dc)",
          children: ["Every debit posts to that account's debit side", "Every credit posts to that account's credit side", "L.F. links journal page to ledger page"]
        },
        {
          label: "Common Adjustments",
          color: "var(--flag)",
          children: ["Outstanding & Prepaid expenses", "Depreciation & write-offs", "Trade discount vs. cash discount", "Goods lost, given as charity, or as drawings"]
        }
      ]
    }
  },

  /* ============================================================
     CHAPTER 1 — ACCOUNTING EQUATION
     ============================================================ */
  equation: {

    theory: {
      simple: [
        {
          h: "What the equation actually says",
          p: "Every business owns some things and owes some things. What it owns is called an asset. What it owes to outsiders is a liability. What it owes to the owner is capital. The accounting equation is just a promise that these three always balance:",
          formula: "Assets = Capital + Liabilities",
          p2: "That's it. Nothing on the left side can change without something on the right side changing too, by the exact same amount. This isn't a coincidence — it's a mathematical guarantee, because of how double-entry recording works."
        },
        {
          h: "Why it can never break",
          p: "Think of a business as a container. Money can come from two places only: the owner (capital) or outside lenders (liabilities). Whatever comes in, in whichever form, has to equal whatever the business now holds. If Rohan puts ₹50,000 into his shop, the shop now has ₹50,000 in cash (an asset) and owes Rohan ₹50,000 (capital). Both sides moved by ₹50,000. They always will."
        },
        {
          h: "The three players",
          list: [
            { term: "Assets", def: "Everything of value the business owns or controls — cash, stock, machinery, land, money owed to it (debtors), furniture." },
            { term: "Liabilities", def: "Everything the business owes to people outside the business — creditors, bank loans, outstanding bills." },
            { term: "Capital", def: "What the business owes to its own owner — the owner's investment, adjusted for profit, loss, and drawings." }
          ]
        }
      ],
      advanced: [
        {
          h: "The expanded equation",
          p: "In a running business, capital doesn't stay fixed — it moves with profit, loss, and drawings. The fuller form of the equation is:",
          formula: "Assets = Liabilities + Capital + Revenues − Expenses − Drawings",
          p2: "Revenues increase what belongs to the owner. Expenses and drawings reduce it. This is why a single trading transaction — a cash sale, for instance — can touch three elements at once: it increases an asset (cash) and simultaneously increases capital (through revenue), while the cost of the goods sold reduces both an asset (stock) and capital (through expense)."
        },
        {
          h: "Effect of transaction types",
          p: "Every transaction falls into one of a small number of patterns. Once you can name the pattern, you can predict the effect on the equation without memorizing each case:",
          list: [
            { term: "Asset ↔ Asset", def: "One asset increases while another decreases by the same amount. Example: buying furniture for cash. Total assets unchanged; equation untouched on the other side." },
            { term: "Asset ↑, Liability ↑", def: "An asset comes in on credit. Example: goods purchased on credit. Both sides of the equation increase equally." },
            { term: "Asset ↑, Capital ↑", def: "Owner brings in more resources, or the business earns revenue. Example: additional capital introduced, or cash sale of goods at a profit." },
            { term: "Asset ↓, Liability ↓", def: "A liability is repaid using an asset. Example: paying a creditor by cheque." },
            { term: "Asset ↓, Capital ↓", def: "An expense is paid, or the owner withdraws. Example: rent paid in cash, or drawings for personal use." },
            { term: "Liability ↑, Capital ↓", def: "Rare but possible — recognizing an outstanding expense increases a liability while reducing capital through the expense." }
          ]
        },
        {
          h: "Why examiners test this specifically",
          p: "CBSE numericals on this chapter almost always ask you to build a full table transaction-by-transaction, tracking the running total of Assets, Liabilities, and Capital after each line. The skill being tested isn't the formula — it's correctly identifying which two elements a transaction touches, and in which direction. That's exactly what the practice bank below is built to drill."
        }
      ]
    },

    concepts: [
      { title: "Dual Aspect", body: "Every transaction has two effects on the accounting equation, recorded simultaneously. This is the real engine behind double-entry bookkeeping — the equation is simply the dual aspect concept expressed as arithmetic." },
      { title: "Business Entity", body: "The business and its owner are treated as two separate accountable units, even in a sole proprietorship. This is why the owner's investment appears as a liability of the business (capital) rather than being ignored." },
      { title: "Money Measurement", body: "Only transactions expressible in money enter the equation. A skilled employee joining the firm doesn't change Assets, Liabilities, or Capital — however valuable, it can't be measured in rupees with objectivity." }
    ],

    /* --------------------------------------------------------
       NUMERICAL BANK — 84 questions
       Fields: id, difficulty, given{}, ask, hint, steps[], answer, explanation
       -------------------------------------------------------- */
    numericals: [
      // ===== EASY (1–30): single or two-variable, direct substitution =====
      { id:1, difficulty:"Easy", given:{assets:60000, liabilities:15000}, ask:"capital",
        hint:"Rearrange: Capital = Assets − Liabilities.",
        steps:["Capital = Assets − Liabilities","Capital = 60,000 − 15,000","Capital = 45,000"],
        answer:45000, explanation:"Whatever isn't owed to outsiders belongs to the owner. Subtracting liabilities from assets leaves exactly the owner's stake." },
      { id:2, difficulty:"Easy", given:{capital:80000, liabilities:22000}, ask:"assets",
        hint:"Assets = Capital + Liabilities.",
        steps:["Assets = Capital + Liabilities","Assets = 80,000 + 22,000","Assets = 1,02,000"],
        answer:102000, explanation:"The business holds exactly as much as it owes in total, to owner and outsiders combined." },
      { id:3, difficulty:"Easy", given:{assets:95000, capital:70000}, ask:"liabilities",
        hint:"Liabilities = Assets − Capital.",
        steps:["Liabilities = Assets − Capital","Liabilities = 95,000 − 70,000","Liabilities = 25,000"],
        answer:25000, explanation:"After setting aside what belongs to the owner, whatever's left of total assets must be owed to outside parties." },
      { id:4, difficulty:"Easy", given:{assets:45000, liabilities:5000}, ask:"capital",
        hint:"Capital = Assets − Liabilities.",
        steps:["Capital = 45,000 − 5,000","Capital = 40,000"], answer:40000,
        explanation:"A small liability means most of the assets are owner-funded." },
      { id:5, difficulty:"Easy", given:{capital:120000, liabilities:30000}, ask:"assets",
        hint:"Assets = Capital + Liabilities.",
        steps:["Assets = 1,20,000 + 30,000","Assets = 1,50,000"], answer:150000,
        explanation:"Total resources equal the sum of internal and external funding." },
      { id:6, difficulty:"Easy", given:{assets:200000, capital:150000}, ask:"liabilities",
        hint:"Liabilities = Assets − Capital.",
        steps:["Liabilities = 2,00,000 − 1,50,000","Liabilities = 50,000"], answer:50000,
        explanation:"The gap between what's owned and what the owner put in is exactly the outside debt." },
      { id:7, difficulty:"Easy", given:{assets:33000, liabilities:8000}, ask:"capital",
        hint:"Capital = Assets − Liabilities.",
        steps:["Capital = 33,000 − 8,000","Capital = 25,000"], answer:25000, explanation:"Direct substitution — no hidden steps." },
      { id:8, difficulty:"Easy", given:{capital:60000, liabilities:60000}, ask:"assets",
        hint:"Assets = Capital + Liabilities.",
        steps:["Assets = 60,000 + 60,000","Assets = 1,20,000"], answer:120000,
        explanation:"When capital and liabilities are equal, assets are exactly double either one." },
      { id:9, difficulty:"Easy", given:{assets:18500, capital:12500}, ask:"liabilities",
        hint:"Liabilities = Assets − Capital.",
        steps:["Liabilities = 18,500 − 12,500","Liabilities = 6,000"], answer:6000, explanation:"Straightforward subtraction gives the outside debt." },
      { id:10, difficulty:"Easy", given:{assets:500000, liabilities:120000}, ask:"capital",
        hint:"Capital = Assets − Liabilities.",
        steps:["Capital = 5,00,000 − 1,20,000","Capital = 3,80,000"], answer:380000,
        explanation:"Larger figures, same single-step logic." },
      { id:11, difficulty:"Easy", given:{capital:45000, liabilities:15000}, ask:"assets",
        hint:"Assets = Capital + Liabilities.",
        steps:["Assets = 45,000 + 15,000","Assets = 60,000"], answer:60000, explanation:"Sum the two right-hand elements to find total assets." },
      { id:12, difficulty:"Easy", given:{assets:72000, capital:52000}, ask:"liabilities",
        hint:"Liabilities = Assets − Capital.",
        steps:["Liabilities = 72,000 − 52,000","Liabilities = 20,000"], answer:20000, explanation:"Whatever assets exceed capital by, is owed outside." },
      { id:13, difficulty:"Easy", given:{assets:10000, liabilities:2500}, ask:"capital",
        hint:"Capital = Assets − Liabilities.",
        steps:["Capital = 10,000 − 2,500","Capital = 7,500"], answer:7500, explanation:"Small-number version of the same single-step problem." },
      { id:14, difficulty:"Easy", given:{capital:250000, liabilities:75000}, ask:"assets",
        hint:"Assets = Capital + Liabilities.",
        steps:["Assets = 2,50,000 + 75,000","Assets = 3,25,000"], answer:325000, explanation:"Add capital and liabilities for total assets." },
      { id:15, difficulty:"Easy", given:{assets:88000, capital:63000}, ask:"liabilities",
        hint:"Liabilities = Assets − Capital.",
        steps:["Liabilities = 88,000 − 63,000","Liabilities = 25,000"], answer:25000, explanation:"Subtract capital from assets." },
      { id:16, difficulty:"Easy", given:{assets:15000, liabilities:4000}, ask:"capital",
        hint:"Capital = Assets − Liabilities.",
        steps:["Capital = 15,000 − 4,000","Capital = 11,000"], answer:11000, explanation:"Direct one-step calculation." },
      { id:17, difficulty:"Easy", given:{capital:99000, liabilities:1000}, ask:"assets",
        hint:"Assets = Capital + Liabilities.",
        steps:["Assets = 99,000 + 1,000","Assets = 1,00,000"], answer:100000, explanation:"A neat round total — check your addition carries correctly." },
      { id:18, difficulty:"Easy", given:{assets:64000, capital:40000}, ask:"liabilities",
        hint:"Liabilities = Assets − Capital.",
        steps:["Liabilities = 64,000 − 40,000","Liabilities = 24,000"], answer:24000, explanation:"Subtraction gives the outstanding external debt." },
      { id:19, difficulty:"Easy", given:{assets:27500, liabilities:9500}, ask:"capital",
        hint:"Capital = Assets − Liabilities.",
        steps:["Capital = 27,500 − 9,500","Capital = 18,000"], answer:18000, explanation:"Watch the hundreds place when subtracting." },
      { id:20, difficulty:"Easy", given:{capital:36000, liabilities:14000}, ask:"assets",
        hint:"Assets = Capital + Liabilities.",
        steps:["Assets = 36,000 + 14,000","Assets = 50,000"], answer:50000, explanation:"Simple addition to close out the equation." },
      { id:21, difficulty:"Easy", given:{assets:81000, capital:81000}, ask:"liabilities",
        hint:"Liabilities = Assets − Capital.",
        steps:["Liabilities = 81,000 − 81,000","Liabilities = 0"], answer:0,
        explanation:"When assets exactly equal capital, the business has no outside debt at all — it's fully owner-funded." },
      { id:22, difficulty:"Easy", given:{assets:41000, liabilities:41000}, ask:"capital",
        hint:"Capital = Assets − Liabilities.",
        steps:["Capital = 41,000 − 41,000","Capital = 0"], answer:0,
        explanation:"If liabilities equal total assets, the owner currently has zero stake — every rupee owned is owed to someone else." },
      { id:23, difficulty:"Easy", given:{capital:0, liabilities:30000}, ask:"assets",
        hint:"Assets = Capital + Liabilities.",
        steps:["Assets = 0 + 30,000","Assets = 30,000"], answer:30000,
        explanation:"With zero capital, every asset traces back to an outside liability." },
      { id:24, difficulty:"Easy", given:{assets:56000, capital:56000}, ask:"liabilities",
        hint:"Liabilities = Assets − Capital.",
        steps:["Liabilities = 56,000 − 56,000","Liabilities = 0"], answer:0, explanation:"Equal assets and capital means no liabilities exist." },
      { id:25, difficulty:"Easy", given:{assets:19000, liabilities:19000}, ask:"capital",
        hint:"Capital = Assets − Liabilities.",
        steps:["Capital = 19,000 − 19,000","Capital = 0"], answer:0, explanation:"Zero capital case — a useful edge case to recognize quickly." },
      { id:26, difficulty:"Easy", given:{capital:73000, liabilities:27000}, ask:"assets",
        hint:"Assets = Capital + Liabilities.",
        steps:["Assets = 73,000 + 27,000","Assets = 1,00,000"], answer:100000, explanation:"Adds cleanly to a round number." },
      { id:27, difficulty:"Easy", given:{assets:38000, capital:9000}, ask:"liabilities",
        hint:"Liabilities = Assets − Capital.",
        steps:["Liabilities = 38,000 − 9,000","Liabilities = 29,000"], answer:29000, explanation:"Most of these assets are debt-funded, not owner-funded." },
      { id:28, difficulty:"Easy", given:{assets:12000, liabilities:3000}, ask:"capital",
        hint:"Capital = Assets − Liabilities.",
        steps:["Capital = 12,000 − 3,000","Capital = 9,000"], answer:9000, explanation:"Single-step subtraction." },
      { id:29, difficulty:"Easy", given:{capital:18000, liabilities:2000}, ask:"assets",
        hint:"Assets = Capital + Liabilities.",
        steps:["Assets = 18,000 + 2,000","Assets = 20,000"], answer:20000, explanation:"Simple addition to a round figure." },
      { id:30, difficulty:"Easy", given:{assets:29000, capital:11000}, ask:"liabilities",
        hint:"Liabilities = Assets − Capital.",
        steps:["Liabilities = 29,000 − 11,000","Liabilities = 18,000"], answer:18000, explanation:"Final easy-tier direct-substitution question." },

      // ===== MEDIUM (31–60): transaction effects, multi-step reasoning =====
      { id:31, difficulty:"Medium", given:{assets:70000, liabilities:20000}, ask:"capital",
        transaction:"Owner starts business with cash ₹70,000 and takes a loan of ₹20,000 to buy machinery. Find the owner's capital.",
        hint:"The loan is a liability, not capital. Only the owner's own contribution counts as capital.",
        steps:["Total assets after both transactions = 70,000 (owner's cash) + 20,000 (loan proceeds, now sitting as an asset or converted to machinery) = 90,000 in the general case, but here the question gives total assets directly as 70,000+","Re-read: capital = assets − liabilities = 90,000 − 20,000"],
        note:"This entry demonstrates a wording trap — always separate 'brought in by owner' (capital) from 'borrowed' (liability) before adding.",
        answer:70000, explanation:"The ₹70,000 is the owner's own money — that is capital. The ₹20,000 loan is a liability and must not be added into capital, even though both increase total assets." },
      { id:32, difficulty:"Medium", ask:"capital",
        transaction:"A firm has machinery ₹1,20,000, stock ₹40,000, cash ₹15,000, and owes ₹35,000 to creditors. Find capital.",
        hint:"First total all assets, then subtract total liabilities.",
        steps:["Total Assets = 1,20,000 + 40,000 + 15,000 = 1,75,000","Capital = Assets − Liabilities","Capital = 1,75,000 − 35,000 = 1,40,000"],
        answer:140000, explanation:"When assets are listed individually, always sum them first before applying the equation — a common place students lose marks is forgetting one asset line in the total." },
      { id:33, difficulty:"Medium", ask:"liabilities",
        transaction:"Total assets of a firm are ₹2,50,000. Capital introduced by the owner was ₹1,80,000 and profit earned during the year was ₹20,000. Find total liabilities.",
        hint:"Capital for the equation includes profit earned — profit increases the owner's stake.",
        steps:["Effective Capital = Capital introduced + Profit = 1,80,000 + 20,000 = 2,00,000","Liabilities = Assets − Capital","Liabilities = 2,50,000 − 2,00,000 = 50,000"],
        answer:50000, explanation:"Profit belongs to the owner and adds directly to capital for equation purposes — it is not a separate element." },
      { id:34, difficulty:"Medium", ask:"assets",
        transaction:"A business had liabilities of ₹45,000. Capital was ₹1,00,000, but the owner had withdrawn ₹8,000 for personal use during the year. Find total assets.",
        hint:"Drawings reduce capital — they represent the owner taking resources out.",
        steps:["Effective Capital = Capital − Drawings = 1,00,000 − 8,000 = 92,000","Assets = Capital + Liabilities","Assets = 92,000 + 45,000 = 1,37,000"],
        answer:137000, explanation:"Drawings are a reduction in capital, exactly opposite to profit. Missing this adjustment is one of the most common Medium-level errors." },
      { id:35, difficulty:"Medium", ask:"capital",
        transaction:"Anjali started her boutique with cash ₹60,000 and furniture worth ₹15,000. She also owes ₹10,000 to a supplier for fabric bought on credit. Find her capital.",
        hint:"Sum every asset first — cash and furniture are both assets here.",
        steps:["Total Assets = 60,000 + 15,000 = 75,000","Capital = Assets − Liabilities = 75,000 − 10,000 = 65,000"],
        answer:65000, explanation:"Two separate assets combine before the equation is applied; the credit purchase is the only liability." },
      { id:36, difficulty:"Medium", ask:"liabilities",
        transaction:"A shop has stock of ₹32,000, debtors of ₹8,000, and cash of ₹5,000. The owner's capital stands at ₹30,000. Find total liabilities.",
        hint:"Debtors — money owed TO the business — are an asset, not a liability.",
        steps:["Total Assets = 32,000 + 8,000 + 5,000 = 45,000","Liabilities = Assets − Capital = 45,000 − 30,000 = 15,000"],
        answer:15000, explanation:"Debtors are frequently misclassified by students as liabilities because the word sounds like 'debt' — but a debtor owes the business money, making it an asset." },
      { id:37, difficulty:"Medium", ask:"assets",
        transaction:"Capital of a firm is ₹95,000. It has a bank loan of ₹40,000 and also owes ₹12,000 in outstanding salary to staff. Find total assets.",
        hint:"Outstanding salary is a liability too — add all external obligations together.",
        steps:["Total Liabilities = 40,000 + 12,000 = 52,000","Assets = Capital + Liabilities = 95,000 + 52,000 = 1,47,000"],
        answer:147000, explanation:"Outstanding expenses (unpaid salary, rent, etc.) are liabilities because the business owes that money to someone outside." },
      { id:38, difficulty:"Medium", ask:"capital",
        transaction:"A trader's assets are: cash ₹18,000, stock ₹22,000, and machinery ₹60,000. His liabilities are: creditors ₹15,000 and a loan of ₹25,000. Find his capital.",
        hint:"Total all assets and all liabilities separately before subtracting.",
        steps:["Total Assets = 18,000 + 22,000 + 60,000 = 1,00,000","Total Liabilities = 15,000 + 25,000 = 40,000","Capital = 1,00,000 − 40,000 = 60,000"],
        answer:60000, explanation:"With multiple line items on both sides, organize a quick sub-total for assets and for liabilities before the final subtraction." },
      { id:39, difficulty:"Medium", ask:"liabilities",
        transaction:"Total assets stand at ₹3,00,000. The owner's original capital was ₹2,20,000, and the business made a loss of ₹15,000 this year. Find liabilities.",
        hint:"A loss reduces capital, the same direction as drawings.",
        steps:["Effective Capital = 2,20,000 − 15,000 = 2,05,000","Liabilities = 3,00,000 − 2,05,000 = 95,000"],
        answer:95000, explanation:"Loss and drawings both pull capital down; profit is the only element that pushes it up." },
      { id:40, difficulty:"Medium", ask:"capital",
        transaction:"A firm owns a building worth ₹5,00,000 and cash of ₹25,000. It took a loan of ₹3,00,000 to buy the building and still owes ₹18,000 to a contractor. Find capital.",
        hint:"Combine both liability figures, and both asset figures, before applying the equation.",
        steps:["Total Assets = 5,00,000 + 25,000 = 5,25,000","Total Liabilities = 3,00,000 + 18,000 = 3,18,000","Capital = 5,25,000 − 3,18,000 = 2,07,000"],
        answer:207000, explanation:"Large multi-item questions test the same single formula — the arithmetic is just longer." },
      { id:41, difficulty:"Medium", ask:"assets",
        transaction:"Ramesh's capital account shows ₹1,50,000. During the year he introduced additional capital of ₹20,000. His liabilities total ₹65,000. Find total assets.",
        hint:"Additional capital introduced adds directly onto the existing capital figure.",
        steps:["Effective Capital = 1,50,000 + 20,000 = 1,70,000","Assets = 1,70,000 + 65,000 = 2,35,000"],
        answer:235000, explanation:"Fresh capital introduced during the year is simply added — it behaves the same way profit does, increasing the owner's stake." },
      { id:42, difficulty:"Medium", ask:"capital",
        transaction:"A business holds cash ₹40,000, stock ₹35,000, and a delivery van worth ₹80,000. Outstanding rent is ₹5,000 and creditors are owed ₹30,000. Find capital.",
        hint:"Outstanding rent counts as a liability even though no cash has left the business.",
        steps:["Total Assets = 40,000 + 35,000 + 80,000 = 1,55,000","Total Liabilities = 5,000 + 30,000 = 35,000","Capital = 1,55,000 − 35,000 = 1,20,000"],
        answer:120000, explanation:"An unpaid expense is still an obligation owed to someone outside the business — it belongs on the liabilities side regardless of whether cash has moved yet." },
      { id:43, difficulty:"Medium", ask:"liabilities",
        transaction:"Total assets of a firm are ₹80,000. The owner's capital was ₹75,000 at the start, increased by profit of ₹5,000, but reduced by drawings of ₹8,000. Find liabilities.",
        hint:"Apply profit and drawings to the opening capital in sequence.",
        steps:["Effective Capital = 75,000 + 5,000 − 8,000 = 72,000","Liabilities = 80,000 − 72,000 = 8,000"],
        answer:8000, explanation:"When both profit and drawings appear in the same question, adjust for both, in either order, before applying the main equation." },
      { id:44, difficulty:"Medium", ask:"capital",
        transaction:"A firm's total assets are ₹1,60,000. It has taken a bank overdraft of ₹22,000 and owes ₹18,000 to suppliers. Find capital.",
        hint:"A bank overdraft is a liability — the business owes the bank, not the other way round.",
        steps:["Total Liabilities = 22,000 + 18,000 = 40,000","Capital = 1,60,000 − 40,000 = 1,20,000"],
        answer:120000, explanation:"An overdraft means the bank account has gone negative — the business now owes the bank, which makes it a liability, not an asset." },
      { id:45, difficulty:"Medium", ask:"assets",
        transaction:"Suman's capital is ₹92,000. She owes ₹14,000 to her brother as a personal loan taken for the business, and ₹9,000 to a stationery supplier. Find total assets.",
        hint:"A loan from a relative, if used for the business, is still a business liability.",
        steps:["Total Liabilities = 14,000 + 9,000 = 23,000","Assets = 92,000 + 23,000 = 1,15,000"],
        answer:115000, explanation:"The source of a loan (bank, relative, or friend) doesn't change its classification — if the business owes it, it's a liability." },
      { id:46, difficulty:"Medium", ask:"capital",
        transaction:"A firm has cash ₹12,000, debtors ₹18,000, stock ₹25,000, and furniture ₹30,000. It owes bills payable ₹14,000 and a bank loan of ₹36,000. Find capital.",
        hint:"Bills payable is a liability — the firm has promised to pay it.",
        steps:["Total Assets = 12,000 + 18,000 + 25,000 + 30,000 = 85,000","Total Liabilities = 14,000 + 36,000 = 50,000","Capital = 85,000 − 50,000 = 35,000"],
        answer:35000, explanation:"Bills payable represents a formal promise to pay — it sits on the liabilities side alongside loans and creditors." },
      { id:47, difficulty:"Medium", ask:"liabilities",
        transaction:"Total assets are ₹2,10,000. Capital brought in was ₹1,40,000, plus additional capital of ₹30,000 introduced mid-year. Find liabilities.",
        hint:"Add the additional capital to the original capital before subtracting from assets.",
        steps:["Effective Capital = 1,40,000 + 30,000 = 1,70,000","Liabilities = 2,10,000 − 1,70,000 = 40,000"],
        answer:40000, explanation:"Additional capital introduced mid-year is treated exactly like the original investment — both increase the owner's total stake." },
      { id:48, difficulty:"Medium", ask:"capital",
        transaction:"A trader's assets include cash ₹8,000, stock ₹22,000, and a computer worth ₹45,000. His only liability is ₹10,000 owed to a creditor for the computer's remaining price. Find capital.",
        hint:"Total the assets, then subtract the single liability given.",
        steps:["Total Assets = 8,000 + 22,000 + 45,000 = 75,000","Capital = 75,000 − 10,000 = 65,000"],
        answer:65000, explanation:"Even a partially-paid asset (like a computer bought partly on credit) is recorded at its full value on the assets side, with the unpaid portion as a liability." },
      { id:49, difficulty:"Medium", ask:"assets",
        transaction:"Capital of a business is ₹65,000, and profit for the year was ₹12,000, but the owner also introduced ₹8,000 of fresh capital. Liabilities are ₹22,000. Find total assets.",
        hint:"All three positive adjustments (capital, profit, fresh capital) add together before the equation is applied.",
        steps:["Effective Capital = 65,000 + 12,000 + 8,000 = 85,000","Assets = 85,000 + 22,000 = 1,07,000"],
        answer:107000, explanation:"Original capital, profit, and additional capital all increase the owner's stake in the same direction — sum them first." },
      { id:50, difficulty:"Medium", ask:"capital",
        transaction:"A firm's assets are: cash ₹5,000, stock ₹40,000, machinery ₹1,00,000, and debtors ₹15,000. It owes creditors ₹28,000 and has an outstanding electricity bill of ₹2,000. Find capital.",
        hint:"An outstanding utility bill is a small but real liability — don't skip it in the total.",
        steps:["Total Assets = 5,000 + 40,000 + 1,00,000 + 15,000 = 1,60,000","Total Liabilities = 28,000 + 2,000 = 30,000","Capital = 1,60,000 − 30,000 = 1,30,000"],
        answer:130000, explanation:"Small outstanding-expense liabilities are exam favorites precisely because they're easy to overlook in a longer list." },
      { id:51, difficulty:"Medium", ask:"liabilities",
        transaction:"Total assets are ₹95,000. The owner started with ₹1,00,000 capital but the business suffered a loss of ₹20,000 and the owner withdrew ₹5,000 for personal use. Find liabilities.",
        hint:"Both loss and drawings reduce capital — apply both before subtracting from assets.",
        steps:["Effective Capital = 1,00,000 − 20,000 − 5,000 = 75,000","Liabilities = 95,000 − 75,000 = 20,000"],
        answer:20000, explanation:"When loss and drawings both appear, each is subtracted independently from the opening capital figure." },
      { id:52, difficulty:"Medium", ask:"capital",
        transaction:"A shop has cash ₹9,000, stock ₹31,000, and a two-wheeler used for deliveries worth ₹55,000. It has a pending loan installment liability of ₹15,000 and owes ₹6,000 to a supplier. Find capital.",
        hint:"Sum every asset and every liability listed before the final subtraction.",
        steps:["Total Assets = 9,000 + 31,000 + 55,000 = 95,000","Total Liabilities = 15,000 + 6,000 = 21,000","Capital = 95,000 − 21,000 = 74,000"],
        answer:74000, explanation:"Vehicles used for business purposes are recorded as assets at their value, just like any other fixed asset." },
      { id:53, difficulty:"Medium", ask:"assets",
        transaction:"Capital of a firm is ₹1,10,000. This includes a profit of ₹18,000 already added in. Liabilities are ₹47,000. Find total assets.",
        hint:"The profit is already reflected in the capital figure given — don't add it again.",
        steps:["Capital (as given, already inclusive of profit) = 1,10,000","Assets = 1,10,000 + 47,000 = 1,57,000"],
        answer:157000, explanation:"This question tests careful reading — when a figure is stated as 'capital including profit,' it should not be adjusted a second time." },
      { id:54, difficulty:"Medium", ask:"capital",
        transaction:"A trader owns land worth ₹2,00,000 and cash ₹30,000. He borrowed ₹1,20,000 from a bank specifically to purchase the land. Find his capital.",
        hint:"Only the bank loan is a liability — the land itself is simply an asset regardless of how it was financed.",
        steps:["Total Assets = 2,00,000 + 30,000 = 2,30,000","Capital = 2,30,000 − 1,20,000 = 1,10,000"],
        answer:110000, explanation:"How an asset was financed doesn't change its own classification — it's still an asset. Only the loan taken to finance it is the liability." },
      { id:55, difficulty:"Medium", ask:"liabilities",
        transaction:"Total assets of a firm are ₹1,75,000. Opening capital was ₹1,30,000, profit for the year ₹25,000, and additional capital introduced ₹10,000. Find liabilities.",
        hint:"Three positive components all add to the opening capital.",
        steps:["Effective Capital = 1,30,000 + 25,000 + 10,000 = 1,65,000","Liabilities = 1,75,000 − 1,65,000 = 10,000"],
        answer:10000, explanation:"With three additive components to capital, add them all first, then subtract from total assets just once." },
      { id:56, difficulty:"Medium", ask:"capital",
        transaction:"A business has cash ₹22,000, stock ₹48,000, and office equipment ₹35,000. Liabilities include a loan of ₹40,000 and creditors of ₹15,000. Find capital.",
        hint:"Total both sides fully before subtracting.",
        steps:["Total Assets = 22,000 + 48,000 + 35,000 = 1,05,000","Total Liabilities = 40,000 + 15,000 = 55,000","Capital = 1,05,000 − 55,000 = 50,000"],
        answer:50000, explanation:"A standard multi-item medium question — accurate addition matters more than the concept itself here." },
      { id:57, difficulty:"Medium", ask:"assets",
        transaction:"A firm's capital is ₹86,000 after accounting for a loss of ₹9,000 already deducted. Its liabilities are ₹31,000. Find total assets.",
        hint:"The loss has already been factored into the ₹86,000 — use it as-is.",
        steps:["Capital (already net of loss) = 86,000","Assets = 86,000 + 31,000 = 1,17,000"],
        answer:117000, explanation:"As with question 53, watch for figures already described as net of an adjustment — applying the adjustment twice is a common error." },
      { id:58, difficulty:"Medium", ask:"capital",
        transaction:"A trader's assets are cash ₹6,500, stock ₹28,500, and machinery ₹90,000. His liabilities are a loan of ₹35,000 and outstanding wages of ₹4,000. Find capital.",
        hint:"Add all assets, add all liabilities, then subtract.",
        steps:["Total Assets = 6,500 + 28,500 + 90,000 = 1,25,000","Total Liabilities = 35,000 + 4,000 = 39,000","Capital = 1,25,000 − 39,000 = 86,000"],
        answer:86000, explanation:"Outstanding wages, like outstanding rent, is money earned by employees but not yet paid — a liability of the business." },
      { id:59, difficulty:"Medium", ask:"liabilities",
        transaction:"Total assets stand at ₹64,000. The owner's capital was ₹50,000, boosted by profit of ₹8,000 but reduced by drawings of ₹3,000. Find liabilities.",
        hint:"Apply profit (add) and drawings (subtract) to the opening capital.",
        steps:["Effective Capital = 50,000 + 8,000 − 3,000 = 55,000","Liabilities = 64,000 − 55,000 = 9,000"],
        answer:9000, explanation:"A clean example of combining one positive and one negative adjustment to capital in a single step." },
      { id:60, difficulty:"Medium", ask:"capital",
        transaction:"A firm has cash ₹14,000, stock ₹52,000, debtors ₹9,000 and furniture ₹25,000. It owes ₹18,000 to creditors and has taken a ₹30,000 loan. Find capital.",
        hint:"Four assets, two liabilities — total each group fully first.",
        steps:["Total Assets = 14,000 + 52,000 + 9,000 + 25,000 = 1,00,000","Total Liabilities = 18,000 + 30,000 = 48,000","Capital = 1,00,000 − 48,000 = 52,000"],
        answer:52000, explanation:"The final Medium-tier question — a clean round total on the assets side is a good self-check that your addition is correct." },

      // ===== HARD (61–84): full transaction tables, verification-style, multi-day sequences =====
      { id:61, difficulty:"Hard", ask:"final-capital",
        transaction:"Priya started a stationery business on Day 1 with cash ₹1,00,000. Day 2: bought furniture for cash ₹20,000. Day 3: purchased goods on credit ₹15,000. Day 4: sold goods costing ₹6,000 for ₹9,000 cash. Find her capital at the end of Day 4.",
        hint:"Track running totals of Assets and Liabilities after each day; Capital is always the balancing figure.",
        steps:[
          "Day 1: Cash 1,00,000. Assets = 1,00,000. Liabilities = 0. Capital = 1,00,000.",
          "Day 2: Cash −20,000, Furniture +20,000. Total assets unchanged at 1,00,000. Capital still = 1,00,000.",
          "Day 3: Stock +15,000 (asset), Creditors +15,000 (liability). Assets = 1,15,000. Liabilities = 15,000. Capital = 1,15,000 − 15,000 = 1,00,000.",
          "Day 4: Cash +9,000, Stock −6,000. Net asset change = +3,000, and this ₹3,000 profit adds to capital. Assets = 1,18,000. Liabilities = 15,000. Capital = 1,18,000 − 15,000 = 1,03,000."
        ],
        answer:103000, explanation:"The ₹3,000 profit from the sale (selling ₹6,000 worth of stock for ₹9,000) is the only thing that changes capital across all four days — every other transaction was either asset-for-asset or asset-for-liability, leaving capital untouched." },
      { id:62, difficulty:"Hard", ask:"missing-liability",
        transaction:"A firm's position over two years: Year 1 — Assets ₹2,00,000, Capital ₹1,50,000. Year 2 — Assets grew to ₹2,80,000, and during the year the owner introduced ₹20,000 additional capital and earned a profit of ₹35,000. Find Year 2 liabilities.",
        hint:"Build Year 2's effective capital from Year 1's capital plus this year's additions, then apply the equation to Year 2's assets.",
        steps:[
          "Year 1 Liabilities = Assets − Capital = 2,00,000 − 1,50,000 = 50,000 (context only, not required for the answer)",
          "Year 2 Effective Capital = Year 1 Capital + Additional Capital + Profit = 1,50,000 + 20,000 + 35,000 = 2,05,000",
          "Year 2 Liabilities = Year 2 Assets − Year 2 Effective Capital = 2,80,000 − 2,05,000 = 75,000"
        ],
        answer:75000, explanation:"This tests whether students can carry a capital balance forward across periods and layer multiple adjustments onto it correctly, rather than treating each year as an isolated single-step problem." },
      { id:63, difficulty:"Hard", ask:"verify-and-correct",
        transaction:"A student recorded a firm's position as: Assets ₹1,40,000, Liabilities ₹35,000, Capital ₹1,00,000. Identify whether this is correct, and if not, find the correct capital.",
        hint:"Plug the given figures into Assets = Capital + Liabilities and see if both sides match.",
        steps:[
          "Check: Capital + Liabilities = 1,00,000 + 35,000 = 1,35,000",
          "Given Assets = 1,40,000",
          "1,35,000 ≠ 1,40,000 — the equation does not balance as recorded.",
          "Correct Capital = Assets − Liabilities = 1,40,000 − 35,000 = 1,05,000"
        ],
        answer:105000, explanation:"The student's capital figure was understated by ₹5,000. Verification questions like this are exactly what the built-in Equation Verifier tool in this chapter checks automatically — practicing this by hand first builds the instinct the tool later confirms." },
      { id:64, difficulty:"Hard", ask:"final-capital",
        transaction:"Karan begins with capital of ₹80,000, all in cash. He buys machinery on credit for ₹25,000. He then pays ₹10,000 cash to reduce that credit balance. He also earns a profit of ₹6,000 on a cash transaction and pays outstanding rent of ₹2,000, which had not been recorded as a liability before. Find his final capital.",
        hint:"Recognizing outstanding rent as a new liability, then immediately settling it, are two separate events even though they happen together in this question.",
        steps:[
          "Start: Cash 80,000, Capital 80,000, Liabilities 0.",
          "Buy machinery on credit: Assets +25,000 (machinery), Liabilities +25,000 (creditor). Capital unchanged at 80,000.",
          "Pay 10,000 to creditor: Cash −10,000, Creditor −10,000. Capital still unchanged at 80,000.",
          "Profit of 6,000 (cash transaction): Capital increases by 6,000 → 86,000.",
          "Pay outstanding rent 2,000: this is an expense paid in cash, reducing capital by 2,000 → 86,000 − 2,000 = 84,000."
        ],
        answer:84000, explanation:"The phrase 'which had not been recorded as a liability before' is a signal that this rent was simply paid as a normal cash expense in this transaction, not settled from an existing outstanding balance — so it reduces capital directly, the same way any cash expense does." },
      { id:65, difficulty:"Hard", ask:"missing-asset",
        transaction:"A firm's capital is ₹1,20,000 and liabilities are ₹45,000. Its recorded assets are: cash ₹20,000, stock ₹38,000, and machinery ₹90,000 — but one asset seems to be missing from the books. Find the value of the missing asset.",
        hint:"First find total assets required by the equation, then compare to what's already listed.",
        steps:[
          "Required Total Assets = Capital + Liabilities = 1,20,000 + 45,000 = 1,65,000",
          "Listed Assets = 20,000 + 38,000 + 90,000 = 1,48,000",
          "Missing Asset = 1,65,000 − 1,48,000 = 17,000"
        ],
        answer:17000, explanation:"This style of question — working backward from the equation to find an unrecorded or omitted item — is common in board exams and tests the equation as a genuine checking tool, not just a formula to plug numbers into." },
      { id:66, difficulty:"Hard", ask:"final-capital",
        transaction:"Meera starts with ₹50,000 cash as capital. She buys stock worth ₹30,000 on credit. She sells half that stock (cost ₹15,000) for ₹22,000 cash. She then pays her supplier ₹18,000 against the credit purchase. Find her final capital.",
        hint:"Only the sale transaction changes capital — track it separately from the pure asset/liability movements.",
        steps:[
          "Start: Cash 50,000, Capital 50,000.",
          "Buy stock on credit: Stock +30,000, Creditors +30,000. Capital unchanged at 50,000.",
          "Sell half stock (cost 15,000) for 22,000 cash: Stock −15,000, Cash +22,000. Net asset change = +7,000, which is profit, so Capital increases by 7,000 → 57,000.",
          "Pay supplier 18,000: Cash −18,000, Creditors −18,000. Capital unchanged, still 57,000."
        ],
        answer:57000, explanation:"Out of four transactions, only the sale at a profit touches capital. This is the core skill for Hard-tier questions: scanning a sequence and isolating exactly which lines are capital-affecting." },
      { id:67, difficulty:"Hard", ask:"missing-liability",
        transaction:"A firm's assets total ₹3,10,000. Its capital consists of an opening balance of ₹2,00,000, profit of ₹40,000, less drawings of ₹15,000. Find the firm's total liabilities, then state what fraction of total assets that represents (nearest whole percent).",
        hint:"First resolve effective capital fully, then apply the main equation, then compute the percentage.",
        steps:[
          "Effective Capital = 2,00,000 + 40,000 − 15,000 = 2,25,000",
          "Liabilities = 3,10,000 − 2,25,000 = 85,000",
          "Fraction of assets = 85,000 / 3,10,000 ≈ 27%"
        ],
        answer:85000, explanation:"The percentage add-on (≈27%) isn't the graded answer here but is the kind of follow-up CBSE case-study questions often add — always finish the core numeric answer first, then handle any interpretation asked afterward." },
      { id:68, difficulty:"Hard", ask:"final-capital",
        transaction:"Aman's business: Day 1, starts with ₹60,000 capital in cash. Day 2, takes a bank loan of ₹40,000. Day 3, buys land for ₹90,000, paying ₹70,000 cash and the rest on credit from the seller. Day 4, receives ₹5,000 as commission income in cash. Find capital at end of Day 4.",
        hint:"The unpaid portion of the land purchase is a new liability — separate from the bank loan.",
        steps:[
          "Day 1: Cash 60,000. Capital 60,000. Liabilities 0.",
          "Day 2: Cash +40,000 (loan), Liabilities +40,000 (bank loan). Assets = 1,00,000. Capital unchanged at 60,000.",
          "Day 3: Land +90,000, Cash −70,000, remaining ₹20,000 owed to seller becomes a new liability. Assets = 1,00,000 − 70,000 + 90,000 = 1,20,000. Liabilities = 40,000 + 20,000 = 60,000. Capital = 1,20,000 − 60,000 = 60,000 (unchanged — this was an asset-for-asset-and-liability swap).",
          "Day 4: Cash +5,000 commission income. This is revenue, so Capital increases by 5,000 → 65,000."
        ],
        answer:65000, explanation:"Day 3 looks complex but is actually capital-neutral — buying an asset partly for cash and partly on credit never changes capital by itself. Only Day 4's commission income (pure revenue) moves the needle." },
      { id:69, difficulty:"Hard", ask:"verify-and-correct",
        transaction:"A firm reports: Assets ₹4,50,000, Capital ₹3,20,000, Liabilities ₹1,40,000. A trainee accountant claims the books balance. Check this claim and, if incorrect, state the correct liabilities figure.",
        hint:"Add Capital and Liabilities and compare the sum to the stated Assets.",
        steps:[
          "Capital + Liabilities = 3,20,000 + 1,40,000 = 4,60,000",
          "Stated Assets = 4,50,000",
          "4,60,000 ≠ 4,50,000 — the trainee is incorrect; the books do not balance as recorded.",
          "Correct Liabilities = Assets − Capital = 4,50,000 − 3,20,000 = 1,30,000"
        ],
        answer:130000, explanation:"The recorded liabilities were overstated by ₹10,000. This is the exact class of error the chapter's built-in verifier tool is designed to catch instantly — the manual working here shows what the tool is doing under the hood." },
      { id:70, difficulty:"Hard", ask:"final-capital",
        transaction:"Rita's shop: starts with cash capital ₹75,000. Buys furniture for cash ₹18,000. Introduces additional capital of ₹25,000 in cash. Takes a loan of ₹30,000. Suffers a loss of ₹4,000 on a cash sale of old furniture (sold for less than its book value). Find final capital.",
        hint:"Additional capital and the loss both affect capital, in opposite directions — the loan and furniture purchase do not.",
        steps:[
          "Start: Capital 75,000.",
          "Buy furniture for cash: asset-for-asset swap, Capital unchanged at 75,000.",
          "Additional capital introduced: Capital +25,000 → 1,00,000.",
          "Loan taken: Liabilities +30,000, Capital unchanged at 1,00,000.",
          "Loss on sale of furniture: Capital −4,000 → 96,000."
        ],
        answer:96000, explanation:"A loss on selling an asset is still a loss, and reduces capital exactly the way a trading loss would — the fact that it came from furniture rather than goods for resale doesn't change its treatment." },
      { id:71, difficulty:"Hard", ask:"missing-asset",
        transaction:"A firm has capital of ₹95,000 and total liabilities of ₹38,000, comprising a loan of ₹25,000 and creditors of ₹13,000. Its known assets are cash ₹12,000 and stock ₹41,000, with the remainder held as machinery. Find the value of the machinery.",
        hint:"Total liabilities are already given as a single figure — use it directly with capital first.",
        steps:[
          "Total Assets required = Capital + Liabilities = 95,000 + 38,000 = 1,33,000",
          "Known Assets = 12,000 + 41,000 = 53,000",
          "Machinery = 1,33,000 − 53,000 = 80,000"
        ],
        answer:80000, explanation:"The breakdown of liabilities into loan and creditors is background detail — since their total (₹38,000) is already given, it doesn't need to be recomputed for this answer." },
      { id:72, difficulty:"Hard", ask:"final-capital",
        transaction:"A trader's ledger over a month: opening capital ₹1,10,000. Introduces goods worth ₹15,000 as additional capital (not cash). Sells goods costing ₹20,000 for ₹27,000, received half in cash and half on credit from the customer. Pays salary of ₹6,000 in cash. Find capital at month end.",
        hint:"Additional capital doesn't have to be cash — goods brought in by the owner still count as capital introduced. A credit sale still generates the same profit as a cash sale.",
        steps:[
          "Start: Capital 1,10,000.",
          "Goods worth 15,000 introduced as capital: Capital +15,000 → 1,25,000.",
          "Sale: cost 20,000, sold for 27,000 (half cash, half credit — doesn't matter for profit calculation, since profit is Selling Price − Cost regardless of how payment was received). Profit = 27,000 − 20,000 = 7,000. Capital +7,000 → 1,32,000.",
          "Salary paid 6,000: this is an expense, Capital −6,000 → 1,26,000."
        ],
        answer:126000, explanation:"Two ideas often missed: capital can be introduced in non-cash form (goods, furniture, anything of value), and profit on a sale is determined by cost vs. selling price — not by whether the money has actually been collected yet." },
      { id:73, difficulty:"Hard", ask:"missing-liability",
        transaction:"Over one year, a firm's assets grew from ₹2,20,000 to ₹3,05,000. Capital grew from ₹1,60,000 to ₹2,10,000 over the same period (after all adjustments for profit and drawings). Liabilities at the start were ₹60,000. Find liabilities at the end of the year.",
        hint:"You're only asked for the ending liabilities — use the ending assets and ending capital directly; the opening figures are useful only as a sanity check.",
        steps:[
          "Sanity check on opening figures: Opening Liabilities = 2,20,000 − 1,60,000 = 60,000 ✓ matches the given figure, confirming consistency.",
          "Ending Liabilities = Ending Assets − Ending Capital = 3,05,000 − 2,10,000 = 95,000"
        ],
        answer:95000, explanation:"When a question gives you a full opening AND ending picture, always check that the opening figures are internally consistent first — it catches transcription errors before they propagate into your final answer." },
      { id:74, difficulty:"Hard", ask:"final-capital",
        transaction:"Vikram starts a repair shop with ₹40,000 cash. Buys tools for cash ₹9,000. Borrows ₹15,000 from a friend for the business. Completes repair work worth ₹6,000, receiving payment in cash immediately. Spends ₹1,200 cash on electricity, an expense for running the shop. Find final capital.",
        hint:"Service income (like repair work) increases capital exactly the way sale of goods does.",
        steps:[
          "Start: Capital 40,000.",
          "Buy tools for cash: asset swap, Capital unchanged at 40,000.",
          "Borrow from friend: Liabilities +15,000, Capital unchanged at 40,000.",
          "Repair income 6,000 cash: Capital +6,000 → 46,000.",
          "Electricity expense 1,200 cash: Capital −1,200 → 44,800."
        ],
        answer:44800, explanation:"Service businesses earn revenue from labor rather than goods, but the accounting treatment is identical: income raises capital, expenses lower it, regardless of what kind of business is generating them." },
      { id:75, difficulty:"Hard", ask:"missing-asset",
        transaction:"A firm's capital and liabilities together total ₹2,40,000, made up of capital ₹1,85,000 and liabilities ₹55,000. Assets on record are cash ₹15,000, debtors ₹22,000, stock ₹68,000 and furniture ₹40,000, with the balance held in a bank fixed deposit. Find the fixed deposit's value.",
        hint:"You're already given the combined Capital + Liabilities figure directly — use it as total assets required.",
        steps:[
          "Total Assets Required = 1,85,000 + 55,000 = 2,40,000 (as stated)",
          "Known Assets = 15,000 + 22,000 + 68,000 + 40,000 = 1,45,000",
          "Fixed Deposit = 2,40,000 − 1,45,000 = 95,000"
        ],
        answer:95000, explanation:"A bank fixed deposit is a genuine business asset, just like cash or stock — money parked in an FD hasn't left the business's ownership, it's simply been converted into a different form of asset." },
      { id:76, difficulty:"Hard", ask:"final-capital",
        transaction:"A firm's position: opening capital ₹1,00,000. During the year — profit ₹22,000; drawings in cash ₹9,000; drawings of goods (for personal use, at cost) worth ₹3,000; additional capital introduced ₹10,000. Find closing capital.",
        hint:"Drawings of goods reduce capital exactly like cash drawings — the form doesn't matter, only that it's the owner taking value out.",
        steps:[
          "Closing Capital = Opening Capital + Profit + Additional Capital − Cash Drawings − Goods Drawings",
          "= 1,00,000 + 22,000 + 10,000 − 9,000 − 3,000",
          "= 1,32,000 − 12,000 = 1,20,000"
        ],
        answer:120000, explanation:"Drawings of goods for personal use is a classic trap: students sometimes only subtract cash drawings and forget that taking goods out of the business for personal use is equally a withdrawal, valued at cost." },
      { id:77, difficulty:"Hard", ask:"missing-liability",
        transaction:"A firm's assets are: land ₹1,50,000, cash ₹25,000, and stock ₹60,000. Its capital is known to be ₹1,80,000. It has two liabilities — a loan and creditors — and the loan is known to be exactly three times the creditors figure. Find the amount of creditors.",
        hint:"First find total liabilities as a single number using the main equation, then split it using the given ratio.",
        steps:[
          "Total Assets = 1,50,000 + 25,000 + 60,000 = 2,35,000",
          "Total Liabilities = 2,35,000 − 1,80,000 = 55,000",
          "Let Creditors = x, Loan = 3x → x + 3x = 55,000 → 4x = 55,000 → x = 13,750"
        ],
        answer:13750, explanation:"This combines the accounting equation with a simple ratio split — a style CBSE uses to test whether students can layer basic algebra on top of the core concept, not just plug straight into a formula." },
      { id:78, difficulty:"Hard", ask:"final-capital",
        transaction:"Neha's boutique: opening capital ₹50,000. She takes goods costing ₹4,000 from stock for her own wedding (drawings). She sells remaining stock costing ₹30,000 for ₹41,000, all on credit. She pays ₹3,000 cash toward electricity. Find capital after all these events, before the credit sale amount is even collected.",
        hint:"A credit sale still generates profit at the point of sale — collection is a separate, later, capital-neutral event.",
        steps:[
          "Start: Capital 50,000.",
          "Drawings of goods worth 4,000: Capital −4,000 → 46,000.",
          "Credit sale: cost 30,000, sale price 41,000. Profit = 11,000, recognized immediately regardless of collection. Capital +11,000 → 57,000.",
          "Electricity paid 3,000: Capital −3,000 → 54,000."
        ],
        answer:54000, explanation:"The phrase 'before the credit sale amount is even collected' is a deliberate signal: profit is recognized at the point of sale under accrual-based accounting, not when cash actually changes hands." },
      { id:79, difficulty:"Hard", ask:"verify-and-correct",
        transaction:"A firm's books show: Assets ₹6,00,000; Capital consisting of opening balance ₹4,00,000 plus profit ₹90,000 minus drawings ₹20,000; Liabilities ₹1,50,000. Verify whether this position balances, and if not, identify the size of the discrepancy.",
        hint:"Work out effective capital fully first, then check Capital + Liabilities against the stated Assets.",
        steps:[
          "Effective Capital = 4,00,000 + 90,000 − 20,000 = 4,70,000",
          "Capital + Liabilities = 4,70,000 + 1,50,000 = 6,20,000",
          "Stated Assets = 6,00,000",
          "Discrepancy = 6,20,000 − 6,00,000 = 20,000 (liabilities or capital have been overstated by this much, or an asset of this value is missing from the books)"
        ],
        answer:20000, explanation:"When a verification question asks for the size of a discrepancy rather than a corrected single figure, the answer is the gap itself — it doesn't require guessing which specific side was wrong, only quantifying the imbalance." },
      { id:80, difficulty:"Hard", ask:"final-capital",
        transaction:"A firm: opening capital ₹75,000. Buys machinery worth ₹40,000, paying ₹15,000 cash and taking a loan for the rest. Earns a commission of ₹8,000, received half in cash and half still receivable. Pays interest of ₹1,500 on the loan, in cash. Find closing capital.",
        hint:"Commission earned but not yet fully received still counts in full toward capital — the receivable portion is simply a different asset (debtors), not unearned income.",
        steps:[
          "Start: Capital 75,000.",
          "Machinery purchase (15,000 cash + 25,000 loan): asset-for-asset-and-liability, Capital unchanged at 75,000.",
          "Commission earned 8,000 (half cash, half receivable): full amount is income regardless of collection status. Capital +8,000 → 83,000.",
          "Interest paid 1,500 cash: expense, Capital −1,500 → 81,500."
        ],
        answer:81500, explanation:"As with the credit sale in question 78, income is recognized in full at the point it's earned — splitting the receipt between cash and a receivable doesn't reduce the amount that counts toward capital." },
      { id:81, difficulty:"Hard", ask:"missing-asset",
        transaction:"A firm's capital is ₹2,05,000. Its liabilities are a loan of ₹60,000 and outstanding expenses of ₹8,000. Known assets: cash ₹18,000, stock ₹75,000, debtors ₹40,000, and furniture ₹55,000. The remaining asset is prepaid insurance. Find its value.",
        hint:"Total both sides of the equation independently, then find the gap on the assets side.",
        steps:[
          "Total Liabilities = 60,000 + 8,000 = 68,000",
          "Total Assets Required = Capital + Liabilities = 2,05,000 + 68,000 = 2,73,000",
          "Known Assets = 18,000 + 75,000 + 40,000 + 55,000 = 1,88,000",
          "Prepaid Insurance = 2,73,000 − 1,88,000 = 85,000"
        ],
        answer:85000, explanation:"Prepaid insurance — paid in advance for coverage not yet used — is a genuine asset, since it represents a future benefit the firm has already paid for and will receive." },
      { id:82, difficulty:"Hard", ask:"final-capital",
        transaction:"A firm's opening capital was ₹90,000. Over the year: profit of ₹15,000; the owner introduced machinery worth ₹20,000 as additional capital; drawings of ₹6,000 cash; and a bad debt of ₹2,000 was written off (a debtor who owed the firm money failed to pay, and the firm gave up on collecting it). Find closing capital.",
        hint:"A bad debt written off is effectively a loss — an asset (debtors) is reduced with no compensating benefit, so capital falls by the same amount.",
        steps:[
          "Closing Capital = Opening Capital + Profit + Additional Capital − Drawings − Bad Debt",
          "= 90,000 + 15,000 + 20,000 − 6,000 − 2,000",
          "= 1,25,000 − 8,000 = 1,17,000"
        ],
        answer:117000, explanation:"A bad debt written off means the firm accepts it will never collect that money — the debtor asset simply disappears from the books, and since nothing is received in exchange, capital absorbs the loss directly." },
      { id:83, difficulty:"Hard", ask:"missing-liability",
        transaction:"A firm's total assets are ₹3,40,000. Opening capital was ₹2,10,000. During the year it earned profit of ₹45,000, the owner introduced ₹15,000 additional capital, and there were total drawings (cash and goods combined) of ₹12,000. Find the firm's liabilities.",
        hint:"Combine all four capital-affecting figures into one effective capital total before applying the main equation.",
        steps:[
          "Effective Capital = 2,10,000 + 45,000 + 15,000 − 12,000 = 2,58,000",
          "Liabilities = 3,40,000 − 2,58,000 = 82,000"
        ],
        answer:82000, explanation:"This question layers four separate adjustments onto opening capital, but each one is a concept already covered individually in earlier questions — the Hard tier's real difficulty is combining familiar pieces correctly, not learning anything new." },
      { id:84, difficulty:"Hard", ask:"final-capital",
        transaction:"Final synthesis question. A firm: Day 1 — opening capital ₹1,20,000, all cash. Day 2 — buys stock on credit ₹35,000. Day 3 — sells half that stock (cost ₹17,500) for ₹26,000, received entirely on credit from the customer. Day 4 — pays ₹20,000 cash to the stock supplier. Day 5 — the customer from Day 3 pays half of what they owe, in cash. Day 6 — owner withdraws ₹5,000 cash for personal use. Find capital at the end of Day 6.",
        hint:"Days 4 and 5 are both pure asset-for-asset movements (or asset-for-liability) and don't touch capital at all — isolate which days actually move the needle.",
        steps:[
          "Day 1: Capital = 1,20,000.",
          "Day 2: Stock +35,000, Creditors +35,000. Capital unchanged at 1,20,000.",
          "Day 3: Stock −17,500, Debtors +26,000. Profit = 26,000 − 17,500 = 8,500. Capital +8,500 → 1,28,500.",
          "Day 4: Cash −20,000, Creditors −20,000. Pure asset-for-liability settlement. Capital unchanged at 1,28,500.",
          "Day 5: Debtor pays half of ₹26,000 owed = ₹13,000. Cash +13,000, Debtors −13,000. Pure asset-for-asset swap. Capital unchanged at 1,28,500.",
          "Day 6: Drawings 5,000 cash. Capital −5,000 → 1,23,500."
        ],
        answer:123500, explanation:"This closing question of the bank deliberately includes two 'distractor' days (4 and 5) that involve real cash movement but don't affect capital at all, alongside two days that genuinely do (Day 3's profit and Day 6's drawings) — exactly the discrimination skill this entire numerical bank has been building toward." }
    ]
  },

  /* ============================================================
     CHAPTER 2 — RULES OF DEBIT & CREDIT
     ============================================================ */
  debitCredit: {
    theory: {
      simple: [
  {
    "h": "Two ways to decide debit or credit",
    "p": "Every account in a business falls into a category, and once you know the category, a simple rule tells you whether to debit or credit it. There are two systems taught side by side: the Traditional (Golden Rules) approach, which sorts accounts into Personal, Real, and Nominal; and the Modern (American) approach, which sorts them into Assets, Liabilities, Capital, Revenue, and Expenses.",
    "p2": "Both systems always produce the same journal entry — they're just two different lenses for reaching it. Most students find the Golden Rules more intuitive for people and things, and the Modern rules faster once the equation is second nature."
  },
  {
    "h": "The three Golden Rules",
    "list": [
      {
        "term": "Personal Account",
        "def": "Debit the Receiver, Credit the Giver. Applies to individuals, firms, companies, and 'representative' accounts like Outstanding Salary or Bank A/c."
      },
      {
        "term": "Real Account",
        "def": "Debit what comes in, Credit what goes out. Applies to assets and properties — cash, machinery, furniture, goodwill."
      },
      {
        "term": "Nominal Account",
        "def": "Debit all expenses and losses, Credit all incomes and gains. Applies to rent, salary, commission, interest, and similar accounts."
      }
    ]
  },
  {
    "h": "Spotting the account type quickly",
    "p": "A name is a Personal account. A thing you can point to (or an intangible right, like goodwill) is a Real account. A cost or an earning is a Nominal account. The trickiest cases are 'representative' personal accounts — Outstanding Salary, Prepaid Insurance, Bank A/c — which stand in for a person or entity even though the name doesn't obviously say so."
  }
],
      advanced: [
  {
    "h": "The Modern Approach, tied to the equation",
    "p": "The Modern Approach maps every account directly onto the accounting equation you already know: Assets = Liabilities + Capital + Revenue − Expenses. Because Assets and Expenses sit conceptually on the same side of that relationship, they behave the same way — both increase with a debit. Liabilities, Capital, and Revenue increase with a credit.",
    "formula": "Assets ↑ / Expenses ↑ = Debit   |   Liabilities ↑ / Capital ↑ / Revenue ↑ = Credit",
    "p2": "Decreases simply reverse the rule for that category — an asset decreasing is a credit, a liability decreasing is a debit, and so on."
  },
  {
    "h": "Why goods-out transactions never touch Sales",
    "p": "Free samples, charity, and goods taken for personal use (drawings) all remove stock from the business without any outsider paying for it. Because there's no sale, Sales A/c is never credited in these cases — instead, Purchases A/c is credited to remove the goods from the trading figures at their original cost, and the corresponding expense/drawings account absorbs the value."
  },
  {
    "h": "Cash discount vs trade discount — a frequent trap",
    "p": "Trade discount is a reduction off the listed price, agreed before the transaction is even finalized — it never appears anywhere in the books; only the net price is recorded. Cash discount, by contrast, is offered at the point of settlement as an incentive for prompt payment, and it IS recorded, through Discount Allowed A/c (an expense) or Discount Received A/c (an income).",
    "p2": "In compound entries involving discount, the personal account (debtor or creditor) is always settled for the FULL original amount, while the discount account absorbs the difference between what was billed and what was actually paid or received."
  }
]
    },
    concepts: [
  {
    "title": "Golden Rules",
    "body": "The three traditional rules — Personal (Debit the receiver, Credit the giver), Real (Debit what comes in, Credit what goes out), and Nominal (Debit expenses/losses, Credit incomes/gains) — are the foundation of manual bookkeeping classification."
  },
  {
    "title": "Modern Rules",
    "body": "Assets and Expenses increase with a Debit; Liabilities, Capital, and Revenue increase with a Credit. This approach is faster once you're comfortable moving between account categories and the accounting equation."
  },
  {
    "title": "Representative Personal Accounts",
    "body": "Accounts like Outstanding Salary, Prepaid Insurance, and Bank A/c don't look like a 'person' at first glance, but they stand in for one — a set of employees owed money, a future benefit owed to the firm, or the bank as a legal entity."
  },
  {
    "title": "Purchases & Sales as Nominal Accounts",
    "body": "Despite dealing with physical goods, Purchases A/c and Sales A/c are treated as Nominal accounts in the traditional system, since they represent the cost of stock acquired and the revenue earned from trading it."
  },
  {
    "title": "Discount: Trade vs Cash",
    "body": "Trade discount is never recorded — the books only ever see the net price. Cash discount IS recorded, because it's a genuine cost (or gain) tied to how quickly a bill is settled."
  },
  {
    "title": "Goods Withdrawn Without a Sale",
    "body": "Charity, free samples, and drawings of goods are all valued strictly at cost and are credited to Purchases A/c — never to Sales A/c, since no outside party has actually bought them."
  }
],
    numericals: [
  {
    "id": 1,
    "difficulty": "Easy",
    "transaction": "Started business with cash ₹50,000.",
    "hint": "Cash coming into the business is a Real account rule; the proprietor is the giver of capital.",
    "accounts": [
      {
        "name": "Cash A/c",
        "type": "Real",
        "treatment": "Debit",
        "reason": "Cash comes into the business"
      },
      {
        "name": "Capital A/c",
        "type": "Personal",
        "treatment": "Credit",
        "reason": "Proprietor is the giver of capital"
      }
    ],
    "modern": {
      "debit": "Asset (Cash) increases",
      "credit": "Capital increases"
    },
    "explanation": "Every rupee the owner puts in is simultaneously an asset for the business and a liability the business owes back to the owner — captured here as Cash debited and Capital credited."
  },
  {
    "id": 2,
    "difficulty": "Easy",
    "transaction": "Purchased goods for cash ₹8,000.",
    "hint": "Purchases A/c is a Nominal account — debit all expenses.",
    "accounts": [
      {
        "name": "Purchases A/c",
        "type": "Nominal",
        "treatment": "Debit",
        "reason": "Debit all expenses — buying stock-in-trade is treated as the trading expense"
      },
      {
        "name": "Cash A/c",
        "type": "Real",
        "treatment": "Credit",
        "reason": "Cash goes out of the business"
      }
    ],
    "modern": {
      "debit": "Expense (Purchases) increases",
      "credit": "Asset (Cash) decreases"
    },
    "explanation": "Purchases A/c is conventionally classified as a Nominal account in the traditional system, so it is debited exactly like any other expense."
  },
  {
    "id": 3,
    "difficulty": "Easy",
    "transaction": "Sold goods for cash ₹12,000.",
    "hint": "Cash is coming in (Real); Sales is an income (Nominal).",
    "accounts": [
      {
        "name": "Cash A/c",
        "type": "Real",
        "treatment": "Debit",
        "reason": "Cash comes into the business"
      },
      {
        "name": "Sales A/c",
        "type": "Nominal",
        "treatment": "Credit",
        "reason": "Credit all incomes and gains"
      }
    ],
    "modern": {
      "debit": "Asset (Cash) increases",
      "credit": "Revenue increases"
    },
    "explanation": "A cash sale increases both an asset (cash in hand) and the firm's revenue for the period — hence Cash is debited and Sales is credited."
  },
  {
    "id": 4,
    "difficulty": "Easy",
    "transaction": "Paid rent ₹3,000 in cash.",
    "hint": "Rent is an expense — debit all expenses, credit the account that gave the cash.",
    "accounts": [
      {
        "name": "Rent A/c",
        "type": "Nominal",
        "treatment": "Debit",
        "reason": "Debit all expenses"
      },
      {
        "name": "Cash A/c",
        "type": "Real",
        "treatment": "Credit",
        "reason": "Cash goes out of the business"
      }
    ],
    "modern": {
      "debit": "Expense increases",
      "credit": "Asset (Cash) decreases"
    },
    "explanation": "A straightforward expense payment: the expense account is debited and the asset that funded it is credited."
  },
  {
    "id": 5,
    "difficulty": "Easy",
    "transaction": "Received commission ₹2,500 in cash.",
    "hint": "Commission received is income — credit all incomes and gains.",
    "accounts": [
      {
        "name": "Cash A/c",
        "type": "Real",
        "treatment": "Debit",
        "reason": "Cash comes into the business"
      },
      {
        "name": "Commission Received A/c",
        "type": "Nominal",
        "treatment": "Credit",
        "reason": "Credit all incomes and gains"
      }
    ],
    "modern": {
      "debit": "Asset (Cash) increases",
      "credit": "Revenue (Commission) increases"
    },
    "explanation": "Income received is credited under the Nominal account rule, while the cash that came in is debited as a Real account."
  },
  {
    "id": 6,
    "difficulty": "Easy",
    "transaction": "Paid salary to employees ₹15,000 in cash.",
    "hint": "Salary is an expense paid out of cash.",
    "accounts": [
      {
        "name": "Salary A/c",
        "type": "Nominal",
        "treatment": "Debit",
        "reason": "Debit all expenses"
      },
      {
        "name": "Cash A/c",
        "type": "Real",
        "treatment": "Credit",
        "reason": "Cash goes out of the business"
      }
    ],
    "modern": {
      "debit": "Expense increases",
      "credit": "Asset (Cash) decreases"
    },
    "explanation": "Same pattern as rent — an expense account debited, cash credited as it leaves the business."
  },
  {
    "id": 7,
    "difficulty": "Easy",
    "transaction": "Purchased furniture for cash ₹7,000.",
    "hint": "Both accounts here are Real accounts — one comes in, one goes out.",
    "accounts": [
      {
        "name": "Furniture A/c",
        "type": "Real",
        "treatment": "Debit",
        "reason": "Furniture comes into the business"
      },
      {
        "name": "Cash A/c",
        "type": "Real",
        "treatment": "Credit",
        "reason": "Cash goes out of the business"
      }
    ],
    "modern": {
      "debit": "Asset (Furniture) increases",
      "credit": "Asset (Cash) decreases"
    },
    "explanation": "This is a pure asset-for-asset swap — total assets are unchanged, only their composition shifts from cash to furniture."
  },
  {
    "id": 8,
    "difficulty": "Easy",
    "transaction": "The proprietor withdrew ₹4,000 cash for personal use.",
    "hint": "Drawings is treated as a personal account of the proprietor, who is the receiver here.",
    "accounts": [
      {
        "name": "Drawings A/c",
        "type": "Personal",
        "treatment": "Debit",
        "reason": "The proprietor, as receiver of the cash, is debited"
      },
      {
        "name": "Cash A/c",
        "type": "Real",
        "treatment": "Credit",
        "reason": "Cash goes out of the business"
      }
    ],
    "modern": {
      "debit": "Capital effectively decreases (via Drawings)",
      "credit": "Asset (Cash) decreases"
    },
    "explanation": "Drawings reduce what the business owes the owner — it is recorded as a debit to Drawings and eventually deducted from Capital."
  },
  {
    "id": 9,
    "difficulty": "Easy",
    "transaction": "Received cash ₹6,000 from Ramesh, a debtor.",
    "hint": "Ramesh is giving cash back to the firm — he is the giver.",
    "accounts": [
      {
        "name": "Cash A/c",
        "type": "Real",
        "treatment": "Debit",
        "reason": "Cash comes into the business"
      },
      {
        "name": "Ramesh's A/c",
        "type": "Personal",
        "treatment": "Credit",
        "reason": "Ramesh, the giver of cash, is credited"
      }
    ],
    "modern": {
      "debit": "Asset (Cash) increases",
      "credit": "Asset (Debtors) decreases"
    },
    "explanation": "One asset (a debtor's claim) converts into another asset (cash) — Ramesh's personal account is credited to close out what he owed."
  },
  {
    "id": 10,
    "difficulty": "Easy",
    "transaction": "Paid cash ₹9,000 to Suresh, a creditor.",
    "hint": "Suresh is receiving the cash — he is the receiver.",
    "accounts": [
      {
        "name": "Suresh's A/c",
        "type": "Personal",
        "treatment": "Debit",
        "reason": "Suresh, the receiver of cash, is debited"
      },
      {
        "name": "Cash A/c",
        "type": "Real",
        "treatment": "Credit",
        "reason": "Cash goes out of the business"
      }
    ],
    "modern": {
      "debit": "Liability (Creditor) decreases",
      "credit": "Asset (Cash) decreases"
    },
    "explanation": "Paying off a creditor reduces a liability and an asset together — Suresh's account is debited to show the debt is settled."
  },
  {
    "id": 11,
    "difficulty": "Easy",
    "transaction": "Deposited cash ₹20,000 into the bank.",
    "hint": "Bank is treated as a personal account (an artificial/legal person) — it is the receiver.",
    "accounts": [
      {
        "name": "Bank A/c",
        "type": "Personal",
        "treatment": "Debit",
        "reason": "The bank, as receiver of the deposit, is debited"
      },
      {
        "name": "Cash A/c",
        "type": "Real",
        "treatment": "Credit",
        "reason": "Cash goes out of hand into the bank"
      }
    ],
    "modern": {
      "debit": "Asset (Bank balance) increases",
      "credit": "Asset (Cash) decreases"
    },
    "explanation": "Only the form of the asset changes — cash-in-hand becomes cash-at-bank; the bank account is treated as a personal account since a bank is a distinct legal entity."
  },
  {
    "id": 12,
    "difficulty": "Easy",
    "transaction": "Paid electricity bill ₹1,200 in cash.",
    "hint": "An expense account is always debited when the expense is incurred.",
    "accounts": [
      {
        "name": "Electricity Expenses A/c",
        "type": "Nominal",
        "treatment": "Debit",
        "reason": "Debit all expenses"
      },
      {
        "name": "Cash A/c",
        "type": "Real",
        "treatment": "Credit",
        "reason": "Cash goes out of the business"
      }
    ],
    "modern": {
      "debit": "Expense increases",
      "credit": "Asset (Cash) decreases"
    },
    "explanation": "A routine utility payment follows the same expense-debit, cash-credit pattern as rent and salary."
  },
  {
    "id": 13,
    "difficulty": "Medium",
    "transaction": "Purchased goods from Mehta on credit ₹18,000.",
    "hint": "No cash moves yet — Mehta is the giver of goods, so his personal account is credited.",
    "accounts": [
      {
        "name": "Purchases A/c",
        "type": "Nominal",
        "treatment": "Debit",
        "reason": "Debit all expenses — the goods purchased"
      },
      {
        "name": "Mehta's A/c",
        "type": "Personal",
        "treatment": "Credit",
        "reason": "Mehta, the giver of goods, is credited"
      }
    ],
    "modern": {
      "debit": "Expense (Purchases) increases",
      "credit": "Liability (Creditor) increases"
    },
    "explanation": "Buying on credit still increases the Purchases expense immediately; the obligation to pay Mehta later is recorded as a liability via his personal account."
  },
  {
    "id": 14,
    "difficulty": "Medium",
    "transaction": "Sold goods to Bansal on credit ₹22,000.",
    "hint": "Bansal receives the goods and now owes the firm — he is the receiver.",
    "accounts": [
      {
        "name": "Bansal's A/c",
        "type": "Personal",
        "treatment": "Debit",
        "reason": "Bansal, the receiver of goods, is debited"
      },
      {
        "name": "Sales A/c",
        "type": "Nominal",
        "treatment": "Credit",
        "reason": "Credit all incomes and gains"
      }
    ],
    "modern": {
      "debit": "Asset (Debtors) increases",
      "credit": "Revenue increases"
    },
    "explanation": "A credit sale still counts as revenue immediately; Bansal's account is debited because he now owes the firm the sale value."
  },
  {
    "id": 15,
    "difficulty": "Medium",
    "transaction": "Took a loan from the bank of ₹1,00,000.",
    "hint": "Two personal accounts are involved here — the bank gives the loan, so it is credited; the firm's bank balance is what actually receives the money.",
    "accounts": [
      {
        "name": "Bank A/c",
        "type": "Personal",
        "treatment": "Debit",
        "reason": "The bank balance, as receiver of the loan amount, is debited"
      },
      {
        "name": "Bank Loan A/c",
        "type": "Personal",
        "treatment": "Credit",
        "reason": "The lending bank, as giver of the loan, is credited"
      }
    ],
    "modern": {
      "debit": "Asset (Bank balance) increases",
      "credit": "Liability (Loan) increases"
    },
    "explanation": "A loan simultaneously increases an asset (money now available) and a liability (the obligation to repay) — both effects are personal-account entries here."
  },
  {
    "id": 16,
    "difficulty": "Medium",
    "transaction": "Paid interest of ₹2,000 on the bank loan, by cheque.",
    "hint": "Interest paid is an expense, funded from the bank balance.",
    "accounts": [
      {
        "name": "Interest on Loan A/c",
        "type": "Nominal",
        "treatment": "Debit",
        "reason": "Debit all expenses"
      },
      {
        "name": "Bank A/c",
        "type": "Personal",
        "treatment": "Credit",
        "reason": "The bank, as giver of the cheque amount, is credited"
      }
    ],
    "modern": {
      "debit": "Expense increases",
      "credit": "Asset (Bank balance) decreases"
    },
    "explanation": "Interest is a cost of borrowing and is debited as an expense; paying by cheque reduces the bank balance, so Bank A/c is credited."
  },
  {
    "id": 17,
    "difficulty": "Medium",
    "transaction": "Goods worth ₹1,500 (at cost) were distributed as free samples for advertisement.",
    "hint": "The goods leaving for promotion count as an advertising expense, and Purchases must be reduced by the same value.",
    "accounts": [
      {
        "name": "Advertisement (Free Samples) A/c",
        "type": "Nominal",
        "treatment": "Debit",
        "reason": "Debit all expenses — this is a promotional cost"
      },
      {
        "name": "Purchases A/c",
        "type": "Nominal",
        "treatment": "Credit",
        "reason": "The value of goods given away is removed from Purchases"
      }
    ],
    "modern": {
      "debit": "Expense (Advertisement) increases",
      "credit": "Expense (Purchases) decreases"
    },
    "explanation": "No sale has occurred, so Sales A/c is never used here — instead, the goods are reclassified out of Purchases and into an advertisement expense."
  },
  {
    "id": 18,
    "difficulty": "Medium",
    "transaction": "Goods worth ₹1,000 (at cost) were given away as charity.",
    "hint": "Same logic as free samples — goods leave the business for a non-trading reason.",
    "accounts": [
      {
        "name": "Charity A/c",
        "type": "Nominal",
        "treatment": "Debit",
        "reason": "Debit all expenses/losses — charity is a distribution, not a sale"
      },
      {
        "name": "Purchases A/c",
        "type": "Nominal",
        "treatment": "Credit",
        "reason": "The value of goods donated is removed from Purchases"
      }
    ],
    "modern": {
      "debit": "Expense (Charity) increases",
      "credit": "Expense (Purchases) decreases"
    },
    "explanation": "Whenever stock leaves the business without being sold — samples, charity, or personal use — Purchases A/c is credited to keep the trading figures accurate."
  },
  {
    "id": 19,
    "difficulty": "Medium",
    "transaction": "Depreciation of ₹5,000 was charged on machinery.",
    "hint": "The asset itself is what 'goes out' in value — Real account rule applies to the credit side.",
    "accounts": [
      {
        "name": "Depreciation A/c",
        "type": "Nominal",
        "treatment": "Debit",
        "reason": "Debit all expenses/losses"
      },
      {
        "name": "Machinery A/c",
        "type": "Real",
        "treatment": "Credit",
        "reason": "The value of machinery going down means value 'goes out' of that asset"
      }
    ],
    "modern": {
      "debit": "Expense increases",
      "credit": "Asset (Machinery) decreases"
    },
    "explanation": "Depreciation is a non-cash expense that directly reduces the book value of the asset — no cash or bank account is touched at all."
  },
  {
    "id": 20,
    "difficulty": "Medium",
    "transaction": "A debtor's balance of ₹2,000 was written off as bad debt.",
    "hint": "The debtor no longer owes anything, so his personal account must be credited to close it.",
    "accounts": [
      {
        "name": "Bad Debts A/c",
        "type": "Nominal",
        "treatment": "Debit",
        "reason": "Debit all losses"
      },
      {
        "name": "Debtor's A/c",
        "type": "Personal",
        "treatment": "Credit",
        "reason": "The debtor's account is credited to write off what they no longer owe"
      }
    ],
    "modern": {
      "debit": "Expense/Loss increases",
      "credit": "Asset (Debtors) decreases"
    },
    "explanation": "Bad debts recognize that an asset (the amount receivable) has become worthless — the loss is debited and the debtor's account is credited to zero it out."
  },
  {
    "id": 21,
    "difficulty": "Medium",
    "transaction": "Outstanding salary of ₹3,000 was recorded at the year-end (salary due but not yet paid).",
    "hint": "No cash has moved — a liability is being created for an expense already incurred.",
    "accounts": [
      {
        "name": "Salary A/c",
        "type": "Nominal",
        "treatment": "Debit",
        "reason": "Debit all expenses, even if unpaid"
      },
      {
        "name": "Outstanding Salary A/c",
        "type": "Personal",
        "treatment": "Credit",
        "reason": "A representative personal account standing for the employees who are owed this amount"
      }
    ],
    "modern": {
      "debit": "Expense increases",
      "credit": "Liability increases"
    },
    "explanation": "Accrual accounting requires the expense to be recognized in the period it is incurred, regardless of when it is actually paid — hence a liability account is credited instead of cash."
  },
  {
    "id": 22,
    "difficulty": "Medium",
    "transaction": "Paid ₹1,800 cash in advance for an insurance policy covering the next year.",
    "hint": "The business now has a future benefit coming — that future benefit is itself treated like a receivable.",
    "accounts": [
      {
        "name": "Prepaid Insurance A/c",
        "type": "Personal",
        "treatment": "Debit",
        "reason": "A representative personal account for the benefit not yet used, treated as a receivable"
      },
      {
        "name": "Cash A/c",
        "type": "Real",
        "treatment": "Credit",
        "reason": "Cash goes out of the business"
      }
    ],
    "modern": {
      "debit": "Asset (Prepaid expense) increases",
      "credit": "Asset (Cash) decreases"
    },
    "explanation": "Paying for a service before it's consumed doesn't create an expense yet — it creates an asset (a right to future coverage), which is why Insurance A/c isn't debited directly here."
  },
  {
    "id": 23,
    "difficulty": "Medium",
    "transaction": "Goods worth ₹4,000 (at cost) were destroyed by fire; the loss is uninsured.",
    "hint": "Nothing is recovered — this is a straightforward loss reducing Purchases.",
    "accounts": [
      {
        "name": "Loss by Fire A/c",
        "type": "Nominal",
        "treatment": "Debit",
        "reason": "Debit all losses"
      },
      {
        "name": "Purchases A/c",
        "type": "Nominal",
        "treatment": "Credit",
        "reason": "The value of goods destroyed is removed from Purchases"
      }
    ],
    "modern": {
      "debit": "Loss increases",
      "credit": "Expense (Purchases) decreases"
    },
    "explanation": "Since there's no insurance claim, the entire cost of the destroyed goods becomes a pure loss with no compensating asset created."
  },
  {
    "id": 24,
    "difficulty": "Medium",
    "transaction": "Interest of ₹2,000 was allowed on the proprietor's capital.",
    "hint": "This interest is a cost to the business but adds to what the business owes the owner.",
    "accounts": [
      {
        "name": "Interest on Capital A/c",
        "type": "Nominal",
        "treatment": "Debit",
        "reason": "Debit all expenses — a cost of using the owner's funds"
      },
      {
        "name": "Capital A/c",
        "type": "Personal",
        "treatment": "Credit",
        "reason": "The proprietor, as the party being credited this benefit, is credited"
      }
    ],
    "modern": {
      "debit": "Expense increases",
      "credit": "Capital increases"
    },
    "explanation": "Interest on capital rewards the owner for the funds tied up in the business — it is an expense from the business's point of view but increases the owner's stake."
  },
  {
    "id": 25,
    "difficulty": "Hard",
    "transaction": "Purchased machinery worth ₹50,000, paying ₹20,000 by cheque immediately and the balance on credit from the supplier, Kiran Traders.",
    "hint": "This is a compound entry — one asset comes in fully, funded by two different sources.",
    "accounts": [
      {
        "name": "Machinery A/c",
        "type": "Real",
        "treatment": "Debit",
        "reason": "The full value of machinery comes into the business (₹50,000)"
      },
      {
        "name": "Bank A/c",
        "type": "Personal",
        "treatment": "Credit",
        "reason": "The bank, as giver of the cheque amount, is credited (₹20,000)"
      },
      {
        "name": "Kiran Traders A/c",
        "type": "Personal",
        "treatment": "Credit",
        "reason": "The supplier, as giver of the remaining goods on credit, is credited (₹30,000)"
      }
    ],
    "modern": {
      "debit": "Asset (Machinery) increases by 50,000",
      "credit": "Asset (Bank) decreases by 20,000; Liability (Creditor) increases by 30,000"
    },
    "explanation": "Compound entries simply apply the golden rules to every account touched — the debit and credit sides still total the same figure, ₹50,000 on each side."
  },
  {
    "id": 26,
    "difficulty": "Hard",
    "transaction": "Sold goods worth ₹20,000 to Verma; received ₹5,000 cash immediately and the rest on credit.",
    "hint": "The full sale value is credited to Sales; the two ways payment is received are debited separately.",
    "accounts": [
      {
        "name": "Cash A/c",
        "type": "Real",
        "treatment": "Debit",
        "reason": "Cash comes in immediately (₹5,000)"
      },
      {
        "name": "Verma's A/c",
        "type": "Personal",
        "treatment": "Debit",
        "reason": "Verma, receiver of the remaining goods on credit, is debited (₹15,000)"
      },
      {
        "name": "Sales A/c",
        "type": "Nominal",
        "treatment": "Credit",
        "reason": "Credit all incomes and gains — the full sale value (₹20,000)"
      }
    ],
    "modern": {
      "debit": "Asset (Cash) increases by 5,000; Asset (Debtors) increases by 15,000",
      "credit": "Revenue increases by 20,000"
    },
    "explanation": "Splitting a single sale between cash and credit doesn't change the total revenue recognized — it only splits which asset account records the receivable portion."
  },
  {
    "id": 27,
    "difficulty": "Hard",
    "transaction": "Purchased goods listed at ₹30,000 from Kunal, paid ₹10,000 immediately by cash, remaining on credit. The bill already showed the trade-discounted price.",
    "hint": "Trade discount is never entered in the books — the bill's net figure is the actual transaction value.",
    "accounts": [
      {
        "name": "Purchases A/c",
        "type": "Nominal",
        "treatment": "Debit",
        "reason": "Debit all expenses — recorded at the net, trade-discounted value (₹30,000, as already billed)"
      },
      {
        "name": "Cash A/c",
        "type": "Real",
        "treatment": "Credit",
        "reason": "Cash goes out immediately (₹10,000)"
      },
      {
        "name": "Kunal's A/c",
        "type": "Personal",
        "treatment": "Credit",
        "reason": "Kunal, giver of the remaining goods on credit, is credited (₹20,000)"
      }
    ],
    "modern": {
      "debit": "Expense (Purchases) increases by 30,000",
      "credit": "Asset (Cash) decreases by 10,000; Liability increases by 20,000"
    },
    "explanation": "Trade discount is a reduction in the listed price before the sale is even finalized, so it never touches the ledger — only the final billed amount does."
  },
  {
    "id": 28,
    "difficulty": "Hard",
    "transaction": "Received a cheque of ₹9,700 from Rohan in full settlement of his account of ₹10,000 (cash discount ₹300 allowed).",
    "hint": "Rohan's account must be cleared for the full ₹10,000 even though only ₹9,700 was actually received.",
    "accounts": [
      {
        "name": "Bank A/c",
        "type": "Personal",
        "treatment": "Debit",
        "reason": "The bank, receiver of the cheque, is debited (₹9,700)"
      },
      {
        "name": "Discount Allowed A/c",
        "type": "Nominal",
        "treatment": "Debit",
        "reason": "Debit all expenses/losses — the discount is a cost of getting paid promptly (₹300)"
      },
      {
        "name": "Rohan's A/c",
        "type": "Personal",
        "treatment": "Credit",
        "reason": "Rohan, giver of the cheque, is credited in full — his account is now settled (₹10,000)"
      }
    ],
    "modern": {
      "debit": "Asset (Bank) increases by 9,700; Expense (Discount Allowed) increases by 300",
      "credit": "Asset (Debtors) decreases by 10,000"
    },
    "explanation": "Cash discount, unlike trade discount, IS recorded in the books because it's an incentive given at the time of settlement, not at the time of the original sale."
  },
  {
    "id": 29,
    "difficulty": "Hard",
    "transaction": "Paid ₹18,600 by cheque to Farida in full settlement of ₹19,000 owed (discount received ₹400).",
    "hint": "Farida's account is cleared for the full amount owed; the discount received is a gain to the business.",
    "accounts": [
      {
        "name": "Farida's A/c",
        "type": "Personal",
        "treatment": "Debit",
        "reason": "Farida, the receiver of payment, is debited in full — her account is now settled (₹19,000)"
      },
      {
        "name": "Bank A/c",
        "type": "Personal",
        "treatment": "Credit",
        "reason": "The bank, giver of the cheque amount, is credited (₹18,600)"
      },
      {
        "name": "Discount Received A/c",
        "type": "Nominal",
        "treatment": "Credit",
        "reason": "Credit all incomes and gains — the discount is a saving for the business (₹400)"
      }
    ],
    "modern": {
      "debit": "Liability (Creditor) decreases by 19,000",
      "credit": "Asset (Bank) decreases by 18,600; Revenue increases by 400"
    },
    "explanation": "Mirror image of question 28 — this time the business is the one settling a debt early and receiving the discount as a benefit."
  },
  {
    "id": 30,
    "difficulty": "Hard",
    "transaction": "Purchased furniture worth ₹25,000 from Modern Furniture House, paying ₹5,000 by cash and the balance by cheque.",
    "hint": "One asset comes in fully; two different accounts fund the payment.",
    "accounts": [
      {
        "name": "Furniture A/c",
        "type": "Real",
        "treatment": "Debit",
        "reason": "Furniture comes into the business in full (₹25,000)"
      },
      {
        "name": "Cash A/c",
        "type": "Real",
        "treatment": "Credit",
        "reason": "Cash goes out (₹5,000)"
      },
      {
        "name": "Bank A/c",
        "type": "Personal",
        "treatment": "Credit",
        "reason": "The bank, giver of the cheque amount, is credited (₹20,000)"
      }
    ],
    "modern": {
      "debit": "Asset (Furniture) increases by 25,000",
      "credit": "Asset (Cash) decreases by 5,000; Asset (Bank) decreases by 20,000"
    },
    "explanation": "Because the supplier was paid in full immediately (partly cash, partly cheque), no liability account is needed at all — only asset accounts are affected."
  },
  {
    "id": 31,
    "difficulty": "Hard",
    "transaction": "Goods worth ₹6,000 (at cost) were destroyed by theft; the insurance company admitted a claim of ₹4,000, and the rest is an uninsured loss.",
    "hint": "Split the loss into what's recoverable (an asset — a claim) and what's genuinely lost.",
    "accounts": [
      {
        "name": "Insurance Claim A/c",
        "type": "Personal",
        "treatment": "Debit",
        "reason": "The insurance company, as receiver-turned-payer of the admitted claim, gives rise to a receivable (₹4,000)"
      },
      {
        "name": "Loss by Theft A/c",
        "type": "Nominal",
        "treatment": "Debit",
        "reason": "Debit all losses — the uninsured portion (₹2,000)"
      },
      {
        "name": "Purchases A/c",
        "type": "Nominal",
        "treatment": "Credit",
        "reason": "The full value of stolen goods is removed from Purchases (₹6,000)"
      }
    ],
    "modern": {
      "debit": "Asset (Insurance Claim Receivable) increases by 4,000; Loss increases by 2,000",
      "credit": "Expense (Purchases) decreases by 6,000"
    },
    "explanation": "Only the amount the insurer refuses to pay becomes a true loss to the business — the admitted claim is still an asset until it's actually received."
  },
  {
    "id": 32,
    "difficulty": "Hard",
    "transaction": "The proprietor withdrew ₹5,000 cash and goods worth ₹2,000 (at cost) for personal use.",
    "hint": "Both withdrawals reduce what belongs to the business, but they come from two different accounts.",
    "accounts": [
      {
        "name": "Drawings A/c",
        "type": "Personal",
        "treatment": "Debit",
        "reason": "The proprietor, as receiver of both cash and goods, is debited for the combined value (₹7,000)"
      },
      {
        "name": "Cash A/c",
        "type": "Real",
        "treatment": "Credit",
        "reason": "Cash goes out of the business (₹5,000)"
      },
      {
        "name": "Purchases A/c",
        "type": "Nominal",
        "treatment": "Credit",
        "reason": "The goods taken are removed from Purchases at cost (₹2,000)"
      }
    ],
    "modern": {
      "debit": "Capital effectively decreases by 7,000 (via Drawings)",
      "credit": "Asset (Cash) decreases by 5,000; Expense (Purchases) decreases by 2,000"
    },
    "explanation": "Drawings of goods are valued strictly at cost, never at selling price, since no sale to an outsider has actually taken place."
  },
  {
    "id": 33,
    "difficulty": "Hard",
    "transaction": "Received ₹3,000 cash as commission in advance for services to be rendered next year.",
    "hint": "The service hasn't been performed yet, so this can't be treated as income right now.",
    "accounts": [
      {
        "name": "Cash A/c",
        "type": "Real",
        "treatment": "Debit",
        "reason": "Cash comes into the business"
      },
      {
        "name": "Commission Received in Advance A/c",
        "type": "Personal",
        "treatment": "Credit",
        "reason": "A representative personal account for the obligation to perform the service later"
      }
    ],
    "modern": {
      "debit": "Asset (Cash) increases",
      "credit": "Liability increases"
    },
    "explanation": "Money received for a service not yet delivered is a liability (an obligation to the customer), not income — it will be transferred to Commission Received A/c only once earned."
  },
  {
    "id": 34,
    "difficulty": "Hard",
    "transaction": "Accrued interest on investments of ₹1,200 was recorded, though not yet actually received.",
    "hint": "The income has been earned under accrual accounting, even without cash changing hands.",
    "accounts": [
      {
        "name": "Accrued Interest A/c",
        "type": "Personal",
        "treatment": "Debit",
        "reason": "A representative personal account standing in as a receivable for interest earned but not yet collected"
      },
      {
        "name": "Interest on Investment A/c",
        "type": "Nominal",
        "treatment": "Credit",
        "reason": "Credit all incomes and gains, once earned"
      }
    ],
    "modern": {
      "debit": "Asset (Interest Receivable) increases",
      "credit": "Revenue increases"
    },
    "explanation": "This is the mirror case of outstanding expenses — income is recognized when earned, and the yet-uncollected amount is parked in a receivable account."
  },
  {
    "id": 35,
    "difficulty": "Hard",
    "transaction": "Purchased a computer for office use, ₹40,000, paying half by cheque immediately and the rest on credit from the supplier, TechMart.",
    "hint": "A fixed asset bought on credit creates a specific liability to the supplier, separate from trade Purchases.",
    "accounts": [
      {
        "name": "Computer A/c",
        "type": "Real",
        "treatment": "Debit",
        "reason": "The computer comes into the business in full (₹40,000)"
      },
      {
        "name": "Bank A/c",
        "type": "Personal",
        "treatment": "Credit",
        "reason": "The bank, giver of the cheque amount, is credited (₹20,000)"
      },
      {
        "name": "TechMart A/c",
        "type": "Personal",
        "treatment": "Credit",
        "reason": "TechMart, giver of the remaining value on credit, is credited (₹20,000)"
      }
    ],
    "modern": {
      "debit": "Asset (Computer) increases by 40,000",
      "credit": "Asset (Bank) decreases by 20,000; Liability increases by 20,000"
    },
    "explanation": "Because this is office equipment (a fixed asset) and not stock-in-trade, Purchases A/c is never used — the asset account itself is debited directly."
  },
  {
    "id": 36,
    "difficulty": "Hard",
    "transaction": "A cheque of ₹8,000 received earlier from a customer, Aakash, was dishonoured by the bank.",
    "hint": "A dishonoured cheque reverses the earlier settlement — the customer's debt is restored.",
    "accounts": [
      {
        "name": "Aakash's A/c",
        "type": "Personal",
        "treatment": "Debit",
        "reason": "Aakash, whose debt is reinstated, is debited again"
      },
      {
        "name": "Bank A/c",
        "type": "Personal",
        "treatment": "Credit",
        "reason": "The bank balance is reduced since the expected deposit did not actually clear"
      }
    ],
    "modern": {
      "debit": "Asset (Debtors) increases (reinstated)",
      "credit": "Asset (Bank) decreases"
    },
    "explanation": "A dishonoured cheque is essentially an 'undo' entry — it exactly reverses the debit and credit of the original receipt, since the payment never truly went through."
  }
],

    /* --------------------------------------------------------
       NEW SECTION — Common Mistakes & Traps
       A curated reference distinct from the transaction bank:
       instead of one worked example each, these group together
       the classification errors students repeat most often
       across many different transaction types, so they can be
       revised as a checklist right before a test.
       -------------------------------------------------------- */
    commonMistakes: [
      {
        trap: "Confusing 'Debtor' with 'Debit' by sound alone",
        wrong: "Assuming a debtor's account is always debited because the word sounds like 'debit'.",
        right: "A debtor's account is debited only while they owe money (an increasing asset). The moment they pay up, their account is credited to close the balance — the direction depends on the transaction, not the word itself.",
        chapterLink: "See transactions on receiving payment from a debtor."
      },
      {
        trap: "Treating 'Debtors' as a liability",
        wrong: "Reading 'debtor' as related to debt owed BY the business, and crediting it as a liability.",
        right: "A debtor owes money TO the business — they are an asset (a Real/Personal account with a debit balance), not a liability. Creditors, not debtors, represent what the business owes to others.",
        chapterLink: "Compare Debtors vs. Creditors examples in the transaction bank."
      },
      {
        trap: "Forgetting representative personal accounts",
        wrong: "Treating Outstanding Salary or Prepaid Insurance as Nominal accounts, since they sound related to an expense.",
        right: "These are representative Personal accounts — they stand in for the actual person owed money (employees) or owing a future benefit (the insurer). Only the expense itself (Salary A/c, Insurance A/c) is Nominal; the outstanding/prepaid balance is Personal.",
        chapterLink: "Review the theory section on representative personal accounts."
      },
      {
        trap: "Crediting Discount Allowed",
        wrong: "Crediting Discount Allowed because a 'discount' sounds like something gained.",
        right: "Discount Allowed is a loss to the business — the business is giving up income to encourage early payment — so it is always debited, following the Nominal rule for expenses/losses. Discount Received (the opposite situation) is what gets credited.",
        chapterLink: "See the discount allowed/received pair of transactions."
      },
      {
        trap: "Assuming trade discount gets its own account",
        wrong: "Recording a separate 'Trade Discount A/c' entry when a bill mentions a trade discount.",
        right: "Trade discount is deducted before any entry is made at all — it never appears anywhere in the journal or ledger. Only cash discount, given at the time of settlement, gets its own Nominal account (Discount Allowed/Received).",
        chapterLink: "Compare the trade discount vs. cash discount transactions."
      },
      {
        trap: "Treating a bank overdraft as an asset",
        wrong: "Debiting Bank A/c when an overdraft is taken, since 'bank' feels like an asset account by default.",
        right: "An overdraft means the account balance has gone negative — the business now owes the bank. This makes it a liability, credited, not an asset.",
        chapterLink: "See the bank overdraft transaction example."
      },
      {
        trap: "Capitalizing every large payment automatically",
        wrong: "Assuming any large amount paid (repairs, legal fees, carriage) must be added to an asset's cost just because the amount is significant.",
        right: "Only costs that genuinely extend an asset's life, capacity, or bring it into first use are capitalized (added to the asset account). Routine repairs and maintenance, however large, are always expensed as Nominal accounts — size alone doesn't decide the treatment.",
        chapterLink: "Compare the machinery-installation vs. routine-repair transactions."
      },
      {
        trap: "Forgetting goods-related entries reduce Purchases, not Sales",
        wrong: "Crediting Sales A/c when goods are given as charity, drawings, or lost by fire.",
        right: "Since these goods were never sold, Sales A/c is never touched. Purchases A/c is credited instead, since the goods are simply leaving the business's stock through a route other than a sale.",
        chapterLink: "See the charity, drawings-of-goods, and loss-by-fire transactions."
      }
    ],

    /* --------------------------------------------------------
       BALANCE SHEET TYPE QUESTIONS — the link between correctly
       debiting/crediting an account and the closing balances
       that eventually sit on the Balance Sheet. Same
       given/ask/steps/answer shape as Chapter 1's numericals so
       they render in the same practice-card component.
       -------------------------------------------------------- */
    balanceSheetQuestions: [
      { id:1, difficulty:"Easy",
        given:{assets:180000, liabilities:45000}, ask:"capital",
        transaction:"After posting a month's entries, a firm's ledger shows total Assets of ₹1,80,000 and total Liabilities of ₹45,000. Find the Capital that must appear on the Balance Sheet.",
        hint:"Every account you correctly debited or credited eventually settles into one of these three balances — rearrange Assets = Capital + Liabilities.",
        steps:["Capital = Assets − Liabilities","Capital = 1,80,000 − 45,000","Capital = 1,35,000"],
        answer:135000, explanation:"Once every transaction has been correctly classified into debits and credits, the resulting ledger balances must still satisfy the accounting equation — this is exactly what a trial balance and Balance Sheet confirm." },
      { id:2, difficulty:"Easy",
        given:{capital:250000, liabilities:60000}, ask:"assets",
        transaction:"A sole trader's books, after all postings, show Capital of ₹2,50,000 and Liabilities (Creditors + Bank Loan) of ₹60,000. What should the total of the Assets side of the Balance Sheet be?",
        hint:"The Assets side and the Capital+Liabilities side of a Balance Sheet must always add up to the same total.",
        steps:["Assets = Capital + Liabilities","Assets = 2,50,000 + 60,000","Assets = 3,10,000"],
        answer:310000, explanation:"A Balance Sheet is simply the accounting equation laid out in two columns — whatever the right side (Capital + Liabilities) totals, the left side (Assets) must match exactly." },
      { id:3, difficulty:"Easy",
        given:{assets:96000, capital:71000}, ask:"liabilities",
        transaction:"Ledger balances after posting: Cash ₹20,000, Furniture ₹36,000, Debtors ₹40,000 (Assets total ₹96,000) and Capital A/c ₹71,000. Find total Liabilities.",
        hint:"Liabilities = Assets − Capital.",
        steps:["Liabilities = 96,000 − 71,000","Liabilities = 25,000"],
        answer:25000, explanation:"Whatever portion of total assets wasn't funded by the owner's Capital account must have come from outside sources — Creditors, a Bank Loan, or similar liability accounts." },
      { id:4, difficulty:"Medium",
        given:{assets:275000, liabilities:82000}, ask:"capital",
        transaction:"A trader's ledger, after posting Cash, Stock, Debtors, Machinery (Real accounts, all debit balances) and Creditors, Bank Loan (Personal/liability accounts, credit balances), shows Assets totalling ₹2,75,000 and Liabilities totalling ₹82,000. Find Capital.",
        hint:"Real-account debit balances are assets; personal-account credit balances owed to outsiders are liabilities. What's left belongs to the owner.",
        steps:["Capital = Assets − Liabilities","Capital = 2,75,000 − 82,000","Capital = 1,93,000"],
        answer:193000, explanation:"This is the same figure a trial balance's 'Capital' line would show once all the individual account balances are correctly sorted by their Golden Rule or Modern classification." },
      { id:5, difficulty:"Medium",
        given:{assets:340000, capital:210000}, ask:"liabilities",
        transaction:"Closing balances: Cash ₹30,000, Bank ₹60,000, Stock ₹90,000, Debtors ₹70,000, Furniture ₹90,000 (Assets total ₹3,40,000). Capital A/c stands at ₹2,10,000. A trainee has not yet totalled the Creditors and Loan accounts — find what that total must be.",
        hint:"Once the correctly-classified asset balances and the Capital balance are known, the liability total is forced by the equation.",
        steps:["Liabilities = Assets − Capital","Liabilities = 3,40,000 − 2,10,000","Liabilities = 1,30,000"],
        answer:130000, explanation:"This is exactly how a Balance Sheet is squared off in practice — you don't need to re-add every creditor individually if you already trust the asset and capital totals." },
      { id:6, difficulty:"Medium", ask:"verify-and-correct",
        transaction:"A junior clerk posts entries and reports: Assets ₹4,20,000, Capital ₹3,10,000, Liabilities ₹1,00,000. Check whether the Balance Sheet tallies, and if not, state the correct Liabilities figure.",
        hint:"Add Capital and Liabilities and compare the sum to the reported Assets — a posting error (wrong debit/credit) is often the hidden cause of a mismatch.",
        steps:[
          "Capital + Liabilities = 3,10,000 + 1,00,000 = 4,10,000",
          "Reported Assets = 4,20,000",
          "4,10,000 ≠ 4,20,000 — the books do not balance as recorded.",
          "Correct Liabilities = Assets − Capital = 4,20,000 − 3,10,000 = 1,10,000"
        ],
        answer:110000, explanation:"A ₹10,000 gap like this is usually one account posted to the wrong side (a debit posted as a credit, or vice versa) — exactly the kind of slip the Golden/Modern rules in this chapter are meant to prevent." },
      { id:7, difficulty:"Hard", ask:"capital",
        transaction:"After posting, a firm's ledger shows these closing balances: Cash A/c (Dr) ₹25,000, Bank A/c (Dr) ₹65,000, Stock A/c (Dr) ₹1,10,000, Debtors A/c (Dr) ₹48,000, Machinery A/c (Dr) ₹1,52,000, Creditors A/c (Cr) ₹73,000, Bank Loan A/c (Cr) ₹90,000. Find the Capital A/c balance that makes the Balance Sheet tally.",
        hint:"First total every debit-balance (Real/asset) account, then every credit-balance liability account — Capital is whatever closes the gap.",
        steps:[
          "Total Assets = 25,000 + 65,000 + 1,10,000 + 48,000 + 1,52,000 = 4,00,000",
          "Total Liabilities = 73,000 + 90,000 = 1,63,000",
          "Capital = Assets − Liabilities = 4,00,000 − 1,63,000 = 2,37,000"
        ],
        answer:237000, explanation:"This mirrors exactly what happens after journalising and posting a full set of transactions — the individual debit and credit balances you classified using the Golden Rules must still net out to a balanced Capital figure." },
      { id:8, difficulty:"Hard", ask:"final-capital",
        transaction:"A trader starts the year with Capital ₹1,50,000. During the year: goods are purchased on credit (Purchases A/c debited, Creditors A/c credited) ₹40,000; the trader introduces further capital in cash ₹20,000; a cash sale earns a profit of ₹15,000; and ₹8,000 is withdrawn in cash for personal use (Drawings). Find the closing Capital.",
        hint:"A credit purchase changes an asset and a liability equally, leaving Capital untouched — only revenue, fresh capital, and drawings actually move the Capital account.",
        steps:[
          "Opening Capital = 1,50,000",
          "Credit purchase: Stock/Purchases ↑ with Creditors ↑ — Capital unaffected.",
          "Fresh capital introduced: +20,000 → 1,70,000",
          "Profit on cash sale: +15,000 → 1,85,000",
          "Drawings: −8,000 → 1,77,000"
        ],
        answer:177000, explanation:"Every one of these events was journalised with a debit and a credit somewhere, but only revenue, fresh capital, and drawings actually change the Capital account balance that ends up on the Balance Sheet." },
      { id:9, difficulty:"Hard",
        given:{assets:512000, liabilities:187000}, ask:"capital",
        transaction:"A firm's Trial Balance, prepared from correctly posted ledger accounts, shows total debit balances (all Real and a few representative Personal accounts, i.e. Assets) of ₹5,12,000 and total credit-side liability balances of ₹1,87,000. What Capital figure should appear so the Balance Sheet tallies?",
        hint:"A correct Trial Balance is not yet a Balance Sheet, but the debit-balance accounts that represent assets and the credit-balance accounts that represent liabilities feed straight into one.",
        steps:["Capital = Assets − Liabilities","Capital = 5,12,000 − 1,87,000","Capital = 3,25,000"],
        answer:325000, explanation:"This is the practical payoff of getting every debit and credit right in this chapter — the Balance Sheet at the end of the process is just a re-arrangement of correctly classified ledger balances." },
      { id:10, difficulty:"Medium", ask:"verify-and-correct",
        transaction:"Two ledger clerks post the same figures differently and each claims their Balance Sheet tallies. Clerk A: Assets ₹2,68,000, Capital ₹1,95,000, Liabilities ₹73,000. Clerk B: Assets ₹2,68,000, Capital ₹2,05,000, Liabilities ₹73,000. Identify which clerk is correct.",
        hint:"Only one combination of Capital and Liabilities can add up to the stated Assets — check both.",
        steps:[
          "Clerk A: Capital + Liabilities = 1,95,000 + 73,000 = 2,68,000 — matches Assets.",
          "Clerk B: Capital + Liabilities = 2,05,000 + 73,000 = 2,78,000 — does not match Assets (2,68,000)."
        ],
        answer:195000, explanation:"Clerk A is correct; Clerk B has likely posted an extra ₹10,000 to the wrong side of some account, inflating Capital without a matching entry elsewhere — the answer given here is Clerk A's correct Capital figure." }
    ],

    /* --------------------------------------------------------
       FULL BALANCE SHEET STATEMENTS — the actual two-column
       financial statement format (Liabilities side vs. Assets
       side, sub-totalled and grand-totalled to tally), matching
       how a real CBSE answer is laid out: Capital adjusted by
       Net Profit and Drawings, a separate Current Liabilities
       group, and a full mix of fixed and current assets.
       This is distinct from balanceSheetQuestions above, which
       only asks for a single missing figure — these ask the
       student to read or reconstruct the entire statement.
       -------------------------------------------------------- */
    balanceSheetStatements: [
      {
        id: 1,
        difficulty: "Medium",
        asOn: "31st March, 2024",
        prompt: "From the following figures, prepare the Balance Sheet of a sole proprietor as on 31st March, 2024.",
        rawFigures: [
          "Capital ₹1,37,450", "Net Profit for the year ₹32,450", "Drawings ₹6,000",
          "Loan on Mortgage ₹20,000", "Sundry Creditors ₹16,100",
          "Trade Marks ₹5,000", "Fixed Deposit with Bank ₹10,000", "Motor Vehicles ₹50,000",
          "Leasehold Land ₹60,000", "Closing Stock ₹36,500", "Sundry Debtors ₹30,000",
          "Cash in Hand ₹1,300", "Loose Tools ₹7,200"
        ],
        liabilitiesSide: [
          { label: "Capital", amount: 137450, isSubtotalStart: true },
          { label: "Add: Net Profit", amount: 32450, isAddition: true },
          { label: "Less: Drawings", amount: -6000, isSubtraction: true, subtotal: 163900 },
          { label: "Loan on Mortgage", amount: 20000 },
          { label: "Current Liabilities", isGroupHeader: true },
          { label: "Sundry Creditors", amount: 16100 }
        ],
        assetsSide: [
          { label: "Fixed Assets", isGroupHeader: true },
          { label: "Trade Marks", amount: 5000 },
          { label: "Fixed Deposit with Bank", amount: 10000 },
          { label: "Motor Vehicles", amount: 50000 },
          { label: "Leasehold Land", amount: 60000 },
          { label: "Current Assets", isGroupHeader: true },
          { label: "Closing Stock", amount: 36500 },
          { label: "Sundry Debtors", amount: 30000 },
          { label: "Cash in Hand", amount: 1300 },
          { label: "Loose Tools", amount: 7200 }
        ],
        grandTotal: 200000,
        explanation: "Capital is never shown at its plain opening figure on a Balance Sheet — it must be built up in three lines: the opening Capital, 'Add: Net Profit' (profit belongs to the owner, so it increases their stake), and 'Less: Drawings' (money or goods the owner took out, reducing their stake): 1,37,450 + 32,450 − 6,000 = 1,63,900. This adjusted Capital, plus the Loan and Creditors, gives total Liabilities of 1,63,900 + 20,000 + 16,100 = 2,00,000. On the Assets side, Fixed Assets (long-term holdings like Trade Marks, Fixed Deposit, Motor Vehicles, Leasehold Land) are conventionally grouped and listed above Current Assets (things expected to convert to cash within the year, like Stock, Debtors, and Cash): 5,000 + 10,000 + 50,000 + 60,000 + 36,500 + 30,000 + 1,300 + 7,200 = 2,00,000. Both sides tally at ₹2,00,000, confirming the accounting equation holds."
      },
      {
        id: 2,
        difficulty: "Medium",
        asOn: "31st March, 2025",
        prompt: "From the following figures, prepare the Balance Sheet of a sole proprietor as on 31st March, 2025.",
        rawFigures: [
          "Capital ₹2,10,000", "Net Profit for the year ₹48,000", "Drawings ₹18,000",
          "Bank Loan ₹50,000", "Sundry Creditors ₹22,500", "Outstanding Salary ₹3,500",
          "Goodwill ₹15,000", "Machinery ₹1,70,000", "Furniture ₹35,000",
          "Closing Stock ₹42,000", "Sundry Debtors ₹38,000", "Cash at Bank ₹12,000", "Cash in Hand ₹4,000"
        ],
        liabilitiesSide: [
          { label: "Capital", amount: 210000, isSubtotalStart: true },
          { label: "Add: Net Profit", amount: 48000, isAddition: true },
          { label: "Less: Drawings", amount: -18000, isSubtraction: true, subtotal: 240000 },
          { label: "Bank Loan", amount: 50000 },
          { label: "Current Liabilities", isGroupHeader: true },
          { label: "Sundry Creditors", amount: 22500 },
          { label: "Outstanding Salary", amount: 3500 }
        ],
        assetsSide: [
          { label: "Fixed Assets", isGroupHeader: true },
          { label: "Goodwill", amount: 15000 },
          { label: "Machinery", amount: 170000 },
          { label: "Furniture", amount: 35000 },
          { label: "Current Assets", isGroupHeader: true },
          { label: "Closing Stock", amount: 42000 },
          { label: "Sundry Debtors", amount: 38000 },
          { label: "Cash at Bank", amount: 12000 },
          { label: "Cash in Hand", amount: 4000 }
        ],
        grandTotal: 316000,
        explanation: "Adjusted Capital = 2,10,000 + 48,000 − 18,000 = 2,40,000. Total Liabilities = 2,40,000 + 50,000 (Bank Loan) + 22,500 (Creditors) + 3,500 (Outstanding Salary) = 3,16,000. Outstanding Salary sits under Current Liabilities alongside Creditors, since both are short-term amounts owed to outsiders. Total Assets = 15,000 + 1,70,000 + 35,000 (Fixed Assets) + 42,000 + 38,000 + 12,000 + 4,000 (Current Assets) = 3,16,000. Both sides tally at ₹3,16,000."
      },
      {
        id: 3,
        difficulty: "Hard",
        asOn: "31st March, 2024",
        prompt: "From the following figures, prepare the Balance Sheet of a sole proprietor as on 31st March, 2024. Note that the firm suffered a net loss this year rather than earning a profit.",
        rawFigures: [
          "Capital ₹3,00,000", "Net Loss for the year ₹25,000", "Drawings ₹12,000",
          "Loan from Bank ₹80,000", "Bills Payable ₹14,000", "Sundry Creditors ₹31,000",
          "Building ₹1,66,000", "Plant & Machinery ₹95,000", "Investments ₹40,000",
          "Closing Stock ₹28,000", "Sundry Debtors ₹45,000", "Bills Receivable ₹9,000", "Cash in Hand ₹5,000"
        ],
        liabilitiesSide: [
          { label: "Capital", amount: 300000, isSubtotalStart: true },
          { label: "Less: Net Loss", amount: -25000, isSubtraction: true },
          { label: "Less: Drawings", amount: -12000, isSubtraction: true, subtotal: 263000 },
          { label: "Loan from Bank", amount: 80000 },
          { label: "Current Liabilities", isGroupHeader: true },
          { label: "Bills Payable", amount: 14000 },
          { label: "Sundry Creditors", amount: 31000 }
        ],
        assetsSide: [
          { label: "Fixed Assets", isGroupHeader: true },
          { label: "Building", amount: 166000 },
          { label: "Plant & Machinery", amount: 95000 },
          { label: "Investments", amount: 40000 },
          { label: "Current Assets", isGroupHeader: true },
          { label: "Closing Stock", amount: 28000 },
          { label: "Sundry Debtors", amount: 45000 },
          { label: "Bills Receivable", amount: 9000 },
          { label: "Cash in Hand", amount: 5000 }
        ],
        grandTotal: 388000,
        explanation: "Unlike the previous two questions, this firm made a Net Loss rather than a profit — so instead of 'Add: Net Profit', the Capital section shows 'Less: Net Loss', since a loss erodes the owner's stake just as drawings do: 3,00,000 − 25,000 − 12,000 = 2,63,000. Both reductions are subtracted from Capital independently, in either order. Total Liabilities = 2,63,000 + 80,000 + 14,000 + 31,000 = 3,88,000. Total Assets = 1,66,000 + 95,000 + 40,000 + 28,000 + 45,000 + 9,000 + 5,000 = 3,88,000. Both sides tally at ₹3,88,000 — always double-check whether a question gives a profit or a loss, since the sign of that one line changes the whole Capital subtotal."
      },
      {
        id: 4,
        difficulty: "Hard",
        asOn: "31st March, 2025",
        prompt: "From the following figures, prepare the Balance Sheet of a sole proprietor as on 31st March, 2025. The firm also introduced additional capital during the year.",
        rawFigures: [
          "Capital (opening) ₹1,80,000", "Additional Capital introduced ₹40,000", "Net Profit for the year ₹36,000", "Drawings ₹15,000",
          "Loan on Mortgage ₹60,000", "Sundry Creditors ₹27,000", "Outstanding Rent ₹5,000",
          "Land & Building ₹1,66,000", "Furniture & Fixtures ₹42,000", "Prepaid Insurance ₹4,000",
          "Closing Stock ₹52,000", "Sundry Debtors ₹48,000", "Cash at Bank ₹18,000", "Cash in Hand ₹3,000"
        ],
        liabilitiesSide: [
          { label: "Capital", amount: 180000, isSubtotalStart: true },
          { label: "Add: Additional Capital", amount: 40000, isAddition: true },
          { label: "Add: Net Profit", amount: 36000, isAddition: true },
          { label: "Less: Drawings", amount: -15000, isSubtraction: true, subtotal: 241000 },
          { label: "Loan on Mortgage", amount: 60000 },
          { label: "Current Liabilities", isGroupHeader: true },
          { label: "Sundry Creditors", amount: 27000 },
          { label: "Outstanding Rent", amount: 5000 }
        ],
        assetsSide: [
          { label: "Fixed Assets", isGroupHeader: true },
          { label: "Land & Building", amount: 166000 },
          { label: "Furniture & Fixtures", amount: 42000 },
          { label: "Current Assets", isGroupHeader: true },
          { label: "Prepaid Insurance", amount: 4000 },
          { label: "Closing Stock", amount: 52000 },
          { label: "Sundry Debtors", amount: 48000 },
          { label: "Cash at Bank", amount: 18000 },
          { label: "Cash in Hand", amount: 3000 }
        ],
        grandTotal: 333000,
        explanation: "With four separate adjustments to Capital, add the positive ones (Additional Capital, Net Profit) and subtract the negative one (Drawings) from the opening figure, in any order: 1,80,000 + 40,000 + 36,000 − 15,000 = 2,41,000. Total Liabilities = 2,41,000 + 60,000 + 27,000 + 5,000 = 3,33,000. Prepaid Insurance, though it relates to an 'expense', is a Current Asset — it represents insurance cover already paid for but not yet used up. Total Assets = 1,66,000 + 42,000 + 4,000 + 52,000 + 48,000 + 18,000 + 3,000 = 3,33,000. Both sides tally at ₹3,33,000."
      }
    ]
  },

  /* ============================================================
     JOURNAL ENTRY GENERATOR — pattern library
     Powers the "type any transaction, get the journal entry"
     tool in Chapter 3. Since this is a static site with no AI
     backend, matching works by detecting keywords and amounts
     in the student's typed sentence against these patterns,
     ordered from most specific to most general so a precise
     match (e.g. "sold goods on credit to X") is tried before a
     looser fallback (e.g. any sentence containing "purchased").
     Each pattern lists the keywords that must ALL appear
     (caseInsensitive, simple substring match) and a template
     for the resulting entry, with {amount} as a placeholder
     for whatever number was found in the sentence.
     ============================================================ */
  journalEntryPatterns: [
    { id: 1, keywords: ["started business", "cash"], notKeywords: ["goods", "furniture"],
      debit: "Cash A/c", credit: "Capital A/c", narration: "Being business started with cash" },
    { id: 2, keywords: ["purchased", "goods", "cash"], notKeywords: ["credit"],
      debit: "Purchases A/c", credit: "Cash A/c", narration: "Being goods purchased for cash" },
    { id: 3, keywords: ["purchased", "goods", "credit"],
      debit: "Purchases A/c", creditTemplate: "To {name} A/c", narration: "Being goods purchased on credit", needsName: true },
    { id: 4, keywords: ["sold", "goods", "cash"], notKeywords: ["credit"],
      debit: "Cash A/c", credit: "Sales A/c", narration: "Being goods sold for cash" },
    { id: 5, keywords: ["sold", "goods", "credit"],
      debitTemplate: "{name} A/c", credit: "Sales A/c", narration: "Being goods sold on credit", needsName: true },
    { id: 6, keywords: ["paid", "rent"],
      debit: "Rent A/c", credit: "Cash A/c", narration: "Being rent paid in cash" },
    { id: 7, keywords: ["received", "rent"],
      debit: "Cash A/c", credit: "Rent Received A/c", narration: "Being rent received" },
    { id: 8, keywords: ["paid", "salary"],
      debit: "Salary A/c", credit: "Cash A/c", narration: "Being salary paid" },
    { id: 9, keywords: ["paid", "wages"],
      debit: "Wages A/c", credit: "Cash A/c", narration: "Being wages paid" },
    { id: 10, keywords: ["received", "commission"],
      debit: "Cash A/c", credit: "Commission Received A/c", narration: "Being commission received" },
    { id: 11, keywords: ["paid", "commission"],
      debit: "Commission Paid A/c", credit: "Cash A/c", narration: "Being commission paid" },
    { id: 12, keywords: ["withdrew", "cash", "personal"],
      debit: "Drawings A/c", credit: "Cash A/c", narration: "Being cash withdrawn by proprietor for personal use" },
    { id: 13, keywords: ["withdrew", "goods", "personal"],
      debit: "Drawings A/c", credit: "Purchases A/c", narration: "Being goods withdrawn by proprietor for personal use" },
    { id: 13.1, keywords: ["away", "personal"], notKeywords: ["goods"],
      debit: "Drawings A/c", credit: "[the specific asset] A/c", narration: "Being an asset taken by proprietor for personal use — substitute the actual asset account (e.g. Furniture A/c, Office Equipment A/c) for [the specific asset]" },
    { id: 14, keywords: ["purchased", "furniture", "cash"], notKeywords: ["credit"],
      debit: "Furniture A/c", credit: "Cash A/c", narration: "Being furniture purchased for cash" },
    { id: 15, keywords: ["purchased", "machinery"], notKeywords: ["credit", "improvement", "second-hand"],
      debit: "Machinery A/c", credit: "Cash/Bank A/c", narration: "Being machinery purchased" },
    { id: 16, keywords: ["paid", "electricity"],
      debit: "Electricity Charges A/c", credit: "Cash A/c", narration: "Being electricity charges paid" },
    { id: 17, keywords: ["paid", "stationery"], 
      debit: "Stationery A/c", credit: "Cash A/c", narration: "Being stationery purchased for cash" },
    { id: 18, keywords: ["received", "interest"],
      debit: "Cash A/c", credit: "Interest Received A/c", narration: "Being interest received" },
    { id: 19, keywords: ["paid", "interest"],
      debit: "Interest Paid A/c", credit: "Cash A/c", narration: "Being interest paid" },
    { id: 20, keywords: ["deposited", "cash", "bank"],
      debit: "Bank A/c", credit: "Cash A/c", narration: "Being cash deposited into bank" },
    { id: 21, keywords: ["withdrew", "bank"], notKeywords: ["personal"],
      debit: "Cash A/c", credit: "Bank A/c", narration: "Being cash withdrawn from bank for office use" },
    { id: 22, keywords: ["paid", "cheque", "creditor"],
      debit: "Creditor's A/c", credit: "Bank A/c", narration: "Being payment made to creditor by cheque" },
    { id: 23, keywords: ["received", "cheque", "debtor"],
      debit: "Bank A/c", credit: "Debtor's A/c", narration: "Being cheque received from debtor and deposited" },
    { id: 24, keywords: ["goods", "returned", "purchase"],
      debitTemplate: "{name} A/c", credit: "Purchases Return A/c", narration: "Being goods returned to supplier", needsName: true },
    { id: 25, keywords: ["goods", "returned", "sales"],
      debit: "Sales Return A/c", creditTemplate: "To {name} A/c", narration: "Being goods returned by customer", needsName: true },
    { id: 26, keywords: ["bad debts", "written off"],
      debit: "Bad Debts A/c", creditTemplate: "To {name} A/c", narration: "Being bad debts written off", needsName: true },
    { id: 27, keywords: ["depreciation", "machinery"],
      debit: "Depreciation A/c", credit: "Machinery A/c", narration: "Being depreciation charged on machinery" },
    { id: 28, keywords: ["depreciation", "furniture"],
      debit: "Depreciation A/c", credit: "Furniture A/c", narration: "Being depreciation charged on furniture" },
    { id: 29, keywords: ["outstanding", "salary"],
      debit: "Salary A/c", credit: "Outstanding Salary A/c", narration: "Being salary outstanding at year end" },
    { id: 29.1, keywords: ["outstanding", "wages"],
      debit: "Wages A/c", credit: "Outstanding Wages A/c", narration: "Being wages outstanding at year end" },
    { id: 30, keywords: ["outstanding", "rent"],
      debit: "Rent A/c", credit: "Outstanding Rent A/c", narration: "Being rent outstanding at year end" },
    { id: 30.1, keywords: ["rent", "due"], notKeywords: ["settlement", "insolvent", "paise"],
      debit: "Rent A/c", credit: "Outstanding Rent A/c", narration: "Being rent due but not yet paid" },
    { id: 31, keywords: ["prepaid", "insurance"],
      debit: "Prepaid Insurance A/c", credit: "Insurance A/c", narration: "Being insurance prepaid, adjusted out of this year's expense" },
    { id: 32, keywords: ["loan", "taken", "bank"],
      debit: "Bank A/c", credit: "Bank Loan A/c", narration: "Being loan taken from bank" },
    { id: 32.1, keywords: ["received", "loan"], notKeywords: ["repaid"],
      debit: "Cash/Bank A/c", creditTemplate: "To Loan from {name} A/c", narration: "Being loan received", needsName: true },
    { id: 33, keywords: ["repaid", "loan"],
      debit: "Bank Loan A/c", credit: "Bank A/c", narration: "Being part of bank loan repaid" },
    { id: 34, keywords: ["paid", "advertising"],
      debit: "Advertising A/c", credit: "Cash A/c", narration: "Being advertising expenses paid" },
    { id: 35, keywords: ["paid", "carriage"],
      debit: "Carriage A/c", credit: "Cash A/c", narration: "Being carriage paid" },
    { id: 36, keywords: ["goods", "destroyed", "fire"], notKeywords: ["insurance", "claim"],
      debit: "Loss by Fire A/c", credit: "Purchases A/c", narration: "Being goods destroyed by fire, uninsured" },
    { id: 37, keywords: ["goods", "fire", "insurance", "claim"],
      debit: "Insurance Claim Receivable A/c", credit: "Purchases A/c", narration: "Being loss of goods by fire, insurance claim admitted" },
    { id: 38, keywords: ["goods", "charity"],
      debit: "Charity A/c", credit: "Purchases A/c", narration: "Being goods given away as charity" },
    { id: 39, keywords: ["goods", "sample", "advertis"],
      debit: "Advertisement A/c", credit: "Purchases A/c", narration: "Being goods distributed as free samples" },
    { id: 40, keywords: ["interest on capital"],
      debit: "Interest on Capital A/c", credit: "Capital A/c", narration: "Being interest on capital allowed to proprietor" },
    { id: 41, keywords: ["interest", "drawings"], notKeywords: ["capital"],
      debit: "Capital A/c", credit: "Interest on Drawings A/c", narration: "Being interest charged on proprietor's drawings" },
    { id: 42, keywords: ["discount allowed"],
      debit: "Discount Allowed A/c", creditTemplate: "To {name} A/c", narration: "Being discount allowed", needsName: true },
    { id: 43, keywords: ["discount received"],
      debitTemplate: "{name} A/c", credit: "Discount Received A/c", narration: "Being discount received", needsName: true },
    { id: 44, keywords: ["purchased", "computer"],
      debit: "Computer A/c", credit: "Bank A/c", narration: "Being computer purchased" },
    { id: 45, keywords: ["received", "cash", "debtor"],
      debit: "Cash A/c", creditTemplate: "To {name} A/c", narration: "Being cash received from debtor", needsName: true },
    { id: 46, keywords: ["paid", "cash", "creditor"], notKeywords: ["cheque"],
      debitTemplate: "{name} A/c", credit: "Cash A/c", narration: "Being cash paid to creditor", needsName: true },
    { id: 47, keywords: ["bad debt", "recovered"],
      debit: "Cash A/c", credit: "Bad Debts Recovered A/c", narration: "Being amount recovered, previously written off as bad debt" },
    { id: 47.1, keywords: ["written off", "earlier year"],
      debit: "Cash A/c", credit: "Bad Debts Recovered A/c", narration: "Being amount recovered, previously written off as bad debt in an earlier year" },
    { id: 48, keywords: ["bills receivable", "received"], notKeywords: ["honoured", "dishonoured"],
      debit: "Bills Receivable A/c", creditTemplate: "To {name} A/c", narration: "Being a Bills Receivable accepted in settlement of account", needsName: true },
    { id: 49, keywords: ["bills receivable", "honoured"],
      debit: "Bank A/c", credit: "Bills Receivable A/c", narration: "Being Bills Receivable honoured on maturity" },
    { id: 50, keywords: ["bank charges"],
      debit: "Bank Charges A/c", credit: "Bank A/c", narration: "Being bank charges debited by the bank as per pass book" },
    { id: 51, keywords: ["interest", "credited", "bank"],
      debit: "Bank A/c", credit: "Interest Received A/c", narration: "Being interest credited by the bank as per pass book" },
    { id: 52, keywords: ["commission", "earned", "not"], notKeywords: ["advance"],
      debit: "Accrued Commission A/c", credit: "Commission Received A/c", narration: "Being commission earned but not yet received, accrued at year-end" },
    { id: 53, keywords: ["deposited", "bank", "customer"],
      debit: "Bank A/c", creditTemplate: "To {name} A/c", narration: "Being amount deposited directly into bank by customer in settlement of account", needsName: true },
    { id: 54, keywords: ["life insurance", "premium"],
      debit: "Drawings A/c", credit: "Bank A/c", narration: "Being proprietor's life insurance premium paid, treated as drawings" },
    { id: 55, keywords: ["insurance premium"], notKeywords: ["life"],
      debit: "Insurance Premium A/c", credit: "Bank A/c", narration: "Being insurance premium paid on business assets" },
    { id: 56, keywords: ["carriage"], notKeywords: ["sold", "sale", "outward", "customer"],
      debit: "Carriage Inwards A/c", credit: "Cash A/c", narration: "Being carriage paid on goods purchased" },
    { id: 57, keywords: ["carriage", "sold"],
      debit: "Carriage Outwards A/c", credit: "Cash A/c", narration: "Being carriage paid on goods sold" },
    { id: 58, keywords: ["withdrew", "bank", "personal"],
      debit: "Drawings A/c", credit: "Bank A/c", narration: "Being cash withdrawn from bank for personal use" },
    { id: 59, keywords: ["additional capital"],
      debit: "Bank A/c", credit: "Capital A/c", narration: "Being additional capital introduced" },
    { id: 60, keywords: ["bills receivable", "dishonoured"],
      debitTemplate: "{name} A/c", credit: "Bills Receivable A/c", narration: "Being Bills Receivable dishonoured on maturity", needsName: true },
    { id: 61, keywords: ["stolen"],
      debit: "Loss by Theft A/c", credit: "Purchases A/c", narration: "Being goods lost by theft" },
    { id: 61.1, keywords: ["theft"], notKeywords: ["stolen"],
      debit: "Loss by Theft A/c", credit: "Purchases A/c", narration: "Being goods lost by theft" },
    { id: 62, keywords: ["overdraft", "interest"],
      debit: "Interest on Overdraft A/c", credit: "Bank A/c", narration: "Being interest on overdraft debited by bank" },
    { id: 63, keywords: ["advance", "supplier"],
      debit: "Advance to Supplier A/c", credit: "Cash A/c", narration: "Being advance paid to supplier for goods to be received later" },
    { id: 64, keywords: ["advance", "customer"],
      debit: "Cash A/c", credit: "Advance from Customer A/c", narration: "Being advance received from customer for goods to be supplied later" },
    { id: 65, keywords: ["dividend", "received"],
      debit: "Bank A/c", credit: "Dividend Received A/c", narration: "Being dividend on investments received directly into bank" },
    { id: 66, keywords: ["bills receivable", "discounted"],
      debit: "Cash A/c", credit: "Bills Receivable A/c", narration: "Being a Bills Receivable discounted with the bank before maturity" },
    { id: 67, keywords: ["repair"], notKeywords: ["improvement"],
      debit: "Repairs A/c", credit: "Cash A/c", narration: "Being repairs carried out on existing asset" },
    { id: 68, keywords: ["improvement", "machinery"],
      debit: "Machinery A/c", credit: "Cash A/c", narration: "Being amount spent on improvement of machinery, capitalised" },
    { id: 69, keywords: ["income tax"],
      debit: "Drawings A/c", credit: "Cash A/c", narration: "Being proprietor's income tax paid, treated as drawings" },
    { id: 70, keywords: ["construction", "building"],
      debit: "Building A/c", credit: "Bank A/c", narration: "Being amount paid for construction of building" },
    { id: 71, keywords: ["cheque", "after banking hours"],
      debit: "Cheque in Hand A/c", creditTemplate: "To {name} A/c", narration: "Being cheque received after banking hours, not yet deposited", needsName: true },
    { id: 71.1, keywords: ["received", "cheque"], notKeywords: ["after banking hours", "dishonoured", "bills receivable", "settlement"],
      debit: "Bank A/c", creditTemplate: "To {name} A/c", narration: "Being cheque received and deposited", needsName: true },
    { id: 72, keywords: ["goods", "used", "furniture"],
      debit: "Furniture A/c", credit: "Purchases A/c", narration: "Being goods used to make furniture for office use" },
    { id: 73, keywords: ["provision", "doubtful debts"],
      debit: "Profit and Loss A/c", credit: "Provision for Doubtful Debts A/c", narration: "Being provision created for doubtful debts" },
    { id: 74, keywords: ["telephone bill"],
      debit: "Telephone Expenses A/c", credit: "Bank A/c", narration: "Being telephone bill paid" },
    { id: 75, keywords: ["electricity bill"],
      debit: "Electricity Expenses A/c", credit: "Bank A/c", narration: "Being electricity bill paid" },
    { id: 76, keywords: ["internet bill"],
      debit: "Internet Expenses A/c", credit: "Bank A/c", narration: "Being internet bill paid" },
    { id: 77, keywords: ["petty cash"],
      debit: "Petty Cash A/c", credit: "Cash A/c", narration: "Being cash paid to petty cashier" },
    { id: 78, keywords: ["interest", "due"], notKeywords: ["credited", "paid"],
      debit: "Interest A/c", credit: "Interest Outstanding A/c", narration: "Being interest due but not yet paid" },
    { id: 79, keywords: ["rebate", "allowed"],
      debit: "Rebate Allowed A/c", creditTemplate: "To {name} A/c", narration: "Being rebate allowed", needsName: true },
    { id: 80, keywords: ["rebate", "received"],
      debitTemplate: "{name} A/c", credit: "Rebate Received A/c", narration: "Being rebate received", needsName: true },
    { id: 81, keywords: ["bank draft"],
      debitTemplate: "{name} A/c", credit: "Bank A/c", narration: "Being payment made by bank draft", needsName: true },
    { id: 82, keywords: ["bank loan", "repaid"],
      debit: "Bank Loan A/c", credit: "Bank A/c", narration: "Being bank loan repaid" },
    { id: 83, keywords: ["transferred", "account"],
      debit: "Bank A/c", credit: "Bank A/c", narration: "Being funds transferred from one bank account to another" },
    { id: 84, keywords: ["miscellaneous", "expenses"],
      debit: "Miscellaneous Expenses A/c", credit: "Cash A/c", narration: "Being small varied expenses paid in cash" },
    { id: 84.1, keywords: ["postage"],
      debit: "Miscellaneous Expenses A/c", credit: "Cash A/c", narration: "Being small varied expenses (postage, refreshment, conveyance, etc.) paid in cash" },
    { id: 85, keywords: ["cheque in hand", "deposited"],
      debit: "Bank A/c", credit: "Cheque in Hand A/c", narration: "Being cheque in hand deposited into bank" },
    { id: 86, keywords: ["insurance premium", "employees"],
      debit: "Employees' Insurance Premium A/c", credit: "Bank A/c", narration: "Being insurance premium paid for employees" },
    { id: 87, keywords: ["advance", "machine"],
      debit: "Advance for Machinery A/c", credit: "Bank A/c", narration: "Being advance paid for machine to be received later" },
    { id: 88, keywords: ["closing stock"],
      debit: "Closing Stock A/c", credit: "Trading A/c", narration: "Being closing stock brought into books at year-end" },
    { id: 89, keywords: ["amortisation"],
      debit: "Amortisation A/c", credit: "Goodwill A/c", narration: "Being intangible asset amortised for the year" },
    { id: 89.1, keywords: ["goodwill", "written off"],
      debit: "Amortisation A/c", credit: "Goodwill A/c", narration: "Being goodwill written off (amortised) for the year" },
    { id: 90, keywords: ["personal", "sold", "invested"],
      debit: "Bank A/c", credit: "Capital A/c", narration: "Being proceeds of proprietor's personal asset invested into the business" },
    { id: 90.1, keywords: ["personal", "sold", "deposited"], notKeywords: ["goods"],
      debit: "Bank A/c", credit: "Capital A/c", narration: "Being proceeds of proprietor's personal asset deposited into the business" },
    { id: 91, keywords: ["capital", "introduced"], notKeywords: ["additional", "further"],
      debit: "Cash/Bank A/c", credit: "Capital A/c", narration: "Being capital introduced" },
    { id: 92, keywords: ["further capital"],
      debit: "Cash/Bank A/c", credit: "Capital A/c", narration: "Being additional capital introduced" },
    { id: 93, keywords: ["invested", "capital"],
      debit: "Cash/Bank A/c", credit: "Capital A/c", narration: "Being capital introduced" },
    { id: 94, keywords: ["brought", "capital"],
      debit: "Cash/Bank A/c", credit: "Capital A/c", narration: "Being capital introduced" },
    { id: 95, keywords: ["owner", "invested"],
      debit: "Cash/Bank A/c", credit: "Capital A/c", narration: "Being capital introduced by owner" },
    { id: 96, keywords: ["proprietor", "invested"],
      debit: "Cash/Bank A/c", credit: "Capital A/c", narration: "Being capital introduced by proprietor" },
    { id: 97, keywords: ["cheque", "dishonoured"], notKeywords: ["bills receivable"],
      debitTemplate: "{name} A/c", credit: "Bank A/c", narration: "Being cheque received earlier now dishonoured", needsName: true },
    { id: 98, keywords: ["newspapers"],
      debit: "Cash A/c", credit: "Sale of Newspapers (Miscellaneous Receipts) A/c", narration: "Being old newspapers sold" },
    { id: 99, keywords: ["cartage", "recovered"],
      debitTemplate: "{name} A/c", credit: "Cartage Recovered A/c", narration: "Being cartage recovered from customer", needsName: true },
    { id: 100, keywords: ["paid", "on account"], notKeywords: ["cheque", "bank"],
      debitTemplate: "{name} A/c", credit: "Cash A/c", narration: "Being cash paid on account", needsName: true },
    { id: 101, keywords: ["paid", "on account", "cheque"],
      debitTemplate: "{name} A/c", credit: "Bank A/c", narration: "Being amount paid by cheque on account", needsName: true },
    { id: 102, keywords: ["received", "on account"], notKeywords: ["cheque", "bank"],
      debit: "Cash A/c", creditTemplate: "To {name} A/c", narration: "Being cash received on account", needsName: true },
    { id: 103, keywords: ["received", "on account", "cheque"],
      debit: "Bank A/c", creditTemplate: "To {name} A/c", narration: "Being amount received by cheque on account", needsName: true }
  ],

  /* ============================================================
     CHAPTER 3 — JOURNAL
     ============================================================ */
  journal: {
    theory: {
      simple: [
  {
    "h": "What the Journal actually is",
    "p": "The Journal is the very first place any business transaction gets written down — which is why it's called the 'book of original entry'. Every transaction, in the order it happens, is analyzed into its debit and credit effects and recorded here before anything is posted to individual ledger accounts.",
    "p2": "Think of it as a chronological diary of the business, written strictly in accounting language — every single line either debits or credits a named account, for a specific amount, on a specific date."
  },
  {
    "h": "The five columns",
    "list": [
      {
        "term": "Date",
        "def": "The day the transaction took place."
      },
      {
        "term": "Particulars",
        "def": "The names of the accounts debited and credited, with the debit account written first (followed by 'Dr.'), and the credited account written second, indented and prefixed with 'To'."
      },
      {
        "term": "Ledger Folio (L.F.)",
        "def": "The ledger page number the entry is posted to — filled in only later, at the time of posting, never while journalising."
      },
      {
        "term": "Debit Amount",
        "def": "The rupee value entered against the debited account."
      },
      {
        "term": "Credit Amount",
        "def": "The rupee value entered against the credited account, always equal in total to the debit amount for that entry."
      }
    ]
  },
  {
    "h": "Narration",
    "p": "Every entry ends with a short explanation in brackets, beginning with 'Being...', describing what actually happened. A narration isn't optional — without it, a reader (or the student re-checking their own work later) has no way to confirm the entry makes business sense, not just arithmetic sense."
  }
],
      advanced: [
  {
    "h": "Compound entries",
    "p": "Not every transaction involves exactly two accounts. When a single event affects three or more accounts — buying machinery partly by cheque and partly on credit, for instance — all the debits are listed first, then all the credits, as one combined entry called a Compound Journal Entry.",
    "formula": "Total of all Debit amounts = Total of all Credit amounts",
    "p2": "This equality must hold for every entry, simple or compound — it's the journal-level expression of the dual aspect concept."
  },
  {
    "h": "Adjustment-style entries",
    "p": "Outstanding expenses, prepaid expenses, accrued income, and income received in advance are all 'non-cash' journal entries that adjust the books to reflect what has actually been earned or incurred during the period, regardless of when cash physically moves. These entries are what make accrual-based financial statements accurate."
  },
  {
    "h": "Entries involving discount and dishonour",
    "p": "When a debtor settles their account early and is allowed a cash discount, or a cheque received earlier bounces, the journal entry has to correctly reflect BOTH what actually happened to cash/bank AND what happened to the personal account, in the right proportions. These are consistently the highest-scoring-potential, highest-error-risk entries in board exams — precision with the personal account's full original balance is the key discipline."
  }
]
    },
    concepts: [
  {
    "title": "Book of Original Entry",
    "body": "The Journal is where every transaction is recorded first, in chronological order, before being posted anywhere else — nothing enters the ledger without passing through the journal first."
  },
  {
    "title": "Journal Format",
    "body": "Date | Particulars (Dr. account, then 'To' credit account, indented) | L.F. | Debit Amount | Credit Amount — followed by a narration in brackets."
  },
  {
    "title": "Compound Entries",
    "body": "A single entry can carry multiple debit lines, multiple credit lines, or both, as long as the total debits equal the total credits for that entry."
  },
  {
    "title": "Narration",
    "body": "A short 'Being...' explanation after every entry — required discipline, not decoration, since it confirms the entry matches the real-world event."
  },
  {
    "title": "Posting",
    "body": "After journalising, each debit and credit is transferred ('posted') to its own ledger account — the next stage of the accounting cycle."
  },
  {
    "title": "Discount & Dishonour Entries",
    "body": "Settling accounts with a cash discount, or reversing a dishonoured cheque, both require debiting/crediting the personal account for its FULL original value, with the discount or reversal handled through a separate line."
  }
],
    numericals: [
  {
    "id": 1,
    "difficulty": "Easy",
    "transaction": "Started business with cash ₹1,00,000.",
    "hint": "Cash comes in, capital is what the business owes the owner.",
    "entries": [
      {
        "particulars": "Cash A/c",
        "dr": 100000,
        "cr": null
      },
      {
        "particulars": "   To Capital A/c",
        "dr": null,
        "cr": 100000
      }
    ],
    "narration": "(Being business started with cash)",
    "explanation": "The opening entry of any business — an asset appears on one side, matched by the owner's stake on the other."
  },
  {
    "id": 2,
    "difficulty": "Easy",
    "transaction": "Purchased goods for cash ₹15,000.",
    "hint": "Purchases is debited as an expense; cash is credited as it leaves.",
    "entries": [
      {
        "particulars": "Purchases A/c",
        "dr": 15000,
        "cr": null
      },
      {
        "particulars": "   To Cash A/c",
        "dr": null,
        "cr": 15000
      }
    ],
    "narration": "(Being goods purchased for cash)",
    "explanation": "A simple cash purchase — stock-in-trade increases the Purchases account while cash decreases by the same amount."
  },
  {
    "id": 3,
    "difficulty": "Easy",
    "transaction": "Sold goods for cash ₹22,000.",
    "hint": "Cash comes in; Sales is credited as income.",
    "entries": [
      {
        "particulars": "Cash A/c",
        "dr": 22000,
        "cr": null
      },
      {
        "particulars": "   To Sales A/c",
        "dr": null,
        "cr": 22000
      }
    ],
    "narration": "(Being goods sold for cash)",
    "explanation": "Revenue is recognized the moment the sale is made and cash is received simultaneously."
  },
  {
    "id": 4,
    "difficulty": "Easy",
    "transaction": "Purchased furniture for cash ₹9,000.",
    "hint": "Both are Real accounts — furniture comes in, cash goes out.",
    "entries": [
      {
        "particulars": "Furniture A/c",
        "dr": 9000,
        "cr": null
      },
      {
        "particulars": "   To Cash A/c",
        "dr": null,
        "cr": 9000
      }
    ],
    "narration": "(Being furniture purchased for office use)",
    "explanation": "This is a fixed asset purchase, not stock-in-trade, so Furniture A/c is used directly instead of Purchases A/c."
  },
  {
    "id": 5,
    "difficulty": "Easy",
    "transaction": "Paid rent ₹4,000 in cash.",
    "hint": "Rent is an expense funded by cash.",
    "entries": [
      {
        "particulars": "Rent A/c",
        "dr": 4000,
        "cr": null
      },
      {
        "particulars": "   To Cash A/c",
        "dr": null,
        "cr": 4000
      }
    ],
    "narration": "(Being rent paid in cash)",
    "explanation": "A routine operating expense — debited to Rent A/c and credited to Cash A/c."
  },
  {
    "id": 6,
    "difficulty": "Easy",
    "transaction": "Received commission ₹1,500 in cash.",
    "hint": "Cash comes in; commission is income.",
    "entries": [
      {
        "particulars": "Cash A/c",
        "dr": 1500,
        "cr": null
      },
      {
        "particulars": "   To Commission Received A/c",
        "dr": null,
        "cr": 1500
      }
    ],
    "narration": "(Being commission received in cash)",
    "explanation": "Income received is credited, and the cash asset that increased is debited."
  },
  {
    "id": 7,
    "difficulty": "Easy",
    "transaction": "The proprietor withdrew ₹3,000 cash for personal use.",
    "hint": "Drawings represents the owner's withdrawal.",
    "entries": [
      {
        "particulars": "Drawings A/c",
        "dr": 3000,
        "cr": null
      },
      {
        "particulars": "   To Cash A/c",
        "dr": null,
        "cr": 3000
      }
    ],
    "narration": "(Being cash withdrawn by proprietor for personal use)",
    "explanation": "Drawings will later be deducted from Capital — for now it is simply recorded as its own account."
  },
  {
    "id": 8,
    "difficulty": "Easy",
    "transaction": "Deposited cash into the bank, ₹18,000.",
    "hint": "This moves value from one asset account (cash) to another (bank).",
    "entries": [
      {
        "particulars": "Bank A/c",
        "dr": 18000,
        "cr": null
      },
      {
        "particulars": "   To Cash A/c",
        "dr": null,
        "cr": 18000
      }
    ],
    "narration": "(Being cash deposited into bank)",
    "explanation": "A contra-type entry between two asset accounts — total assets are unchanged, only their form shifts."
  },
  {
    "id": 9,
    "difficulty": "Easy",
    "transaction": "Purchased goods from Farhan on credit ₹12,000.",
    "hint": "No cash moves — Farhan becomes a creditor.",
    "entries": [
      {
        "particulars": "Purchases A/c",
        "dr": 12000,
        "cr": null
      },
      {
        "particulars": "   To Farhan's A/c",
        "dr": null,
        "cr": 12000
      }
    ],
    "narration": "(Being goods purchased from Farhan on credit)",
    "explanation": "The expense is recognized immediately on purchase; payment is deferred, so a liability (Farhan's A/c) is credited instead of cash."
  },
  {
    "id": 10,
    "difficulty": "Easy",
    "transaction": "Sold goods to Divya on credit ₹16,000.",
    "hint": "Divya now owes the firm — she is debited as a debtor.",
    "entries": [
      {
        "particulars": "Divya's A/c",
        "dr": 16000,
        "cr": null
      },
      {
        "particulars": "   To Sales A/c",
        "dr": null,
        "cr": 16000
      }
    ],
    "narration": "(Being goods sold to Divya on credit)",
    "explanation": "Revenue is recognized at the point of sale regardless of when payment is actually collected."
  },
  {
    "id": 11,
    "difficulty": "Easy",
    "transaction": "Paid salary ₹10,000 by cheque.",
    "hint": "Salary is an expense; the bank balance funds it.",
    "entries": [
      {
        "particulars": "Salary A/c",
        "dr": 10000,
        "cr": null
      },
      {
        "particulars": "   To Bank A/c",
        "dr": null,
        "cr": 10000
      }
    ],
    "narration": "(Being salary paid by cheque)",
    "explanation": "Whenever payment is made by cheque rather than cash, Bank A/c is credited instead of Cash A/c."
  },
  {
    "id": 12,
    "difficulty": "Easy",
    "transaction": "Received ₹8,000 cash from a debtor, Chetan.",
    "hint": "Chetan is settling what he owes — his personal account is credited.",
    "entries": [
      {
        "particulars": "Cash A/c",
        "dr": 8000,
        "cr": null
      },
      {
        "particulars": "   To Chetan's A/c",
        "dr": null,
        "cr": 8000
      }
    ],
    "narration": "(Being cash received from Chetan)",
    "explanation": "Collecting from a debtor converts one asset (a receivable) into another (cash) — total assets don't change."
  },
  {
    "id": 13,
    "difficulty": "Medium",
    "transaction": "Paid ₹14,000 to a creditor, Om Traders, by cheque.",
    "hint": "Om Traders' liability account is settled and closed.",
    "entries": [
      {
        "particulars": "Om Traders A/c",
        "dr": 14000,
        "cr": null
      },
      {
        "particulars": "   To Bank A/c",
        "dr": null,
        "cr": 14000
      }
    ],
    "narration": "(Being amount paid to Om Traders by cheque)",
    "explanation": "Settling a creditor reduces both a liability and an asset (bank balance) by the same amount."
  },
  {
    "id": 14,
    "difficulty": "Medium",
    "transaction": "Purchased machinery for ₹60,000 by cheque.",
    "hint": "Machinery is a fixed asset, funded from the bank.",
    "entries": [
      {
        "particulars": "Machinery A/c",
        "dr": 60000,
        "cr": null
      },
      {
        "particulars": "   To Bank A/c",
        "dr": null,
        "cr": 60000
      }
    ],
    "narration": "(Being machinery purchased by cheque)",
    "explanation": "Fixed asset purchases never touch Purchases A/c — they get their own dedicated asset account."
  },
  {
    "id": 15,
    "difficulty": "Medium",
    "transaction": "Sold old newspapers for ₹200 cash.",
    "hint": "This is incidental, non-trading income.",
    "entries": [
      {
        "particulars": "Cash A/c",
        "dr": 200,
        "cr": null
      },
      {
        "particulars": "   To Sundry Income A/c",
        "dr": null,
        "cr": 200
      }
    ],
    "narration": "(Being sale proceeds of old newspapers received)",
    "explanation": "Small, irregular receipts unrelated to the main business are grouped under a Sundry/Miscellaneous Income account rather than Sales."
  },
  {
    "id": 16,
    "difficulty": "Medium",
    "transaction": "Paid ₹2,500 for stationery in cash.",
    "hint": "Stationery consumed is an office expense.",
    "entries": [
      {
        "particulars": "Stationery A/c",
        "dr": 2500,
        "cr": null
      },
      {
        "particulars": "   To Cash A/c",
        "dr": null,
        "cr": 2500
      }
    ],
    "narration": "(Being stationery purchased for office use)",
    "explanation": "Office supplies used up in operations are expensed directly rather than treated as an asset, since they're consumed quickly."
  },
  {
    "id": 17,
    "difficulty": "Medium",
    "transaction": "Received interest on investments ₹3,200 by cheque.",
    "hint": "Interest income increases the bank balance directly.",
    "entries": [
      {
        "particulars": "Bank A/c",
        "dr": 3200,
        "cr": null
      },
      {
        "particulars": "   To Interest on Investment A/c",
        "dr": null,
        "cr": 3200
      }
    ],
    "narration": "(Being interest on investments received by cheque)",
    "explanation": "Passive income like interest is credited to its own nominal account, separate from the main trading income (Sales)."
  },
  {
    "id": 18,
    "difficulty": "Medium",
    "transaction": "Goods worth ₹1,000 (at cost) were given away as charity.",
    "hint": "Goods leaving without a sale must be removed from Purchases.",
    "entries": [
      {
        "particulars": "Charity A/c",
        "dr": 1000,
        "cr": null
      },
      {
        "particulars": "   To Purchases A/c",
        "dr": null,
        "cr": 1000
      }
    ],
    "narration": "(Being goods distributed as charity, at cost)",
    "explanation": "Charity is a non-business distribution, so it's valued strictly at cost and reduces Purchases rather than generating Sales."
  },
  {
    "id": 19,
    "difficulty": "Medium",
    "transaction": "Goods worth ₹1,500 (at cost) were distributed as free samples for advertisement.",
    "hint": "Same idea as charity — no sale has occurred.",
    "entries": [
      {
        "particulars": "Advertisement (Free Samples) A/c",
        "dr": 1500,
        "cr": null
      },
      {
        "particulars": "   To Purchases A/c",
        "dr": null,
        "cr": 1500
      }
    ],
    "narration": "(Being goods distributed as free samples for advertisement)",
    "explanation": "Promotional giveaways are treated as a marketing expense, valued at the original cost of the goods given away."
  },
  {
    "id": 20,
    "difficulty": "Medium",
    "transaction": "Outstanding wages of ₹2,200 were recorded at the year-end.",
    "hint": "The expense is due but hasn't been paid — this creates a liability.",
    "entries": [
      {
        "particulars": "Wages A/c",
        "dr": 2200,
        "cr": null
      },
      {
        "particulars": "   To Outstanding Wages A/c",
        "dr": null,
        "cr": 2200
      }
    ],
    "narration": "(Being wages outstanding at the end of the year)",
    "explanation": "Accrual accounting requires this expense to be recorded in the year it was incurred, even though cash hasn't left the business yet."
  },
  {
    "id": 21,
    "difficulty": "Medium",
    "transaction": "Paid ₹6,000 cash as rent in advance for the next quarter.",
    "hint": "This creates a future benefit, treated as an asset — not yet an expense.",
    "entries": [
      {
        "particulars": "Prepaid Rent A/c",
        "dr": 6000,
        "cr": null
      },
      {
        "particulars": "   To Cash A/c",
        "dr": null,
        "cr": 6000
      }
    ],
    "narration": "(Being rent paid in advance)",
    "explanation": "Since the space hasn't been used yet, the payment sits as a receivable-like asset until the related period actually arrives."
  },
  {
    "id": 22,
    "difficulty": "Medium",
    "transaction": "Depreciation of ₹1,200 was charged on furniture.",
    "hint": "The value of the furniture itself reduces — a Real account is credited.",
    "entries": [
      {
        "particulars": "Depreciation A/c",
        "dr": 1200,
        "cr": null
      },
      {
        "particulars": "   To Furniture A/c",
        "dr": null,
        "cr": 1200
      }
    ],
    "narration": "(Being depreciation charged on furniture)",
    "explanation": "No cash is involved — this entry simply reduces the book value of the asset while recognizing the wear-and-tear as an expense."
  },
  {
    "id": 23,
    "difficulty": "Medium",
    "transaction": "Bad debts of ₹900 were written off against a debtor, Naresh.",
    "hint": "Naresh's account must be closed since the amount is now considered irrecoverable.",
    "entries": [
      {
        "particulars": "Bad Debts A/c",
        "dr": 900,
        "cr": null
      },
      {
        "particulars": "   To Naresh's A/c",
        "dr": null,
        "cr": 900
      }
    ],
    "narration": "(Being bad debts written off against Naresh)",
    "explanation": "Writing off a bad debt recognizes a genuine loss — an asset that will never be converted into cash."
  },
  {
    "id": 24,
    "difficulty": "Medium",
    "transaction": "Received ₹5,000 as a loan from Priya.",
    "hint": "Cash comes in; a new liability to Priya is created.",
    "entries": [
      {
        "particulars": "Cash A/c",
        "dr": 5000,
        "cr": null
      },
      {
        "particulars": "   To Loan from Priya A/c",
        "dr": null,
        "cr": 5000
      }
    ],
    "narration": "(Being loan received from Priya)",
    "explanation": "A loan received increases both an asset (cash on hand) and a liability (the obligation to repay Priya)."
  },
  {
    "id": 25,
    "difficulty": "Hard",
    "transaction": "Purchased machinery for ₹80,000, paying ₹30,000 by cheque immediately and the balance after 60 days on credit from the supplier.",
    "hint": "A compound entry — one asset account debited in full, two accounts credited for the two funding sources.",
    "entries": [
      {
        "particulars": "Machinery A/c",
        "dr": 80000,
        "cr": null
      },
      {
        "particulars": "   To Bank A/c",
        "dr": null,
        "cr": 30000
      },
      {
        "particulars": "   To Supplier's A/c",
        "dr": null,
        "cr": 50000
      }
    ],
    "narration": "(Being machinery purchased, part paid by cheque and part on credit)",
    "explanation": "In a compound journal entry, the total of all debit amounts must still equal the total of all credit amounts — here, both sides total ₹80,000."
  },
  {
    "id": 26,
    "difficulty": "Hard",
    "transaction": "Sold goods worth ₹25,000 to Meera; received ₹10,000 cash immediately and the balance on credit.",
    "hint": "The full sale value is credited once; the receipt is split between two debit accounts.",
    "entries": [
      {
        "particulars": "Cash A/c",
        "dr": 10000,
        "cr": null
      },
      {
        "particulars": "Meera's A/c",
        "dr": 15000,
        "cr": null
      },
      {
        "particulars": "   To Sales A/c",
        "dr": null,
        "cr": 25000
      }
    ],
    "narration": "(Being goods sold to Meera, part received in cash and part on credit)",
    "explanation": "Splitting how a sale is paid for doesn't change the total revenue recognized — it only changes which asset accounts record the two portions received."
  },
  {
    "id": 27,
    "difficulty": "Hard",
    "transaction": "Received a cheque of ₹11,700 from Yash in full settlement of ₹12,000 due (cash discount ₹300 allowed).",
    "hint": "Yash's account must be cleared for the full amount owed, even though less cash actually came in.",
    "entries": [
      {
        "particulars": "Bank A/c",
        "dr": 11700,
        "cr": null
      },
      {
        "particulars": "Discount Allowed A/c",
        "dr": 300,
        "cr": null
      },
      {
        "particulars": "   To Yash's A/c",
        "dr": null,
        "cr": 12000
      }
    ],
    "narration": "(Being cheque received from Yash in full settlement, discount allowed)",
    "explanation": "Cash discount is recorded in the books (unlike trade discount) because it's a genuine cost incurred to encourage prompt payment."
  },
  {
    "id": 28,
    "difficulty": "Hard",
    "transaction": "Paid ₹18,600 by cheque to Farida in full settlement of ₹19,000 owed (discount received ₹400).",
    "hint": "Farida's account is cleared in full; the discount saved is a gain to the business.",
    "entries": [
      {
        "particulars": "Farida's A/c",
        "dr": 19000,
        "cr": null
      },
      {
        "particulars": "   To Bank A/c",
        "dr": null,
        "cr": 18600
      },
      {
        "particulars": "   To Discount Received A/c",
        "dr": null,
        "cr": 400
      }
    ],
    "narration": "(Being amount paid to Farida by cheque, discount received)",
    "explanation": "This is the mirror of question 27 — here the business is the one being offered a discount for paying early, and that saving is recorded as income."
  },
  {
    "id": 29,
    "difficulty": "Hard",
    "transaction": "A cheque of ₹7,500 received earlier from Anil was dishonoured by the bank.",
    "hint": "The original receipt must be reversed — Anil's debt is restored.",
    "entries": [
      {
        "particulars": "Anil's A/c",
        "dr": 7500,
        "cr": null
      },
      {
        "particulars": "   To Bank A/c",
        "dr": null,
        "cr": 7500
      }
    ],
    "narration": "(Being cheque received from Anil earlier, now dishonoured)",
    "explanation": "A dishonoured cheque exactly reverses the original entry, since the expected payment never actually cleared the bank."
  },
  {
    "id": 30,
    "difficulty": "Hard",
    "transaction": "The proprietor withdrew ₹4,000 cash and goods worth ₹1,500 (at cost) for personal use.",
    "hint": "Drawings absorbs both withdrawals; two different accounts are credited for the two forms taken.",
    "entries": [
      {
        "particulars": "Drawings A/c",
        "dr": 5500,
        "cr": null
      },
      {
        "particulars": "   To Cash A/c",
        "dr": null,
        "cr": 4000
      },
      {
        "particulars": "   To Purchases A/c",
        "dr": null,
        "cr": 1500
      }
    ],
    "narration": "(Being cash and goods withdrawn by proprietor for personal use)",
    "explanation": "Goods withdrawn for personal use are valued strictly at their original cost, never at what they could have been sold for."
  },
  {
    "id": 31,
    "difficulty": "Hard",
    "transaction": "Goods worth ₹5,000 (at cost) were destroyed by fire; the insurance company admitted a claim of ₹3,000.",
    "hint": "Split the loss between what's recoverable (a claim receivable) and what's genuinely lost.",
    "entries": [
      {
        "particulars": "Insurance Claim A/c",
        "dr": 3000,
        "cr": null
      },
      {
        "particulars": "Loss by Fire A/c",
        "dr": 2000,
        "cr": null
      },
      {
        "particulars": "   To Purchases A/c",
        "dr": null,
        "cr": 5000
      }
    ],
    "narration": "(Being goods destroyed by fire, insurance claim admitted for part of the loss)",
    "explanation": "Only the portion the insurer refuses to cover becomes a true loss — the admitted claim remains an asset until actually received in cash."
  },
  {
    "id": 32,
    "difficulty": "Hard",
    "transaction": "Purchased goods listed at ₹20,000 from Bhavya, less 10% trade discount, half paid immediately by cash.",
    "hint": "Trade discount is deducted before any entry is made — only the net billed value is recorded.",
    "entries": [
      {
        "particulars": "Purchases A/c",
        "dr": 18000,
        "cr": null
      },
      {
        "particulars": "   To Cash A/c",
        "dr": null,
        "cr": 9000
      },
      {
        "particulars": "   To Bhavya's A/c",
        "dr": null,
        "cr": 9000
      }
    ],
    "narration": "(Being goods purchased from Bhavya at net of trade discount, half paid in cash)",
    "explanation": "The net price after trade discount (₹18,000) is what actually appears in the books — trade discount itself is never recorded as a separate figure."
  },
  {
    "id": 33,
    "difficulty": "Hard",
    "transaction": "Received ₹4,000 cash as commission in advance for work to be done next year.",
    "hint": "The service hasn't been performed, so this cannot be recognized as income yet.",
    "entries": [
      {
        "particulars": "Cash A/c",
        "dr": 4000,
        "cr": null
      },
      {
        "particulars": "   To Commission Received in Advance A/c",
        "dr": null,
        "cr": 4000
      }
    ],
    "narration": "(Being commission received in advance)",
    "explanation": "Money received before it's earned is a liability — an obligation to deliver the service — not revenue."
  },
  {
    "id": 34,
    "difficulty": "Hard",
    "transaction": "Interest on capital of ₹3,500 was allowed to the proprietor.",
    "hint": "This is an expense to the business but increases what the business owes the owner.",
    "entries": [
      {
        "particulars": "Interest on Capital A/c",
        "dr": 3500,
        "cr": null
      },
      {
        "particulars": "   To Capital A/c",
        "dr": null,
        "cr": 3500
      }
    ],
    "narration": "(Being interest on capital allowed to proprietor)",
    "explanation": "From the business's perspective this is a cost of using owner funds; from the owner's perspective, it increases their capital balance."
  },
  {
    "id": 35,
    "difficulty": "Hard",
    "transaction": "Interest of ₹800 was charged on the proprietor's drawings.",
    "hint": "This is income to the business, charged against the owner's drawings.",
    "entries": [
      {
        "particulars": "Drawings A/c",
        "dr": 800,
        "cr": null
      },
      {
        "particulars": "   To Interest on Drawings A/c",
        "dr": null,
        "cr": 800
      }
    ],
    "narration": "(Being interest charged on proprietor's drawings)",
    "explanation": "Interest on drawings compensates the business for funds the owner took out during the year — it increases Drawings and is recorded as income."
  },
  {
    "id": 36,
    "difficulty": "Hard",
    "transaction": "Purchased a computer for office use, ₹45,000, paying 60% by cheque immediately and the balance on credit from Cyber Solutions Ltd.",
    "hint": "A fixed asset bought partly on credit — the supplier becomes a specific creditor, separate from trade Purchases.",
    "entries": [
      {
        "particulars": "Computer A/c",
        "dr": 45000,
        "cr": null
      },
      {
        "particulars": "   To Bank A/c",
        "dr": null,
        "cr": 27000
      },
      {
        "particulars": "   To Cyber Solutions Ltd. A/c",
        "dr": null,
        "cr": 18000
      }
    ],
    "narration": "(Being computer purchased for office use, part paid by cheque and part on credit)",
    "explanation": "Because this is office equipment and not stock-in-trade, it is debited directly to an asset account rather than routed through Purchases A/c."
  },
  {
    "id": 37,
    "difficulty": "Hard",
    "transaction": "Started business on 1st April with cash ₹20,000; bank balance ₹40,000; stock ₹30,000; furniture ₹25,000; debtors ₹15,000; creditors ₹18,000; and a bank loan of ₹12,000.",
    "hint": "This is an Opening Entry — debit every asset, credit every liability, and let Capital be whatever balances the two sides.",
    "entries": [
      { "particulars": "Cash A/c", "dr": 20000, "cr": null },
      { "particulars": "Bank A/c", "dr": 40000, "cr": null },
      { "particulars": "Stock A/c", "dr": 30000, "cr": null },
      { "particulars": "Furniture A/c", "dr": 25000, "cr": null },
      { "particulars": "Debtors A/c", "dr": 15000, "cr": null },
      { "particulars": "   To Creditors A/c", "dr": null, "cr": 18000 },
      { "particulars": "   To Bank Loan A/c", "dr": null, "cr": 12000 },
      { "particulars": "   To Capital A/c", "dr": null, "cr": 100000 }
    ],
    "narration": "(Being balances of assets and liabilities brought forward from the previous year)",
    "explanation": "An Opening Entry follows one rule: debit all assets, credit all liabilities, and Capital is never given directly — it's always the balancing figure. Here, total assets (₹1,30,000) minus total liabilities (₹30,000) leaves Capital at ₹1,00,000, so both sides of the entry total ₹1,30,000."
  },
  {
    "id": 38,
    "difficulty": "Hard",
    "transaction": "Sold old machinery, whose book value was ₹20,000, for ₹25,000 cash.",
    "hint": "Machinery A/c is credited only for its own book value — the extra ₹5,000 received is a separate gain, not more machinery revenue.",
    "entries": [
      { "particulars": "Cash A/c", "dr": 25000, "cr": null },
      { "particulars": "   To Machinery A/c", "dr": null, "cr": 20000 },
      { "particulars": "   To Gain (Profit) on Sale of Machinery A/c", "dr": null, "cr": 5000 }
    ],
    "narration": "(Being old machinery sold at a profit)",
    "explanation": "Selling a fixed asset is never routed through Sales A/c — that account is reserved for goods held for resale. Machinery A/c is credited only to remove its own book value from the books, and any amount received above that book value is a capital gain, credited to its own 'Profit on Sale' account."
  },
  {
    "id": 39,
    "difficulty": "Hard",
    "transaction": "Sold old furniture, whose book value was ₹10,000, for ₹7,000 cash.",
    "hint": "The asset is removed at its full book value; the shortfall is a loss, debited separately.",
    "entries": [
      { "particulars": "Cash A/c", "dr": 7000, "cr": null },
      { "particulars": "Loss on Sale of Furniture A/c", "dr": 3000, "cr": null },
      { "particulars": "   To Furniture A/c", "dr": null, "cr": 10000 }
    ],
    "narration": "(Being old furniture sold at a loss)",
    "explanation": "This is the mirror image of a profit on sale: Furniture A/c is still credited for its full ₹10,000 book value regardless of what was actually received, and the ₹3,000 shortfall is debited to a Loss on Sale account — a Nominal account loss, not a reduction of Sales."
  },
  {
    "id": 40,
    "difficulty": "Medium",
    "transaction": "Returned goods worth ₹4,000 to Rakesh, from whom they were purchased on credit, being defective.",
    "hint": "Rakesh's balance owed by us goes down; the return reduces what was originally debited to Purchases.",
    "entries": [
      { "particulars": "Rakesh's A/c", "dr": 4000, "cr": null },
      { "particulars": "   To Purchases Return A/c", "dr": null, "cr": 4000 }
    ],
    "narration": "(Being defective goods returned to Rakesh)",
    "explanation": "Purchases Return (also called Returns Outward) is credited rather than reducing Purchases A/c directly, so the books keep a separate running record of how much stock was sent back — useful information that would otherwise be lost. Rakesh's account is debited because the firm now owes him ₹4,000 less."
  },
  {
    "id": 41,
    "difficulty": "Medium",
    "transaction": "Goods worth ₹2,500 were returned by Kavita, to whom they were sold on credit, as they were not as per sample.",
    "hint": "Kavita now owes ₹2,500 less; the return reduces what was originally credited to Sales.",
    "entries": [
      { "particulars": "Sales Return A/c", "dr": 2500, "cr": null },
      { "particulars": "   To Kavita's A/c", "dr": null, "cr": 2500 }
    ],
    "narration": "(Being goods returned by Kavita, not as per sample)",
    "explanation": "Sales Return (or Returns Inward) is debited in its own account rather than directly reversing Sales A/c, which keeps the original sales figure intact for reporting. Kavita's personal account is credited because her outstanding balance to the firm has now reduced."
  },
  {
    "id": 42,
    "difficulty": "Hard",
    "transaction": "Received ₹900 in cash from Naresh, whose account had been written off as a bad debt in an earlier year.",
    "hint": "Naresh's personal account was already closed when the debt was written off — this recovery cannot be credited back to him.",
    "entries": [
      { "particulars": "Cash A/c", "dr": 900, "cr": null },
      { "particulars": "   To Bad Debts Recovered A/c", "dr": null, "cr": 900 }
    ],
    "narration": "(Being amount recovered from Naresh, previously written off as bad debt)",
    "explanation": "Once a debt is written off, the debtor's personal account is closed to zero — there is nothing left in it to credit. Any later recovery is pure, unexpected income, so it is credited to a Bad Debts Recovered account (a Nominal gain) instead of reopening Naresh's account."
  },
  {
    "id": 43,
    "difficulty": "Hard",
    "transaction": "A debtor, Suresh, who owed ₹10,000, was declared insolvent. A first and final payment of 60 paise in the rupee was received in cash from his estate; the rest could not be recovered.",
    "hint": "Split the ₹10,000 owed between what was actually recovered and what must now be written off.",
    "entries": [
      { "particulars": "Cash A/c", "dr": 6000, "cr": null },
      { "particulars": "Bad Debts A/c", "dr": 4000, "cr": null },
      { "particulars": "   To Suresh's A/c", "dr": null, "cr": 10000 }
    ],
    "narration": "(Being 60 paise in the rupee received from Suresh's estate on insolvency, balance written off as bad debt)",
    "explanation": "Insolvency simply means a debtor cannot pay in full. Suresh's account is credited and closed for the complete ₹10,000 he owed — matched by the cash actually recovered (60% = ₹6,000) on one side and the unrecoverable balance (40% = ₹4,000) debited to Bad Debts A/c on the other."
  },
  {
    "id": 44,
    "difficulty": "Medium",
    "transaction": "Received a Bills Receivable of ₹8,000 from debtor Vikram, in settlement of his account, payable after 3 months.",
    "hint": "Vikram's personal account is settled; a new asset — a written promise to pay — replaces it.",
    "entries": [
      { "particulars": "Bills Receivable A/c", "dr": 8000, "cr": null },
      { "particulars": "   To Vikram's A/c", "dr": null, "cr": 8000 }
    ],
    "narration": "(Being a Bills Receivable accepted by Vikram in settlement of his account)",
    "explanation": "A Bill of Exchange accepted by a debtor is a formal, legally enforceable promise to pay on a fixed future date. It converts an ordinary debtor balance into a separate asset, Bills Receivable A/c, which behaves like a more secure form of debtor until it matures."
  },
  {
    "id": 45,
    "difficulty": "Medium",
    "transaction": "The Bills Receivable of ₹8,000 received earlier from Vikram was honoured on the due date, the amount being collected through the bank.",
    "hint": "The bill is now settled — it is removed from the books once the cash actually arrives.",
    "entries": [
      { "particulars": "Bank A/c", "dr": 8000, "cr": null },
      { "particulars": "   To Bills Receivable A/c", "dr": null, "cr": 8000 }
    ],
    "narration": "(Being the Bills Receivable from Vikram honoured on maturity, collected through bank)",
    "explanation": "A bill being 'honoured' simply means the acceptor paid on the due date as promised. Bills Receivable A/c, having done its job, is credited and closed, while the bank account that actually received the money is debited."
  },
  {
    "id": 46,
    "difficulty": "Easy",
    "transaction": "Withdrew ₹10,000 from the bank for office use.",
    "hint": "Both accounts affected are Real accounts — money simply changes form.",
    "entries": [
      { "particulars": "Cash A/c", "dr": 10000, "cr": null },
      { "particulars": "   To Bank A/c", "dr": null, "cr": 10000 }
    ],
    "narration": "(Being cash withdrawn from bank for office use)",
    "explanation": "This is the exact reverse of depositing cash into the bank — a contra entry between two asset accounts. Total assets of the business don't change at all; only how much sits as physical cash versus as a bank balance shifts."
  },
  {
    "id": 47,
    "difficulty": "Medium",
    "transaction": "As per the bank statement, the bank debited ₹150 as bank charges for the month.",
    "hint": "The bank itself initiated this — there's no cash or cheque instruction from the firm, but the bank balance still falls.",
    "entries": [
      { "particulars": "Bank Charges A/c", "dr": 150, "cr": null },
      { "particulars": "   To Bank A/c", "dr": null, "cr": 150 }
    ],
    "narration": "(Being bank charges debited by the bank as per the pass book)",
    "explanation": "Some entries originate from the bank's own records rather than the firm's cash book — bank charges, interest, and similar deductions are noticed only when the pass book or statement is checked, but they still reduce the real Bank A/c balance and must be journalised like any other expense."
  },
  {
    "id": 48,
    "difficulty": "Medium",
    "transaction": "As per the pass book, the bank credited ₹600 as interest on the balance held in the account.",
    "hint": "This is income the bank paid directly — the firm didn't 'receive' it through cash or cheque in the usual sense.",
    "entries": [
      { "particulars": "Bank A/c", "dr": 600, "cr": null },
      { "particulars": "   To Interest Received A/c", "dr": null, "cr": 600 }
    ],
    "narration": "(Being interest credited by the bank as per the pass book)",
    "explanation": "Just like bank charges, interest the bank pays on a balance shows up first in the bank statement rather than in a receipt the firm itself recorded — but it is genuine income, so Bank A/c is debited (it increased) and Interest Received A/c is credited."
  },
  {
    "id": 49,
    "difficulty": "Hard",
    "transaction": "Commission of ₹1,200 was earned during the year but had not been received by the year-end.",
    "hint": "Income has genuinely been earned, even though no cash has come in yet — this is the mirror image of an outstanding expense.",
    "entries": [
      { "particulars": "Accrued Commission A/c", "dr": 1200, "cr": null },
      { "particulars": "   To Commission Received A/c", "dr": null, "cr": 1200 }
    ],
    "narration": "(Being commission earned but not yet received, accrued at year-end)",
    "explanation": "The accrual concept requires income to be recorded in the period it is actually earned, not the period cash happens to arrive. Accrued Commission A/c (an asset — a right to receive money) is debited, while the full amount earned is credited to Commission Received A/c so the income statement reflects the true total earned for the year, not just what was collected."
  },
  {
    "id": 50,
    "difficulty": "Hard",
    "transaction": "A customer, Rohit, deposited ₹5,000 directly into the firm's bank account in settlement of his dues, without informing the firm in advance.",
    "hint": "The firm only learns of this from the bank statement, but the effect on Rohit's account is identical to any other receipt.",
    "entries": [
      { "particulars": "Bank A/c", "dr": 5000, "cr": null },
      { "particulars": "   To Rohit's A/c", "dr": null, "cr": 5000 }
    ],
    "narration": "(Being amount deposited directly into bank by Rohit in settlement of his account)",
    "explanation": "Whether a customer hands over a cheque personally or deposits straight into the firm's account, the accounting effect is the same — Bank A/c increases and the debtor's account is credited by the same amount. The bank statement, not a cheque in hand, is simply the source document confirming it happened."
  },
  {
    "id": 51,
    "difficulty": "Medium",
    "transaction": "Started business with cash ₹40,000, goods worth ₹20,000, and furniture worth ₹15,000.",
    "hint": "Every asset brought in is debited at its own value; Capital is credited for the total, since it all came from the proprietor.",
    "entries": [
      { "particulars": "Cash A/c", "dr": 40000, "cr": null },
      { "particulars": "Purchases A/c", "dr": 20000, "cr": null },
      { "particulars": "Furniture A/c", "dr": 15000, "cr": null },
      { "particulars": "   To Capital A/c", "dr": null, "cr": 75000 }
    ],
    "narration": "(Being business started with cash, goods, and furniture)",
    "explanation": "This differs from a simple cash start only in having more than one asset — each is debited separately at its own value, and Capital A/c is credited for their combined total (₹75,000), since the proprietor is the source of every one of them. Goods brought in as capital go to Purchases A/c, exactly as they would if bought normally."
  },
  {
    "id": 52,
    "difficulty": "Easy",
    "transaction": "The proprietor introduced additional capital of ₹20,000 by cheque.",
    "hint": "This is separate money coming in from the owner after the business has already started — still Capital, just introduced later.",
    "entries": [
      { "particulars": "Bank A/c", "dr": 20000, "cr": null },
      { "particulars": "   To Capital A/c", "dr": null, "cr": 20000 }
    ],
    "narration": "(Being additional capital introduced by cheque)",
    "explanation": "Additional capital is journalised exactly like the original investment — it simply happens partway through the business's life rather than at the very start. Whether it arrives as cash, by cheque, or as an asset, Capital A/c is credited either way."
  },
  {
    "id": 53,
    "difficulty": "Medium",
    "transaction": "Withdrew ₹6,000 from the bank for the proprietor's personal use.",
    "hint": "Compare this carefully with cash withdrawn from bank for office use — the debit here is completely different.",
    "entries": [
      { "particulars": "Drawings A/c", "dr": 6000, "cr": null },
      { "particulars": "   To Bank A/c", "dr": null, "cr": 6000 }
    ],
    "narration": "(Being cash withdrawn from bank for personal use of the proprietor)",
    "explanation": "This is the transaction students most often confuse with withdrawing bank funds for office use. Office use is a contra entry between two business assets (Cash A/c Dr / Bank A/c Cr) — the money is still inside the business. Personal use means the money has left the business entirely, so Drawings A/c is debited instead of Cash A/c."
  },
  {
    "id": 54,
    "difficulty": "Medium",
    "transaction": "The proprietor took away office equipment worth ₹2,000 for personal use.",
    "hint": "This is a drawing of an asset other than cash or goods — the specific asset account is reduced directly.",
    "entries": [
      { "particulars": "Drawings A/c", "dr": 2000, "cr": null },
      { "particulars": "   To Office Equipment A/c", "dr": null, "cr": 2000 }
    ],
    "narration": "(Being office equipment withdrawn by proprietor for personal use)",
    "explanation": "Drawings aren't limited to cash or goods — any business asset taken for personal use is credited directly from its own account (here, Office Equipment A/c) and debited to Drawings A/c, reducing the owner's capital in the business."
  },
  {
    "id": 55,
    "difficulty": "Hard",
    "transaction": "Paid the proprietor's life insurance premium of ₹5,000 by cheque.",
    "hint": "A life insurance premium belongs to the owner personally, never to the business — no matter which account paid for it.",
    "entries": [
      { "particulars": "Drawings A/c", "dr": 5000, "cr": null },
      { "particulars": "   To Bank A/c", "dr": null, "cr": 5000 }
    ],
    "narration": "(Being proprietor's life insurance premium paid by cheque, treated as drawings)",
    "explanation": "This is a classic trap: it looks like a routine 'insurance premium paid' business expense, but a life insurance policy is always personal to the proprietor, never an asset or expense of the business. Because the business's money was used to pay a personal obligation, it is Drawings — not Insurance Premium A/c — that gets debited."
  },
  {
    "id": 56,
    "difficulty": "Easy",
    "transaction": "Paid insurance premium of ₹6,000 by cheque for insuring the business's stock and building.",
    "hint": "Unlike the proprietor's life insurance, this genuinely protects business property — a real business expense.",
    "entries": [
      { "particulars": "Insurance Premium A/c", "dr": 6000, "cr": null },
      { "particulars": "   To Bank A/c", "dr": null, "cr": 6000 }
    ],
    "narration": "(Being insurance premium paid on business assets by cheque)",
    "explanation": "Unlike a proprietor's personal life insurance, premium paid to insure the business's own stock, building, or other assets is a genuine business expense — Insurance Premium A/c (Nominal) is debited, and Bank A/c is credited."
  },
  {
    "id": 57,
    "difficulty": "Medium",
    "transaction": "Paid carriage of ₹1,200 in cash on goods purchased and brought to the godown.",
    "hint": "Carriage on incoming goods is treated as part of the cost of bringing stock in, not a general expense.",
    "entries": [
      { "particulars": "Carriage Inwards A/c", "dr": 1200, "cr": null },
      { "particulars": "   To Cash A/c", "dr": null, "cr": 1200 }
    ],
    "narration": "(Being carriage paid on goods purchased)",
    "explanation": "Carriage Inwards (or Carriage on Purchases) is kept in its own account because it forms part of the cost of getting goods ready for sale — it's added to the cost of purchases in the Trading Account, unlike a general operating expense."
  },
  {
    "id": 58,
    "difficulty": "Medium",
    "transaction": "Paid carriage of ₹800 in cash on goods delivered to a customer after sale.",
    "hint": "Carriage on outgoing, already-sold goods is a selling expense — a different account entirely from carriage on purchases.",
    "entries": [
      { "particulars": "Carriage Outwards A/c", "dr": 800, "cr": null },
      { "particulars": "   To Cash A/c", "dr": null, "cr": 800 }
    ],
    "narration": "(Being carriage paid on goods sold and delivered)",
    "explanation": "Carriage Outwards (or Carriage on Sales) is a distribution/selling expense — it's incurred after the sale is already complete, so it belongs in the Profit & Loss Account, not added to the cost of purchases like Carriage Inwards is."
  },
  {
    "id": 59,
    "difficulty": "Hard",
    "transaction": "The Bills Receivable of ₹8,000 accepted by Vikram was dishonoured on the due date — Vikram failed to pay.",
    "hint": "Since the bill was never actually paid, the debtor's account must be reinstated for the same amount.",
    "entries": [
      { "particulars": "Vikram's A/c", "dr": 8000, "cr": null },
      { "particulars": "   To Bills Receivable A/c", "dr": null, "cr": 8000 }
    ],
    "narration": "(Being Bills Receivable from Vikram dishonoured on maturity)",
    "explanation": "Dishonour means the promise to pay was broken. Because no cash was actually received, Bills Receivable A/c is credited to close it out exactly as it would be if honoured — but instead of debiting Bank, Vikram's personal account is debited, effectively restoring him as an ordinary debtor again."
  },
  {
    "id": 60,
    "difficulty": "Medium",
    "transaction": "As per the pass book, the bank debited ₹350 as interest on overdraft for the month.",
    "hint": "This is the mirror image of interest the bank credits — here, the business is paying the bank, not the other way around.",
    "entries": [
      { "particulars": "Interest on Overdraft A/c", "dr": 350, "cr": null },
      { "particulars": "   To Bank A/c", "dr": null, "cr": 350 }
    ],
    "narration": "(Being interest on overdraft debited by the bank as per pass book)",
    "explanation": "When a business overdraws its account, the bank charges interest on the amount borrowed — a genuine finance expense for the business. Like bank charges, it's noticed only via the pass book, but Interest on Overdraft A/c is still debited and Bank A/c credited, same as any other bank-initiated deduction."
  },
  {
    "id": 61,
    "difficulty": "Medium",
    "transaction": "Goods worth ₹2,000 (at cost) were stolen from the godown; no insurance claim was admitted.",
    "hint": "Unlike loss by fire with an insurance claim, nothing at all is recoverable here.",
    "entries": [
      { "particulars": "Loss by Theft A/c", "dr": 2000, "cr": null },
      { "particulars": "   To Purchases A/c", "dr": null, "cr": 2000 }
    ],
    "narration": "(Being goods lost by theft, no insurance claim admitted)",
    "explanation": "Compare this with goods lost by fire where an insurance claim is admitted: there, the recoverable portion goes to Insurance Claim A/c (an asset) and only the shortfall is a real loss. Here, since nothing is recoverable at all, the entire ₹2,000 is a straight loss, credited out of Purchases A/c (removing it from the cost of goods available for sale) and debited in full to Loss by Theft A/c."
  },
  {
    "id": 62,
    "difficulty": "Hard",
    "transaction": "Sold old furniture, book value ₹10,000, to Mohan on credit for ₹12,000.",
    "hint": "Selling a fixed asset on credit still avoids Sales A/c — only the buyer's name changes from Cash to a personal account.",
    "entries": [
      { "particulars": "Mohan's A/c", "dr": 12000, "cr": null },
      { "particulars": "   To Furniture A/c", "dr": null, "cr": 10000 },
      { "particulars": "   To Gain (Profit) on Sale of Furniture A/c", "dr": null, "cr": 2000 }
    ],
    "narration": "(Being old furniture sold to Mohan on credit at a profit)",
    "explanation": "Whether a fixed asset is sold for cash or on credit changes only which account is debited — Cash/Bank A/c for a cash sale, or the buyer's personal account (Mohan's A/c) for a credit sale. Furniture A/c is still credited only for its own book value, and the profit is still credited separately, exactly as in a cash sale."
  },
  {
    "id": 63,
    "difficulty": "Hard",
    "transaction": "Purchased machinery for ₹50,000 by cheque, and paid ₹2,000 in cash for its installation.",
    "hint": "Installation charges make the asset usable — they add to its cost rather than being a separate expense.",
    "entries": [
      { "particulars": "Machinery A/c", "dr": 52000, "cr": null },
      { "particulars": "   To Bank A/c", "dr": null, "cr": 50000 },
      { "particulars": "   To Cash A/c", "dr": null, "cr": 2000 }
    ],
    "narration": "(Being machinery purchased and installation charges paid, capitalised with the asset)",
    "explanation": "Any cost incurred to bring a fixed asset into a usable condition — installation, carriage on the asset, setup fees — is added to (capitalised with) the asset's own cost rather than treated as a separate expense. Machinery A/c is therefore debited for the full ₹52,000, not just the ₹50,000 purchase price."
  },
  {
    "id": 64,
    "difficulty": "Medium",
    "transaction": "Paid ₹5,000 in cash to a supplier in advance, for goods to be delivered next month.",
    "hint": "No goods have actually been received yet — this can't be treated as a normal credit purchase.",
    "entries": [
      { "particulars": "Advance to Supplier A/c", "dr": 5000, "cr": null },
      { "particulars": "   To Cash A/c", "dr": null, "cr": 5000 }
    ],
    "narration": "(Being advance paid to supplier for goods to be received later)",
    "explanation": "Since no goods have changed hands yet, this cannot be debited to Purchases A/c. Advance to Supplier A/c (an asset — the supplier owes the business goods, or a refund) is debited instead, and adjusted later once the actual goods are received."
  },
  {
    "id": 65,
    "difficulty": "Medium",
    "transaction": "Received ₹6,000 in cash from a customer as an advance, for goods to be supplied next month.",
    "hint": "No sale has actually happened yet — this cannot be credited to Sales A/c.",
    "entries": [
      { "particulars": "Cash A/c", "dr": 6000, "cr": null },
      { "particulars": "   To Advance from Customer A/c", "dr": null, "cr": 6000 }
    ],
    "narration": "(Being advance received from customer for goods to be supplied later)",
    "explanation": "Because the goods haven't been delivered yet, this can't be credited to Sales A/c. Advance from Customer A/c (a liability — the business owes goods, or a refund, to the customer) is credited instead, and adjusted once the actual sale takes place."
  },
  {
    "id": 66,
    "difficulty": "Medium",
    "transaction": "As per the pass book, a dividend of ₹2,000 on investments was received directly into the bank account.",
    "hint": "Like interest credited by the bank, this is income the business never personally collected — it simply appeared in the statement.",
    "entries": [
      { "particulars": "Bank A/c", "dr": 2000, "cr": null },
      { "particulars": "   To Dividend Received A/c", "dr": null, "cr": 2000 }
    ],
    "narration": "(Being dividend on investments received directly into bank)",
    "explanation": "Dividend received directly into the bank account (rather than by cheque handed over) is journalised the same way as any other income credited by the bank — Bank A/c is debited for the increase, and Dividend Received A/c is credited for the genuine investment income earned."
  },
  {
    "id": 67,
    "difficulty": "Hard",
    "transaction": "A Bills Receivable of ₹10,000 (not yet due) was discounted with the bank for ₹9,700 in cash.",
    "hint": "The bank deducts its own charge upfront for paying early — that shortfall is a genuine finance expense, not a loss on the bill itself.",
    "entries": [
      { "particulars": "Cash A/c", "dr": 9700, "cr": null },
      { "particulars": "Discounting Charges A/c", "dr": 300, "cr": null },
      { "particulars": "   To Bills Receivable A/c", "dr": null, "cr": 10000 }
    ],
    "narration": "(Being a Bills Receivable discounted with the bank before maturity)",
    "explanation": "Discounting a bill means getting cash from the bank before the due date, in exchange for a fee. Bills Receivable A/c is credited and closed for its full face value (₹10,000), same as if it were honoured — but since only ₹9,700 was actually received, the ₹300 shortfall is debited to Discounting Charges A/c, a normal finance expense, not a bad debt or loss."
  },
  {
    "id": 68,
    "difficulty": "Medium",
    "transaction": "Paid ₹2,000 in cash for repairs to existing machinery.",
    "hint": "Repairs restore an asset to its normal working condition — they don't make it more valuable than before.",
    "entries": [
      { "particulars": "Repairs A/c", "dr": 2000, "cr": null },
      { "particulars": "   To Cash A/c", "dr": null, "cr": 2000 }
    ],
    "narration": "(Being repairs carried out on existing machinery)",
    "explanation": "Ordinary repairs keep an asset running as before — they are a revenue expense, debited to Repairs A/c and charged fully against this year's profit, unlike money spent on genuinely improving or expanding an asset's capacity."
  },
  {
    "id": 69,
    "difficulty": "Hard",
    "transaction": "Paid ₹15,000 in cash for a major improvement to machinery that increased its production capacity.",
    "hint": "Compare this with ordinary repairs — this spending makes the asset more valuable or capable than it was before.",
    "entries": [
      { "particulars": "Machinery A/c", "dr": 15000, "cr": null },
      { "particulars": "   To Cash A/c", "dr": null, "cr": 15000 }
    ],
    "narration": "(Being amount spent on improvement of machinery, capitalised)",
    "explanation": "Unlike ordinary repairs, an improvement that genuinely increases an asset's earning capacity or working life is capital expenditure — it's added to (capitalised with) Machinery A/c rather than treated as an expense of the current year, since its benefit extends well beyond this year alone."
  },
  {
    "id": 70,
    "difficulty": "Hard",
    "transaction": "Paid the proprietor's income tax of ₹3,000 in cash.",
    "hint": "Income tax is a personal liability of the proprietor as an individual, never a business expense — the same trap as life insurance premium.",
    "entries": [
      { "particulars": "Drawings A/c", "dr": 3000, "cr": null },
      { "particulars": "   To Cash A/c", "dr": null, "cr": 3000 }
    ],
    "narration": "(Being proprietor's income tax paid in cash, treated as drawings)",
    "explanation": "A sole proprietor and their business are not legally separate persons, but for accounting purposes the business is treated as distinct from its owner. Income tax is charged on the proprietor's personal income, not the business as a separate entity, so paying it with business cash is drawings — exactly like the life insurance premium case."
  },
  {
    "id": 71,
    "difficulty": "Medium",
    "transaction": "Paid ₹60,000 by cheque for the construction of a building for business use.",
    "hint": "A new building is a fixed asset that will benefit the business for many years — not a one-year expense.",
    "entries": [
      { "particulars": "Building A/c", "dr": 60000, "cr": null },
      { "particulars": "   To Bank A/c", "dr": null, "cr": 60000 }
    ],
    "narration": "(Being amount paid for construction of building)",
    "explanation": "Constructing a building is capital expenditure — the full amount spent is debited to Building A/c (an asset), not to any expense account, because the benefit lasts for many years rather than being used up within the current accounting period."
  },
  {
    "id": 72,
    "difficulty": "Medium",
    "transaction": "Received a cheque of ₹7,000 from a customer after banking hours; it could not be deposited into the bank the same day.",
    "hint": "The business genuinely has the cheque in hand, but it isn't yet part of the bank balance.",
    "entries": [
      { "particulars": "Cheque in Hand A/c", "dr": 7000, "cr": null },
      { "particulars": "   To Debtor's A/c", "dr": null, "cr": 7000 }
    ],
    "narration": "(Being cheque received after banking hours, not yet deposited)",
    "explanation": "Until a received cheque is actually deposited, it isn't part of the Bank A/c balance — it's held in a separate Cheque in Hand A/c (an asset). Once deposited on a later date, a follow-up entry (Bank A/c Dr.; To Cheque in Hand A/c) moves it into the bank balance."
  },
  {
    "id": 73,
    "difficulty": "Hard",
    "transaction": "The firm's own goods costing ₹4,000 were used to make furniture for office use.",
    "hint": "These goods never actually get sold — they become a fixed asset of the business instead.",
    "entries": [
      { "particulars": "Furniture A/c", "dr": 4000, "cr": null },
      { "particulars": "   To Purchases A/c", "dr": null, "cr": 4000 }
    ],
    "narration": "(Being goods used to make furniture for office use)",
    "explanation": "Even though these goods were originally bought as stock-in-trade, using them to build office furniture converts them into a fixed asset. Purchases A/c is credited to remove their cost from trading stock, and Furniture A/c is debited — similar in spirit to goods withdrawn for personal use, except here the goods end up as a business asset instead of leaving the business."
  },
  {
    "id": 74,
    "difficulty": "Hard",
    "transaction": "At the year-end, a Provision for Doubtful Debts of ₹1,000 was created on outstanding debtors.",
    "hint": "This isn't an actual bad debt yet — it's a cautious estimate of debts that might not be collected.",
    "entries": [
      { "particulars": "Profit and Loss A/c", "dr": 1000, "cr": null },
      { "particulars": "   To Provision for Doubtful Debts A/c", "dr": null, "cr": 1000 }
    ],
    "narration": "(Being provision created for doubtful debts)",
    "explanation": "Unlike Bad Debts (a debt already confirmed unrecoverable), a Provision for Doubtful Debts is a prudent estimate set aside for debts that might turn bad in future, following the principle of conservatism. It reduces reported profit now rather than waiting for an actual loss to be confirmed, and doesn't touch any individual debtor's account."
  },
  {
    "id": 75,
    "difficulty": "Hard",
    "transaction": "The proprietor personally paid the business's electricity bill of ₹1,500 from their own pocket.",
    "hint": "The business still owes for this expense — but now it owes the proprietor instead of the electricity company.",
    "entries": [
      { "particulars": "Electricity Expenses A/c", "dr": 1500, "cr": null },
      { "particulars": "   To Capital A/c", "dr": null, "cr": 1500 }
    ],
    "narration": "(Being business expense paid by proprietor from personal funds)",
    "explanation": "This is the mirror image of drawings. The business genuinely incurred the expense, so Electricity Expenses A/c is debited as usual — but since the proprietor used personal money rather than business cash, it's treated as an injection of additional capital rather than a payment from Cash or Bank A/c."
  },
  {
    "id": 76,
    "difficulty": "Hard",
    "transaction": "Goods sold to Raman were of poor quality, so a Rebate of ₹2,000 was allowed to him, unrelated to any trade or cash discount.",
    "hint": "Rebate is given for reasons like poor quality or a specification mismatch — never for bulk volume or prompt payment, which is what trade and cash discount are for.",
    "entries": [
      { "particulars": "Rebate Allowed A/c", "dr": 2000, "cr": null },
      { "particulars": "   To Raman's A/c", "dr": null, "cr": 2000 }
    ],
    "narration": "(Being rebate allowed to Raman on goods sold)",
    "explanation": "Rebate looks similar to a discount but is granted for a completely different reason — quality problems, wrong specifications, or similar complaints — never for buying in bulk (that's Trade Discount) or paying promptly (that's Cash Discount). It gets its own account, Rebate Allowed A/c, and reduces what Raman owes exactly like a discount would, but the underlying reason is different and it's tracked separately."
  },
  {
    "id": 77,
    "difficulty": "Medium",
    "transaction": "A rebate of ₹3,000 was received from Kapil on goods purchased, as the goods were not up to the agreed specification.",
    "hint": "From the buyer's side, a rebate received reduces what's owed, just like a discount received would — but for a different underlying reason.",
    "entries": [
      { "particulars": "Kapil's A/c", "dr": 3000, "cr": null },
      { "particulars": "   To Rebate Received A/c", "dr": null, "cr": 3000 }
    ],
    "narration": "(Being rebate received from Kapil on goods purchased)",
    "explanation": "Rebate Received works exactly like Discount Received mechanically — it reduces the amount owed to Kapil — but it's kept in its own account because the reason (a quality complaint) is fundamentally different from a discount for prompt payment or bulk buying."
  },
  {
    "id": 78,
    "difficulty": "Hard",
    "transaction": "An advance of ₹5,000 was given to an employee, Rajiv, for a business trip. He later submitted a travelling bill of ₹4,750, and returned the unspent balance in cash.",
    "hint": "Only the amount actually spent is a real expense — the advance itself was never an expense, just money handed over in trust.",
    "entries": [
      { "particulars": "Travelling Expenses A/c", "dr": 4750, "cr": null },
      { "particulars": "Cash A/c", "dr": 250, "cr": null },
      { "particulars": "   To Travelling Advance A/c", "dr": null, "cr": 5000 }
    ],
    "narration": "(Being travelling expenses adjusted against advance, balance refunded in cash)",
    "explanation": "The original advance sits in Travelling Advance A/c (an asset — money given to Rajiv that he must account for). Once he reports how it was actually spent, that account is closed: the genuine expense (₹4,750) goes to Travelling Expenses A/c, and whatever wasn't spent (₹250) comes back into Cash A/c."
  },
  {
    "id": 79,
    "difficulty": "Hard",
    "transaction": "Rajiv later submitted a travelling bill of ₹5,500 against an earlier advance of ₹5,000, and the extra amount was paid to him in cash.",
    "hint": "This time he spent more than the advance covered — the business now owes him the difference.",
    "entries": [
      { "particulars": "Travelling Expenses A/c", "dr": 5500, "cr": null },
      { "particulars": "   To Cash A/c", "dr": null, "cr": 500 },
      { "particulars": "   To Travelling Advance A/c", "dr": null, "cr": 5000 }
    ],
    "narration": "(Being travelling expenses adjusted against advance, extra amount paid in cash)",
    "explanation": "The full expense actually incurred (₹5,500) is debited to Travelling Expenses A/c regardless of how it's funded. Travelling Advance A/c is credited and closed for the original ₹5,000, and the shortfall (₹500) is paid out of Cash — the mirror image of the previous case, where money came back instead of going out."
  },
  {
    "id": 80,
    "difficulty": "Medium",
    "transaction": "A cheque of ₹7,000 received from a debtor after banking hours (and recorded in Cheque in Hand A/c) was deposited into the bank the next day.",
    "hint": "This is simply the follow-up step — the cheque moves from 'in hand' into the actual bank balance.",
    "entries": [
      { "particulars": "Bank A/c", "dr": 7000, "cr": null },
      { "particulars": "   To Cheque in Hand A/c", "dr": null, "cr": 7000 }
    ],
    "narration": "(Being cheque in hand deposited into bank)",
    "explanation": "This closes out Cheque in Hand A/c, which was opened when the cheque first arrived too late to bank the same day. No debtor's account is touched here at all — that was already settled in the earlier entry; this step purely reclassifies the asset from 'cheque in hand' to 'money in the bank'."
  },
  {
    "id": 81,
    "difficulty": "Hard",
    "transaction": "Issued a bank draft of ₹5,000 in favour of Lal & Sons; the bank charged ₹700 for issuing the draft.",
    "hint": "A draft costs a fee to obtain — that fee is a separate expense from the amount actually paid to the creditor.",
    "entries": [
      { "particulars": "Lal & Sons' A/c", "dr": 5000, "cr": null },
      { "particulars": "Bank Charges A/c", "dr": 700, "cr": null },
      { "particulars": "   To Bank A/c", "dr": null, "cr": 5700 }
    ],
    "narration": "(Being payment made to Lal & Sons by bank draft, bank charges for issuing the draft)",
    "explanation": "A bank draft is simply a more formal way of paying than a cheque — Lal & Sons' account is debited and settled for the ₹5,000 it was owed, exactly as if paid by cheque. But since banks charge a fee to issue a draft, that ₹700 is a separate, genuine expense (Bank Charges A/c), and the total drawn from the bank is ₹5,700, not ₹5,000."
  },
  {
    "id": 82,
    "difficulty": "Medium",
    "transaction": "Repaid a bank loan of ₹35,000 by cheque, which included ₹3,000 towards interest.",
    "hint": "Only part of this payment reduces what's owed on the loan itself — the rest is a separate expense.",
    "entries": [
      { "particulars": "Bank Loan A/c", "dr": 32000, "cr": null },
      { "particulars": "Interest A/c", "dr": 3000, "cr": null },
      { "particulars": "   To Bank A/c", "dr": null, "cr": 35000 }
    ],
    "narration": "(Being bank loan repaid by cheque, including interest)",
    "explanation": "It's tempting to debit Bank Loan A/c for the full ₹35,000, but only ₹32,000 actually reduces the loan balance — the remaining ₹3,000 is interest, a genuine finance expense of the current year, and belongs in Interest A/c instead."
  },
  {
    "id": 83,
    "difficulty": "Medium",
    "transaction": "₹50,000 was transferred from the firm's account at SBI to its account at PNB.",
    "hint": "Both accounts belong to the same business — nothing has left the business, it's just sitting in a different bank now.",
    "entries": [
      { "particulars": "Bank A/c (PNB)", "dr": 50000, "cr": null },
      { "particulars": "   To Bank A/c (SBI)", "dr": null, "cr": 50000 }
    ],
    "narration": "(Being funds transferred from SBI account to PNB account)",
    "explanation": "This is a contra entry between two asset accounts, similar in spirit to withdrawing cash from a bank for office use — the business's total assets don't change at all, only how much sits in each individual bank account. Since a business can hold more than one Bank A/c, each is tracked and named separately (e.g. 'Bank A/c (SBI)', 'Bank A/c (PNB)')."
  },
  {
    "id": 84,
    "difficulty": "Medium",
    "transaction": "Small, varied cash expenses — postage, refreshment, and conveyance — totalling ₹500, were paid during the month.",
    "hint": "These are too varied and small individually to justify a separate account for each one.",
    "entries": [
      { "particulars": "Miscellaneous (Sundry) Expenses A/c", "dr": 500, "cr": null },
      { "particulars": "   To Cash A/c", "dr": null, "cr": 500 }
    ],
    "narration": "(Being small, varied expenses paid in cash)",
    "explanation": "Miscellaneous or Sundry Expenses A/c is a practical catch-all for small, immaterial, varied cash expenses that don't individually justify their own ledger account. This is different from Petty Cash A/c, which is an imprest fund set up specifically to hand small amounts to a petty cashier — Miscellaneous Expenses is about the nature of the expense, Petty Cash is about how the money is administered."
  },
  {
    "id": 85,
    "difficulty": "Hard",
    "transaction": "At the end of the year, unsold closing stock was valued at ₹85,000.",
    "hint": "This isn't a transaction with an outside party at all — it's a year-end adjustment to correctly measure the year's profit.",
    "entries": [
      { "particulars": "Closing Stock A/c", "dr": 85000, "cr": null },
      { "particulars": "   To Trading A/c", "dr": null, "cr": 85000 }
    ],
    "narration": "(Being closing stock brought into the books at year-end)",
    "explanation": "Closing Stock A/c (an asset, representing goods still unsold) is debited, and Trading A/c is credited — this is what allows the Trading Account to correctly calculate gross profit for the year, since goods still on hand shouldn't be counted as part of the cost of what was actually sold."
  },
  {
    "id": 86,
    "difficulty": "Hard",
    "transaction": "Goodwill (an intangible asset) worth ₹40,000 was written off by ₹4,000 during the year.",
    "hint": "This is the same idea as depreciation, but for an intangible asset instead of a physical one.",
    "entries": [
      { "particulars": "Amortisation A/c", "dr": 4000, "cr": null },
      { "particulars": "   To Goodwill A/c", "dr": null, "cr": 4000 }
    ],
    "narration": "(Being goodwill amortised for the year)",
    "explanation": "Amortisation is depreciation's counterpart for intangible assets — Patents, Trademarks, Goodwill, and similar assets with no physical form still lose value over their useful life, and that reduction is debited to Amortisation A/c and credited directly to the intangible asset's own account, just as Depreciation A/c is credited to a tangible fixed asset."
  },
  {
    "id": 87,
    "difficulty": "Hard",
    "transaction": "The proprietor sold his personal scooter for ₹35,000 and deposited the amount into the business's bank account.",
    "hint": "The scooter was never a business asset — this money is coming from outside the business entirely.",
    "entries": [
      { "particulars": "Bank A/c", "dr": 35000, "cr": null },
      { "particulars": "   To Capital A/c", "dr": null, "cr": 35000 }
    ],
    "narration": "(Being proceeds of proprietor's personal scooter, sold and invested in the business)",
    "explanation": "Because the scooter belonged to the proprietor personally and was never on the business's books, its sale itself isn't journalised at all — only the moment the proceeds actually enter the business matters, and that's treated exactly like any other capital introduced, whether it originated as cash, a cheque, or (as here) the sale of something personal."
  },
  {
    "id": 88,
    "difficulty": "Hard",
    "transaction": "Paid rent of ₹15,000 for a building of which two-thirds is used for the business and one-third is occupied by the proprietor as a residence.",
    "hint": "Only the business-use portion is a genuine business expense — the rest is really a personal cost paid with business money.",
    "entries": [
      { "particulars": "Rent A/c", "dr": 10000, "cr": null },
      { "particulars": "Drawings A/c", "dr": 5000, "cr": null },
      { "particulars": "   To Cash/Bank A/c", "dr": null, "cr": 15000 }
    ],
    "narration": "(Being rent paid, two-thirds for business use and one-third for proprietor's residence)",
    "explanation": "When a single payment mixes a genuine business expense with a personal one, it must be split rather than debited entirely to one account. Rent A/c takes only the two-thirds actually related to the business (₹10,000); the remaining third, being for the proprietor's own residence, is Drawings (₹5,000) — money spent for personal benefit, even though it was paid out of business funds."
  },
  {
    "id": 89,
    "difficulty": "Hard",
    "transaction": "Paid ₹22,000 by cheque: ₹15,000 as insurance premium on business stock, and ₹7,000 as the proprietor's own personal insurance premium.",
    "hint": "One payment, but two completely different accounting treatments depending on whose risk is actually being insured.",
    "entries": [
      { "particulars": "Insurance Premium A/c", "dr": 15000, "cr": null },
      { "particulars": "Drawings A/c", "dr": 7000, "cr": null },
      { "particulars": "   To Bank A/c", "dr": null, "cr": 22000 }
    ],
    "narration": "(Being insurance premium paid on business stock and proprietor's personal insurance)",
    "explanation": "Even paid together in one cheque, these are two unrelated transactions from an accounting point of view. Insuring the business's own stock genuinely protects a business asset, so that portion is a real expense (Insurance Premium A/c). Insuring the proprietor personally protects him, not the business, so that portion is Drawings — exactly the same trap as a proprietor's life insurance premium."
  },
  {
    "id": 90,
    "difficulty": "Hard",
    "transaction": "Goods costing ₹80,000 were destroyed by fire. An insurance claim was lodged with the insurance company but not yet admitted.",
    "hint": "Until the insurer actually admits the claim, none of it can be treated as a recoverable asset — the whole cost is provisionally a loss.",
    "entries": [
      { "particulars": "Loss by Fire A/c", "dr": 80000, "cr": null },
      { "particulars": "   To Purchases A/c", "dr": null, "cr": 80000 }
    ],
    "narration": "(Being goods destroyed by fire, insurance claim lodged but not yet admitted)",
    "explanation": "Compare this with a case where the claim is admitted immediately: here, since the insurance company hasn't yet confirmed how much (if anything) it will pay, the entire cost is provisionally treated as a loss. Once the claim is later admitted, a follow-up entry reclassifies the recoverable portion out of this loss and into Insurance Claim A/c."
  },
  {
    "id": 91,
    "difficulty": "Hard",
    "transaction": "The insurance company later admitted and settled the fire claim from the previous transaction at 80% of the ₹80,000 loss, in full and final settlement.",
    "hint": "Only the admitted portion becomes a genuine recoverable asset — the rest remains a real loss.",
    "entries": [
      { "particulars": "Insurance Claim A/c", "dr": 64000, "cr": null },
      { "particulars": "   To Loss by Fire A/c", "dr": null, "cr": 64000 }
    ],
    "narration": "(Being insurance claim admitted at 80% of the loss, in full and final settlement)",
    "explanation": "This entry doesn't touch Cash or Bank at all — it simply reclassifies part of the provisional loss into a genuine receivable now that the insurer has confirmed it will pay. Insurance Claim A/c is debited for the admitted 80% (₹64,000), and Loss by Fire A/c is credited to reduce the loss by the same amount — leaving the remaining 20% (₹16,000) as the business's final, real loss. A separate entry (Cash/Bank A/c Dr; To Insurance Claim A/c) would record the money once actually received."
  },
  {
    "id": 92,
    "difficulty": "Hard",
    "transaction": "Sold goods costing ₹20,000 to Sunil at a profit of 20% on sale, less 20% trade discount, and paid cartage of ₹150 on delivery — to be recovered from Sunil.",
    "hint": "The cartage isn't really an expense of the business at all here — it's simply passed through to the customer.",
    "entries": [
      { "particulars": "Sunil's A/c", "dr": 150, "cr": null },
      { "particulars": "   To Cartage Recovered A/c", "dr": null, "cr": 150 }
    ],
    "narration": "(Being cartage paid on Sunil's delivery, recovered from him)",
    "explanation": "Because this cartage is explicitly billed back to the customer rather than absorbed by the business, it isn't Carriage Outwards (a genuine selling expense) at all — it's added to what Sunil owes and credited to Cartage Recovered A/c, which behaves like income rather than an expense. This entry is separate from (and in addition to) the main sale entry for the goods themselves."
  },
  {
    "id": 93,
    "difficulty": "Hard",
    "transaction": "Goods of list price ₹40,000 were purchased from a supplier at 20% trade discount. Some goods, of list price ₹4,000, were later returned as defective. The balance due was then settled in cash, availing a 2% cash discount.",
    "hint": "Trade discount is applied first to get the invoice value; the return then reduces that balance; cash discount applies only to what's actually paid at settlement.",
    "entries": [
      { "particulars": "Supplier's A/c", "dr": 3200, "cr": null },
      { "particulars": "   To Purchases Return A/c", "dr": null, "cr": 3200 },
      { "particulars": "Supplier's A/c", "dr": 28800, "cr": null },
      { "particulars": "   To Cash A/c", "dr": null, "cr": 28224 },
      { "particulars": "   To Discount Received A/c", "dr": null, "cr": 576 }
    ],
    "narration": "(Being goods returned, and balance settled in cash with discount received)",
    "explanation": "This works in three steps: ₹40,000 less 20% trade discount gives an invoice value of ₹32,000. The return of ₹4,000 (list price) is also net of trade discount, so it reduces the supplier's account by ₹3,200 (Supplier's A/c Dr; To Purchases Return A/c), leaving ₹28,800 owed. Only then is the 2% cash discount calculated — on that final ₹28,800 balance, not the original ₹32,000 — giving a discount of ₹576 and a net cash payment of ₹28,224."
  },
  {
    "id": 94,
    "difficulty": "Hard",
    "transaction": "Goods were sold on the condition that a cash discount would apply only if the full amount was paid within 14 days. The customer paid 50% within 14 days and the remaining 50% later — so no cash discount was allowed at all.",
    "hint": "A conditional cash discount is all-or-nothing when it depends on full payment within a window — a partial payment inside the deadline does not earn a partial discount.",
    "entries": [
      { "particulars": "Cash/Bank A/c", "dr": 5000, "cr": null },
      { "particulars": "   To Debtor's A/c", "dr": null, "cr": 5000 }
    ],
    "narration": "(Being 50% received within the discount period; no discount allowed since full payment was not made in time)",
    "explanation": "This is easy to confuse with a straightforward part-cash-part-credit sale, where discount is simply calculated on whatever portion is paid immediately. Here, the discount was explicitly conditional on the *entire* invoice being paid within 14 days — since the customer didn't meet that condition, no discount is earned at all, not even a proportional one on the part paid on time. Always check whether a cash discount is a plain percentage on the amount received, or a conditional offer tied to full payment by a deadline — the calculator on this page assumes the first case."
  },
  {
    "id": 95,
    "difficulty": "Hard",
    "transaction": "Paid ₹5,000 as life insurance premium covering the firm's employees under a group policy.",
    "hint": "Compare this carefully with the proprietor's own life insurance — who is actually being insured here?",
    "entries": [
      { "particulars": "Employees' Insurance Premium A/c", "dr": 5000, "cr": null },
      { "particulars": "   To Cash/Bank A/c", "dr": null, "cr": 5000 }
    ],
    "narration": "(Being life insurance premium paid for employees under a group scheme)",
    "explanation": "This is the direct opposite of the proprietor's-own-life-insurance trap. Insuring employees is a genuine staff welfare cost the business incurs for its workforce, so it's a real business expense (Employees' Insurance Premium A/c) — not Drawings. The deciding question is always the same: whose personal risk is actually being covered? The proprietor's own life → Drawings. Employees' lives, as a business cost → a genuine expense."
  },
  {
    "id": 96,
    "difficulty": "Medium",
    "transaction": "An advance of ₹40,000 was paid by cheque to a machine supplier for a machine to be delivered next month.",
    "hint": "This is the fixed-asset equivalent of paying a supplier in advance for goods — but the account used is specific to the asset.",
    "entries": [
      { "particulars": "Advance for Machinery A/c", "dr": 40000, "cr": null },
      { "particulars": "   To Bank A/c", "dr": null, "cr": 40000 }
    ],
    "narration": "(Being advance paid for machine to be received later)",
    "explanation": "Just as an advance to a goods supplier is debited to Advance to Supplier A/c rather than Purchases A/c (since no goods have arrived yet), an advance for a fixed asset not yet delivered is debited to its own Advance for Machinery A/c rather than Machinery A/c itself — the asset account is only debited once the machine actually arrives and is ready for use."
  }
],

    /* --------------------------------------------------------
       NEW SECTION — Ledger Posting Practice
       A distinct skill from writing the journal entry itself:
       taking a journal entry and correctly posting each line
       into its own T-account, on the correct side, with the
       correct "opposite account" reference — exactly what
       students are asked to do immediately after journalising
       in the CBSE syllabus, and not covered by the transaction
       bank above (which stops at the journal entry).
       -------------------------------------------------------- */
    ledgerPostings: [
      {
        id: 1,
        journalEntry: "Cash A/c Dr. 50,000; To Capital A/c 50,000",
        postings: [
          { account: "Cash A/c", side: "Debit", amount: 50000, oppositeRef: "To Capital A/c" },
          { account: "Capital A/c", side: "Credit", amount: 50000, oppositeRef: "By Cash A/c" }
        ],
        explanation: "Every debit in the journal is posted to the debit side of that account's own T-account, referencing the account it was paired with using 'To'. Every credit is posted to the credit side, referencing its pair using 'By'. Here, Cash A/c's debit side shows 'To Capital A/c 50,000', and Capital A/c's credit side shows 'By Cash A/c 50,000' — two mirror-image postings from one journal entry."
      },
      {
        id: 2,
        journalEntry: "Purchases A/c Dr. 20,000; To Cash A/c 20,000",
        postings: [
          { account: "Purchases A/c", side: "Debit", amount: 20000, oppositeRef: "To Cash A/c" },
          { account: "Cash A/c", side: "Credit", amount: 20000, oppositeRef: "By Purchases A/c" }
        ],
        explanation: "Purchases A/c is debited (posted to its debit side, referencing Cash), and Cash A/c is credited (posted to its credit side, referencing Purchases) — note that Cash A/c can appear on both the debit side (from posting 1 above) and credit side (here) as more transactions accumulate over the accounting period; a ledger account is a running record, not a single-entry box."
      },
      {
        id: 3,
        journalEntry: "Machinery A/c Dr. 90,000; To Bank A/c 30,000; To Supplier's A/c 60,000",
        postings: [
          { account: "Machinery A/c", side: "Debit", amount: 90000, oppositeRef: "To Bank A/c & Supplier's A/c" },
          { account: "Bank A/c", side: "Credit", amount: 30000, oppositeRef: "By Machinery A/c" },
          { account: "Supplier's A/c", side: "Credit", amount: 60000, oppositeRef: "By Machinery A/c" }
        ],
        explanation: "A compound entry with one debit and two credits results in three separate postings, not two. Machinery A/c is debited once for the full ₹90,000 (referencing both credit accounts together, since strict practice writes 'To Sundries' or lists both). Bank A/c and Supplier's A/c are each credited separately for their own portion, each referencing Machinery A/c as the opposite account."
      },
      {
        id: 4,
        journalEntry: "Rent A/c Dr. 5,000; To Cash A/c 5,000",
        postings: [
          { account: "Rent A/c", side: "Debit", amount: 5000, oppositeRef: "To Cash A/c" },
          { account: "Cash A/c", side: "Credit", amount: 5000, oppositeRef: "By Rent A/c" }
        ],
        explanation: "A simple two-line entry always produces exactly two postings — one to each account named, on opposite sides. Rent A/c, being a Nominal expense account, will typically only ever appear on the debit side across the whole year, since expenses aren't usually credited except to close them out at year-end."
      },
      {
        id: 5,
        journalEntry: "Cash A/c Dr. 9,400; Discount Allowed A/c Dr. 600; To Debtor's A/c 10,000",
        postings: [
          { account: "Cash A/c", side: "Debit", amount: 9400, oppositeRef: "To Debtor's A/c" },
          { account: "Discount Allowed A/c", side: "Debit", amount: 600, oppositeRef: "To Debtor's A/c" },
          { account: "Debtor's A/c", side: "Credit", amount: 10000, oppositeRef: "By Cash A/c & Discount Allowed A/c" }
        ],
        explanation: "This compound entry has two debits and one credit — again, three postings result. The Debtor's account is credited in full (₹10,000) in a single posting, referencing both accounts that together make up that amount, while Cash A/c and Discount Allowed A/c are each posted separately to their own debit sides."
      },
      {
        id: 6,
        journalEntry: "Depreciation A/c Dr. 6,000; To Furniture A/c 6,000",
        postings: [
          { account: "Depreciation A/c", side: "Debit", amount: 6000, oppositeRef: "To Furniture A/c" },
          { account: "Furniture A/c", side: "Credit", amount: 6000, oppositeRef: "By Depreciation A/c" }
        ],
        explanation: "Furniture A/c, normally a debit-heavy Real account (since assets usually increase), receives a credit posting here — this is exactly how a T-account shows an asset's value declining over time: not by erasing the earlier debit, but by adding an offsetting credit entry that reduces the account's net balance."
      },
      {
        id: 7,
        journalEntry: "Bank A/c Dr. 27,000; To Sales A/c 27,000",
        postings: [
          { account: "Bank A/c", side: "Debit", amount: 27000, oppositeRef: "To Sales A/c" },
          { account: "Sales A/c", side: "Credit", amount: 27000, oppositeRef: "By Bank A/c" }
        ],
        explanation: "Sales A/c, a Nominal income account, accumulates postings only on its credit side throughout the year from every sale transaction — by the end of the period, its credit side total represents the firm's total revenue from sales, ready to be carried to the Trading Account."
      },
      {
        id: 8,
        journalEntry: "New Furniture A/c Dr. 16,000; To Old Furniture A/c 9,000; To Bank A/c 7,000",
        postings: [
          { account: "New Furniture A/c", side: "Debit", amount: 16000, oppositeRef: "To Old Furniture A/c & Bank A/c" },
          { account: "Old Furniture A/c", side: "Credit", amount: 9000, oppositeRef: "By New Furniture A/c" },
          { account: "Bank A/c", side: "Credit", amount: 7000, oppositeRef: "By New Furniture A/c" }
        ],
        explanation: "Even though New Furniture and Old Furniture might feel like they should share one 'Furniture A/c', in this exchange transaction they are kept as genuinely separate ledger accounts — Old Furniture A/c is closed out via this credit posting (bringing its balance to zero, since the asset has been disposed of), while New Furniture A/c is opened fresh with its own debit posting."
      },
      {
        id: 9,
        journalEntry: "Cash A/c Dr. 20,000; Bank A/c Dr. 40,000; To Creditors A/c 18,000; To Capital A/c 42,000",
        postings: [
          { account: "Cash A/c", side: "Debit", amount: 20000, oppositeRef: "To Sundries" },
          { account: "Bank A/c", side: "Debit", amount: 40000, oppositeRef: "To Sundries" },
          { account: "Creditors A/c", side: "Credit", amount: 18000, oppositeRef: "By Sundries" },
          { account: "Capital A/c", side: "Credit", amount: 42000, oppositeRef: "By Sundries" }
        ],
        explanation: "An Opening Entry posts every single account exactly once, on the side matching its role in the entry — assets (Cash, Bank) are posted as opening debits, liabilities and Capital (Creditors, Capital) as opening credits. Where several accounts share one side of a compound entry, each still gets its own individual posting; 'To/By Sundries' is used as the reference precisely because no single opposite account tells the whole story."
      },
      {
        id: 10,
        journalEntry: "Cash A/c Dr. 25,000; To Machinery A/c 20,000; To Gain (Profit) on Sale of Machinery A/c 5,000",
        postings: [
          { account: "Cash A/c", side: "Debit", amount: 25000, oppositeRef: "To Sundries" },
          { account: "Machinery A/c", side: "Credit", amount: 20000, oppositeRef: "By Cash A/c" },
          { account: "Gain (Profit) on Sale of Machinery A/c", side: "Credit", amount: 5000, oppositeRef: "By Cash A/c" }
        ],
        explanation: "Notice Machinery A/c only ever loses its own book value (₹20,000) here — never the full ₹25,000 received. The extra ₹5,000 is posted to a completely separate Gain on Sale account, which is exactly why mixing up 'amount received' with 'amount to remove from the asset account' is the single most common error students make on this transaction."
      },
      {
        id: 11,
        journalEntry: "Cash A/c Dr. 900; To Bad Debts Recovered A/c 900",
        postings: [
          { account: "Cash A/c", side: "Debit", amount: 900, oppositeRef: "To Bad Debts Recovered A/c" },
          { account: "Bad Debts Recovered A/c", side: "Credit", amount: 900, oppositeRef: "By Cash A/c" }
        ],
        explanation: "There is deliberately no posting to the original debtor's personal account here — it was already closed to zero when the debt was first written off, and it stays closed. Bad Debts Recovered A/c is a fresh Nominal account for this one purpose: capturing unexpected income from a debt the business had already given up on."
      },
      {
        id: 12,
        journalEntry: "Bank A/c Dr. 8,000; To Bills Receivable A/c 8,000",
        postings: [
          { account: "Bank A/c", side: "Debit", amount: 8000, oppositeRef: "To Bills Receivable A/c" },
          { account: "Bills Receivable A/c", side: "Credit", amount: 8000, oppositeRef: "By Bank A/c" }
        ],
        explanation: "This posting closes out Bills Receivable A/c, which would have opened with a debit posting when the bill was first received from the debtor. A bill's full life cycle across the ledger is: debit Bills Receivable when accepted, then credit it (and debit Bank or Cash) when it's honoured — the account's balance should return to zero once this posting is made."
      }
    ]
  },

  /* ============================================================
     CHAPTER 4 — LEDGER
     Everything a Class 11 CBSE student needs on posting from
     Journal to Ledger, T-account format, posting rules,
     balancing, and exam-style practice.
     ============================================================ */
  ledger: {
    intro: {
      meaning: "A Ledger is the book in which all the accounts that appear in a business's Journal are collected and kept together, one account per page (or per T-shaped box). Where the Journal records transactions in date order without sorting them by account, the Ledger takes every single debit and credit already recorded there and files it under the correct account name — Cash A/c, Capital A/c, Rent A/c, and so on. Because every account a business needs ends up here, the Ledger is often called the 'Book of Final Entry' or the 'Principal Book of Accounts'.",
      definition: "The Ledger may be defined as the principal book of accounts in which all transactions relating to a particular account — first recorded in the Journal — are transferred (posted) in a classified and permanent form, so that the net effect of every transaction on that one account can be seen together, and its balance found at any time.",
      importance: [
        "It groups scattered transactions: a business might record 'sold goods to Meera' on three different days across the Journal; the Ledger brings all three postings to Meera's Account together in one place.",
        "It reveals the balance of every account — how much cash is in hand, how much a debtor owes, how much is owed to a creditor — which the Journal alone cannot show at a glance.",
        "It is essential for preparing the Trial Balance, which in turn is the base for the Trading Account, Profit & Loss Account, and Balance Sheet.",
        "It helps in verifying arithmetical accuracy of the books, since total debits across all ledger accounts must equal total credits.",
        "It supports quick decision-making — a trader can check any single account's ledger balance instantly instead of scanning the whole Journal."
      ],
      relationship: "The Journal and the Ledger are two connected steps of the same process, not competing books. The Journal is the 'Book of Original Entry' — every transaction is analysed into its debit and credit aspects and recorded here first, in the order it happens. The Ledger is the 'Book of Final Entry' — the debit and credit of each Journal entry is then transferred ('posted') into the separate account it belongs to. Put simply: Journal → records chronologically by transaction; Ledger → classifies and re-records the same information by account. Without the Journal there is nothing to post; without the Ledger, no single account's running balance could ever be found."
    },

    postingRules: [
      { title: "Journal Debit → Ledger Debit", body: "Whichever account was debited in the Journal entry is posted to the DEBIT (left-hand) side of that same account in the Ledger. The account name and amount move across unchanged — only the layout changes, from a Journal line to a Ledger-account entry." },
      { title: "Journal Credit → Ledger Credit", body: "Whichever account was credited in the Journal entry is posted to the CREDIT (right-hand) side of that same account in the Ledger. Every Journal entry therefore results in at least two postings — one debit posting and one credit posting — keeping the dual-aspect principle intact all the way through to the Ledger." },
      { title: "Use \"To\" on the Debit Side", body: "When an entry is posted to the debit side of an account, the name written in the Particulars column is prefixed with the word 'To' — for example 'To Capital A/c'. This word signals that the amount is what this account received FROM the account named alongside it (the one that was credited in the original entry)." },
      { title: "Use \"By\" on the Credit Side", body: "When an entry is posted to the credit side of an account, the name written in the Particulars column is prefixed with the word 'By' — for example 'By Cash A/c'. This word signals that the value went OUT to (or was given by) the account named alongside it (the one that was debited in the original entry)." }
    ],

    balancing: {
      steps: [
        "Total (foot) both the debit side and the credit side of the account separately — add up every amount posted to each side.",
        "Compare the two totals. If the debit total is bigger, the difference is called the 'Balance c/d' (carried down) and is written on the SMALLER side (the credit side here) so both sides show the same final total.",
        "Write 'To Balance c/d' or 'By Balance c/d' (whichever side needs it), with the difference amount, then draw a line and write the now-equal totals on both sides.",
        "Immediately below the totals, bring the same figure down to the OPPOSITE side, on the next date, as 'Balance b/d' (brought down) — this becomes the opening balance for the next period.",
        "The side on which the Balance b/d appears tells you the nature of the balance: b/d on the debit side = a Debit Balance; b/d on the credit side = a Credit Balance.",
        "If both sides total to exactly the same figure with nothing left over, the account has a Nil (zero) balance — common for Nominal accounts once they are closed off to the Trading or Profit & Loss Account at year-end."
      ],
      example: {
        accountName: "Cash Account",
        period: "for the month of April",
        debitRows: [
          { date: "Apr 1", particulars: "To Balance b/d", jf: "—", amount: 5000 },
          { date: "Apr 4", particulars: "To Sales A/c", jf: "12", amount: 12000 },
          { date: "Apr 25", particulars: "To Rohit A/c", jf: "18", amount: 3000 }
        ],
        creditRows: [
          { date: "Apr 10", particulars: "By Rent A/c", jf: "14", amount: 2000 },
          { date: "Apr 18", particulars: "By Purchases A/c", jf: "16", amount: 6000 }
        ],
        totalDebit: 20000,
        totalCredit: 8000,
        balanceCD: 12000,
        balanceCDNature: "Debit",
        workingExplanation: "Total of the debit side = 5,000 + 12,000 + 3,000 = ₹20,000. Total of the credit side = 2,000 + 6,000 = ₹8,000. Since the debit side is bigger, the difference (20,000 − 8,000 = ₹12,000) is written on the credit side as 'By Balance c/d 12,000' on 30 April, making both sides total ₹20,000. On 1 May, the same ₹12,000 is brought down on the debit side as 'To Balance b/d', showing that Cash A/c carries forward a Debit Balance of ₹12,000 into May — exactly what we'd expect, since a Cash Account can never have a credit balance (you cannot pay out more cash than you have)."
      }
    },

    /* A couple of extra practice transactions not already covered among
       the Journal chapter's 36 numericals, so the Ledger practice pool
       includes goods-return transactions too. Same schema as
       APP_DATA.journal.numericals so they slot into the same pipeline. */
    extraPracticeTransactions: [
      { id: 1, difficulty: "Medium",
        transaction: "Goods worth ₹2,000 were returned by a customer, Divya, as they did not match the order.",
        hint: "A sales return reverses part of a sale — Sales Return A/c is debited (it works against Sales), and the customer's personal account is credited since the business now owes them less / owes them a reduction.",
        entries: [
          { particulars: "Sales Return A/c", dr: 2000, cr: null },
          { particulars: "   To Divya A/c", dr: null, cr: 2000 }
        ],
        narration: "(Being goods returned by Divya)",
        explanation: "Sales Return A/c (also called 'Returns Inward A/c') is a Nominal account debited to record the reduction in net sales, while Divya's personal account is credited because the amount she owes the business goes down." },
      { id: 2, difficulty: "Medium",
        transaction: "Goods worth ₹1,200 were returned to a supplier, Farhan, as they were found defective.",
        hint: "A purchase return reverses part of a purchase — the supplier's personal account is debited (the business owes them less), and Purchases Return A/c is credited since it works against Purchases.",
        entries: [
          { particulars: "Farhan A/c", dr: 1200, cr: null },
          { particulars: "   To Purchases Return A/c", dr: null, cr: 1200 }
        ],
        narration: "(Being goods returned to Farhan)",
        explanation: "Farhan's personal account is debited because the amount owed to him decreases, while Purchases Return A/c (also called 'Returns Outward A/c') is credited to record the reduction in net purchases." }
    ],

    quickRevision: {
      definition: "The Ledger is the principal book of accounts where every transaction, already recorded date-wise in the Journal, is transferred ('posted') and collected account-wise, so each account's net position (its balance) can be found.",
      rules: [
        "Journal debit → posted to the Ledger DEBIT side of that account.",
        "Journal credit → posted to the Ledger CREDIT side of that account.",
        "On the debit side, prefix the other account's name with 'To'.",
        "On the credit side, prefix the other account's name with 'By'."
      ],
      balancingSteps: [
        "Total both sides separately.",
        "Find the difference; write it as 'Balance c/d' on the smaller side.",
        "Make both sides equal and draw the total line.",
        "Bring the same figure down on the opposite side as 'Balance b/d' for the next period.",
        "Debit balance if b/d is on the debit side; Credit balance if on the credit side; Nil if both sides already match exactly."
      ],
      commonMistakes: [
        "Posting the correct amount to the wrong side of an account (turns a debit into a credit or vice versa).",
        "Forgetting 'To' on the debit side or 'By' on the credit side in the Particulars column.",
        "Posting only one leg of an entry and forgetting the other account entirely — every Journal entry needs exactly two (or more, for compound entries) postings.",
        "Mixing up which side a Balance c/d belongs on — it always goes on the SMALLER (lower-total) side, never the larger one.",
        "Writing the L.F. number while journalising instead of only at the time of actual posting."
      ],
      mnemonic: "DEBIT = 'To' comes in on the Left (both start with a similar rounded feel: think 'To the Debit'). CREDIT = 'By' goes on the Right. Quick memory hook: \"Dr. — To; Cr. — By\" — say it out loud a few times before an exam and it sticks."
    },

    examQuestions: {
      easy: [
        { q: "What is a Ledger?", a: "The Ledger is the principal book of accounts in which all the transactions first recorded in the Journal are classified and posted account-wise, so each account's balance can be found." },
        { q: "Why is the Ledger called the 'Principal Book of Accounts'?", a: "Because every account a business ever needs — Cash, Capital, individual debtors, creditors, expenses, incomes — is ultimately kept and finalised here; all financial statements are prepared from Ledger balances, not directly from the Journal." },
        { q: "What are the two sides of a ledger account called?", a: "The left-hand side is called the Debit side (Dr.) and the right-hand side is called the Credit side (Cr.)." },
        { q: "What is meant by 'posting' in accounting?", a: "Posting means transferring the debit and credit amounts of a Journal entry into their respective accounts in the Ledger." },
        { q: "Name the standard columns found on each side of a ledger account.", a: "Date, Particulars, Journal Folio (J.F.), and Amount." },
        { q: "Which word is written before the account name on the debit side, and which on the credit side, of a ledger account?", a: "'To' is written on the debit side and 'By' is written on the credit side." },
        { q: "What is a T-account, and why is it called that?", a: "A T-account is the simplified way of drawing a ledger account with just a vertical line down the middle and a horizontal line across the top, so the debit and credit sides sit side by side — the shape resembles the letter 'T'." },
        { q: "State one difference between a Journal and a Ledger.", a: "The Journal records transactions in chronological (date) order as they happen; the Ledger reorganises the same transactions account-wise, grouping every entry that affects a particular account together." },
        { q: "What does 'J.F.' stand for in a ledger account, and when is it filled in?", a: "J.F. stands for Journal Folio — the page number of the Journal from which the entry was posted. It is filled in only at the time of posting, never while journalising." },
        { q: "What is meant by 'balancing' a ledger account?", a: "Balancing means totaling both sides of an account and inserting the difference as 'Balance c/d' on the smaller side, so both sides show equal totals, and then bringing that figure down to the opposite side as 'Balance b/d' for the next period." }
      ],
      medium: [
        { q: "Post the following journal entry to its two ledger accounts: Cash A/c Dr. ₹25,000; To Capital A/c ₹25,000.", a: "Cash A/c — Debit side: 'To Capital A/c ... 25,000'. Capital A/c — Credit side: 'By Cash A/c ... 25,000'." },
        { q: "Explain, with a reason, why the Cash Account normally never shows a credit balance.", a: "Cash A/c is debited whenever cash comes in and credited whenever cash goes out. Since a business cannot pay out more cash than it actually has, the debit side total will always be equal to or greater than the credit side total, so Cash A/c will always show either a debit balance or, at most, a nil balance — never a credit balance." },
        { q: "A Purchases Account shows a total debit of ₹85,000 during the year and no credit entries. What kind of 'balance' does it carry, and what happens to it at year-end?", a: "Purchases A/c will show a debit balance of ₹85,000. Being a Nominal account, it is not carried forward like a Real or Personal account — instead, this balance is transferred (closed) to the debit side of the Trading Account at the end of the year." },
        { q: "Differentiate between 'Balance carried down (c/d)' and 'Balance brought down (b/d)'.", a: "Balance c/d is the closing balancing figure written at the end of the current period, on the smaller side, to make both sides of the account equal. Balance b/d is the exact same figure brought forward onto the opposite side at the start of the next period, becoming that period's opening balance." },
        { q: "A Debtor's personal account has a total debit side of ₹40,000 and a total credit side of ₹28,000. Find the closing balance and state its nature.", a: "Closing balance = 40,000 − 28,000 = ₹12,000, and since the debit side is larger, it is a Debit balance — meaning the debtor still owes the business ₹12,000." },
        { q: "A Creditor's personal account has a total debit side of ₹12,000 and a total credit side of ₹30,000. Find the closing balance and state its nature.", a: "Closing balance = 30,000 − 12,000 = ₹18,000, and since the credit side is larger, it is a Credit balance — meaning the business still owes the creditor ₹18,000." },
        { q: "Why does a Capital Account usually show a credit balance?", a: "Capital represents what the business owes back to its owner. Under the rules for Personal accounts, an increase in what is owed is credited, so contributions of capital and profits are credited to this account far more often than it is debited (mainly only for drawings or losses), leaving it with a credit balance." },
        { q: "From 'Furniture A/c Dr. 18,000; To Cash A/c 9,000; To Ramesh A/c 9,000', how many separate ledger postings will be made, and to which accounts?", a: "Three postings: Furniture A/c is debited once for the full ₹18,000 (referencing both credit accounts); Cash A/c is credited ₹9,000; and Ramesh A/c is credited ₹9,000 — each on their own credit side, referencing Furniture A/c." },
        { q: "Explain why a Nominal account like Rent A/c may end up showing a nil balance at certain points, and what that indicates.", a: "A Nominal account like Rent A/c is closed off at the end of the accounting year by transferring its balance to the Profit & Loss Account. Once this closing entry is posted, the account's debit and credit totals become exactly equal, leaving a nil balance — this simply shows the account has been fully accounted for in that period's profit calculation, not that anything was recorded incorrectly." },
        { q: "A student posts 'Sold goods to Meera ₹5,000' only to the Sales Account, forgetting Meera's personal account. Identify and explain this error.", a: "This is a 'partial omission' or 'one-sided posting' error — only the credit side of the entry (Sales A/c) has been posted, while the debit side (Meera's A/c, which should have been debited ₹5,000 since she now owes the business) has been left out entirely. This will cause the Trial Balance to not tally." },
        { q: "Why must the Ledger Folio (L.F.) column be left blank while journalising, and filled in only during posting?", a: "The L.F. column records the ledger page number that an entry has actually been posted to. Since posting happens after journalising, filling in the L.F. while journalising would be premature — it also serves as a useful check that every journal entry has genuinely been posted, since a blank L.F. flags unposted entries." },
        { q: "How is a Nominal account (like Salary A/c) typically closed at the end of the accounting year, as opposed to being 'balanced' and carried forward?", a: "Rather than carrying a balance forward into the next year, a Nominal account's net balance is transferred to the Trading Account or Profit & Loss Account through a closing entry — expenses to the debit side, incomes to the credit side — after which the Nominal account itself shows a nil balance." },
        { q: "Differentiate between a Personal Account and a Real Account, giving one ledger example of each.", a: "A Personal account relates to a person, firm, or organisation the business deals with — for example, 'Ramesh A/c' (a debtor). A Real account relates to assets and properties owned by the business — for example, 'Furniture A/c'. Both types of accounts, unlike Nominal accounts, are balanced and their closing balances carried forward to the next year, ultimately appearing on the Balance Sheet." },
        { q: "If the debit and credit totals of a ledger account do not eventually help the Trial Balance tally, what should a student first check?", a: "First check that every Journal entry has actually been posted twice — once to the debit side of one account and once to the credit side of another — and that the amounts and sides match the Journal exactly, since a single omitted or wrongly-sided posting is the most common cause of a mismatched Trial Balance." },
        { q: "From 'Bank A/c Dr. 40,000; To Loan A/c 40,000', write out exactly how each account's posting reference will read.", a: "Bank A/c (debit side): 'To Loan A/c ... 40,000'. Loan A/c (credit side): 'By Bank A/c ... 40,000'." }
      ],
      hard: [
        { q: "Prepare and balance the Cash Account (T-format) from: Apr 1 Balance b/d ₹5,000; Apr 4 Sold goods for cash ₹12,000; Apr 10 Paid rent ₹2,000; Apr 18 Purchased goods for cash ₹6,000; Apr 25 Received from Rohit ₹3,000.", a: "Debit side: To Balance b/d 5,000; To Sales A/c 12,000; To Rohit A/c 3,000 = ₹20,000 total. Credit side: By Rent A/c 2,000; By Purchases A/c 6,000 = ₹8,000 total. Balance c/d = 20,000 − 8,000 = ₹12,000, written on the credit side, then brought down on 1 May as 'To Balance b/d ₹12,000' on the debit side — a Debit balance of ₹12,000." },
        { q: "Prepare Ramesh's Account (a debtor) from: opening Balance b/d (Dr.) ₹8,000; goods sold to him on credit ₹10,000; cash received from him ₹9,000; discount allowed to him ₹500.", a: "Debit side: To Balance b/d 8,000; To Sales A/c 10,000 = ₹18,000. Credit side: By Cash A/c 9,000; By Discount Allowed A/c 500 = ₹9,500. Balance c/d = 18,000 − 9,500 = ₹8,500, a Debit balance — the amount Ramesh still owes." },
        { q: "Prepare Suresh's Account (a creditor) from: opening Balance b/d (Cr.) ₹6,000; goods purchased from him on credit ₹15,000; paid him by cheque ₹10,000; discount received ₹300.", a: "Credit side: By Balance b/d 6,000; By Purchases A/c 15,000 = ₹21,000. Debit side: To Bank A/c 10,000; To Discount Received A/c 300 = ₹10,300. Balance c/d = 21,000 − 10,300 = ₹10,700, a Credit balance — the amount still owed to Suresh." },
        { q: "Prepare the Bank Account from: opening Balance b/d (Dr.) ₹20,000; cash deposited into bank ₹15,000; paid Farhan by cheque ₹8,000; cheque received from Meera ₹12,000; rent paid by cheque ₹3,000.", a: "Debit side: To Balance b/d 20,000; To Cash A/c 15,000; To Meera A/c 12,000 = ₹47,000. Credit side: By Farhan A/c 8,000; By Rent A/c 3,000 = ₹11,000. Balance c/d = 47,000 − 11,000 = ₹36,000, a Debit balance." },
        { q: "Prepare the Sales Account from: cash sales ₹22,000; credit sales to Divya ₹16,000; credit sales to Meera ₹25,000; and goods returned by a customer ₹2,000 (posted to the debit side as 'To Sales Return A/c').", a: "Credit side total = 22,000 + 16,000 + 25,000 = ₹63,000. Debit side (Sales Return) = ₹2,000. Net figure = 63,000 − 2,000 = ₹61,000. Being a Nominal account, this net amount is not carried forward as a 'balance c/d' but transferred to the credit side of the Trading Account at year-end." },
        { q: "Prepare the Purchases Account from: cash purchases ₹15,000; credit purchases from Farhan ₹12,000; and goods returned to a supplier ₹1,500 (posted to the credit side as 'By Purchase Return A/c').", a: "Debit side total = 15,000 + 12,000 = ₹27,000. Credit side (Purchase Return) = ₹1,500. Net figure = 27,000 − 1,500 = ₹25,500, transferred to the debit side of the Trading Account at year-end, since Purchases A/c is a Nominal account." },
        { q: "Prepare the Furniture Account from: opening Balance b/d (Dr.) ₹40,000; additional furniture purchased for cash ₹10,000; depreciation charged ₹5,000.", a: "Debit side: To Balance b/d 40,000; To Cash A/c 10,000 = ₹50,000. Credit side: By Depreciation A/c 5,000. Balance c/d = 50,000 − 5,000 = ₹45,000, a Debit balance carried forward as the furniture's book value." },
        { q: "Prepare the Capital Account from: opening Balance b/d (Cr.) ₹1,50,000; additional capital introduced in cash ₹30,000; net profit transferred ₹40,000; drawings ₹12,000.", a: "Credit side: By Balance b/d 1,50,000; By Cash A/c 30,000; By P&L A/c (Net Profit) 40,000 = ₹2,20,000. Debit side: To Drawings A/c 12,000. Balance c/d = 2,20,000 − 12,000 = ₹2,08,000, a Credit balance carried forward as the owner's closing stake in the business." },
        { q: "Rent A/c shows three monthly payments of ₹4,000 each (₹12,000 total, all on the debit side) and no other entries. At the end of the year it is closed by transfer to the Profit & Loss Account. What balance does Rent A/c show after this closing entry, and why?", a: "After the closing entry (crediting Rent A/c with ₹12,000 and debiting P&L A/c with the same amount), Rent A/c's debit and credit sides both total ₹12,000, leaving it with a Nil balance — this is the normal, correct outcome for a Nominal expense account once its cost has been fully absorbed into that year's profit calculation." },
        { q: "Post the compound entry 'Machinery A/c Dr. 90,000; To Bank A/c 30,000; To Kapoor & Sons A/c 60,000' to all three ledger accounts involved.", a: "Machinery A/c — debit side: 'To Bank A/c & Kapoor & Sons A/c ... 90,000' (one posting for the full amount). Bank A/c — credit side: 'By Machinery A/c ... 30,000'. Kapoor & Sons A/c — credit side: 'By Machinery A/c ... 60,000'. A one-debit, two-credit compound entry always results in exactly three postings." },
        { q: "Explain, using the rules of debit and credit, why an Asset account like Machinery A/c will almost always show a debit balance, while a Liability account like Bank Loan A/c will almost always show a credit balance.", a: "Under the rules for Real and Personal accounts, increases in assets are debited and decreases are credited, so an asset account like Machinery A/c accumulates far more on its debit side over time. Conversely, increases in liabilities are credited and decreases are debited, so a liability account like Bank Loan A/c accumulates far more on its credit side — giving each its typical, expected balance nature." },
        { q: "A Trial Balance fails to tally after posting. List three common ledger-posting errors that could cause this, and how each would typically be detected.", a: "(1) One-sided posting — only a debit or only a credit was posted, not both — detected by checking every Journal entry has exactly matching debit and credit postings. (2) Wrong amount posted — the figure posted differs from the Journal — detected by comparing each posted amount back to its Journal entry. (3) Posted to the wrong side — a debit posted as a credit or vice versa — detected by re-checking whether 'To' (debit side) or 'By' (credit side) was used correctly against the original entry." },
        { q: "Explain how the closing balance of a Debtor's personal account in the Ledger becomes part of the 'Sundry Debtors' figure on the Balance Sheet.", a: "Each individual debtor's account is balanced separately in the Ledger, giving a debit balance representing what that debtor still owes. When the final accounts are prepared, all such individual debit balances across every debtor's personal account are added together, and this combined total is shown as 'Sundry Debtors' under Current Assets on the Balance Sheet." },
        { q: "Why is it incorrect to post a Journal entry's debit line to the debit side of a different account than the one actually named? Give an example of the resulting error.", a: "Posting is meant to be a mechanical transfer, not a re-interpretation, of the Journal entry — every account named must receive its posting exactly. For example, if 'Furniture A/c Dr. 9,000; To Cash A/c 9,000' is mistakenly posted with the debit going to 'Fixtures A/c' instead of 'Furniture A/c', Furniture A/c's balance will be understated by ₹9,000 and an unrelated account will be wrongly inflated — this is called an 'error of commission' and, though the Trial Balance may still tally, the individual account balances (and hence the Balance Sheet) will be wrong." },
        { q: "What would a credit balance in a Debtor's personal account (instead of the usual debit balance) practically mean?", a: "A credit balance in a debtor's account means the business actually owes that debtor money — most often because the debtor has overpaid, or has returned goods after already having settled the account in full. It is the reverse of the account's normal expected nature and should be shown separately (sometimes even reclassified as a small creditor) rather than netted silently into Sundry Debtors." },
        { q: "If 'Rent A/c Dr. 6,000; To Cash A/c 6,000' were mistakenly posted to the credit side of Cash A/c twice instead of once, what would be the effect on Cash A/c's balance?", a: "Cash A/c would be credited ₹12,000 in total instead of the correct ₹6,000, understating its balance by an extra ₹6,000 — a clear illustration of why one Journal entry must always translate into exactly one debit posting and one credit posting (or their compound equivalents), never a repeated posting on the same side." },
        { q: "State two differences in how a Real account and a Nominal account are typically treated at the end of the accounting year.", a: "(1) A Real account (like Furniture A/c) is balanced and its closing balance is carried forward to the next year as an opening balance, eventually appearing on the Balance Sheet. A Nominal account (like Rent A/c) is closed off completely by transfer to the Trading or Profit & Loss Account, leaving no balance to carry forward. (2) A Real account's balance represents something the business still owns; a Nominal account's balance, once closed, has already fed into that year's profit or loss figure and has no ongoing existence." },
        { q: "Why must the amount posted to a ledger account exactly match the net amount in the Journal entry, even when a trade discount applied to the original transaction?", a: "Trade discount is deducted before the Journal entry is even made — it is never recorded as a separate account, only the net (discounted) invoice value is journalised. Since posting is a direct transfer of the Journal figures, the Ledger must show that same net amount; posting the gross (pre-discount) figure would overstate both the account and, eventually, the Trial Balance and financial statements." },
        { q: "Explain the role of the Ledger Folio (L.F.) column in cross-referencing between the Journal and Ledger, and why it matters during error-checking.", a: "The Journal's L.F. column records which Ledger page an entry was posted to, while the Ledger account's own J.F. column records which Journal page the posting came from. Together they create a two-way trail: given any Journal entry, you can instantly find where it was posted, and given any Ledger posting, you can trace it straight back to its original entry — invaluable when hunting down the source of a Trial Balance mismatch." },
        { q: "Why are 'Old Furniture A/c' and 'New Furniture A/c' opened as two separate ledger accounts for an exchange transaction, instead of using one shared 'Furniture A/c'? How is each eventually closed?", a: "Keeping them separate makes each asset's own history and disposal traceable — Old Furniture A/c can be closed out cleanly via a credit posting (showing the asset has left the business), while New Furniture A/c starts fresh with its own debit posting, without the two values getting tangled together in one account. In practice, Old Furniture A/c's balance is reduced to nil by this closing posting, while New Furniture A/c carries forward its debit balance as an asset, going forward under a single 'Furniture A/c' name in later years once the exchange is fully settled." }
      ]
    }
  },

  /* ============================================================
     CHAPTER 5 — SPECIAL PURPOSE BOOKS I: CASH BOOK
     Sourced entirely from the provided "Special Purpose Books I —
     Cash Book" chapter PDF. No outside definitions, rules, or
     examples have been added.
     ============================================================ */
  cashBook: {

    theory: {
      simple: [
        {
          h: "Meaning of Subsidiary Books of Accounting",
          p: "Business transactions are normally large in number, and it becomes difficult to record all of them in one book of primary entry, i.e., the Journal Book. So it is convenient to maintain a separate book for each type of transaction — one to record cash transactions, another to record credit purchase of goods, and yet another to record credit sale of goods. A book of this type is called a book of original entry or primary entry — it is a special form of Journal, a sub-division of it. Journal entry is not passed for transactions recorded in such books; they are directly posted in the ledger accounts.",
          p2: "These books of original or primary entry are also called Special Purpose Books or Special Journals or Subsidiary Books. Subsidiary Books or Special Purpose Books are books of accounts maintained to record transactions of a particular nature — such as Cash Book to record cash and bank transactions, Purchases Book to record credit purchases of goods, Sales Book to record credit sale of goods, Purchases Return Book to record return of goods purchased, and Sales Return Book to record return of goods sold."
        },
        {
          h: "Classification of Subsidiary Books (Sub-division of Journal)",
          p: "The Journal, for convenience, is divided into the following Subsidiary Books:",
          list: [
            { term: "1. Cash Book", def: "To record receipts and payments of cash, including receipts into and payments from the bank." },
            { term: "2. Purchases Book", def: "To record credit purchases of goods." },
            { term: "3. Sales Book", def: "To record the credit sales of goods." },
            { term: "4. Purchases Return Book", def: "To record the return of goods previously purchased on credit." },
            { term: "5. Sales Return Book", def: "To record the return of credit sales made by customers." },
            { term: "6. Journal Proper", def: "To record the transactions which cannot be recorded in any of the above books." }
          ]
        },
        {
          h: "Advantages of Subsidiary Books",
          list: [
            { term: "Division of Work", def: "Accounting work can be divided among a number of persons, since subsidiary books are maintained for each category of transactions." },
            { term: "Specialisation and Efficiency", def: "Same work is handled by a particular person for a considerable time, thus he acquires specialisation in it and becomes more efficient in handling it." },
            { term: "Saving of Time", def: "Various accounting processes can be undertaken simultaneously because of the use of a number of books, leading to completing the work timely." },
            { term: "Availability of Information", def: "Since a separate book is maintained for each type of transactions, information relating to each type is available at one place." },
            { term: "Facility in Checking", def: "In case the Trial Balance does not match, locating the error(s) is facilitated by the existence of separate books, since the number of transactions is less in each Subsidiary Book as compared to only one Journal." },
            { term: "Responsibility", def: "Division of work results in assigning a particular job to a particular person. If an error is committed in recording, responsibility can be easily fixed." }
          ]
        },
        {
          h: "Meaning and Features of Cash Book",
          p: "Cash Book is a book of primary entry in which cash and bank transactions are recorded in a chronological order, i.e., in the order they are entered into. Receipts are written in the debit of Cash Book while payments are written in the credit. In case of a two-column Cash Book, cash transactions are written in the cash column and bank transactions are written in the bank column. It is balanced by deducting total payments from total receipts to know the cash balance and balance at bank.",
          list: [
            { term: "Feature 1", def: "Only cash and bank transactions are recorded in the Cash Book." },
            { term: "Feature 2", def: "Cash receipts and cheques deposited are recorded in the debit while cash and cheque payments are recorded in the credit." },
            { term: "Feature 3", def: "It records only one aspect of the cash and bank transactions." },
            { term: "Feature 4", def: "Cash and bank transactions are recorded in the Cash Book in a chronological order, i.e., in the order the transactions/events are entered." },
            { term: "Feature 5", def: "It is both Journal and the Ledger at the same time." }
          ]
        },
        {
          h: "Cash Book — is it both a Subsidiary Book and a Principal Book?",
          p: "Cash and bank transactions are recorded in the Cash Book, and transactions other than those affecting cash and bank are transferred (posted) to Ledger Accounts. Therefore, Cash Book is a Subsidiary Book. Further, Cash Book by itself is Cash Account and Bank Account. The balances are placed in the Trial Balance directly. Cash Book, therefore, is a part of the Ledger also. Hence, it is also a Principal Book.",
          p2: "Cash Book is, thus, both a Subsidiary Book and a Principal Book."
        },
        {
          h: "Types of Cash Book",
          p: "There are two types of Cash Books: (1) Simple Cash Book or Single Column Cash Book — for recording cash transactions only, and (2) Two-column or Double Column Cash Book (Cash Book with cash and bank columns) — for recording cash and bank transactions. In addition to the main Cash Book, firms also maintain a Petty Cash Book."
        },
        {
          h: "(1) Simple Cash Book or Single Column Cash Book",
          p: "Simple Cash Book is similar to an account, with one column on each side. On the left-hand side, receipts of cash are written and on the right-hand side payments are written. In Simple Cash Book only Cash receipts and payments are recorded.",
          list: [
            { term: "Date", def: "Date of the transaction is written." },
            { term: "Particulars", def: "Name of the account under which cash is received or paid is written. In an existing business, Cash Book starts with the Opening Balance of cash written on the receipts side as 'To Balance b/d'. A new business will not have an opening balance." },
            { term: "Voucher No. (V. No.)", def: "The document supporting a transaction is called a Voucher. There are two types of cash vouchers: (1) Receipt Voucher, and (2) Payment Voucher. Generally, a Voucher has a serial number which is written in this column." },
            { term: "Ledger Folio (L.F.)", def: "In the column for 'L.F.', the page number of the Ledger where the amount is posted is written." },
            { term: "Amount (₹)", def: "The amounts received are written on the Debit side and amounts paid are written on the Credit side." }
          ],
          formula: "Cash Account is a Real Account (Traditional Classification) and an Asset Account (Modern Classification). Rule: \"Debit what comes in and Credit what goes out\" or \"Increases in assets are debited and decreases are credited.\""
        },
        {
          h: "Balancing of Single Column Cash Book",
          p: "Cash Book is balanced like an account. The total of the receipts column is higher than or equal to the total of the payments column. The difference is written in the credit as 'By Balance c/d'. The totals are then written in the two columns opposite to one another, and then in the debit, the balance is written as 'To Balance b/d' to show the cash balance in hand at the beginning of the next accounting period."
        },
        {
          h: "Simple Cash Book — Some Observations",
          list: [
            { term: "1", def: "When Cash Book is maintained, Cash Account is not opened in the Ledger." },
            { term: "2", def: "Cash Book is balanced like any other account." },
            { term: "3", def: "It does not record (a) non-cash transactions, (b) cheques received or given, and (c) cash discount allowed and received." },
            { term: "4", def: "When an entry is recorded in Simple Cash Book, a corresponding entry is recorded in the Ledger. For example, if Ashok pays ₹5,000, the receipt (or debit) entry is passed in the Cash Book and Ashok's Account is credited in the Ledger." },
            { term: "5", def: "Cash Book will not have a credit balance, i.e., Cash in Hand, because cash paid cannot exceed Cash in Hand." }
          ],
          p2: "Note: Discount Received, Discount Allowed, and Reversal of Discount Received or Discount Allowed (when there is dishonour of cheque) are recorded in Journal Proper — never in the Cash Book itself."
        },
        {
          h: "Posting of Payments (Credit Side)",
          p: "Payments are recorded in the credit (Payments Side) of the Cash Book and, to complete the process of dual aspect, they are posted to the debit side in the ledger accounts by writing 'To Cash A/c'. Note: the opening balance shown on the debit side of Simple Cash Book is not posted, and, in the same manner, the closing balance is also not posted — it is shown on the assets side of the Balance Sheet."
        },
        {
          h: "(2) Two-Column or Double Column Cash Book (Cash Book with Cash and Bank Columns)",
          p: "Two-Column Cash Book or Double Column Cash Book is a Cash Book which has two columns for amount on each side — one column to record cash transactions and the other column to record bank transactions. Cash received and cash paid are written in the Cash Column of the Cash Book. Deposit of cash or cheques in bank, withdrawal of cash from bank, and issue of cheques, etc., are written in the Bank Column of the Cash Book. Thus, a Two-Column Cash Book represents two accounts, i.e., Cash Account and Bank Account.",
          p2: "Bank Account is an Asset Account as per the Modern Approach (Personal Account as per the Traditional Approach), and while recording transactions in the bank column, the rule 'Increase in assets is debited and decrease credited' (or 'Debit the receiver and Credit the giver') is followed. Thus, for cash deposited in the bank, bank balance increases (bank is the receiver) and is debited in the bank column, while cash decreases and is credited in the Cash Column. Similarly, for cash withdrawn or a cheque issued, bank balance decreases and bank is credited in the bank column of the Cash Book."
        },
        {
          h: "Cash Discount — recorded in Journal Proper, not in the Cash Book",
          p: "Cash discount may be received when payment is made by cheque/cash, and similarly it may be allowed when payment is received. Cash Discount allowed or received is recorded by passing a Journal entry in Journal Proper as follows:",
          formula: "For Discount Allowed: Discount Allowed A/c ...Dr.  To Party's A/c\nFor Discount Received: Party's A/c ...Dr.  To Discount Received A/c",
          p2: "In case a cheque is dishonoured, discount allowed or received is also written back by passing a Journal entry in Journal Proper: for reversal of Discount Allowed — Party's A/c Dr., To Discount Allowed A/c; for reversal of Discount Received — Discount Received A/c Dr., To Party's A/c."
        },
        {
          h: "Balancing of Double Column Cash Book",
          p: "Cash columns are balanced in the same manner as in Simple Cash Book. The process is similar for balancing the bank column. Bank may allow the firm to withdraw more amount than deposited — this is known as Overdraft or Bank Overdraft. In such a case, the total of the bank column on the credit side will be higher than the total of the debit side. The difference is written in the debit as 'To Balance c/d'; the totals are then written on the two sides opposite one another, and the balance is then written in the credit by writing 'By Balance b/d'.",
          list: [
            { term: "Point 1", def: "Cash Column will either have a debit balance or a nil balance." },
            { term: "Point 2", def: "Bank Column may have either a debit balance (balance in Bank) or a credit balance (Overdraft)." },
            { term: "Point 3", def: "If Cash Book with Cash and Bank Columns is maintained, Cash Account and Bank Account are not opened in the Ledger." }
          ]
        }
      ],

      advanced: [
        {
          h: "Two-Column Cash Book — Some Observations",
          list: [
            { term: "(i) Opening capital", def: "When a new business is started, the proprietor introduces capital. Amount brought as capital may be in cash and/or by cheque. Amount brought in cash is written in the cash column (Receipts side / Debit) with explanation 'To Capital A/c'. Amount brought by cheque is written in the bank column (Receipts side / Debit) with explanation 'To Capital A/c'. If a new Cash Book is started for an existing business, the opening balance is written as 'To Balance b/d'." },
            { term: "(ii) Receipts", def: "Receipts are written in the debit, i.e., receipts side — cash in the cash column and cheques/drafts in the bank column. In the Particulars column, the name of the account under which the payment is received is written." },
            { term: "(iii) Payments", def: "Payments are written in the credit, i.e., payments side — cash payments in the cash column and payments by cheques or drafts in the bank column." },
            { term: "(iv) Contra Entries", def: "Contra Entries are the entries which affect both cash and bank, i.e., balance of one will decrease and the other will increase due to such transactions. Such transactions are recorded on both sides of the Cash Book, once in the cash column and once in the bank column, writing 'C' in the L.F. column. These entries are NOT posted in a Ledger Account." },
            { term: "(v) Dishonoured cheque deposited", def: "A cheque deposited in bank, if returned dishonoured, i.e., is not paid, reduces the balance in bank. The uncollected amount is written in the credit, i.e., payments side, of the Cash Book in the bank column with the name of the party who issued the cheque, in the Particulars column. In other words, when a cheque received from a customer and deposited in the bank is returned dishonoured, the Customer's Account is debited and the Bank Account is credited." },
            { term: "(vi) Cheque issued not paid on presentation", def: "If a cheque issued by the firm is not paid on presentation, it is recorded in the bank column in the debit, i.e., receipts side, of the Cash Book with the name of the party to whom the cheque was issued." },
            { term: "(vii) Cheque endorsed to another party", def: "A cheque received may be given to another party, i.e., endorsed to another party. The receipt and endorsement of the cheque is recorded through a Journal entry because the cheque is not deposited in the Bank Account." },
            { term: "(viii) Cheques deposited by customers", def: "Cheques or drafts deposited by customers directly into the bank are recorded in the bank column in the debit, i.e., receipts side, of the Cash Book." },
            { term: "(ix) Bank Charges", def: "If the firm pays charges for services to the bank, called Bank Charges, it is written in the payments or credit side of the Cash Book in the bank column." },
            { term: "(x) Cash Discount", def: "Cash Discount Allowed or Received is recorded by passing a Journal entry, not directly in the Cash Book." },
            { term: "(xi) Discount on dishonour", def: "Discount may be allowed when payment is received by cheque. If the cheque is dishonoured, Discount Allowed is written back by passing an entry in Journal Proper — but the entry for the amount of the cheque itself is recorded in the Cash Book. Similarly, cash discount may be received when payment is made by cheque; if that cheque is dishonoured, Discount Received is written back by passing an entry in Journal Proper, while the entry for the amount of the cheque is recorded in the Cash Book." }
          ]
        },
        {
          h: "Cheques-in-Hand Account",
          p: "When a cheque or a draft is deposited in the bank on the same day it is received, the amount is recorded in the bank column on the debit side. But if cheques and drafts received are not deposited in the bank on the same day, they are recorded in the books of account through a Journal entry: Cheques-in-Hand A/c ...Dr.  To Party's A/c. When the cheque/draft received is deposited, it is recorded in the Cash Book by writing in the bank column on the receipts side: To Cheques-in-Hand A/c. In this manner the balance in Cheques-in-Hand A/c becomes nil."
        },
        {
          h: "Post-Dated Cheque",
          p: "A post-dated cheque means a cheque issued or received of a future date. These cheques can be presented to the bank for payment on or after the specified date. A post-dated cheque may be discounted by a bank, which charges discounting charges for the remaining period of the cheque.",
          formula: "Discounting charges = Amount of cheque × Rate % p.a. × Remaining period / 12",
          p2: "Accounting of a post-dated cheque RECEIVED: it is accounted for by passing an entry in Journal Proper — Cheques-in-Hand A/c ...Dr.  To Party's A/c (Post-dated cheque received). On the date written on the cheque, it is deposited in the bank, and the entry for deposit is written in the debit of the Cash Book in the bank column: To Cheques-in-Hand A/c. If the cheque is discounted before its date, the entry is recorded in the Cash Book (bank column, debit side) at the net amount actually received, and a separate entry — Discounting Charges A/c ...Dr.  To Party's A/c — is passed in Journal Proper for the discounting charge."
        },
        {
          h: "Post-Dated Cheque Issued",
          p: "Post-dated cheques issued are written in the Bank Column of the Cash Book on the date it is issued, and NOT on the date of the cheque, since the transaction is entered on the date the cheque is issued. It is recorded in the credit (payments) side in the bank column with the name of the party to whom it was issued. It is shown in the Bank Reconciliation Statement as a cheque outstanding for payment."
        },
        {
          h: "Bank Overdraft",
          p: "Bank Overdraft means the amount withdrawn from bank in excess of the available balance in the account — the amount overdrawn is the bank overdraft. It is a liability, meaning that this amount is payable to the bank.",
          p2: "A credit bank balance (i.e., overdraft) at the beginning of a period is shown in the credit, i.e., payments side, of the Cash Book as 'By Balance b/d'. At the end of the period, the bank column is balanced, and if the debit total is less (i.e., overdraft), the bank column is balanced by writing 'To Balance c/d' in the bank column in the debit, i.e., receipts side, of the Cash Book. At the beginning of the next year, it is written in the credit, i.e., payments side, of the Cash Book as 'By Balance b/d'."
        },
        {
          h: "Petty Cash Book",
          p: "Petty Cash Book is the book which is used for recording expenses involving petty/small amounts. Petty Cash Book is a Cash Book in which receipts and payments of petty (small) amounts are recorded. Besides petty expenses, receipts from the main cashier are also recorded. Petty Cash Book is like Petty Cash Account and is maintained by the Petty Cashier."
        },
        {
          h: "Recording of Petty Cash",
          p: "Petty cash given to the Petty Cashier for small payments is recorded in the credit, i.e., Payments Side, of the Cash Book as 'By Petty Cash A/c' and is posted to the debit, i.e., Receipts Side, of the Petty Cash A/c in the Ledger."
        },
        {
          h: "Systems of Petty Cash",
          p: "Petty Cash Book may be maintained by the Simple (Ordinary) System or by the Imprest System.",
          list: [
            { term: "Simple System of Petty Cash", def: "A system of maintaining Petty Cash whereby the Petty Cashier is given an appropriate amount of cash, and after spending the amount, he submits the Petty Cash Account to the Head Cashier." },
            { term: "Imprest System of Petty Cash", def: "A system of maintaining Petty Cash whereby an estimate is made of the amount required for petty expenses for a period (say a week, a fortnight, or a month). This estimated amount, called the imprest money, is given to the Petty Cashier at the beginning of a period, and the amount of petty expenses paid by the Petty Cashier is reimbursed to him periodically, so he again has the specified amount at the start of the new period. This system of paying an advance at the beginning and reimbursing the amount spent from time to time is called the imprest system." }
          ]
        },
        {
          h: "Advantages of Imprest System of Petty Cash",
          list: [
            { term: "(i) Control over Mistakes", def: "The Petty Cash Book is checked by the Head Cashier at regular intervals, so that a mistake, if committed, is soon rectified." },
            { term: "(ii) Control over Petty Expenses", def: "Petty expenses are kept within the limits of the imprest, since the petty cashier cannot spend more than the available petty cash." },
            { term: "(iii) Control over Frauds", def: "Under this system, misuse of cash can be minimised since the Petty Cashier is not allowed to draw cash as and when he desires." }
          ]
        },
        {
          h: "Types of Petty Cash Books",
          p: "There are two types of Petty Cash Books: (1) Simple Petty Cash Book, and (2) Analytical Petty Cash Book.",
          list: [
            { term: "1. Simple Petty Cash Book", def: "A book in which the amount received and paid by the Petty Cashier is recorded in one column each for Receipts and Payments. It is identical with a Cash Book — cash the Petty Cashier receives is recorded on the left-hand (debit/receipts) column, and cash he pays is recorded on the right-hand (credit/payments) column. The date and particulars of every transaction are written in the same date and particulars column." },
            { term: "2. Analytical Petty Cash Book", def: "Has two sides — the left-hand side is used for recording receipts of cash, and the right-hand side is used for recording payments. In this Cash Book, a separate column is provided for recording a particular expense, i.e., courier, stationery, advertisement, etc. A column is normally provided for 'sundries' to record infrequent payments. When a petty expense is recorded on the right-hand total payments column, the same amount is also recorded in the appropriate expense column. At the end of a particular period, the analysis (expenses) columns are added and posted to the debit side of the respective accounts — this makes posting from Petty Cash Book easy." }
          ]
        },
        {
          h: "Difference between Simple and Analytical Petty Cash Book",
          list: [
            { term: "Separate record of expenses", def: "Simple Petty Cash Book: a separate record of each kind of petty expense is not maintained. Analytical Petty Cash Book: analysis columns are used for each commonly occurring item of expense, such as stationery, postage, and travelling." },
            { term: "Manner of writing", def: "Simple Petty Cash Book: written in the same manner as a Cash Book is written, and the pages are divided down the centre. Analytical Petty Cash Book: the pages are not divided down the centre; major space is provided for the expense side, having separate columns for expenses incurred regularly." },
            { term: "Determining totals under each head", def: "Simple Petty Cash Book: at the end of the period, total expenses under different heads cannot be determined easily. Analytical Petty Cash Book: at the end of the period, expenses under different heads can be determined easily." }
          ]
        },
        {
          h: "Balancing the Petty Cash Book",
          p: "Petty Cash Book is balanced at the end of the month or a specified period. The columns for payments and expenses are totalled, and the total equals the total in the 'Total Payments Column'. Thereafter, the Petty Cash Book is balanced. The method of balancing the Petty Cash Book is the same as that of a Simple Cash Book."
        },
        {
          h: "Posting the Petty Cash Book",
          p: "Entries in the Petty Cash Book are posted in the ledger accounts at the end of a specified period, i.e., month or quarter as the case may be. Petty Cash Book is considered a memorandum book. The petty expenses are not directly posted to ledger accounts. A Petty Cash Account is maintained in the ledger. When petty cash is advanced to the petty cashier, the Chief Cashier records it on the credit side of the Cash Book as 'By Petty Cash A/c'. At the end of the specified period, for the total expenses paid, a Journal entry is passed by debiting the individual petty expenses and crediting the Petty Cash Account. All the accounts relating to petty expenses are maintained in the ledger individually. Posting is made on the debit side of these accounts by writing 'To Petty Cash A/c' in the Particulars column.",
          formula: "(a) When amount is advanced to the Petty Cashier: Petty Cash A/c ...Dr.  To Cash A/c\n(b) On submission of Petty Cash Account by the Petty Cashier: Expenses A/c(s) ...Dr.  To Petty Cash A/c"
        },
        {
          h: "Advantages of Petty Cash Book",
          list: [
            { term: "1. Time Saving", def: "Saves the Chief Cashier's time." },
            { term: "2. Labour Saving", def: "Saving of labour in writing up the Cash Book and posting in the Ledger." },
            { term: "3. Control", def: "It provides better control over small payments." },
            { term: "4. Convenience in Ledger Posting", def: "The totals of expenses are only taken to post them in the Ledger — no unnecessary detail is to be given. Hence, it is convenient to post these balances directly in the Ledger." }
          ]
        }
      ]
    },

    concepts: [
      { title: "Subsidiary Books", body: "Books of accounts maintained to record transactions of a particular nature, so a large volume of transactions doesn't all pile into one Journal. The six Subsidiary Books are Cash Book, Purchases Book, Sales Book, Purchases Return Book, Sales Return Book, and Journal Proper." },
      { title: "Cash Book — Both Subsidiary and Principal Book", body: "It is a Subsidiary Book because cash and bank transactions are first recorded here. It is also a Principal Book because it IS the Cash Account and Bank Account — its balances go straight into the Trial Balance, with no separate ledger posting needed for cash/bank." },
      { title: "Contra Entries", body: "Entries affecting both cash and bank at once — one balance decreases while the other increases (e.g. cash deposited into bank, or cash withdrawn from bank for office use). Marked 'C' in the L.F. column on BOTH sides of the Cash Book, and never posted to a separate Ledger Account." },
      { title: "Cash Discount stays out of the Cash Book", body: "Discount Allowed, Discount Received, and their reversal on dishonour of a cheque are never entered directly in the Cash Book — they are always recorded through a Journal entry in Journal Proper." },
      { title: "Bank Overdraft", body: "The amount withdrawn from bank in excess of the available balance — a liability payable to the bank. It shows up as a credit balance in the bank column (opening 'By Balance b/d'; closing 'To Balance c/d' on the debit side if overdrawn)." },
      { title: "Imprest System", body: "The Petty Cashier is given a fixed estimated amount (the imprest money) at the start of a period, and is reimbursed exactly what he spent at the end of that period — so he always starts the next period with the same original imprest amount again." }
    ],

    /* Numerical practice bank for the "Practice Bank" tab. Each entry is a
       short transaction; the student identifies which side and column of
       the Cash Book it belongs on (or, for the trick questions, that it
       doesn't belong in the Cash Book at all). Answers must exactly match
       one of the six strings in CB_PRACTICE_OPTIONS in app.js. */
    numericals: [
      { id: 1, difficulty: "Easy", transaction: "Started business with cash ₹75,000.",
        answer: "Debit side — Cash column", posting: "To Capital A/c ₹75,000",
        hint: "Cash is coming into the business — that's a receipt.",
        explanation: "Cash brought in by the owner is a receipt, so it goes on the debit (receipts) side of the cash column." },
      { id: 2, difficulty: "Easy", transaction: "Purchased goods for cash ₹18,000.",
        answer: "Credit side — Cash column", posting: "By Purchases A/c ₹18,000",
        hint: "Cash is going out to pay for goods.",
        explanation: "Cash paid out is a payment, so it goes on the credit (payments) side of the cash column." },
      { id: 3, difficulty: "Easy", transaction: "Sold goods for cash ₹32,000.",
        answer: "Debit side — Cash column", posting: "To Sales A/c ₹32,000",
        hint: "Cash is coming in from the sale.",
        explanation: "Cash received from a sale is a receipt — debit side of the cash column." },
      { id: 4, difficulty: "Easy", transaction: "Paid salaries in cash ₹9,000.",
        answer: "Credit side — Cash column", posting: "By Salary A/c ₹9,000",
        hint: "Cash is leaving the business.",
        explanation: "A cash payment for salaries goes on the credit (payments) side of the cash column." },
      { id: 5, difficulty: "Easy", transaction: "Received commission in cash ₹1,200.",
        answer: "Debit side — Cash column", posting: "To Commission Received A/c ₹1,200",
        hint: "Cash is coming in.",
        explanation: "Any cash receipt, including commission received, is entered on the debit side of the cash column." },
      { id: 6, difficulty: "Easy", transaction: "Paid Rahul, a creditor, in cash ₹4,500.",
        answer: "Credit side — Cash column", posting: "By Rahul A/c ₹4,500",
        hint: "Cash is going out to settle what the firm owes him.",
        explanation: "A cash payment to a creditor is a payment — credit side of the cash column." },
      { id: 7, difficulty: "Easy", transaction: "Cash received from Anita, a debtor, ₹6,000.",
        answer: "Debit side — Cash column", posting: "To Anita A/c ₹6,000",
        hint: "Cash is coming in from someone who owed the business money.",
        explanation: "Collecting from a debtor is a cash receipt — debit side of the cash column." },
      { id: 8, difficulty: "Easy", transaction: "Paid the monthly electricity bill in cash ₹850.",
        answer: "Credit side — Cash column", posting: "By Electricity Expenses A/c ₹850",
        hint: "Cash is going out for an expense.",
        explanation: "A cash expense payment is entered on the credit (payments) side of the cash column." },
      { id: 9, difficulty: "Easy", transaction: "Paid rent by cheque ₹5,000.",
        answer: "Credit side — Bank column", posting: "By Rent A/c ₹5,000",
        hint: "This is a payment, and it's made through the bank, not in cash.",
        explanation: "A payment made by cheque affects the bank column, and being a payment, it goes on the credit side." },
      { id: 10, difficulty: "Easy", transaction: "Received a cheque from Meera and deposited it into the bank on the very same day, ₹15,000.",
        answer: "Debit side — Bank column", posting: "To Meera A/c ₹15,000",
        hint: "A cheque banked the same day it's received goes straight into the bank column.",
        explanation: "A cheque received and deposited on the same day is a receipt in the bank column — debit side." },
      { id: 11, difficulty: "Medium", transaction: "The bank debited the firm's account with ₹150 as bank charges for the month.",
        answer: "Credit side — Bank column", posting: "By Bank Charges A/c ₹150",
        hint: "The bank is taking money out of the firm's balance.",
        explanation: "Bank charges reduce the bank balance, so they're a payment in the bank column — credit side." },
      { id: 12, difficulty: "Easy", transaction: "Issued a cheque to Farhan for ₹8,200 in full settlement of his account.",
        answer: "Credit side — Bank column", posting: "By Farhan A/c ₹8,200",
        hint: "Issuing a cheque is a payment.",
        explanation: "Issuing a cheque to a creditor is a bank payment — credit side of the bank column." },
      { id: 13, difficulty: "Medium", transaction: "The bank allowed interest of ₹300 on the balance held in the account.",
        answer: "Debit side — Bank column", posting: "To Interest A/c ₹300",
        hint: "The bank is adding money to the firm's balance.",
        explanation: "Interest allowed by the bank increases the bank balance — a receipt, debit side of the bank column." },
      { id: 14, difficulty: "Medium", transaction: "Cash deposited into the bank, ₹20,000.",
        answer: "Contra entry — both sides (Cash & Bank)", posting: "Contra: Bank A/c debited, Cash A/c credited, ₹20,000",
        hint: "This transaction affects both the cash balance and the bank balance at once.",
        explanation: "Depositing cash into the bank decreases cash and increases the bank balance — a Contra Entry, marked 'C' on both sides and never posted to a separate ledger account." },
      { id: 15, difficulty: "Medium", transaction: "Cash withdrawn from the bank for office use, ₹10,000.",
        answer: "Contra entry — both sides (Cash & Bank)", posting: "Contra: Cash A/c debited, Bank A/c credited, ₹10,000",
        hint: "Money is simply moving between the firm's own cash box and its own bank account.",
        explanation: "Withdrawing cash from the bank for use in the office increases cash and decreases the bank balance — a Contra Entry." },
      { id: 16, difficulty: "Hard", transaction: "The proprietor withdrew ₹5,000 from the bank for his personal use.",
        answer: "Credit side — Bank column", posting: "By Drawings A/c ₹5,000",
        hint: "This looks like the contra examples above, but the money never enters the firm's cash box.",
        explanation: "This is NOT a Contra Entry, even though money leaves the bank — it goes straight to the proprietor as Drawings, never into the firm's own cash column. Only the bank column is credited." },
      { id: 17, difficulty: "Hard", transaction: "A cheque for ₹9,500 received from a debtor and deposited last week is now returned dishonoured by the bank.",
        answer: "Credit side — Bank column", posting: "By [Debtor] A/c ₹9,500",
        hint: "The bank balance that had gone up now has to come back down.",
        explanation: "A dishonoured cheque that had already been deposited reduces the bank balance again — recorded on the credit (payments) side of the bank column, with the debtor's name." },
      { id: 18, difficulty: "Hard", transaction: "A cheque for ₹6,000 issued to a supplier last week is now returned by the bank as 'not paid on presentation'.",
        answer: "Debit side — Bank column", posting: "To [Supplier] A/c ₹6,000",
        hint: "The payment never actually went through, so the bank balance effectively recovers.",
        explanation: "Since the cheque was never honoured, the amount the firm thought it had paid comes back — recorded on the debit (receipts) side of the bank column, with the supplier's name." },
      { id: 19, difficulty: "Hard", transaction: "A cheque of ₹10,000 received from Maira on 27th March (and held, not yet banked) is finally deposited into the bank on 31st March.",
        answer: "Debit side — Bank column", posting: "To Cheques-in-Hand A/c ₹10,000",
        hint: "Nothing was entered in the Cash Book back on 27th March — that receipt went through Cheques-in-Hand A/c in Journal Proper instead.",
        explanation: "Only on the actual date of deposit does the cheque enter the Cash Book's bank column, on the debit (receipts) side, as 'To Cheques-in-Hand A/c'." },
      { id: 20, difficulty: "Hard", transaction: "A cheque of ₹24,000 received on 1st May (dated 1st June) is discounted by the bank the very same day at 10% p.a., and the firm receives the net amount after discounting charges.",
        answer: "Debit side — Bank column", posting: "To [Party] A/c ₹23,800 (net, after ₹200 discounting charge)",
        hint: "Discounting the cheque early is like depositing it right away, but for a slightly smaller amount.",
        explanation: "The net amount actually received, ₹23,800, is entered on the debit (receipts) side of the bank column. The ₹200 discounting charge is recorded separately." },
      { id: 21, difficulty: "Hard", transaction: "For the cheque above, where is the ₹200 discounting charge itself recorded?",
        answer: "Not recorded in the Cash Book (Journal Proper)", posting: "Discounting Charges A/c Dr. 200; To [Party] A/c 200",
        hint: "Only the net cash actually received enters the Cash Book — the charge is a separate cost.",
        explanation: "The discounting charge is recorded through a Journal Proper entry (Discounting Charges A/c Dr., To [Party] A/c), not anywhere in the Cash Book." },
      { id: 22, difficulty: "Medium", transaction: "A cheque dated 31st July for ₹50,000 is issued to Harish on 10th June.",
        answer: "Credit side — Bank column", posting: "By Harish A/c ₹50,000 (entered on 10th June)",
        hint: "A post-dated cheque is entered on the date it's actually handed over, not the date printed on it.",
        explanation: "A post-dated cheque issued is recorded on the date it is actually issued (10th June), not the future date written on it — credit side of the bank column." },
      { id: 23, difficulty: "Medium", transaction: "A customer pays ₹9,500 in cash in full settlement of dues of ₹10,000, with ₹500 allowed as cash discount. Where is the ₹500 discount itself recorded?",
        answer: "Not recorded in the Cash Book (Journal Proper)", posting: "Discount Allowed A/c Dr. 500; To [Customer] A/c 500",
        hint: "A two-column Cash Book has no discount column at all.",
        explanation: "Cash Discount Allowed is never entered directly in the Cash Book — it always goes through a Journal Proper entry." },
      { id: 24, difficulty: "Easy", transaction: "A customer pays ₹9,500 in cash in full settlement of a larger amount due.",
        answer: "Debit side — Cash column", posting: "To [Customer] A/c ₹9,500",
        hint: "The actual cash received is a normal receipt.",
        explanation: "The ₹9,500 actually received in cash is a straightforward receipt — debit side of the cash column (the discount portion is handled separately, via Journal Proper)." },
      { id: 25, difficulty: "Medium", transaction: "The Main Cashier gives ₹6,000 in cash to the Petty Cashier to start the imprest.",
        answer: "Credit side — Cash column", posting: "By Petty Cash A/c ₹6,000",
        hint: "Cash is leaving the Main Cash Book to fund the Petty Cash Book.",
        explanation: "Handing imprest money to the Petty Cashier is a cash payment from the main Cash Book's point of view — credit side of the cash column." },
      { id: 26, difficulty: "Medium", transaction: "At the end of the week, the Main Cashier reimburses the Petty Cashier the exact ₹1,750 spent, restoring the imprest.",
        answer: "Credit side — Cash column", posting: "By Petty Cash A/c ₹1,750",
        hint: "This is another cash payment out of the main Cash Book.",
        explanation: "Reimbursing the Petty Cashier is again a cash payment from the Main Cash Book — credit side of the cash column." },
      { id: 27, difficulty: "Hard", transaction: "The bank charges ₹450 as interest on an overdrawn balance.",
        answer: "Credit side — Bank column", posting: "By Interest A/c ₹450",
        hint: "Interest on an overdraft is a cost the bank deducts from (or adds to) what the firm owes.",
        explanation: "Interest on an overdraft further increases what the firm owes the bank, so it is entered on the credit side of the bank column, alongside the overdraft itself." },
      { id: 28, difficulty: "Easy", transaction: "Received ₹2,500 in cash as a refund from a supplier for goods over-billed earlier.",
        answer: "Debit side — Cash column", posting: "To [Supplier] A/c ₹2,500",
        hint: "Cash is coming in.",
        explanation: "A cash refund received is a receipt — debit side of the cash column." },
      { id: 29, difficulty: "Medium", transaction: "Paid ₹1,100 in cash towards office stationery.",
        answer: "Credit side — Cash column", posting: "By Stationery A/c ₹1,100",
        hint: "Cash is going out for an expense.",
        explanation: "A cash payment for stationery is a payment — credit side of the cash column." },
      { id: 30, difficulty: "Medium", transaction: "A cheque of ₹18,000 received from a customer is deposited into the bank on the same day.",
        answer: "Debit side — Bank column", posting: "To [Customer] A/c ₹18,000",
        hint: "Same-day deposits go straight into the bank column.",
        explanation: "A cheque received and banked the same day is a receipt in the bank column — debit side." },
      { id: 31, difficulty: "Easy", transaction: "Received cash of ₹3,000 as an advance from a customer for goods to be delivered next month.",
        answer: "Debit side — Cash column", posting: "To [Customer] A/c (Advance) ₹3,000",
        hint: "Cash is coming in — the reason for the receipt doesn't change where it's recorded.",
        explanation: "Any cash received is a receipt, whatever it's for — debit side of the cash column." },
      { id: 32, difficulty: "Easy", transaction: "Paid ₹700 in cash for postage and stationery for the main office.",
        answer: "Credit side — Cash column", posting: "By Postage & Stationery A/c ₹700",
        hint: "Cash is going out for an expense.",
        explanation: "A cash expense payment is entered on the credit (payments) side of the cash column." },
      { id: 33, difficulty: "Medium", transaction: "The bank returns a cheque of ₹4,000, deposited last week, marked 'insufficient funds' in the drawer's account.",
        answer: "Credit side — Bank column", posting: "By [Party] A/c ₹4,000",
        hint: "A deposited cheque that bounces takes the bank balance back down.",
        explanation: "A dishonoured cheque that had already been deposited reduces the bank balance again — credit (payments) side of the bank column." },
      { id: 34, difficulty: "Medium", transaction: "Received ₹40,000 by cheque as a loan from a director, deposited into the bank on the same day.",
        answer: "Debit side — Bank column", posting: "To Director's Loan A/c ₹40,000",
        hint: "Money is coming in through the bank.",
        explanation: "A cheque received and banked the same day is a receipt — debit side of the bank column, whatever the source." },
      { id: 35, difficulty: "Hard", transaction: "The bank overdraft brought forward at the start of the year is ₹12,000. How is this opening balance entered on the first day of the new Cash Book?",
        answer: "Credit side — Bank column", posting: "By Balance b/d ₹12,000",
        hint: "An overdraft is a credit balance, so it's carried forward on the credit side — opposite of a normal cash balance.",
        explanation: "Since an overdraft is a credit balance, its opening balance is entered as 'By Balance b/d' on the credit side of the bank column." },
      { id: 36, difficulty: "Medium", transaction: "Paid ₹2,500 in cash as an advance on salary to an employee.",
        answer: "Credit side — Cash column", posting: "By Advance Salary A/c ₹2,500",
        hint: "Cash is going out.",
        explanation: "Any cash paid out, including an advance, is a payment — credit side of the cash column." },
      { id: 37, difficulty: "Medium", transaction: "A cheque for ₹15,000 is received and deposited into the bank; the firm also allows the customer ₹300 cash discount for early payment. Where is the ₹300 discount itself recorded?",
        answer: "Not recorded in the Cash Book (Journal Proper)", posting: "Discount Allowed A/c Dr. 300; To [Customer] A/c 300",
        hint: "The Cash Book has no discount column.",
        explanation: "Cash Discount Allowed never appears directly in the Cash Book — it's recorded via a Journal Proper entry." },
      { id: 38, difficulty: "Easy", transaction: "For the transaction above, where does the ₹15,000 net cheque itself go?",
        answer: "Debit side — Bank column", posting: "To [Customer] A/c ₹15,000",
        hint: "The actual money banked is a normal receipt.",
        explanation: "The ₹15,000 actually received and banked is a straightforward receipt — debit side of the bank column." },
      { id: 39, difficulty: "Hard", transaction: "Cash is withdrawn from the bank for office use, ₹8,000, which is then handed to the Petty Cashier to replenish the imprest.",
        answer: "Contra entry — both sides (Cash & Bank)", posting: "Contra: Cash A/c debited, Bank A/c credited, ₹8,000",
        hint: "The withdrawal itself is what matters here — what the office does with the cash afterwards is a separate step.",
        explanation: "Withdrawing cash from the bank for office use is a Contra Entry regardless of what the cash is used for afterward — handing it to the Petty Cashier would be recorded as a further, separate cash payment." },
      { id: 40, difficulty: "Easy", transaction: "Sold old newspapers and scrap material for cash, ₹350.",
        answer: "Debit side — Cash column", posting: "To Sale of Scrap A/c ₹350",
        hint: "Cash is coming in.",
        explanation: "Any cash received, even from selling scrap, is a receipt — debit side of the cash column." },
      { id: 41, difficulty: "Medium", transaction: "Paid ₹12,000 by cheque as an advance to a supplier for goods to be delivered next month.",
        answer: "Credit side — Bank column", posting: "By [Supplier] A/c (Advance) ₹12,000",
        hint: "Money is going out through the bank.",
        explanation: "A payment made by cheque, for any reason, is a bank payment — credit side of the bank column." },
      { id: 42, difficulty: "Hard", transaction: "A post-dated cheque of ₹7,500 received from a customer on 5th March is kept in hand; it is finally deposited into the bank on 2nd April, the date written on it.",
        answer: "Debit side — Bank column", posting: "To Cheques-in-Hand A/c ₹7,500",
        hint: "The deposit only happens — and only gets entered — on 2nd April.",
        explanation: "The cheque enters the Cash Book only on the actual date of deposit (2nd April) — debit (receipts) side of the bank column, as 'To Cheques-in-Hand A/c'." },
      { id: 43, difficulty: "Medium", transaction: "On 5th March, before the post-dated cheque above is deposited, is anything entered in the Cash Book for its receipt?",
        answer: "Not recorded in the Cash Book (Journal Proper)", posting: "Cheques-in-Hand A/c Dr.; To [Customer] A/c",
        hint: "The cheque can't be banked yet, so nothing changes in the Cash Book yet either.",
        explanation: "Holding a post-dated cheque is recorded via a Journal Proper entry (Cheques-in-Hand A/c) — nothing enters the Cash Book until it's actually deposited." },
      { id: 44, difficulty: "Medium", transaction: "The bank statement shows the bank credited the firm's account with ₹600 as interest earned for the quarter.",
        answer: "Debit side — Bank column", posting: "To Interest A/c ₹600",
        hint: "The bank is adding to the firm's balance.",
        explanation: "Interest credited by the bank increases the bank balance — a receipt, debit side of the bank column." },
      { id: 45, difficulty: "Hard", transaction: "A bearer cheque for ₹5,000 received from a customer is, instead of being deposited, endorsed over directly to pay a supplier the same day — it never passes through the firm's own bank account.",
        answer: "Not recorded in the Cash Book (Journal Proper)", posting: "[Customer] A/c Dr. 5,000; To [Supplier] A/c 5,000",
        hint: "If the cheque never actually touches the firm's own bank account, the bank column can't record it.",
        explanation: "A cheque endorsed straight over to a third party — without ever being banked by the firm — never enters the Cash Book at all; it's recorded via a Journal Proper entry instead." }
    ],

    quickRevision: {
      definition: "Cash Book is a book in which receipts and payments in Cash and through Bank are recorded, in chronological order. Receipts go on the debit side, payments go on the credit side. It is both a book of original entry (Subsidiary Book) AND the Ledger's own Cash/Bank Account (Principal Book).",
      keyPoints: [
        "Simple Cash Book (one amount column each side) records ONLY cash transactions — no cheques, no discount.",
        "Two-Column/Double Column Cash Book has a Cash column AND a Bank column on each side — represents Cash A/c + Bank A/c together.",
        "Contra entries (cash ↔ bank) are marked 'C' in the L.F. column and are never posted to a separate ledger account.",
        "Cash Discount Allowed/Received (and its reversal on dishonour) is ALWAYS recorded via a Journal entry in Journal Proper — never directly in the Cash Book.",
        "A post-dated cheque received/issued is not entered on the date printed on it, but on the date it is actually deposited/issued (and via Cheques-in-Hand A/c until then, for a cheque received but not yet banked).",
        "Bank Overdraft is a credit balance in the bank column — a liability owed to the bank.",
        "Petty Cash Book records small/petty payments, kept by the Petty Cashier, most commonly under the Imprest System (fixed amount given, exact amount spent reimbursed each period)."
      ],
      balancingSteps: [
        "Total both sides of the cash column (and, separately, both sides of the bank column).",
        "Write the difference as 'Balance c/d' on the smaller side — credit side for cash (always debit-or-nil balance); either side for bank, depending on whether it's a balance in hand or an overdraft.",
        "Rule off both sides at the equal, larger total.",
        "Bring the difference down to the opposite side as 'Balance b/d', dated at the start of the next period."
      ],
      commonMistakes: [
        "Posting a contra entry to a separate Ledger account — it should never be posted at all; it's marked 'C' and stops there.",
        "Recording Discount Allowed/Received inside the Cash Book itself instead of via a Journal Proper entry.",
        "Entering a post-dated cheque on the date written on the cheque instead of the date it is actually deposited (received) or issued.",
        "Forgetting that a cheque received but not deposited the same day must first go through Cheques-in-Hand A/c, not straight into the bank column.",
        "Treating 'cash withdrawn from bank for personal use' as a contra entry — it is NOT a contra entry; it is Drawings A/c Dr. to Bank A/c, a normal two-sided entry outside the Cash Book's contra mechanism.",
        "Posting the opening or closing balance of the Cash Book to a Ledger account — neither is ever posted; the closing balance goes straight to the Balance Sheet."
      ],
      mnemonic: "Cash Book = Cash A/c + Bank A/c, all in one book — receipts Debit (left), payments Credit (right), and discount NEVER lives inside it."
    },

    illustrations: [
      {
        title: "Simple Cash Book — Vikas starts a business (1st April 2026)",
        given: "Vikas starts a business on 1st April, 2026 and invests ₹50,000 in cash as capital.",
        working: "Cash received by the firm is recorded on the Receipts side (Debit) of the Cash Book.",
        table: {
          headers: ["Dr. — Date", "Particulars", "₹", "Cr. — Date", "Particulars", "₹"],
          rows: [
            ["2026 Apr 1", "To Capital A/c", "50,000", "2026 Apr 1", "By Balance c/d", "50,000"],
            ["Apr 2", "To Balance b/d", "50,000", "", "", ""]
          ]
        }
      },
      {
        title: "Simple Cash Book — Goods purchased in cash (2nd April 2026)",
        given: "Goods are purchased in cash on 2nd April, 2026 for ₹20,000 (continuing from the illustration above).",
        working: "Cash paid by the firm is recorded on the Payments side (Credit) of the Cash Book.",
        table: {
          headers: ["Dr. — Date", "Particulars", "₹", "Cr. — Date", "Particulars", "₹"],
          rows: [
            ["2026 Apr 2", "To Balance b/d", "50,000", "2026 Apr 2", "By Purchases A/c", "20,000"],
            ["", "", "", "Apr 2", "By Balance c/d", "30,000"],
            ["Apr 3", "To Balance b/d", "30,000", "", "", ""]
          ]
        }
      },
      {
        title: "Simple Cash Book — Goods sold for cash (3rd April 2026)",
        given: "Goods are sold for cash for ₹30,000 on 3rd April, 2026 (continuing from the illustration above).",
        working: "Cash received by the firm is recorded on the Receipts side (Debit) of the Cash Book.",
        table: {
          headers: ["Dr. — Date", "Particulars", "₹", "Cr. — Date", "Particulars", "₹"],
          rows: [
            ["2026 Apr 3", "To Balance b/d", "30,000", "2026 Apr 3", "By Balance c/d", "60,000"],
            ["Apr 3", "To Sales A/c", "30,000", "", "", ""],
            ["Apr 4", "To Balance b/d", "60,000", "", "", ""]
          ]
        }
      },
      {
        title: "Simple Cash Book with posting — In the Books of Amrit",
        given: "Cash Book of Amrit: Mar 1 Balance b/d ₹15,000; Mar 8 Purchases A/c ₹3,200 (payment); Mar 20 Commission Received A/c ₹650 (receipt); Mar 28 Commission Paid A/c ₹550 (payment); Mar 28 Samuel ₹7,150 (payment); Mar 31 Salary A/c ₹1,000 (payment); Mar 31 Electricity Expenses A/c ₹600 (payment).",
        working: "Debit (Receipts) side total = 15,000 + 650 = ₹15,650. Credit (Payments) side total before balancing = 3,200 + 550 + 7,150 + 1,000 + 600 = ₹12,500. Balance c/d = 15,650 − 12,500 = ₹3,150, brought down as Balance b/d on 1st April.",
        table: {
          headers: ["Dr. — Date", "Particulars", "₹", "Cr. — Date", "Particulars", "₹"],
          rows: [
            ["Mar 1", "To Balance b/d", "15,000", "Mar 8", "By Purchases A/c", "3,200"],
            ["Mar 20", "To Commission Received A/c", "650", "Mar 28", "By Commission Paid A/c", "550"],
            ["", "", "", "Mar 28", "By Samuel", "7,150"],
            ["", "", "", "Mar 31", "By Salary A/c", "1,000"],
            ["", "", "", "Mar 31", "By Electricity Expenses A/c", "600"],
            ["", "", "", "Mar 31", "By Balance c/d", "3,150"],
            ["", "Total", "15,650", "", "Total", "15,650"],
            ["Apr 1", "To Balance b/d", "3,150", "", "", ""]
          ]
        },
        note: "Every payment posted from the credit side is posted to the DEBIT of its own ledger account, e.g. Electricity Expenses Account: 'To Cash A/c ₹9,000' for a payment of ₹9,000 (a separate illustration in the PDF, shown to demonstrate the posting mechanism). Each of Purchases A/c, Commission Paid A/c, Samuel's A/c, Salary A/c, and Electricity Expenses A/c is debited with its own figure ('To Cash A/c'), and Commission Received A/c is credited ('By Cash A/c ₹650'). Opening and closing balances of the Cash Book are never posted."
      },
      {
        title: "Cheques-in-Hand A/c — cheque not deposited same day",
        given: "On 27th March, 2026, a cheque of ₹10,000 is received by Shlok from Maira. The cheque is deposited in the bank on 31st March, 2026.",
        working: "Journal entry passed by Shlok on 27th March: Cheques-in-Hand A/c Dr. ₹10,000; To Maira ₹10,000. On deposit (31st March), the Cash Book (bank column, receipts side) records: To Cheques-in-Hand A/c — Bank ₹10,000.",
        table: {
          headers: ["Dr. — Date", "Particulars", "Cash ₹", "Bank ₹", "Cr. — Date", "Particulars"],
          rows: [
            ["2026 Mar 31", "To Cheques-in-Hand A/c", "…", "10,000", "", ""]
          ]
        }
      },
      {
        title: "Post-dated cheque received and discounted",
        given: "A cheque of ₹24,000 received on 1st May, 2026, dated 1st June, 2026, is discounted by the bank at 10% p.a. for the remaining period.",
        working: "Discounting charges = 24,000 × 10/100 × 1/12 = ₹200. Cash Book (bank column, receipts side): To Amit ₹23,800 (net amount received on discounting). Journal Proper entry: Discounting Charges A/c Dr. ₹200; To Amit ₹200.",
        table: {
          headers: ["Dr. — Date", "Particulars", "Cash ₹", "Bank ₹", "", ""],
          rows: [
            ["2026 May 1", "To Amit", "…", "23,800", "", ""]
          ]
        }
      },
      {
        title: "Post-dated cheque issued",
        given: "A cheque dated 31st July, 2026 for ₹50,000 is issued to Harish on 10th June, 2026.",
        working: "Recorded in the bank column of the Payments (credit) side of the Cash Book on 10th June (the date issued, not the date on the cheque). Shown in the Bank Reconciliation Statement as on 30th June as a cheque outstanding for payment.",
        table: {
          headers: ["", "", "", "Cr. — Date", "Particulars", "Bank ₹"],
          rows: [
            ["", "", "", "2026 Jun 10", "By Harish", "50,000"]
          ]
        }
      },
      {
        title: "Contra Entries — cash deposited and cash withdrawn",
        given: "(a) Cash deposited in Bank ₹20,000. (b) Cash withdrawn from Bank for Office Use ₹10,000.",
        working: "(a) Bank A/c is debited (asset increases) and Cash A/c is credited (asset decreases) — recorded once on each side of the Cash Book, marked 'C' in the L.F. column. (b) Cash A/c is debited and Bank A/c is credited — again marked 'C' on both sides. Contra entries are NOT posted to any separate Ledger Account.",
        table: {
          headers: ["Dr.", "Particulars", "L.F.", "Cash ₹", "Bank ₹", "Cr. side"],
          rows: [
            ["(a)", "To Cash A/c", "C", "…", "20,000", "By Bank A/c … C … 20,000 (Cash column)"],
            ["(b)", "To Bank A/c", "C", "10,000", "…", "By Cash A/c … C … 10,000 (Bank column)"]
          ]
        }
      },
      {
        title: "Bank Overdraft — opening and closing overdraft (imaginary amounts)",
        given: "A double-column Cash Book with: Jan 1 Balance b/d — Cash ₹12,400, Bank ₹14,000 Overdraft (Cr.); Jan 3 contra — cash ₹5,000 deposited into bank; Jan 10 Purchases A/c (bank) ₹10,000; Jan 31 Bank Charges A/c ₹650.",
        working: "Bank column: opening 'By Balance b/d 14,000' (credit, overdraft). Debit side total = 5,000; Credit side total = 14,000 + 10,000 + 650 = 24,650. Since credit is larger, 'To Balance c/d 19,650' is written on the debit side, both sides then total ₹24,650. This is brought down as 'By Balance b/d 19,650' on 1st Feb — still an overdraft.",
        table: {
          headers: ["Dr. — Date", "Particulars", "Cash ₹", "Bank ₹", "Cr. — Date", "Particulars / Cash ₹ / Bank ₹"],
          rows: [
            ["Jan 1", "To Balance b/d", "12,400", "…", "Jan 1", "By Balance b/d … / 14,000"],
            ["Jan 3", "To Cash A/c (C)", "…", "5,000", "Jan 3", "By Bank A/c (C) … 5,000 / …"],
            ["Jan 31", "To Balance c/d", "…", "19,650", "Jan 10", "By Purchases A/c … / 10,000"],
            ["", "", "", "", "Jan 31", "By Bank Charges A/c … / 650"],
            ["", "Total", "12,400", "24,650", "", "Total … 12,400 / 24,650"],
            ["Feb 1", "To Balance b/d", "7,400", "…", "Feb 1", "By Balance b/d … / 19,650"]
          ]
        }
      },
      {
        title: "Simple Petty Cash Book — Illustration 10 (Imprest ₹5,000, April 2026)",
        given: "April 1 Drew for Petty Cash ₹5,000; Apr 3 Paid for courier ₹300; Apr 5 Paid telephone bill ₹400; Apr 8 Paid for cartage ₹140; Apr 9 Paid for courier ₹200; Apr 12 Paid for sundries ₹100; Apr 27 Paid for stationery ₹300.",
        working: "Total payments = 300 + 400 + 140 + 200 + 100 + 300 = ₹1,440... wait — total per the book's own solution: Amount Received 5,000; total payments recorded 300+400+140+200+100+300 = 1,440, Balance c/d = 5,000 − 1,440 = 3,560. On 1st May, Balance b/d ₹3,560, and the Petty Cashier draws ₹1,440 more from the bank (To Bank A/c) to restore the imprest amount back up to ₹5,000.",
        table: {
          headers: ["Amount Received ₹", "Date", "Particulars", "Voucher No.", "Amount Paid ₹"],
          rows: [
            ["5,000", "2026 Apr 1", "To Bank A/c", "", ""],
            ["", "Apr 3", "By Courier Expenses A/c", "", "300"],
            ["", "Apr 5", "By Telephone Expenses A/c", "", "400"],
            ["", "Apr 8", "By Cartage A/c", "", "140"],
            ["", "Apr 9", "By Courier Expenses A/c", "", "200"],
            ["", "Apr 12", "By Sundry Expenses A/c", "", "100"],
            ["", "Apr 27", "By Stationery A/c", "", "300"],
            ["", "Apr 30", "By Balance c/d", "", "3,560"],
            ["5,000", "", "Total", "", "5,000"],
            ["3,560", "May 1", "To Balance b/d", "", ""],
            ["1,440", "May 1", "To Bank A/c", "", ""]
          ]
        }
      },
      {
        title: "Analytical Petty Cash Book with posting — Illustration 11 (Imprest ₹10,000, January 2026)",
        given: "Jan 1 Received cash for Petty Expenses ₹10,000; Jan 2 Paid Metro fare ₹50; Jan 2 Paid cartage ₹250; Jan 3 Paid for courier ₹500; Jan 3 Paid wages for casual labourers ₹600; Jan 4 Paid for stationery ₹400; plus further payments bringing total analysis-column totals for the week to: Conveyance ₹650, Cartage ₹950, Stationery ₹400, Courier ₹1,200, Repairs ₹1,500, Telephone Expenses ₹200, Wages ₹600.",
        working: "Total expenses for the week ended 6th January = 650 + 950 + 400 + 1,200 + 1,500 + 200 + 600 = ₹5,500. Balance c/d = 10,000 − 5,500 = ₹4,500, brought down on 7th January as Balance b/d, and a further ₹5,500 is drawn from the Chief Cashier (To Cash A/c) to restore the imprest to ₹10,000.",
        journalEntry: "Analysis of the Petty Cash Book for the week ended 6th January: Conveyance A/c Dr. 650; Cartage A/c Dr. 950; Stationery A/c Dr. 400; Courier A/c Dr. 1,200; Repairs A/c Dr. 1,500; Telephone Expenses A/c Dr. 200; Wages A/c Dr. 600; To Petty Cash A/c 5,500.",
        table: {
          headers: ["Dr. — Petty Cash A/c", "Particulars", "₹", "Cr.", "Particulars", "₹"],
          rows: [
            ["Jan 1", "To Cash A/c", "10,000", "Jan 6", "By Conveyance A/c", "650"],
            ["", "", "", "Jan 6", "By Cartage A/c", "950"],
            ["", "", "", "Jan 6", "By Stationery A/c", "400"],
            ["", "", "", "Jan 6", "By Courier A/c", "1,200"],
            ["", "", "", "Jan 6", "By Repairs A/c", "1,500"],
            ["", "", "", "Jan 6", "By Telephone Expenses A/c", "200"],
            ["", "", "", "Jan 6", "By Wages A/c", "600"],
            ["", "", "", "Jan 6", "By Balance c/d", "4,500"],
            ["", "Total", "10,000", "", "Total", "10,000"],
            ["Jan 7", "To Balance b/d", "4,500", "", "", ""],
            ["Jan 7", "To Cash A/c", "5,500", "", "", ""]
          ]
        },
        note: "Each expense account (e.g. Conveyance Account) is posted separately on its own debit side as 'To Petty Cash A/c' with its own figure — Conveyance A/c 650, Cartage A/c 950, Stationery A/c 400, Courier A/c 1,200, Repairs A/c 1,500, Telephone Expenses A/c 200, Wages A/c 600 — one Ledger account per expense head."
      }
    ]
  },

  /* ============================================================
     SPECIAL PURPOSE BOOKS 2 — OTHER BOOKS (Chapter 6)
     Purchases Book, Sales Book, Purchases Return Book, Sales
     Return Book, and Journal Proper — the remaining Subsidiary
     Books beyond the Cash Book covered in Chapter 5.
     ============================================================ */
  specialBooks2: {

    theory: {
      simple: [
        {
          h: "Recap: Goods, Stock, Purchases & Sales",
          p: "Goods are the items a business trades in or uses to manufacture the products it sells — for a garments trader, garments are goods; office furniture bought for its own use is not. Stock (or Inventory) is the balance of goods held at the beginning or end of a period — opening stock or closing stock — and for a manufacturer this includes Raw Materials, Work-in-Progress (partly finished goods), and Finished Goods.",
          p2: "'Purchases' covers both cash and credit purchases of goods for resale or for manufacturing. 'Sales' covers both cash and credit sale of goods and services rendered by the business."
        },
        {
          h: "Sub-Division of Journal (Recap)",
          p: "As transactions grow in number, the Journal is sub-divided into six Books of Original Entry, also called Subsidiary Books, Special Purpose Books, or Special Journals:",
          list: [
            { term: "1. Cash Book", def: "Covered in Chapter 5 — records all cash and bank receipts and payments." },
            { term: "2. Purchases Book", def: "Records credit purchases of goods." },
            { term: "3. Sales Book", def: "Records credit sales of goods." },
            { term: "4. Purchases Return Book", def: "Records return of goods purchased on credit (Returns Outward Book)." },
            { term: "5. Sales Return Book", def: "Records return of goods sold on credit (Returns Inward Book)." },
            { term: "6. Journal Proper", def: "Records everything that cannot be recorded in any of the five books above." }
          ],
          p2: "This chapter covers the five books other than the Cash Book — hence \"Special Purpose Books II — Other Books\"."
        },
        {
          h: "Purchases Book or Purchases Journal — Meaning",
          p: "Purchases Book is a subsidiary book in which credit purchases of goods — i.e., goods the firm trades in or uses for manufacturing — are recorded. Cash purchases of goods, and purchases of items other than goods (such as fixed assets), are never recorded in the Purchases Book. Entries are made on the basis of Invoices received from suppliers, with the amount net of trade discount — i.e., List Price (or Catalogue Price) less Trade Discount, if any.",
          formula: "Purchases Book or Purchases Journal is a book to record credit purchases of goods or raw material used for manufacturing goods."
        },
        {
          h: "Features of Purchases Book",
          list: [
            { term: "Only credit purchases of goods", def: "Credit purchases of goods dealt in, or material used for manufacturing, are recorded. Credit purchases of non-goods — fixed assets like furniture or computers for office use — are recorded in Journal Proper instead." },
            { term: "Cash purchases excluded", def: "Cash purchases of goods, whatever the amount, are recorded in the Cash Book, never in the Purchases Book." },
            { term: "Based on invoices, net of trade discount", def: "Entries are recorded on the basis of invoices received, with the amount net of trade discount — i.e., after deducting Trade Discount from the List Price." }
          ]
        },
        {
          h: "Utilities of Purchases Book",
          list: [
            { term: "Less journalising work", def: "Reduces the volume of work required to pass a separate Journal entry for every credit purchase." },
            { term: "Easier ledger posting", def: "Since all credit purchases sit in one book, posting to the ledger becomes easier." },
            { term: "Periodic totals available", def: "A periodic (weekly/fortnightly/monthly) total of credit purchases of goods is readily available." },
            { term: "Easier price checking", def: "Makes it easier to check the price charged and other calculations against what was agreed." }
          ]
        },
        {
          h: "Sales Book or Sales Journal — Meaning",
          p: "Sales Book is a Subsidiary Book or Special Journal in which credit sales of goods dealt or traded in are recorded. Cash sales of goods are recorded in the Cash Book, and credit sales of items other than goods (e.g. sale of an old asset) are recorded in Journal Proper. Entries are based on invoices issued to customers, with the net amount after allowing trade discount.",
          formula: "Sales Book or Sales Journal is a book to record credit sales of goods."
        },
        {
          h: "Features & Utilities of Sales Book",
          list: [
            { term: "Only credit sales of goods dealt in", def: "Credit sales of items other than goods traded in (e.g. sale of assets) are not recorded here — they go to Journal Proper." },
            { term: "Cash sales excluded", def: "Cash sales are recorded in the Cash Book since they are not credit transactions." },
            { term: "Based on invoices issued", def: "Entries are recorded on the basis of invoices issued to the customer." },
            { term: "Utilities", def: "Reduces journalising work, makes posting easier (single book for all credit sales), allows checking whether prices charged match the catalogue, and gives a ready periodic total of credit sales of goods." }
          ]
        },
        {
          h: "Purchases Return Book or Returns Outward Book — Meaning",
          p: "Purchases Return Book or Returns Outward Book is a subsidiary book maintained to record goods or materials returned to sellers that were purchased on credit. Neither the return of goods purchased for cash, nor the return of any asset, is recorded in this book. Goods may be returned because they are not as per sample, are defective, are not as per order, or were delivered late and the customer refused to accept them. In every such case, the purchaser prepares a Debit Note and sends it to the supplier, and the entry in the Purchases Return Book is made on the basis of this Debit Note.",
          formula: "Purchases Return Book or Returns Outward Book is a book to record return of goods purchased on credit.\n\nDebit Note: a document notifying the supplier that a debit has been made to their account, stating the reason."
        },
        {
          h: "Sales Return Book or Returns Inward Book — Meaning",
          p: "Sales Return Book or Returns Inward Book is a subsidiary book maintained to record goods or materials returned by the purchaser that had been sold on credit — usually maintained only when returns are frequent, otherwise recorded directly in the Journal. A Credit Note is prepared when goods are returned by the purchaser, and the entry in the Sales Return Book is made on its basis.",
          formula: "Sales Return Book or Returns Inward Book is a book to record returns of goods sold on credit.\n\nCredit Note: a document evidencing that a credit entry has been recorded to the account of the debtor."
        },
        {
          h: "Difference between Debit Note and Credit Note",
          list: [
            { term: "Prepared by", def: "A Debit Note is prepared by the customer (purchaser); a Credit Note is prepared by the seller of goods." },
            { term: "Purpose", def: "A Debit Note intimates a debit made to the seller's account (with the reasons); a Credit Note intimates a credit made to the customer's account (with the reasons)." },
            { term: "Basis for recording", def: "A Debit Note is the basis for an entry in the Purchases Return Book; a Credit Note is the basis for an entry in the Sales Return Book." }
          ]
        },
        {
          h: "Journal Proper or General Journal — Meaning",
          p: "Journal Proper (or General Journal) is used to record transactions that cannot be recorded in any of the other subsidiary books — Cash Book, Purchases Book, Sales Book, Purchases Return Book, or Sales Return Book. Its role is usually restricted to the following types of entries:",
          list: [
            { term: "1. Opening Entry", def: "Recorded at the beginning of a financial year to open the books, by debiting assets and crediting liabilities and capital appearing in the previous year's Balance Sheet." },
            { term: "2. Closing Entries", def: "Passed at year end to close accounts relating to expenses and revenues (Nominal Accounts) by transferring them to the Trading Account and Profit & Loss Account." },
            { term: "3. Rectification Entries", def: "Entries to rectify errors made in the books of original entry or in the Ledger." },
            { term: "4. Transfer Entries", def: "Used whenever an amount needs to be transferred from one account to another." },
            { term: "5. Adjustment Entries", def: "For outstanding expenses, prepaid expenses, accrued income, income received in advance, interest on capital, and depreciation." },
            { term: "6. Miscellaneous Entries", def: "Credit purchase of goods other than goods dealt in (e.g. furniture, machinery); Discount Allowed/Received reversed on dishonour; allowances given to customers after the invoice; amounts becoming irrecoverable (bad debts); loss of property by fire/theft; and capital brought in kind by the proprietor." }
          ]
        }
      ],

      advanced: [
        {
          h: "Ruling of Purchases Book — Column by Column",
          list: [
            { term: "Date", def: "Date of the transaction." },
            { term: "Particulars", def: "Name of the seller, description of the goods, price per unit, and quantity purchased." },
            { term: "Invoice No.", def: "Invoice number of the goods purchased." },
            { term: "L.F. (Ledger Folio)", def: "Page number of the ledger, filled in when the entry is posted." },
            { term: "Details (₹)", def: "List Price (Quantity × Price per Article), Less: Trade Discount, Add: Expenses (Freight/Carriage, etc.) — leading to the Total Payable." },
            { term: "Cost (₹)", def: "Cost of the goods purchased (net of trade discount)." },
            { term: "Freight/Cartage etc. (₹)", def: "Expenses like freight, carriage, or packing material payable to the seller of goods." },
            { term: "Total (₹)", def: "The full invoice amount payable — cost plus expenses." }
          ]
        },
        {
          h: "Important Entries Relating to Purchases — Freight & Packing",
          p: "A seller's invoice may include Freight/Carriage/Cartage charges or Packing and Forwarding Expenses. The Purchases Book keeps a separate column for each. At the period end, the total of the Cost column is debited to the Purchases Account, the total of the Freight column is debited to a Freight/Carriage/Cartage Inwards Account, and the total of the Packing column is debited to a Packing Expenses Account — while the total invoice price (cost + expenses) is credited to the individual seller's account."
        },
        {
          h: "Mechanics of Posting the Purchases Book in Ledger Accounts",
          p: "Individual entries in the Particulars column name the parties from whom goods have been purchased on credit — each such party's account is credited (\"By Purchases A/c\", plus \"By Freight Inwards A/c\" or \"By Packing Charges A/c\" if any amount is payable towards them) with the value of goods purchased from them. At the period end, the periodic total of the Cost column is posted to the debit of Purchases Account, and the totals of the Freight and Packing columns are posted to the debit of their own accounts — keeping total debits equal to total credits, exactly as double entry requires."
        },
        {
          h: "Difference between Purchases Book and Purchases Account",
          list: [
            { term: "Part", def: "Purchases Book is part of the Journal; Purchases Account is part of the Ledger." },
            { term: "Format", def: "Purchases Book, like a ledger account, does not have separate debit and credit columns; Purchases Account has debit and credit columns." },
            { term: "Contents", def: "Purchases Book records only credit purchases of goods dealt in or consumed for production; Purchases Account records credit as well as cash purchases of such goods." },
            { term: "Amount", def: "Total of the Purchases Book is posted to the Purchases Account; the balance in the Purchases Account is transferred to the Trading Account." }
          ]
        },
        {
          h: "Ruling of Sales Book & Important Entries Relating to Sales",
          list: [
            { term: "Columns", def: "Same layout as the Purchases Book — Date, Particulars (buyer's name, goods, price, quantity), Invoice No., L.F., Details (List Price less Trade Discount, plus expenses = Invoice Price), Sale Value, Freight/Carriage etc., and Total." },
            { term: "Freight/Carriage/Cartage recovered from the buyer", def: "Recorded in a separate column since it is not part of the sale itself — totalled periodically and debited to the Purchaser's (buyer's) Account along with the sale value." },
            { term: "Packing Charges recovered from the customer", def: "Also recorded in a separate column, since it is not part of sale proceeds — totalled and credited to Packing Charges Account, while the Purchaser's Account is debited with sale amount plus packing charges." }
          ]
        },
        {
          h: "Difference between Sales Book and Sales Account",
          list: [
            { term: "Part", def: "Sales Book is part of the Journal Book; Sales Account is part of the Ledger." },
            { term: "Format", def: "Sales Book, like a ledger account, has no debit/credit columns; Sales Account has debit and credit columns." },
            { term: "Contents", def: "Sales Book records only credit sales of goods; Sales Account records credit as well as cash sales of goods." },
            { term: "Amount", def: "Total of the Sales Book is posted periodically to the Sales Account; the balance in the Sales Account is transferred to the Trading Account." }
          ]
        },
        {
          h: "Ruling & Casting of Purchases Return Book and Sales Return Book",
          list: [
            { term: "Purchases Return Book ruling", def: "Identical to the Purchases Book ruling, except a 'Debit Note No.' column replaces the 'Invoice No.' column." },
            { term: "Sales Return Book ruling", def: "Identical to the Sales Book ruling, except a 'Credit Note No.' column replaces the 'Invoice No.' column." },
            { term: "Casting (totalling)", def: "Both books are totalled at the end of the period. The Purchases Return Book total is posted to the credit of Purchases Return Account (and debited to each supplier's own account); the Sales Return Book total is posted to the debit of Sales Return Account (and credited to each customer's own account)." }
          ]
        },
        {
          h: "Journal Proper — Opening & Closing Entries (Pattern)",
          p: "Opening Entry pattern — assets are debited, liabilities and capital are credited, all brought forward from the previous year's Balance Sheet:",
          formula: "Sundry Assets A/c ...Dr.\n  To Sundry Liabilities A/c\n  To Capital A/c\n(Last year's balances of assets, liabilities and capital brought forward)",
          p2: "Closing Entry pattern — nominal accounts are transferred to Trading A/c or Profit & Loss A/c, e.g. for Purchases Account: Trading A/c Dr. To Purchases A/c; for Sales Account: Sales A/c Dr. To Trading A/c; for an expense like Salaries: Profit & Loss A/c Dr. To Salaries A/c."
        },
        {
          h: "Miscellaneous Entries recorded in Journal Proper",
          list: [
            { term: "Credit purchase of an asset (not goods)", def: "E.g. furniture or machinery bought on credit — not the firm's stock-in-trade." },
            { term: "Discount Allowed & Discount Received", def: "Recorded through Journal Proper whenever they arise outside a Cash Book entry, including their reversal on dishonour of a cheque." },
            { term: "Allowance given after the invoice", def: "An allowance given to, or charge made on, a customer after the original invoice has already been issued." },
            { term: "Amounts becoming irrecoverable", def: "E.g. Bad Debts, when a customer becomes insolvent." },
            { term: "Effects of accidents", def: "E.g. loss of property/goods by fire or theft." },
            { term: "Capital brought in kind", def: "When the proprietor introduces an asset (not cash) as capital." }
          ]
        }
      ]
    },

    concepts: [
      { title: "Purchases Book records goods only", body: "Only CREDIT purchases of goods the firm trades in (or uses for manufacturing) go here. Cash purchases go to the Cash Book; credit purchases of assets not traded in (furniture, computers for own use) go to Journal Proper." },
      { title: "Sales Book records goods only", body: "Only CREDIT sales of goods the firm trades in go here — regardless of what the buyer intends to do with them. Cash sales go to the Cash Book; credit sales of an asset the firm doesn't deal in go to Journal Proper." },
      { title: "Trade Discount is never recorded separately", body: "Trade Discount is deducted from the List Price before the entry is even made — only the NET amount (List Price − Trade Discount) enters the Purchases Book or Sales Book. It never appears as its own ledger account." },
      { title: "Debit Note vs Credit Note", body: "A Debit Note is prepared by the PURCHASER on returning goods (basis for the Purchases Return Book). A Credit Note is prepared by the SELLER when goods are returned to them (basis for the Sales Return Book)." },
      { title: "Return Books swap in a Note No. column", body: "Purchases Return Book and Sales Return Book are ruled exactly like Purchases Book and Sales Book, except the 'Invoice No.' column is replaced by 'Debit Note No.' and 'Credit Note No.' respectively." },
      { title: "Journal Proper is the catch-all book", body: "Anything that doesn't fit the Cash Book, Purchases Book, Sales Book, Purchases Return Book, or Sales Return Book lands here — opening/closing entries, rectifications, transfers, adjustments, and one-off miscellaneous entries." }
    ],

    /* Practice bank for the "Practice Bank" tab. Each entry is a short
       transaction; the student identifies which Subsidiary Book (or
       Cash Book, via the "not recorded here" option) it belongs in.
       Answers must exactly match one of the six strings in
       SP2_PRACTICE_OPTIONS in app.js. */
    numericals: [
      { id: 1, difficulty: "Easy", transaction: "Purchased garments on credit worth ₹45,000 from Bright Textiles.",
        answer: "Purchases Book", posting: "By Purchases A/c ₹45,000 (credited to Bright Textiles' account; total posted to debit of Purchases A/c)",
        hint: "A firm dealing in garments buying garments, on credit.",
        explanation: "Credit purchase of goods the firm trades in — recorded in the Purchases Book." },
      { id: 2, difficulty: "Easy", transaction: "Sold garments on credit worth ₹32,000 to Neha Boutique.",
        answer: "Sales Book", posting: "To Sales A/c ₹32,000 (debited to Neha Boutique's account; total posted to credit of Sales A/c)",
        hint: "Credit sale of goods the firm deals in.",
        explanation: "Credit sale of goods dealt in — recorded in the Sales Book." },
      { id: 3, difficulty: "Easy", transaction: "Purchased garments for cash worth ₹10,000 from Om Traders.",
        answer: "Not recorded here — recorded in the Cash Book", posting: "By Purchases A/c ₹10,000 (Cash Book, payments side)",
        hint: "No credit is involved — cash changes hands immediately.",
        explanation: "Cash purchases, even of goods dealt in, never enter the Purchases Book — they're recorded in the Cash Book." },
      { id: 4, difficulty: "Easy", transaction: "Sold garments for cash worth ₹18,000 to a walk-in customer.",
        answer: "Not recorded here — recorded in the Cash Book", posting: "To Sales A/c ₹18,000 (Cash Book, receipts side)",
        hint: "Cash sale — no credit period involved.",
        explanation: "Cash sales are recorded in the Cash Book, never in the Sales Book." },
      { id: 5, difficulty: "Medium", transaction: "Ravi Furnishings, a trader in furniture, purchased office furniture worth ₹85,000 on credit from Elite Furniture Mart, for use in its own office.",
        answer: "Journal Proper", posting: "Office Furniture A/c Dr. ₹85,000; To Elite Furniture Mart ₹85,000",
        hint: "Ravi Furnishings deals in furniture — but is this furniture for resale, or for the firm's own use?",
        explanation: "Even though the firm trades in furniture, this piece is bought for the firm's OWN office use, not for resale — a fixed-asset purchase, recorded in Journal Proper, not the Purchases Book." },
      { id: 6, difficulty: "Medium", transaction: "Ramesh, a trader in laptops, sold 2 laptops on credit @ ₹50,000 each to Akhil, who will use them in his own office.",
        answer: "Sales Book", posting: "To Sales A/c ₹1,00,000 (2 × ₹50,000, debited to Akhil's account)",
        hint: "What matters for the SELLER's Sales Book is what he deals in — not what the buyer plans to do with it.",
        explanation: "Ramesh is selling laptops — goods he deals in — in the ordinary course of business. The buyer's intended use doesn't change how the seller records the sale, so it goes to the Sales Book." },
      { id: 7, difficulty: "Medium", transaction: "Bright Computers (a firm that trades in garments) purchased a laptop on credit for ₹45,000 from Sunrise Traders, for office use.",
        answer: "Journal Proper", posting: "Office Equipment A/c Dr. ₹45,000; To Sunrise Traders ₹45,000",
        hint: "Does Bright Computers actually trade in laptops?",
        explanation: "The laptop is not goods Bright Computers deals in — it's a fixed asset bought for office use, recorded through Journal Proper." },
      { id: 8, difficulty: "Medium", transaction: "Purchased goods from Meera Traders on credit: list price ₹20,000, less trade discount 10%.",
        answer: "Purchases Book", posting: "By Purchases A/c ₹18,000 (List Price 20,000 − Trade Discount 2,000)",
        hint: "Trade discount is deducted before the entry is even made.",
        explanation: "List Price ₹20,000 less 10% Trade Discount (₹2,000) = ₹18,000. Only this net amount is recorded in the Purchases Book — Trade Discount itself is never separately entered." },
      { id: 9, difficulty: "Medium", transaction: "Sold goods to Kiran on credit: list price ₹15,000, less trade discount 20%.",
        answer: "Sales Book", posting: "To Sales A/c ₹12,000 (List Price 15,000 − Trade Discount 3,000)",
        hint: "Same trade-discount logic, from the seller's side.",
        explanation: "List Price ₹15,000 less 20% Trade Discount (₹3,000) = ₹12,000, the net amount recorded in the Sales Book." },
      { id: 10, difficulty: "Medium", transaction: "Purchased goods worth ₹12,000 on credit from Ganga Traders; the invoice also included freight charges of ₹400 payable to Ganga Traders.",
        answer: "Purchases Book", posting: "Cost column ₹12,000 + Freight column ₹400 = Total ₹12,400 credited to Ganga Traders",
        hint: "Freight billed BY the supplier as part of the invoice gets its own column here.",
        explanation: "Total invoice (₹12,400) is credited to Ganga Traders; the Cost column total (₹12,000) is later debited to Purchases A/c and the Freight column total (₹400) to Freight/Cartage Inwards A/c." },
      { id: 11, difficulty: "Medium", transaction: "Sold goods worth ₹9,000 on credit to Farhan; the invoice included packing charges of ₹150 recovered from him.",
        answer: "Sales Book", posting: "Sale Value column ₹9,000 + Packing column ₹150 = Total ₹9,150 debited to Farhan",
        hint: "Packing charges recovered from the buyer sit in their own column too.",
        explanation: "Farhan's account is debited with the full ₹9,150; the Sale Value column total (₹9,000) is credited to Sales A/c and the Packing column total (₹150) to Packing Charges A/c." },
      { id: 12, difficulty: "Medium", transaction: "Paid freight of ₹600 in cash on goods already sold and dispatched to a customer — this freight was borne by the seller and not charged to the buyer.",
        answer: "Not recorded here — recorded in the Cash Book", posting: "By Freight/Carriage Outwards A/c ₹600 (Cash Book, payments side)",
        hint: "This freight is an expense actually PAID in cash by the seller — it was never billed to the customer.",
        explanation: "Since this freight is a cash expense the seller bears itself (not recovered from the buyer via the invoice), it's a Cash Book payment — not a Sales Book entry." },
      { id: 13, difficulty: "Easy", transaction: "Goods at list price ₹4,000, purchased on credit from Ashok Traders, were found defective and returned; no trade discount was involved in the original purchase.",
        answer: "Purchases Return Book (Returns Outward)", posting: "Ashok Traders Dr. ₹4,000; To Purchases Return A/c ₹4,000",
        hint: "A Debit Note is sent to the supplier.",
        explanation: "Return of goods purchased on credit — the purchaser prepares a Debit Note and records it in the Purchases Return Book." },
      { id: 14, difficulty: "Hard", transaction: "Goods originally purchased on credit at a 25% trade discount off an ₹8,000 list price are now returned to the supplier.",
        answer: "Purchases Return Book (Returns Outward)", posting: "Return recorded net of the same discount: 8,000 − 25% (2,000) = ₹6,000",
        hint: "The return should be recorded on the same net basis as the original purchase.",
        explanation: "List Price ₹8,000 less 25% Trade Discount (₹2,000) = ₹6,000 — the return is recorded at this same net figure, matching how it was originally invoiced." },
      { id: 15, difficulty: "Easy", transaction: "A customer, Priya, returned goods to us that she had bought on credit earlier, sale value ₹3,200, because the size was wrong.",
        answer: "Sales Return Book (Returns Inward)", posting: "Sales Return A/c Dr. ₹3,200; To Priya ₹3,200",
        hint: "We prepare a Credit Note for her.",
        explanation: "Return of goods sold on credit — we prepare a Credit Note and record it in the Sales Return Book." },
      { id: 16, difficulty: "Medium", transaction: "Goods costing ₹2,000 were taken by the proprietor for personal/household use.",
        answer: "Journal Proper", posting: "Drawings A/c Dr. ₹2,000; To Purchases A/c ₹2,000",
        hint: "This isn't a purchase, a sale, or a return — it's a withdrawal by the owner.",
        explanation: "Goods withdrawn by the proprietor for personal use is a miscellaneous entry, recorded through Journal Proper." },
      { id: 17, difficulty: "Medium", transaction: "Goods costing ₹1,500 were distributed as free samples for advertisement.",
        answer: "Journal Proper", posting: "Advertisement A/c Dr. ₹1,500; To Purchases A/c ₹1,500",
        hint: "No sale and no customer involved — it's a business expense paid in goods.",
        explanation: "Free samples given away are neither a purchase nor a sale — recorded through Journal Proper." },
      { id: 18, difficulty: "Medium", transaction: "A firm that trades in stationery sold its old, unused furniture (not stock-in-trade) on credit for ₹6,000 to Mohan Furniture Mart.",
        answer: "Journal Proper", posting: "Mohan Furniture Mart Dr. ₹6,000; To Furniture A/c ₹6,000",
        hint: "The firm doesn't deal in furniture — this is a sale of an asset, not of goods.",
        explanation: "Sale of an asset the firm does NOT trade in is never a Sales Book entry, credit or otherwise — it goes through Journal Proper." },
      { id: 19, difficulty: "Medium", transaction: "Bad debts of ₹2,500 were written off against a customer who became insolvent.",
        answer: "Journal Proper", posting: "Bad Debts A/c Dr. ₹2,500; To Customer's A/c ₹2,500",
        hint: "An amount becoming irrecoverable is a miscellaneous Journal Proper entry.",
        explanation: "Writing off an irrecoverable amount is recorded through Journal Proper." },
      { id: 20, difficulty: "Medium", transaction: "Outstanding rent of ₹1,200 was recorded through an adjustment entry at the year end.",
        answer: "Journal Proper", posting: "Rent A/c Dr. ₹1,200; To Outstanding Rent A/c ₹1,200",
        hint: "Adjustment entries at year end have their own home.",
        explanation: "Adjustment entries — outstanding/prepaid expenses, accrued income, and the like — are passed through Journal Proper." },
      { id: 21, difficulty: "Medium", transaction: "Depreciation of ₹5,000 was charged on machinery at the year end.",
        answer: "Journal Proper", posting: "Depreciation A/c Dr. ₹5,000; To Machinery A/c ₹5,000",
        hint: "No cash moves, and it isn't a purchase, sale, or return.",
        explanation: "Depreciation is one of the standard adjustment entries passed through Journal Proper." },
      { id: 22, difficulty: "Medium", transaction: "An Opening Entry was passed at the start of the financial year, bringing forward last year's balances of assets, liabilities, and capital.",
        answer: "Journal Proper", posting: "Sundry Assets A/c Dr.; To Sundry Liabilities A/c; To Capital A/c",
        hint: "This happens once a year, right at the start of the books.",
        explanation: "The Opening Entry is one of the six standard categories of entries recorded through Journal Proper." },
      { id: 23, difficulty: "Hard", transaction: "An error where Wages A/c was wrongly debited instead of Machinery A/c was rectified.",
        answer: "Journal Proper", posting: "Machinery A/c Dr.; To Wages A/c (for the amount wrongly posted)",
        hint: "Correcting a posting error is its own category of entry.",
        explanation: "Rectification of errors made in the books of original entry or the Ledger is always passed through Journal Proper." },
      { id: 24, difficulty: "Hard", transaction: "Discount Received of ₹300 for prompt payment to a creditor was recorded — the (two-column) Cash Book itself has no discount column.",
        answer: "Journal Proper", posting: "Creditor's A/c Dr. ₹300; To Discount Received A/c ₹300",
        hint: "Cash discount never has a column of its own inside the Cash Book.",
        explanation: "Cash discount allowed or received is never entered directly in the Cash Book — it's always journalised through Journal Proper." },
      { id: 25, difficulty: "Hard", transaction: "A cheque earlier received from a debtor in full settlement, along with the ₹400 discount allowed to him at that time, was later dishonoured. Which book records the reversal of the ₹400 discount allowed?",
        answer: "Journal Proper", posting: "Debtor's A/c Dr. ₹400; To Discount Allowed A/c ₹400",
        hint: "The cheque's own reversal is a Cash Book entry — but what about the discount portion?",
        explanation: "The cheque amount itself is reversed in the Cash Book, but the discount that was allowed at the time must be separately reversed — Debtor's A/c Dr.; To Discount Allowed A/c — through Journal Proper." },
      { id: 26, difficulty: "Medium", transaction: "The proprietor brought in additional capital in the form of furniture (not cash) worth ₹30,000.",
        answer: "Journal Proper", posting: "Furniture A/c Dr. ₹30,000; To Capital A/c ₹30,000",
        hint: "No cash or bank is involved — the Cash Book can't record this one.",
        explanation: "Capital brought in kind (an asset, not cash) can't pass through the Cash Book — it's recorded via Journal Proper." }
    ],

    quickRevision: {
      definition: "Special Purpose Books II covers the five Subsidiary Books other than the Cash Book: Purchases Book (credit purchases of goods), Sales Book (credit sales of goods), Purchases Return Book (returns of goods purchased on credit), Sales Return Book (returns of goods sold on credit), and Journal Proper (everything that fits none of the above).",
      keyPoints: [
        "Purchases Book and Sales Book record ONLY credit transactions in goods the firm deals in — cash purchases/sales always go to the Cash Book instead.",
        "Trade Discount is deducted before the entry is made — only the net amount (List Price − Trade Discount) is ever recorded; Trade Discount never gets its own account.",
        "Freight/Carriage and Packing charges billed as part of a purchase or sale invoice get their own column — they are not part of the Purchases/Sales figure itself.",
        "A Debit Note (prepared by the purchaser) is the basis for a Purchases Return Book entry; a Credit Note (prepared by the seller) is the basis for a Sales Return Book entry.",
        "The Return Books are ruled exactly like the Purchases/Sales Books, except 'Invoice No.' is replaced by 'Debit Note No.' or 'Credit Note No.'.",
        "Journal Proper handles: Opening Entries, Closing Entries, Rectification Entries, Transfer Entries, Adjustment Entries, and Miscellaneous Entries (credit purchase of assets, discount reversal on dishonour, bad debts, loss by fire/theft, capital in kind, goods for own use/samples)."
      ],
      postingRules: [
        "Purchases Book: each supplier's account is credited individually; the periodic total is debited to Purchases A/c (and to Freight/Packing accounts, if any).",
        "Sales Book: each customer's account is debited individually; the periodic total is credited to Sales A/c (and to Packing Charges A/c, if recovered).",
        "Purchases Return Book: each supplier's account is debited individually; the periodic total is credited to Purchases Return A/c.",
        "Sales Return Book: each customer's account is credited individually; the periodic total is debited to Sales Return A/c."
      ],
      commonMistakes: [
        "Recording a cash purchase or cash sale of goods in the Purchases Book or Sales Book instead of the Cash Book.",
        "Recording the credit purchase of a fixed asset (furniture, machinery, computers for own use) in the Purchases Book, instead of Journal Proper.",
        "Forgetting that what matters for the SELLER's Sales Book is whether they deal in the goods sold — not what the buyer intends to do with them.",
        "Entering Trade Discount as a separate figure instead of simply reducing the net amount recorded.",
        "Mixing up Debit Note (purchaser → Purchases Return Book) with Credit Note (seller → Sales Return Book).",
        "Treating cash discount, bad debts, depreciation, or opening/closing entries as if they belong in a Subsidiary Book, instead of Journal Proper."
      ],
      mnemonic: "Purchases & Sales Books = credit + goods only. Returns Books swap in a Note number. Everything else lands in Journal Proper."
    }
  },

  brs: {

    theory: {
      /* ---- INTRODUCTION (rendered on the "Introduction" tab) ---- */
      simple: [
        {
          h: "Meaning of Bank Reconciliation Statement",
          p: "A business that keeps money in the bank maintains its own record of every deposit and withdrawal — the Bank Column of the Cash Book (or a separate Bank Book). The bank, on its side, keeps its own record of the same account, called the Pass Book (or Bank Statement). In theory, both records describe the exact same account, so their balances should always match. In practice, they often don't — on any given date, the balance shown by the Cash Book and the balance shown by the Pass Book can differ.",
          p2: "A Bank Reconciliation Statement (BRS) is a statement prepared to explain, item by item, every difference between the balance as shown by the Cash Book and the balance as shown by the Pass Book on a given date, and to prove that the two balances — after adjusting for these differences — agree with each other."
        },
        {
          h: "Why do Cash Book and Pass Book balances differ?",
          p: "Both books record the same bank account, but from two different sides — the firm records a transaction when IT becomes aware of it and enters it in the Cash Book; the bank records the same transaction when THE BANK processes it and enters it in the Pass Book. These two moments in time are very often different, which is the root cause of every difference between the two balances.",
          list: [
            { term: "Timing differences", def: "A transaction has been recorded by one side but not yet by the other, simply because of the time gap involved — e.g. a cheque issued by the firm is recorded immediately in the Cash Book, but the bank only records it when the payee actually presents it for payment, which may be days or weeks later." },
            { term: "Transactions recorded by the bank first", def: "Some transactions are initiated by the bank itself — bank charges, interest allowed, direct collections or payments made on the firm's standing instructions. The bank enters these in the Pass Book immediately, but the firm only comes to know of them (and enters them in the Cash Book) when it later receives the Pass Book or bank statement." },
            { term: "Errors", def: "Either the firm or the bank may make a genuine error while recording an entry or totalling a column — an incorrect amount, an entry recorded twice, or an entry omitted altogether." }
          ]
        },
        {
          h: "Balance as per Cash Book",
          p: "This is the balance of the Bank Column of the firm's own Cash Book — it reflects every bank transaction exactly as the firm itself has recorded it, based on what the firm knows on that date. A debit balance in the Cash Book's bank column means money is available with the bank (an asset for the firm); a credit balance means the firm has overdrawn its account (a bank overdraft, a liability)."
        },
        {
          h: "Balance as per Pass Book",
          p: "This is the balance shown in the copy of the firm's account that the bank maintains and issues to the firm as a Pass Book or Bank Statement. Because the bank is recording from ITS own point of view, the debit/credit language is reversed: money the firm has with the bank (an asset to the firm) is a CREDIT balance in the Pass Book, since from the bank's perspective it owes that money back to the firm. A bank overdraft, in turn, shows as a DEBIT balance in the Pass Book.",
          p2: "This reversal of debit/credit language is a common source of confusion, but it does not change the reconciliation logic taught in this chapter — throughout this chapter, 'balance as per Pass Book' simply means the closing balance figure the bank statement shows on the given date."
        },
        {
          h: "Relationship between Cash Book and Pass Book",
          p: "The Pass Book is nothing but a copy, from the bank's records, of the firm's own account with the bank. Every entry the firm makes in the debit of its Cash Book's bank column (money deposited or collected) should, sooner or later, appear as a credit entry in the Pass Book — and every entry the firm makes in the credit of its Cash Book's bank column (a cheque issued) should, sooner or later, appear as a debit entry in the Pass Book. As long as both sides have recorded exactly the same transactions, the two balances must agree; whenever they don't, it is because one side has recorded something the other has not — yet."
        },
        {
          h: "Purpose of Preparing a Bank Reconciliation Statement",
          list: [
            { term: "Locating the difference", def: "It identifies, one by one, every transaction responsible for the gap between the two balances, instead of leaving the mismatch unexplained." },
            { term: "Detecting errors", def: "Comparing the two records closely often brings genuine errors — in the firm's Cash Book or in the bank's Pass Book — to light, which can then be corrected." },
            { term: "Detecting fraud or embezzlement", def: "A careful, regular reconciliation makes it harder for cheques or deposits to be misappropriated or for the bank account to be misused without detection." },
            { term: "Keeping the Cash Book up to date", def: "Reconciling regularly ensures the firm records, in its own Cash Book, every transaction the bank has already put through — bank charges, interest, direct collections and payments — so the Cash Book balance always reflects reality." },
            { term: "Verifying the correct bank balance", def: "It confirms exactly how much money the firm actually has with the bank (or how much it owes as an overdraft) on a given date, which is essential before finalising the Balance Sheet." }
          ]
        },
        {
          h: "Importance / Need for Reconciliation",
          p: "Since the bank balance is an important figure that appears directly in the firm's Balance Sheet, an unreconciled or wrongly stated bank balance can mislead anyone reading the financial statements. Regular reconciliation — usually done monthly — keeps the accounting records accurate, up to date, and free from unnoticed errors or fraud, and gives management a reliable, current picture of the firm's cash position at the bank."
        },
        {
          h: "Basic Idea of Reconciling the Two Balances",
          p: "Reconciliation always starts from ONE of the two balances (either Cash Book or Pass Book) and works forward: every item that caused the two records to differ is either ADDED or DEDUCTED from the starting balance, until the figure arrived at exactly matches the OTHER balance. If it does, the reconciliation is complete and correct; if it doesn't, at least one causing item has been missed, wrongly treated, or wrongly calculated.",
          formula: "Starting Balance ± Reconciling Items = The Other Balance"
        }
      ],

      /* ---- FORMAT & RULES + STANDARD CAUSES OF DIFFERENCE
         (rendered on the "Format & Rules" tab) ---- */
      advanced: [
        {
          h: "The One Rule Behind Every Add/Less Decision",
          p: "Every reconciling item is, in the end, an entry that ONE of the two books has already made but the OTHER has not made yet. To decide Add or Less, ask a single question:",
          p2: "\"Because of this item, is the balance I am STARTING FROM smaller or larger than the balance I am TRYING TO REACH?\" — if smaller, ADD the item; if larger, DEDUCT (Less) the item. This one question replaces the need to memorise a fixed list, because it works for every cause of difference, in either direction.",
          formula: "If the starting balance is short of the target balance → ADD.\nIf the starting balance exceeds the target balance → LESS (Deduct)."
        },
        {
          h: "Format — Starting with Balance as per Cash Book",
          p: "This is the more common approach — you begin with the balance shown in your own Cash Book's bank column, and adjust it item by item until it matches the Pass Book balance.",
          formula: "Bank Reconciliation Statement as on [date]\n\n            Balance as per Cash Book                    XXXX\n  Add:      Items that increase this balance\n            towards the Pass Book figure                XXXX\n            ---------\n            Sub-total                                    XXXX\n  Less:     Items that decrease this balance\n            towards the Pass Book figure                (XXXX)\n            ---------\n            Balance as per Pass Book                     XXXX\n            ========="
        },
        {
          h: "Format — Starting with Balance as per Pass Book",
          p: "The same statement can equally be prepared the other way round — starting with the Pass Book balance and working towards the Cash Book balance. Every item that was 'Add' when starting from the Cash Book becomes 'Less' here, and every item that was 'Less' becomes 'Add' — because the direction of travel has reversed.",
          formula: "Bank Reconciliation Statement as on [date]\n\n            Balance as per Pass Book                     XXXX\n  Add:      Items that increase this balance\n            towards the Cash Book figure                 XXXX\n            ---------\n            Sub-total                                    XXXX\n  Less:     Items that decrease this balance\n            towards the Cash Book figure                (XXXX)\n            ---------\n            Balance as per Cash Book                     XXXX\n            ========="
        },
        {
          h: "Why the Same Item Flips Direction",
          p: "Take a cheque issued by the firm but not yet presented at the bank. The firm has already reduced its own Cash Book balance (it credited the payment the moment the cheque was written) — but the bank has NOT yet reduced its Pass Book balance, because the payee hasn't presented the cheque for payment. So, compared to the Pass Book, the Cash Book balance is the SMALLER of the two figures right now.",
          p2: "Starting from the Cash Book and moving towards the (larger) Pass Book figure, this item must be ADDED. Starting from the Pass Book and moving towards the (smaller) Cash Book figure, the very same item must be DEDUCTED. Nothing about the transaction changed — only the direction of travel did. This is the logic to apply to every cause below, instead of memorising two separate lists."
        },
        {
          h: "Cause 1 — Cheques Issued but Not Yet Presented for Payment",
          p: "The firm writes and hands over a cheque to a supplier or creditor. What happened: the firm immediately records the payment and reduces its Cash Book balance on the date the cheque is issued. Why the balances differ: the payee may take several days to present the cheque at the bank, and until they do, the bank has no idea the cheque was ever issued — so the Pass Book balance stays unchanged, higher than the Cash Book balance, for that period. Which book has recorded it: the Cash Book only, at this stage.",
          list: [
            { term: "Starting from Cash Book balance", def: "ADD this amount (Cash Book is currently the smaller/short figure)." },
            { term: "Starting from Pass Book balance", def: "LESS (deduct) this amount." }
          ]
        },
        {
          h: "Cause 2 — Cheques Deposited/Paid into the Bank but Not Yet Collected",
          p: "The firm deposits a cheque received from a customer. What happened: the firm records the receipt and increases its Cash Book balance immediately on the date of deposit. Why the balances differ: the bank only credits the firm's account once the cheque actually clears (is collected from the paying bank), which can take a few working days — until then, the Pass Book balance stays lower than the Cash Book balance. Which book has recorded it: the Cash Book only, at this stage.",
          list: [
            { term: "Starting from Cash Book balance", def: "LESS (deduct) this amount (Cash Book is currently the larger/excess figure)." },
            { term: "Starting from Pass Book balance", def: "ADD this amount." }
          ]
        },
        {
          h: "Cause 3 — Bank Charges / Bank Commission Debited by the Bank",
          p: "The bank deducts its own charges — for maintaining the account, issuing a chequebook, or processing a transaction — directly from the firm's balance. What happened: the bank debits (reduces) the Pass Book balance the moment it levies the charge. Why the balances differ: the firm usually only learns of these charges when it later checks its Pass Book or bank statement, so its own Cash Book stays un-reduced in the meantime. Which book has recorded it: the Pass Book only, at this stage.",
          list: [
            { term: "Starting from Cash Book balance", def: "LESS (deduct) this amount." },
            { term: "Starting from Pass Book balance", def: "ADD this amount." }
          ]
        },
        {
          h: "Cause 4 — Interest Credited/Allowed by the Bank",
          p: "The bank pays the firm interest on the balance kept with it. What happened: the bank credits (increases) the Pass Book balance directly. Why the balances differ: the firm generally records this only after seeing it on the Pass Book, so meanwhile the Cash Book stays lower. Which book has recorded it: the Pass Book only, at this stage.",
          list: [
            { term: "Starting from Cash Book balance", def: "ADD this amount." },
            { term: "Starting from Pass Book balance", def: "LESS (deduct) this amount." }
          ]
        },
        {
          h: "Cause 5 — Direct Collection by the Bank (on the firm's behalf)",
          p: "Under standing instructions, the bank may directly collect amounts for the firm — e.g. interest or dividend on investments, or a bill of exchange due for collection. What happened: the bank credits the Pass Book the moment it collects the amount. Why the balances differ: the firm only records this once it is intimated by the bank, so its Cash Book stays un-updated until then. Which book has recorded it: the Pass Book only, at this stage.",
          list: [
            { term: "Starting from Cash Book balance", def: "ADD this amount." },
            { term: "Starting from Pass Book balance", def: "LESS (deduct) this amount." }
          ]
        },
        {
          h: "Cause 6 — Direct Payment by the Bank (on the firm's standing instructions)",
          p: "The bank may make certain payments directly on the firm's behalf — e.g. insurance premium, electricity bill, or a loan instalment, under a standing order. What happened: the bank debits the Pass Book the moment it makes the payment. Why the balances differ: the firm only records this once it checks the Pass Book, so its Cash Book stays un-reduced meanwhile. Which book has recorded it: the Pass Book only, at this stage.",
          list: [
            { term: "Starting from Cash Book balance", def: "LESS (deduct) this amount." },
            { term: "Starting from Pass Book balance", def: "ADD this amount." }
          ]
        },
        {
          h: "Cause 7 — Cheque Deposited but Later Dishonoured",
          p: "A customer's cheque, earlier deposited and recorded as a receipt in the Cash Book, bounces (is dishonoured) when the bank presents it for payment. What happened: the firm had already increased its Cash Book balance when the cheque was deposited, treating it as good money received; the bank has now reversed the corresponding credit in the Pass Book, since the cheque failed to clear. Why the balances differ: the firm typically records the dishonour in its own books only after being informed by the bank, so its Cash Book stays overstated in the meantime. Which book has recorded the reversal: the Pass Book only, at this stage.",
          list: [
            { term: "Starting from Cash Book balance", def: "LESS (deduct) this amount (the Cash Book is currently overstated — it still shows this cheque as realised)." },
            { term: "Starting from Pass Book balance", def: "ADD this amount." }
          ]
        },
        {
          h: "Cause 8 — Direct Deposit into the Bank, Not Yet Recorded in the Cash Book",
          p: "A customer deposits money directly into the firm's bank account (e.g. through a bank transfer), without informing the firm at the time. What happened: the bank credits the Pass Book as soon as the deposit is made. Why the balances differ: the firm only learns of it, and records it in the Cash Book, once it checks the Pass Book — meanwhile the Cash Book understates the true balance. Which book has recorded it: the Pass Book only, at this stage.",
          list: [
            { term: "Starting from Cash Book balance", def: "ADD this amount." },
            { term: "Starting from Pass Book balance", def: "LESS (deduct) this amount." }
          ]
        },
        {
          h: "Cause 9 — Errors in the Cash Book",
          p: "The firm itself may undercast (under-total), overcast (over-total), or wrongly record an amount in the bank column of its own Cash Book. Since the error exists only in the Cash Book, it must be corrected while reconciling towards the (correct) Pass Book figure.",
          list: [
            { term: "Receipts side undercast (totalled short)", def: "The Cash Book balance is understated → ADD the shortfall when starting from the Cash Book." },
            { term: "Receipts side overcast (totalled in excess)", def: "The Cash Book balance is overstated → LESS the excess when starting from the Cash Book." },
            { term: "Payments side undercast (totalled short)", def: "The Cash Book balance is overstated (payments understated means less was deducted than should have been) → LESS the shortfall when starting from the Cash Book." },
            { term: "Payments side overcast (totalled in excess)", def: "The Cash Book balance is understated → ADD the excess when starting from the Cash Book." }
          ]
        },
        {
          h: "Cause 10 — Errors in the Pass Book (by the bank)",
          p: "The bank itself may occasionally debit or credit the firm's account with a wrong amount, or with an entry that belongs to a different customer altogether. Since the error exists only in the Pass Book, it must be corrected while reconciling towards the (correct) Cash Book figure.",
          list: [
            { term: "Bank has wrongly credited (over-credited) the account", def: "The Pass Book balance is overstated → LESS this amount when starting from the Pass Book (Add when starting from Cash Book, to reach the inflated Pass Book figure)." },
            { term: "Bank has wrongly debited (over-debited) the account", def: "The Pass Book balance is understated → ADD this amount when starting from the Pass Book (Less when starting from Cash Book, to reach the deflated Pass Book figure)." }
          ]
        }
      ]
    },

    concepts: [
      { title: "Bank Reconciliation Statement", body: "A statement, prepared on a given date, that explains every item causing the Cash Book's bank balance and the Pass Book balance to differ — and proves that, once these items are adjusted, the two figures agree." },
      { title: "Balance as per Cash Book", body: "The bank balance shown by the firm's own record — the bank column of its Cash Book — reflecting only what the firm itself has recorded so far." },
      { title: "Balance as per Pass Book", body: "The bank balance shown in the copy of the account the bank maintains and issues to the firm — reflecting only what the bank has recorded so far. Debit/credit language here is the reverse of the firm's own books, since it is written from the bank's point of view." },
      { title: "Timing Difference", body: "The most common reason the two balances differ — a transaction has already been recorded by one side, but the other side will only record it a few days later, once it becomes aware of it." },
      { title: "Cheques Issued but Not Presented", body: "A payment already reduced in the Cash Book, but not yet reduced by the bank because the payee hasn't cashed the cheque yet — makes the Cash Book balance temporarily lower than the Pass Book balance." },
      { title: "Cheques Deposited but Not Collected", body: "A receipt already increased in the Cash Book, but not yet increased by the bank because the cheque hasn't cleared yet — makes the Cash Book balance temporarily higher than the Pass Book balance." },
      { title: "The One Add/Less Rule", body: "Ask: is my starting balance short of, or ahead of, the balance I'm trying to reach? Short → Add. Ahead → Less. The same rule works for every cause, in either direction — nothing needs memorising as a fixed list." }
    ],

    /* ---- PRACTICE BANK — classification-style questions, matching
       the interaction pattern used in Chapters 5 & 6's Practice Bank.
       Each item states a starting balance explicitly; the student
       identifies whether the given item should be Added or Deducted
       to move from that starting balance towards the other one.
       Every "answer" is independently verified against the reasoning
       in "explanation", including the resulting figure. ---- */
    numericals: [
      { id: 1, difficulty: "Easy",
        transaction: "You are preparing a BRS starting from the Cash Book balance of ₹25,000. A cheque of ₹5,000 issued to a supplier has not yet been presented for payment at the bank.",
        answer: "Add — to arrive at Balance as per Pass Book",
        posting: "₹25,000 + ₹5,000 = ₹30,000 (Balance as per Pass Book)",
        hint: "The firm has already reduced its own balance for this cheque — has the bank?",
        explanation: "The firm reduced its Cash Book balance the moment the cheque was issued, but the bank hasn't reduced its Pass Book balance yet since the cheque hasn't been presented. So the Cash Book (₹25,000) is currently short of the Pass Book — Add ₹5,000: ₹25,000 + ₹5,000 = ₹30,000, the Balance as per Pass Book." },
      { id: 2, difficulty: "Easy",
        transaction: "You are preparing a BRS starting from the Cash Book balance of ₹25,000. A cheque of ₹3,000 deposited into the bank has not yet been collected/credited by the bank.",
        answer: "Less — to arrive at Balance as per Pass Book",
        posting: "₹25,000 − ₹3,000 = ₹22,000 (Balance as per Pass Book)",
        hint: "The firm already recorded this as money received — has the bank actually credited it yet?",
        explanation: "The firm increased its Cash Book balance on depositing the cheque, but the bank will only credit it once collected. So the Cash Book (₹25,000) is currently ahead of the Pass Book — Less ₹3,000: ₹25,000 − ₹3,000 = ₹22,000, the Balance as per Pass Book." },
      { id: 3, difficulty: "Easy",
        transaction: "You are preparing a BRS starting from the Cash Book balance of ₹25,000. Bank charges of ₹200 have been debited by the bank but not yet entered in the Cash Book.",
        answer: "Less — to arrive at Balance as per Pass Book",
        posting: "₹25,000 − ₹200 = ₹24,800 (Balance as per Pass Book)",
        hint: "The bank has already reduced its own record for this charge — has the firm?",
        explanation: "The bank has already debited (reduced) the Pass Book for its charge; the firm hasn't reduced its Cash Book yet. So the Cash Book (₹25,000) is currently ahead of the Pass Book — Less ₹200: ₹25,000 − ₹200 = ₹24,800, the Balance as per Pass Book." },
      { id: 4, difficulty: "Easy",
        transaction: "You are preparing a BRS starting from the Cash Book balance of ₹25,000. Interest of ₹150 credited by the bank has not yet been entered in the Cash Book.",
        answer: "Add — to arrive at Balance as per Pass Book",
        posting: "₹25,000 + ₹150 = ₹25,150 (Balance as per Pass Book)",
        hint: "The bank has already increased its own record for this interest — has the firm?",
        explanation: "The bank has already credited (increased) the Pass Book with the interest; the firm hasn't recorded it in the Cash Book yet. So the Cash Book (₹25,000) is currently short of the Pass Book — Add ₹150: ₹25,000 + ₹150 = ₹25,150, the Balance as per Pass Book." },
      { id: 5, difficulty: "Medium",
        transaction: "You are preparing a BRS starting from the Cash Book balance of ₹25,000. Dividend of ₹1,000 on the firm's investments was collected directly by the bank, but not yet entered in the Cash Book.",
        answer: "Add — to arrive at Balance as per Pass Book",
        posting: "₹25,000 + ₹1,000 = ₹26,000 (Balance as per Pass Book)",
        hint: "This is money the bank collected on the firm's behalf, under standing instructions.",
        explanation: "The bank has already credited the Pass Book on collecting the dividend for the firm; the Cash Book hasn't been updated yet. Cash Book is short — Add ₹1,000: ₹25,000 + ₹1,000 = ₹26,000, the Balance as per Pass Book." },
      { id: 6, difficulty: "Medium",
        transaction: "You are preparing a BRS starting from the Cash Book balance of ₹25,000. An insurance premium of ₹600 was paid by the bank directly under a standing instruction, but not yet entered in the Cash Book.",
        answer: "Less — to arrive at Balance as per Pass Book",
        posting: "₹25,000 − ₹600 = ₹24,400 (Balance as per Pass Book)",
        hint: "The bank has already made this payment on the firm's behalf.",
        explanation: "The bank has already debited the Pass Book for the premium it paid; the Cash Book hasn't recorded this payment yet. Cash Book is ahead — Less ₹600: ₹25,000 − ₹600 = ₹24,400, the Balance as per Pass Book." },
      { id: 7, difficulty: "Medium",
        transaction: "You are preparing a BRS starting from the Cash Book balance of ₹25,000. A customer's cheque for ₹2,000, earlier deposited and recorded as received, has now been dishonoured by the bank — the dishonour is not yet entered in the Cash Book.",
        answer: "Less — to arrive at Balance as per Pass Book",
        posting: "₹25,000 − ₹2,000 = ₹23,000 (Balance as per Pass Book)",
        hint: "The Cash Book still shows this cheque as good money received — but is it, any more?",
        explanation: "The Cash Book still shows the ₹2,000 as realised, but the bank has already reversed the credit in the Pass Book since the cheque bounced. The Cash Book is now overstated — Less ₹2,000: ₹25,000 − ₹2,000 = ₹23,000, the Balance as per Pass Book." },
      { id: 8, difficulty: "Medium",
        transaction: "You are preparing a BRS starting from the Cash Book balance of ₹25,000. A customer deposited ₹1,500 directly into the firm's bank account; the firm has not yet entered this in its Cash Book.",
        answer: "Add — to arrive at Balance as per Pass Book",
        posting: "₹25,000 + ₹1,500 = ₹26,500 (Balance as per Pass Book)",
        hint: "The bank has already recorded this deposit — has the firm?",
        explanation: "The bank credited the Pass Book as soon as the direct deposit was made; the firm hasn't recorded it in the Cash Book yet. Cash Book is short — Add ₹1,500: ₹25,000 + ₹1,500 = ₹26,500, the Balance as per Pass Book." },
      { id: 9, difficulty: "Easy",
        transaction: "You are preparing a BRS starting from the Pass Book balance of ₹30,000. A cheque of ₹5,000 issued to a supplier has not yet been presented for payment at the bank.",
        answer: "Less — to arrive at Balance as per Cash Book",
        posting: "₹30,000 − ₹5,000 = ₹25,000 (Balance as per Cash Book)",
        hint: "This is the same item as issuing an unpresented cheque — but now you're starting from the Pass Book, the LARGER figure.",
        explanation: "Since the cheque isn't presented yet, the Pass Book (₹30,000) is currently ahead of the Cash Book (which already reduced its balance). Starting from the Pass Book, Less ₹5,000: ₹30,000 − ₹5,000 = ₹25,000, the Balance as per Cash Book. Notice this is the exact reverse of Q1's treatment for the identical transaction." },
      { id: 10, difficulty: "Easy",
        transaction: "You are preparing a BRS starting from the Pass Book balance of ₹22,000. A cheque of ₹3,000 deposited into the bank has not yet been collected/credited by the bank.",
        answer: "Add — to arrive at Balance as per Cash Book",
        posting: "₹22,000 + ₹3,000 = ₹25,000 (Balance as per Cash Book)",
        hint: "This is the same item as an uncollected cheque — but now you're starting from the Pass Book, the SMALLER figure.",
        explanation: "The bank hasn't credited this deposit yet, so the Pass Book (₹22,000) is currently short of the Cash Book (which already recorded it as received). Starting from the Pass Book, Add ₹3,000: ₹22,000 + ₹3,000 = ₹25,000, the Balance as per Cash Book — the exact reverse of Q2's treatment." },
      { id: 11, difficulty: "Medium",
        transaction: "You are preparing a BRS starting from the Pass Book balance of ₹24,800. Bank charges of ₹200 have been debited by the bank but not yet entered in the Cash Book.",
        answer: "Add — to arrive at Balance as per Cash Book",
        posting: "₹24,800 + ₹200 = ₹25,000 (Balance as per Cash Book)",
        hint: "Compare with Q3, which started from the Cash Book for the same item.",
        explanation: "The Pass Book already reflects the charge (it is the smaller figure now); the Cash Book does not. Starting from the Pass Book, Add ₹200: ₹24,800 + ₹200 = ₹25,000, the Balance as per Cash Book — the reverse of Q3." },
      { id: 12, difficulty: "Medium",
        transaction: "You are preparing a BRS starting from the Pass Book balance of ₹25,150. Interest of ₹150 credited by the bank has not yet been entered in the Cash Book.",
        answer: "Less — to arrive at Balance as per Cash Book",
        posting: "₹25,150 − ₹150 = ₹25,000 (Balance as per Cash Book)",
        hint: "Compare with Q4, which started from the Cash Book for the same item.",
        explanation: "The Pass Book already reflects the interest (it is the larger figure now); the Cash Book does not. Starting from the Pass Book, Less ₹150: ₹25,150 − ₹150 = ₹25,000, the Balance as per Cash Book — the reverse of Q4." },
      { id: 13, difficulty: "Hard",
        transaction: "You are preparing a BRS starting from the Pass Book balance of ₹23,000. A customer's cheque for ₹2,000, earlier deposited and recorded as received, has been dishonoured by the bank; the dishonour is not yet entered in the Cash Book.",
        answer: "Add — to arrive at Balance as per Cash Book",
        posting: "₹23,000 + ₹2,000 = ₹25,000 (Balance as per Cash Book)",
        hint: "Compare with Q7, which started from the Cash Book for the same item.",
        explanation: "The Pass Book already reflects the reversal of the dishonoured cheque (it is now the smaller figure); the Cash Book still overstates its balance by ₹2,000. Starting from the Pass Book, Add ₹2,000: ₹23,000 + ₹2,000 = ₹25,000, the Balance as per Cash Book — the reverse of Q7." },
      { id: 14, difficulty: "Hard",
        transaction: "You are preparing a BRS starting from the Cash Book balance of ₹40,000. The receipts side of the Cash Book's bank column has been undercast (totalled ₹500 short).",
        answer: "Add — to arrive at Balance as per Pass Book",
        posting: "₹40,000 + ₹500 = ₹40,500 (corrected Cash Book figure, en route to the Pass Book balance)",
        hint: "If receipts were understated, is the Cash Book balance too high or too low?",
        explanation: "Undercasting the receipts side means the true receipts (and hence the true balance) are ₹500 more than what the Cash Book currently shows. Add ₹500: ₹40,000 + ₹500 = ₹40,500 — the Cash Book balance corrected to what it should actually be, on the way to matching the Pass Book." },
      { id: 15, difficulty: "Hard",
        transaction: "You are preparing a BRS starting from the Cash Book balance of ₹40,000. The payments side of the Cash Book's bank column has been overcast (totalled ₹300 in excess).",
        answer: "Add — to arrive at Balance as per Pass Book",
        posting: "₹40,000 + ₹300 = ₹40,300 (corrected Cash Book figure)",
        hint: "If payments were overstated, was too much or too little deducted from the balance?",
        explanation: "Overcasting the payments side means ₹300 too much was deducted, so the true balance is ₹300 higher than currently shown. Add ₹300: ₹40,000 + ₹300 = ₹40,300, correcting the Cash Book balance." },
      { id: 16, difficulty: "Medium",
        transaction: "You are preparing a BRS starting from the Cash Book balance of ₹18,000. A cheque of ₹2,500 issued to a creditor has not yet been presented for payment.",
        answer: "Add — to arrive at Balance as per Pass Book",
        posting: "₹18,000 + ₹2,500 = ₹20,500 (Balance as per Pass Book)",
        hint: "Same pattern as Q1 — different numbers.",
        explanation: "The Cash Book already reduced its balance for this unpresented cheque, so it is short of the Pass Book. Add ₹2,500: ₹18,000 + ₹2,500 = ₹20,500, the Balance as per Pass Book." },
      { id: 17, difficulty: "Medium",
        transaction: "You are preparing a BRS starting from the Cash Book balance of ₹18,000. A cheque of ₹1,200 deposited has not yet been collected by the bank.",
        answer: "Less — to arrive at Balance as per Pass Book",
        posting: "₹18,000 − ₹1,200 = ₹16,800 (Balance as per Pass Book)",
        hint: "Same pattern as Q2 — different numbers.",
        explanation: "The Cash Book already increased its balance for this deposit, but the bank hasn't credited it yet, so the Cash Book is ahead. Less ₹1,200: ₹18,000 − ₹1,200 = ₹16,800, the Balance as per Pass Book." },
      { id: 18, difficulty: "Hard",
        transaction: "You are preparing a BRS starting from the Cash Book balance of ₹50,000. Items: a cheque of ₹8,000 issued but not presented; a cheque of ₹4,500 deposited but not collected; bank charges ₹150 not yet entered in the Cash Book. What is the combined effect of ALL three items on the way to the Pass Book balance?",
        answer: "Add — to arrive at Balance as per Pass Book",
        posting: "₹50,000 + ₹8,000 − ₹4,500 − ₹150 = ₹53,350 (Balance as per Pass Book)",
        hint: "Work out each item's own Add/Less first, then combine the net effect.",
        explanation: "Unpresented cheque: Add ₹8,000. Uncollected cheque: Less ₹4,500. Bank charges: Less ₹150. Net effect: +8,000 − 4,500 − 150 = +3,350, an overall ADD. ₹50,000 + ₹3,350 = ₹53,350, the Balance as per Pass Book." },
      { id: 19, difficulty: "Easy",
        transaction: "You are preparing a BRS starting from the Cash Book balance of ₹12,000. A dividend of ₹800 collected directly by the bank is not yet entered in the Cash Book.",
        answer: "Add — to arrive at Balance as per Pass Book",
        posting: "₹12,000 + ₹800 = ₹12,800 (Balance as per Pass Book)",
        hint: "The bank has already increased its own record for this collection.",
        explanation: "The Pass Book already reflects the dividend collected by the bank; the Cash Book does not yet. Add ₹800: ₹12,000 + ₹800 = ₹12,800, the Balance as per Pass Book." },
      { id: 20, difficulty: "Easy",
        transaction: "You are preparing a BRS starting from the Cash Book balance of ₹12,000. Electricity bill of ₹450 paid by the bank directly (standing instruction) is not yet entered in the Cash Book.",
        answer: "Less — to arrive at Balance as per Pass Book",
        posting: "₹12,000 − ₹450 = ₹11,550 (Balance as per Pass Book)",
        hint: "The bank has already reduced its own record for this payment.",
        explanation: "The Pass Book already reflects the payment the bank made on the firm's behalf; the Cash Book does not yet. Less ₹450: ₹12,000 − ₹450 = ₹11,550, the Balance as per Pass Book." }
    ],

    quickRevision: {
      definition: "A Bank Reconciliation Statement (BRS) is a statement prepared on a given date to explain, item by item, every difference between the balance as per Cash Book and the balance as per Pass Book, and to prove that both balances agree once these items are adjusted for.",
      keyPoints: [
        "Both Cash Book (bank column) and Pass Book record the SAME bank account, but from two different sides — the firm's and the bank's — recorded at two different points in time.",
        "Most differences are TIMING differences: one side has recorded a transaction, the other hasn't — yet.",
        "Some differences originate with the BANK ITSELF: bank charges, interest allowed, direct collections, and direct payments the firm only learns of from the Pass Book.",
        "A minority of differences are outright ERRORS — in the Cash Book (the firm's mistake) or in the Pass Book (the bank's mistake).",
        "Balance as per Pass Book uses the bank's own debit/credit language — money the firm has with the bank is a CREDIT balance there, the reverse of the firm's own books."
      ],
      addLessLogic: [
        "Cheque issued, not yet presented → Add (starting from Cash Book) / Less (starting from Pass Book).",
        "Cheque deposited, not yet collected → Less (starting from Cash Book) / Add (starting from Pass Book).",
        "Bank charges not yet in Cash Book → Less (starting from Cash Book) / Add (starting from Pass Book).",
        "Interest credited, not yet in Cash Book → Add (starting from Cash Book) / Less (starting from Pass Book).",
        "Direct collection by bank, not yet in Cash Book → Add (starting from Cash Book) / Less (starting from Pass Book).",
        "Direct payment by bank, not yet in Cash Book → Less (starting from Cash Book) / Add (starting from Pass Book).",
        "Cheque deposited, later dishonoured, not yet in Cash Book → Less (starting from Cash Book) / Add (starting from Pass Book).",
        "Direct deposit by a customer, not yet in Cash Book → Add (starting from Cash Book) / Less (starting from Pass Book).",
        "The universal test: is the starting balance short of, or ahead of, the target balance because of this item? Short → Add. Ahead → Less."
      ],
      commonMistakes: [
        "Confusing an unpresented cheque (issued, Cash Book already reduced) with an uncollected cheque (deposited, Cash Book already increased) — they take opposite treatment.",
        "Reversing the Add/Less direction by forgetting which balance the statement is starting from.",
        "Forgetting the starting balance itself and jumping straight to listing items, without asking 'short of, or ahead of, the target?' for each one.",
        "Mixing up which book has ALREADY recorded an item — bank-initiated items (charges, interest, direct collection/payment) are already in the Pass Book, not the Cash Book.",
        "Trying to pass a Journal entry for every BRS item — most reconciling items need no Journal entry at all; they are simply timing differences that will resolve themselves once both books record the transaction.",
        "Simple arithmetic slips while adding/deducting several items in a row — always re-total the final figure and check it against the other balance."
      ],
      mnemonic: "Ask ONE question for every item: is my starting balance SHORT of, or AHEAD of, where I'm trying to reach? Short → Add. Ahead → Less. Works both ways, every time."
    },

    /* ---- BRS DETECTIVE — short banking scenarios; the student
       decides Add or Less (always starting from the Cash Book
       balance given, for a single, consistent, teachable framing),
       then the reasoning and reversed-direction note are revealed. ---- */
    detective: [
      {
        id: 1,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 22000,
        situation: "A cheque of ₹4,000 issued to a supplier has not yet been presented for payment at the bank.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 26000,
        items: [
        { label: "Cheque issued, not yet presented", correctAnswer: "Add", amount: 4000, reasoning: "The business has already reduced its Cash Book balance for this cheque, but the bank hasn't reduced the Pass Book yet since the payee hasn't presented it." }
        ]
      },
      {
        id: 2,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 18500,
        situation: "A cheque of ₹3,200 deposited into the bank has not yet been collected/credited by the bank.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 15300,
        items: [
        { label: "Cheque deposited, not yet collected", correctAnswer: "Less", amount: 3200, reasoning: "The business already increased its Cash Book balance on deposit, but the bank will only credit it once the cheque actually clears." }
        ]
      },
      {
        id: 3,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 27500,
        situation: "A customer's cheque for ₹2,600, earlier deposited and recorded as received, has now been dishonoured by the bank; the dishonour is not yet entered in the Cash Book.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 24900,
        items: [
        { label: "Cheque deposited, later dishonoured", correctAnswer: "Less", amount: 2600, reasoning: "The Cash Book still shows this cheque as good money received, but the bank has already reversed the credit since it bounced." }
        ]
      },
      {
        id: 4,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 31000,
        situation: "The bank has debited ₹220 as bank charges for the quarter; this is not yet entered in the Cash Book.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 30780,
        items: [
        { label: "Bank charges debited", correctAnswer: "Less", amount: 220, reasoning: "The bank has already reduced the Pass Book for its own charges; the business hasn't reduced its Cash Book yet." }
        ]
      },
      {
        id: 5,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 15600,
        situation: "The account was overdrawn during the month, and the bank has debited ₹340 as interest on the overdrawn balance; this is not yet entered in the Cash Book.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 15260,
        items: [
        { label: "Interest charged by bank (on overdraft)", correctAnswer: "Less", amount: 340, reasoning: "The bank has already debited the Pass Book for the interest it charged; the business only finds out once it checks the Pass Book." }
        ]
      },
      {
        id: 6,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 24000,
        situation: "The bank has debited ₹150 as commission for collecting a bill on the business's behalf; this is not yet entered in the Cash Book.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 23850,
        items: [
        { label: "Commission charged by bank", correctAnswer: "Less", amount: 150, reasoning: "The bank has already reduced the Pass Book for its commission; the business hasn't recorded this charge yet." }
        ]
      },
      {
        id: 7,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 19800,
        situation: "The bank has credited ₹300 as interest on the balance kept with it; this is not yet entered in the Cash Book.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 20100,
        items: [
        { label: "Interest credited by bank", correctAnswer: "Add", amount: 300, reasoning: "The bank has already increased the Pass Book for the interest allowed; the business hasn't recorded it yet." }
        ]
      },
      {
        id: 8,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 33500,
        situation: "The bank has directly collected ₹800 as dividend on the business's investments; this is not yet entered in the Cash Book.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 34300,
        items: [
        { label: "Dividend collected by bank", correctAnswer: "Add", amount: 800, reasoning: "The bank already credited the Pass Book on collecting the dividend for the business; the Cash Book hasn't been updated yet." }
        ]
      },
      {
        id: 9,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 21200,
        situation: "Under a standing instruction, the bank has directly collected ₹1,100 of interest due on the business's fixed deposit; this is not yet entered in the Cash Book.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 22300,
        items: [
        { label: "Interest collected by bank on the firm's behalf", correctAnswer: "Add", amount: 1100, reasoning: "The bank already credited the Pass Book on collecting the interest for the business; the Cash Book hasn't been updated yet." }
        ]
      },
      {
        id: 10,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 17300,
        situation: "A customer deposited ₹2,000 directly into the business's bank account; the business has not yet entered this in its Cash Book.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 19300,
        items: [
        { label: "Direct deposit by a customer", correctAnswer: "Add", amount: 2000, reasoning: "The bank credited the Pass Book as soon as the direct deposit was made; the business hasn't recorded it in the Cash Book yet." }
        ]
      },
      {
        id: 11,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 29000,
        situation: "Under a standing instruction, the bank made a direct payment of ₹1,400 to one of the business's suppliers; this is not yet entered in the Cash Book.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 27600,
        items: [
        { label: "Direct payment made by bank", correctAnswer: "Less", amount: 1400, reasoning: "The bank has already debited the Pass Book for the payment it made; the business hasn't recorded it in the Cash Book yet." }
        ]
      },
      {
        id: 12,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 26400,
        situation: "The bank paid an insurance premium of ₹950 directly under a standing instruction; this is not yet entered in the Cash Book.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 25450,
        items: [
        { label: "Insurance premium paid directly by bank", correctAnswer: "Less", amount: 950, reasoning: "The bank has already debited the Pass Book for the premium it paid; the business hasn't recorded this payment yet." }
        ]
      },
      {
        id: 13,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 14700,
        situation: "The bank paid the office rent of ₹1,200 directly under a standing instruction; this is not yet entered in the Cash Book.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 13500,
        items: [
        { label: "Rent paid directly by bank", correctAnswer: "Less", amount: 1200, reasoning: "The bank has already debited the Pass Book for the rent it paid; the business hasn't recorded it in the Cash Book yet." }
        ]
      },
      {
        id: 14,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 20500,
        situation: "A bill of exchange for ₹1,700, held for collection, has been collected by the bank on maturity; this is not yet entered in the Cash Book.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 22200,
        items: [
        { label: "Bill collected by bank", correctAnswer: "Add", amount: 1700, reasoning: "The bank has already credited the Pass Book on collecting the bill on maturity; the business hasn't recorded this yet." }
        ]
      },
      {
        id: 15,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 23100,
        situation: "The bank charged ₹90 as fees for collecting a bill of exchange on the business's behalf; this is not yet entered in the Cash Book.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 23010,
        items: [
        { label: "Bank's bill-collection charges", correctAnswer: "Less", amount: 90, reasoning: "The bank has already debited the Pass Book for its collection charges; the business hasn't recorded this yet." }
        ]
      },
      {
        id: 16,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 36200,
        situation: "The maturity proceeds of ₹2,500 from an investment were credited by the bank directly; this is not yet entered in the Cash Book.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 38700,
        items: [
        { label: "Other direct bank credit (investment proceeds)", correctAnswer: "Add", amount: 2500, reasoning: "The bank has already credited the Pass Book with the maturity proceeds; the business hasn't recorded this receipt yet." }
        ]
      },
      {
        id: 17,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 12900,
        situation: "The bank debited ₹500 as locker rent for the year, as per standing instructions; this is not yet entered in the Cash Book.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 12400,
        items: [
        { label: "Other direct bank debit (locker rent)", correctAnswer: "Less", amount: 500, reasoning: "The bank has already debited the Pass Book for the locker rent; the business hasn't recorded this payment yet." }
        ]
      },
      {
        id: 18,
        category: "Cash Book Errors",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 25000,
        situation: "A cheque of ₹3,000 issued to a creditor (and already paid by the bank) was completely omitted from the Cash Book.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 22000,
        items: [
        { label: "Cheque issued, omitted from Cash Book", correctAnswer: "Less", amount: 3000, reasoning: "Since the payment was never recorded at all, the Cash Book balance shown is too HIGH by the omitted amount — it must be reduced to reflect the payment the bank has already made." }
        ]
      },
      {
        id: 19,
        category: "Cash Book Errors",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 19000,
        situation: "A cheque of ₹1,500 issued to a supplier was recorded TWICE in the Cash Book by mistake.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 20500,
        items: [
        { label: "Cheque issued, entered twice in Cash Book", correctAnswer: "Add", amount: 1500, reasoning: "Recording the same payment twice deducts the amount from the Cash Book balance twice, making it too LOW by one extra ₹1,500 — this must be added back." }
        ]
      },
      {
        id: 20,
        category: "Cash Book Errors",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 22800,
        situation: "A cheque of ₹2,400 received from a customer and deposited into the bank was completely omitted from the Cash Book.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 25200,
        items: [
        { label: "Cheque deposited, omitted from Cash Book", correctAnswer: "Add", amount: 2400, reasoning: "Since the receipt was never recorded at all, the Cash Book balance shown is too LOW by the omitted amount — it must be increased to reflect the deposit the bank has already credited." }
        ]
      },
      {
        id: 21,
        category: "Cash Book Errors",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 16200,
        situation: "A cheque for ₹5,000 was deposited into the bank, but was wrongly recorded in the Cash Book as only ₹4,200.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 17000,
        items: [
        { label: "Cheque deposited, recorded short by ₹800", correctAnswer: "Add", amount: 800, reasoning: "The Cash Book recorded ₹800 less than the actual receipt, so its balance is understated by that shortfall — it must be added to reach the correct figure." }
        ]
      },
      {
        id: 22,
        category: "Cash Book Errors",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 28400,
        situation: "A cheque for ₹3,600 was issued to a supplier, but was wrongly recorded in the Cash Book as only ₹3,100.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 27900,
        items: [
        { label: "Cheque issued, recorded short by ₹500", correctAnswer: "Less", amount: 500, reasoning: "The Cash Book recorded ₹500 less payment than actually made, so its balance is overstated by that shortfall — it must be deducted to reach the correct figure." }
        ]
      },
      {
        id: 23,
        category: "Cash Book Errors",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 20600,
        situation: "While closing the Cash Book for the month, the closing balance was carried forward as ₹20,600 instead of the correct ₹21,100.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 21100,
        items: [
        { label: "Cash Book closing balance calculated incorrectly", correctAnswer: "Add", amount: 500, reasoning: "The balance actually carried forward is ₹500 less than it should be, so it is understated — the shortfall must be added to reach the correct figure." }
        ]
      },
      {
        id: 24,
        category: "Cash Book Errors",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 34000,
        situation: "The receipts side of the Cash Book's bank column was totalled ₹600 in excess (an addition/overcasting error).",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 33400,
        items: [
        { label: "Receipts side overcast by ₹600", correctAnswer: "Less", amount: 600, reasoning: "Overcasting the receipts side inflates the balance by the excess amount, so it is overstated — the excess must be deducted to correct it." }
        ]
      },
      {
        id: 25,
        category: "Cash Book Errors",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 18300,
        situation: "The payments side of the Cash Book's bank column was totalled ₹450 short (a subtraction/undercasting error).",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 17850,
        items: [
        { label: "Payments side undercast by ₹450", correctAnswer: "Less", amount: 450, reasoning: "Undercasting the payments side means ₹450 less was deducted than should have been, so the balance is overstated by that shortfall — it must be deducted to correct it." }
        ]
      },
      {
        id: 26,
        category: "Cash Book Errors",
        difficulty: "Medium",
        startingPoint: "Cash Book",
        startingBalance: 26000,
        situation: "A receipt of ₹1,000 from a customer was, by mistake, entered on the PAYMENTS side of the Cash Book instead of the receipts side.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 28000,
        items: [
        { label: "Receipt wrongly entered on the payments side", correctAnswer: "Add", amount: 2000, reasoning: "This single mistake causes a double error: the ₹1,000 receipt was never added (so the balance is short by ₹1,000), AND it was wrongly deducted as if it were a payment (a further ₹1,000 short). The full correction is therefore 2 × ₹1,000 = ₹2,000, added back." }
        ]
      },
      {
        id: 27,
        category: "Cash Book Errors",
        difficulty: "Medium",
        startingPoint: "Cash Book",
        startingBalance: 30500,
        situation: "A bank deposit of ₹1,200 was wrongly recorded in the Cash Book as a bank WITHDRAWAL.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 32900,
        items: [
        { label: "Bank deposit recorded as a withdrawal", correctAnswer: "Add", amount: 2400, reasoning: "Recording a ₹1,200 deposit as a withdrawal both fails to add it and wrongly deducts it — a double error. The full correction is 2 × ₹1,200 = ₹2,400, added back." }
        ]
      },
      {
        id: 28,
        category: "Cash Book Errors",
        difficulty: "Medium",
        startingPoint: "Cash Book",
        startingBalance: 24700,
        situation: "A bank withdrawal of ₹900 was wrongly recorded in the Cash Book as a bank DEPOSIT.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 22900,
        items: [
        { label: "Bank withdrawal recorded as a deposit", correctAnswer: "Less", amount: 1800, reasoning: "Recording a ₹900 withdrawal as a deposit both fails to deduct it and wrongly adds it — a double error. The full correction is 2 × ₹900 = ₹1,800, deducted." }
        ]
      },
      {
        id: 29,
        category: "Cash Book Errors",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 15900,
        situation: "A bank transfer of ₹1,600 received from another branch was completely omitted from the Cash Book.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 17500,
        items: [
        { label: "Bank transaction (receipt) completely omitted", correctAnswer: "Add", amount: 1600, reasoning: "Since the receipt was never recorded, the Cash Book balance is too LOW by the omitted amount — it must be added to reach the correct figure." }
        ]
      },
      {
        id: 30,
        category: "Cash Book Errors",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 32100,
        situation: "A deposit of ₹1,300 was, by mistake, entered TWICE on the receipts side of the Cash Book.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 30800,
        items: [
        { label: "Amount entered twice in Cash Book", correctAnswer: "Less", amount: 1300, reasoning: "Recording the same receipt twice adds the amount to the Cash Book balance twice, making it too HIGH by one extra ₹1,300 — this duplicate must be deducted." }
        ]
      },
      {
        id: 31,
        category: "Cash Book Errors",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 21700,
        situation: "The opening balance was brought forward from the previous month as ₹21,700 instead of the correct ₹22,400.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 22400,
        items: [
        { label: "Incorrect balance carried forward", correctAnswer: "Add", amount: 700, reasoning: "The opening (and hence every later) balance is understated by ₹700 because of the carry-forward mistake — the shortfall must be added to correct it." }
        ]
      },
      {
        id: 32,
        category: "Bank Errors",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 27000,
        situation: "The bank wrongly debited the business's account with ₹800 that actually belonged to another customer.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 26200,
        items: [
        { label: "Bank wrongly debited the account", correctAnswer: "Less", amount: 800, reasoning: "The Pass Book has been reduced by a debit that shouldn't be there, so — until the bank corrects it — the Pass Book balance is lower than it should be. Starting from the Cash Book, deduct ₹800 to reach the (currently incorrect) Pass Book figure." }
        ]
      },
      {
        id: 33,
        category: "Bank Errors",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 19400,
        situation: "The bank wrongly credited the business's account with ₹650 that actually belonged to another customer.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 20050,
        items: [
        { label: "Bank wrongly credited the account", correctAnswer: "Add", amount: 650, reasoning: "The Pass Book has been increased by a credit that shouldn't be there, so — until the bank corrects it — the Pass Book balance is higher than it should be. Starting from the Cash Book, add ₹650 to reach the (currently incorrect) Pass Book figure." }
        ]
      },
      {
        id: 34,
        category: "Bank Errors",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 23600,
        situation: "The bank correctly debited a cheque payment, but by mistake entered ₹400 more than the actual amount.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 23200,
        items: [
        { label: "Bank debited an excess amount", correctAnswer: "Less", amount: 400, reasoning: "The excess debit reduces the Pass Book balance more than it should be reduced, so the Pass Book is temporarily lower than correct. Starting from the Cash Book, deduct the ₹400 excess to match the Pass Book figure." }
        ]
      },
      {
        id: 35,
        category: "Bank Errors",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 30900,
        situation: "The bank correctly credited a deposit, but by mistake entered ₹350 more than the actual amount.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 31250,
        items: [
        { label: "Bank credited an excess amount", correctAnswer: "Add", amount: 350, reasoning: "The excess credit increases the Pass Book balance more than it should be increased, so the Pass Book is temporarily higher than correct. Starting from the Cash Book, add the ₹350 excess to match the Pass Book figure." }
        ]
      },
      {
        id: 36,
        category: "Bank Errors",
        difficulty: "Medium",
        startingPoint: "Cash Book",
        startingBalance: 17800,
        situation: "The bank mistakenly entered a ₹1,000 cheque payment belonging to another customer of the same name into the business's account.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 16800,
        items: [
        { label: "Bank entered another customer's transaction", correctAnswer: "Less", amount: 1000, reasoning: "This wrong debit reduces the Pass Book balance for a payment the business never made, so the Pass Book is temporarily lower than correct. Starting from the Cash Book, deduct ₹1,000 to match the Pass Book figure." }
        ]
      },
      {
        id: 37,
        category: "Bank Errors",
        difficulty: "Medium",
        startingPoint: "Cash Book",
        startingBalance: 26500,
        situation: "The bank omitted to debit a standing-instruction payment of ₹700 that it should have made on the due date.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 27200,
        items: [
        { label: "Bank omitted a transaction it should have recorded", correctAnswer: "Add", amount: 700, reasoning: "Since the bank hasn't yet deducted this payment from the Pass Book, the Pass Book balance is temporarily higher than correct. Starting from the Cash Book (which already reflects the payment being due), add ₹700 to match the Pass Book figure." }
        ]
      },
      {
        id: 38,
        category: "Starting Balance & Overdraft",
        difficulty: "Easy",
        startingPoint: "Cash Book",
        startingBalance: 15000,
        situation: "Starting with a favourable (debit) balance as per Cash Book. A cheque of ₹2,000 issued to a supplier has not yet been presented for payment.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 17000,
        items: [
        { label: "Cheque issued, not yet presented (favourable balance, Cash Book start)", correctAnswer: "Add", amount: 2000, reasoning: "The Cash Book already reduced its balance for this cheque; the bank hasn't reduced the Pass Book yet — so the Cash Book is short of the Pass Book, and the item is added." }
        ]
      },
      {
        id: 39,
        category: "Starting Balance & Overdraft",
        difficulty: "Easy",
        startingPoint: "Pass Book",
        startingBalance: 17000,
        situation: "Starting with a favourable (credit) balance as per Pass Book — the same transaction as Case 38. A cheque of ₹2,000 issued to a supplier has not yet been presented for payment.",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 15000,
        items: [
        { label: "Cheque issued, not yet presented (favourable balance, Pass Book start)", correctAnswer: "Less", amount: 2000, reasoning: "This is the exact same transaction as Case 38, but the direction has reversed because the starting point has changed — starting from the Pass Book (currently the larger figure), the item is deducted to reach the Cash Book balance." }
        ]
      },
      {
        id: 40,
        category: "Starting Balance & Overdraft",
        difficulty: "Medium",
        startingPoint: "Cash Book",
        startingBalance: -8000,
        situation: "Starting with an OVERDRAFT (credit balance) as per Cash Book. A cheque of ₹1,500 issued to a supplier has not yet been presented for payment.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: -6500,
        items: [
        { label: "Cheque issued, not yet presented (overdraft, Cash Book start)", correctAnswer: "Add", amount: 1500, reasoning: "Even with an overdraft, the logic doesn't change: the Cash Book has already reduced its balance further for this cheque (deepening the overdraft), but the bank hasn't yet — so the Cash Book figure is 'short of' (more negative than) the Pass Book figure, and the item is still added." }
        ]
      },
      {
        id: 41,
        category: "Starting Balance & Overdraft",
        difficulty: "Medium",
        startingPoint: "Pass Book",
        startingBalance: -6500,
        situation: "Starting with an OVERDRAFT (debit balance) as per Pass Book — the same transaction as Case 40. A cheque of ₹1,500 issued to a supplier has not yet been presented for payment.",
        targetLabel: "Balance as per Cash Book",
        finalBalance: -8000,
        items: [
        { label: "Cheque issued, not yet presented (overdraft, Pass Book start)", correctAnswer: "Less", amount: 1500, reasoning: "This is the same transaction as Case 40, reversed. Starting from the Pass Book overdraft of ₹6,500 (currently the smaller overdraft, i.e. the 'larger' of the two signed figures), the item is deducted to reach the Cash Book's deeper overdraft of ₹8,000." }
        ]
      },
      {
        id: 42,
        category: "Mixed Cases",
        difficulty: "Medium",
        startingPoint: "Cash Book",
        startingBalance: 30000,
        situation: "Prepare the reconciliation using BOTH of the following items, identified separately: (1) A cheque of ₹5,000 issued has not yet been presented for payment. (2) Bank charges of ₹150 have been debited by the bank but not yet entered in the Cash Book.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 34850,
        items: [
        { label: "Cheque issued, not yet presented", correctAnswer: "Add", amount: 5000, reasoning: "The Cash Book already reduced its balance for this cheque; the bank hasn't reduced the Pass Book yet." },
        { label: "Bank charges, not yet in Cash Book", correctAnswer: "Less", amount: 150, reasoning: "The bank has already reduced the Pass Book for its charges; the Cash Book hasn't been reduced yet." }
        ]
      },
      {
        id: 43,
        category: "Mixed Cases",
        difficulty: "Medium",
        startingPoint: "Cash Book",
        startingBalance: 24000,
        situation: "Prepare the reconciliation using BOTH of the following items, identified separately: (1) A cheque of ₹3,500 deposited has not yet been collected by the bank. (2) Interest of ₹200 credited by the bank is not yet entered in the Cash Book.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 20700,
        items: [
        { label: "Cheque deposited, not yet collected", correctAnswer: "Less", amount: 3500, reasoning: "The Cash Book already increased its balance on deposit; the bank hasn't credited it yet." },
        { label: "Interest credited by bank, not yet in Cash Book", correctAnswer: "Add", amount: 200, reasoning: "The bank has already credited the Pass Book with interest; the Cash Book hasn't been updated yet." }
        ]
      },
      {
        id: 44,
        category: "Mixed Cases",
        difficulty: "Medium",
        startingPoint: "Cash Book",
        startingBalance: 21500,
        situation: "Prepare the reconciliation using BOTH of the following items, identified separately: (1) Interest of ₹280 credited by the bank is not yet entered in the Cash Book. (2) Bank charges of ₹120 debited by the bank are not yet entered in the Cash Book.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 21660,
        items: [
        { label: "Interest credited by bank", correctAnswer: "Add", amount: 280, reasoning: "The bank has already credited the Pass Book with interest; the Cash Book hasn't been updated yet." },
        { label: "Bank charges debited by bank", correctAnswer: "Less", amount: 120, reasoning: "The bank has already debited the Pass Book for its charges; the Cash Book hasn't been reduced yet." }
        ]
      },
      {
        id: 45,
        category: "Mixed Cases",
        difficulty: "Medium",
        startingPoint: "Cash Book",
        startingBalance: 28600,
        situation: "Prepare the reconciliation using BOTH of the following items, identified separately: (1) A customer deposited ₹1,800 directly into the bank account, not yet entered in the Cash Book. (2) A cheque of ₹4,200 issued has not yet been presented for payment.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 34600,
        items: [
        { label: "Direct deposit by a customer", correctAnswer: "Add", amount: 1800, reasoning: "The bank already credited the Pass Book for the direct deposit; the Cash Book hasn't recorded it yet." },
        { label: "Cheque issued, not yet presented", correctAnswer: "Add", amount: 4200, reasoning: "The Cash Book already reduced its balance for this cheque; the bank hasn't reduced the Pass Book yet." }
        ]
      },
      {
        id: 46,
        category: "Mixed Cases",
        difficulty: "Medium",
        startingPoint: "Cash Book",
        startingBalance: 32400,
        situation: "Prepare the reconciliation using BOTH of the following items, identified separately: (1) A cheque of ₹2,100, earlier recorded as received, has been dishonoured; not yet entered in the Cash Book. (2) Bank charges of ₹175 debited by the bank are not yet entered in the Cash Book.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 30125,
        items: [
        { label: "Dishonoured cheque", correctAnswer: "Less", amount: 2100, reasoning: "The Cash Book still shows this cheque as realised money, but the bank has already reversed the credit." },
        { label: "Bank charges debited by bank", correctAnswer: "Less", amount: 175, reasoning: "The bank has already debited the Pass Book for its charges; the Cash Book hasn't been reduced yet." }
        ]
      },
      {
        id: 47,
        category: "Mixed Cases",
        difficulty: "Medium",
        startingPoint: "Cash Book",
        startingBalance: 26800,
        situation: "Prepare the reconciliation using BOTH of the following items, identified separately: (1) The bank paid an insurance premium of ₹900 directly, not yet entered in the Cash Book. (2) The bank directly collected ₹1,300 as dividend on investments, not yet entered in the Cash Book.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 27200,
        items: [
        { label: "Direct payment by bank (insurance premium)", correctAnswer: "Less", amount: 900, reasoning: "The bank has already debited the Pass Book for the payment it made; the Cash Book hasn't recorded it yet." },
        { label: "Direct collection by bank (dividend)", correctAnswer: "Add", amount: 1300, reasoning: "The bank has already credited the Pass Book for the dividend it collected; the Cash Book hasn't recorded it yet." }
        ]
      },
      {
        id: 48,
        category: "Mixed Cases",
        difficulty: "Medium",
        startingPoint: "Cash Book",
        startingBalance: 40000,
        situation: "Prepare the reconciliation using ALL THREE of the following timing differences, identified separately: (1) A cheque of ₹6,000 issued has not yet been presented. (2) A cheque of ₹3,500 deposited has not yet been collected. (3) Interest of ₹250 credited by the bank is not yet entered in the Cash Book.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 42750,
        items: [
        { label: "Cheque issued, not yet presented", correctAnswer: "Add", amount: 6000, reasoning: "The Cash Book already reduced its balance for this cheque; the bank hasn't reduced the Pass Book yet." },
        { label: "Cheque deposited, not yet collected", correctAnswer: "Less", amount: 3500, reasoning: "The Cash Book already increased its balance on deposit; the bank hasn't credited it yet." },
        { label: "Interest credited by bank", correctAnswer: "Add", amount: 250, reasoning: "The bank has already credited the Pass Book with interest; the Cash Book hasn't been updated yet." }
        ]
      },
      {
        id: 49,
        category: "Mixed Cases",
        difficulty: "Medium",
        startingPoint: "Cash Book",
        startingBalance: 22000,
        situation: "Prepare the reconciliation using BOTH of the following items, identified separately: (1) A cheque of ₹3,000 issued has not yet been presented for payment (a timing difference). (2) A cheque of ₹1,200 received and deposited was completely omitted from the Cash Book (a Cash Book error).",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 26200,
        items: [
        { label: "Cheque issued, not yet presented (timing difference)", correctAnswer: "Add", amount: 3000, reasoning: "The Cash Book already reduced its balance for this cheque; the bank hasn't reduced the Pass Book yet." },
        { label: "Cheque deposit omitted from Cash Book (Cash Book error)", correctAnswer: "Add", amount: 1200, reasoning: "Since this receipt was never recorded at all, the Cash Book balance is too low by the omitted amount — it must be added to reach the correct figure." }
        ]
      },
      {
        id: 50,
        category: "Mixed Cases",
        difficulty: "Medium",
        startingPoint: "Cash Book",
        startingBalance: 29500,
        situation: "Prepare the reconciliation using BOTH of the following items, identified separately: (1) A cheque of ₹2,700 deposited has not yet been collected by the bank (a timing difference). (2) The bank wrongly debited the account with ₹450 that belonged to another customer (a bank error).",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 26350,
        items: [
        { label: "Cheque deposited, not yet collected (timing difference)", correctAnswer: "Less", amount: 2700, reasoning: "The Cash Book already increased its balance on deposit; the bank hasn't credited it yet." },
        { label: "Bank wrongly debited the account (bank error)", correctAnswer: "Less", amount: 450, reasoning: "The wrong debit reduces the Pass Book balance for a payment the business never made, so — until corrected — the Pass Book is lower than it should be." }
        ]
      },
      {
        id: 51,
        category: "Mixed Cases",
        difficulty: "Medium",
        startingPoint: "Cash Book",
        startingBalance: 18800,
        situation: "Prepare the reconciliation using BOTH of the following Cash Book errors, identified separately: (1) A cheque of ₹1,000 issued to a supplier was recorded TWICE in the Cash Book. (2) A cheque of ₹2,200, correctly issued, was recorded in the Cash Book as only ₹1,700.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 19300,
        items: [
        { label: "Cheque issued, entered twice (Cash Book error)", correctAnswer: "Add", amount: 1000, reasoning: "Recording the same payment twice deducts it from the Cash Book balance twice, making the balance too low by the duplicate amount — it must be added back." },
        { label: "Cheque issued, recorded ₹500 short (Cash Book error)", correctAnswer: "Less", amount: 500, reasoning: "The Cash Book recorded ₹500 less payment than actually made, so its balance is overstated by that shortfall — it must be deducted." }
        ]
      },
      {
        id: 52,
        category: "Mixed Cases",
        difficulty: "Medium",
        startingPoint: "Cash Book",
        startingBalance: 25300,
        situation: "Prepare the reconciliation using BOTH of the following bank errors, identified separately: (1) The bank wrongly debited the account with ₹600 belonging to another customer. (2) The bank wrongly credited the account with ₹350 belonging to another customer.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 25050,
        items: [
        { label: "Bank wrongly debited the account", correctAnswer: "Less", amount: 600, reasoning: "The wrong debit reduces the Pass Book balance for a payment the business never made — until corrected, the Pass Book is lower than it should be." },
        { label: "Bank wrongly credited the account", correctAnswer: "Add", amount: 350, reasoning: "The wrong credit increases the Pass Book balance for a receipt the business never actually got — until corrected, the Pass Book is higher than it should be." }
        ]
      },
      {
        id: 53,
        category: "Mixed Cases",
        difficulty: "Medium",
        startingPoint: "Cash Book",
        startingBalance: 50000,
        situation: "This is a full reconciliation with FIVE different differences — identify each one separately: (1) A cheque of ₹7,000 issued has not yet been presented. (2) A cheque of ₹4,500 deposited has not yet been collected. (3) Bank charges of ₹180 debited by the bank are not yet in the Cash Book. (4) Interest of ₹320 credited by the bank is not yet in the Cash Book. (5) A customer deposited ₹1,600 directly into the bank account, not yet entered in the Cash Book.",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 54240,
        items: [
        { label: "Cheque issued, not yet presented", correctAnswer: "Add", amount: 7000, reasoning: "The Cash Book already reduced its balance for this cheque; the bank hasn't reduced the Pass Book yet." },
        { label: "Cheque deposited, not yet collected", correctAnswer: "Less", amount: 4500, reasoning: "The Cash Book already increased its balance on deposit; the bank hasn't credited it yet." },
        { label: "Bank charges debited by bank", correctAnswer: "Less", amount: 180, reasoning: "The bank has already debited the Pass Book for its charges; the Cash Book hasn't been reduced yet." },
        { label: "Interest credited by bank", correctAnswer: "Add", amount: 320, reasoning: "The bank has already credited the Pass Book with interest; the Cash Book hasn't been updated yet." },
        { label: "Direct deposit by a customer", correctAnswer: "Add", amount: 1600, reasoning: "The bank already credited the Pass Book for the direct deposit; the Cash Book hasn't recorded it yet." }
        ]
      }
      ,
      {
        id: 54,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Pass Book",
        startingBalance: 26000,
        situation: "A cheque of ₹4,000 issued to a supplier has not yet been presented for payment at the bank. (Same situation as Case 1, but this time you are given the Balance as per Pass Book, not the Cash Book.)",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 22000,
        items: [
        { label: "Cheque issued, not yet presented (starting from Pass Book)", correctAnswer: "Less", amount: 4000, reasoning: "This is the same transaction as Case 1, but now we start from the Pass Book instead of the Cash Book, so the direction reverses. The business has already reduced its Cash Book balance for this cheque, but the bank hasn't reduced the Pass Book yet since the payee hasn't presented it. Since we are starting from the (already-adjusted) Pass Book and moving towards the Cash Book, the treatment flips to 'Less'." }
        ]
      },
      {
        id: 55,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Pass Book",
        startingBalance: 15300,
        situation: "A cheque of ₹3,200 deposited into the bank has not yet been collected/credited by the bank. (Same situation as Case 2, but this time you are given the Balance as per Pass Book, not the Cash Book.)",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 18500,
        items: [
        { label: "Cheque deposited, not yet collected (starting from Pass Book)", correctAnswer: "Add", amount: 3200, reasoning: "This is the same transaction as Case 2, but now we start from the Pass Book instead of the Cash Book, so the direction reverses. The business already increased its Cash Book balance on deposit, but the bank will only credit it once the cheque actually clears. Since we are starting from the (already-adjusted) Pass Book and moving towards the Cash Book, the treatment flips to 'Add'." }
        ]
      },
      {
        id: 56,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Pass Book",
        startingBalance: 24900,
        situation: "A customer's cheque for ₹2,600, earlier deposited and recorded as received, has now been dishonoured by the bank; the dishonour is not yet entered in the Cash Book. (Same situation as Case 3, but this time you are given the Balance as per Pass Book, not the Cash Book.)",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 27500,
        items: [
        { label: "Cheque deposited, later dishonoured (starting from Pass Book)", correctAnswer: "Add", amount: 2600, reasoning: "This is the same transaction as Case 3, but now we start from the Pass Book instead of the Cash Book, so the direction reverses. The Cash Book still shows this cheque as good money received, but the bank has already reversed the credit since it bounced. Since we are starting from the (already-adjusted) Pass Book and moving towards the Cash Book, the treatment flips to 'Add'." }
        ]
      },
      {
        id: 57,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Pass Book",
        startingBalance: 30780,
        situation: "The bank has debited ₹220 as bank charges for the quarter; this is not yet entered in the Cash Book. (Same situation as Case 4, but this time you are given the Balance as per Pass Book, not the Cash Book.)",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 31000,
        items: [
        { label: "Bank charges debited (starting from Pass Book)", correctAnswer: "Add", amount: 220, reasoning: "This is the same transaction as Case 4, but now we start from the Pass Book instead of the Cash Book, so the direction reverses. The bank has already reduced the Pass Book for its own charges; the business hasn't reduced its Cash Book yet. Since we are starting from the (already-adjusted) Pass Book and moving towards the Cash Book, the treatment flips to 'Add'." }
        ]
      },
      {
        id: 58,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Pass Book",
        startingBalance: 15260,
        situation: "The account was overdrawn during the month, and the bank has debited ₹340 as interest on the overdrawn balance; this is not yet entered in the Cash Book. (Same situation as Case 5, but this time you are given the Balance as per Pass Book, not the Cash Book.)",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 15600,
        items: [
        { label: "Interest charged by bank (on overdraft) (starting from Pass Book)", correctAnswer: "Add", amount: 340, reasoning: "This is the same transaction as Case 5, but now we start from the Pass Book instead of the Cash Book, so the direction reverses. The bank has already debited the Pass Book for the interest it charged; the business only finds out once it checks the Pass Book. Since we are starting from the (already-adjusted) Pass Book and moving towards the Cash Book, the treatment flips to 'Add'." }
        ]
      },
      {
        id: 59,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Pass Book",
        startingBalance: 23850,
        situation: "The bank has debited ₹150 as commission for collecting a bill on the business's behalf; this is not yet entered in the Cash Book. (Same situation as Case 6, but this time you are given the Balance as per Pass Book, not the Cash Book.)",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 24000,
        items: [
        { label: "Commission charged by bank (starting from Pass Book)", correctAnswer: "Add", amount: 150, reasoning: "This is the same transaction as Case 6, but now we start from the Pass Book instead of the Cash Book, so the direction reverses. The bank has already reduced the Pass Book for its commission; the business hasn't recorded this charge yet. Since we are starting from the (already-adjusted) Pass Book and moving towards the Cash Book, the treatment flips to 'Add'." }
        ]
      },
      {
        id: 60,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Pass Book",
        startingBalance: 20100,
        situation: "The bank has credited ₹300 as interest on the balance kept with it; this is not yet entered in the Cash Book. (Same situation as Case 7, but this time you are given the Balance as per Pass Book, not the Cash Book.)",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 19800,
        items: [
        { label: "Interest credited by bank (starting from Pass Book)", correctAnswer: "Less", amount: 300, reasoning: "This is the same transaction as Case 7, but now we start from the Pass Book instead of the Cash Book, so the direction reverses. The bank has already increased the Pass Book for the interest allowed; the business hasn't recorded it yet. Since we are starting from the (already-adjusted) Pass Book and moving towards the Cash Book, the treatment flips to 'Less'." }
        ]
      },
      {
        id: 61,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Pass Book",
        startingBalance: 34300,
        situation: "The bank has directly collected ₹800 as dividend on the business's investments; this is not yet entered in the Cash Book. (Same situation as Case 8, but this time you are given the Balance as per Pass Book, not the Cash Book.)",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 33500,
        items: [
        { label: "Dividend collected by bank (starting from Pass Book)", correctAnswer: "Less", amount: 800, reasoning: "This is the same transaction as Case 8, but now we start from the Pass Book instead of the Cash Book, so the direction reverses. The bank already credited the Pass Book on collecting the dividend for the business; the Cash Book hasn't been updated yet. Since we are starting from the (already-adjusted) Pass Book and moving towards the Cash Book, the treatment flips to 'Less'." }
        ]
      },
      {
        id: 62,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Pass Book",
        startingBalance: 22300,
        situation: "Under a standing instruction, the bank has directly collected ₹1,100 of interest due on the business's fixed deposit; this is not yet entered in the Cash Book. (Same situation as Case 9, but this time you are given the Balance as per Pass Book, not the Cash Book.)",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 21200,
        items: [
        { label: "Interest collected by bank on the firm's behalf (starting from Pass Book)", correctAnswer: "Less", amount: 1100, reasoning: "This is the same transaction as Case 9, but now we start from the Pass Book instead of the Cash Book, so the direction reverses. The bank already credited the Pass Book on collecting the interest for the business; the Cash Book hasn't been updated yet. Since we are starting from the (already-adjusted) Pass Book and moving towards the Cash Book, the treatment flips to 'Less'." }
        ]
      },
      {
        id: 63,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Pass Book",
        startingBalance: 19300,
        situation: "A customer deposited ₹2,000 directly into the business's bank account; the business has not yet entered this in its Cash Book. (Same situation as Case 10, but this time you are given the Balance as per Pass Book, not the Cash Book.)",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 17300,
        items: [
        { label: "Direct deposit by a customer (starting from Pass Book)", correctAnswer: "Less", amount: 2000, reasoning: "This is the same transaction as Case 10, but now we start from the Pass Book instead of the Cash Book, so the direction reverses. The bank credited the Pass Book as soon as the direct deposit was made; the business hasn't recorded it in the Cash Book yet. Since we are starting from the (already-adjusted) Pass Book and moving towards the Cash Book, the treatment flips to 'Less'." }
        ]
      },
      {
        id: 64,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Pass Book",
        startingBalance: 27600,
        situation: "Under a standing instruction, the bank made a direct payment of ₹1,400 to one of the business's suppliers; this is not yet entered in the Cash Book. (Same situation as Case 11, but this time you are given the Balance as per Pass Book, not the Cash Book.)",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 29000,
        items: [
        { label: "Direct payment made by bank (starting from Pass Book)", correctAnswer: "Add", amount: 1400, reasoning: "This is the same transaction as Case 11, but now we start from the Pass Book instead of the Cash Book, so the direction reverses. The bank has already debited the Pass Book for the payment it made; the business hasn't recorded it in the Cash Book yet. Since we are starting from the (already-adjusted) Pass Book and moving towards the Cash Book, the treatment flips to 'Add'." }
        ]
      },
      {
        id: 65,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Pass Book",
        startingBalance: 25450,
        situation: "The bank paid an insurance premium of ₹950 directly under a standing instruction; this is not yet entered in the Cash Book. (Same situation as Case 12, but this time you are given the Balance as per Pass Book, not the Cash Book.)",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 26400,
        items: [
        { label: "Insurance premium paid directly by bank (starting from Pass Book)", correctAnswer: "Add", amount: 950, reasoning: "This is the same transaction as Case 12, but now we start from the Pass Book instead of the Cash Book, so the direction reverses. The bank has already debited the Pass Book for the premium it paid; the business hasn't recorded this payment yet. Since we are starting from the (already-adjusted) Pass Book and moving towards the Cash Book, the treatment flips to 'Add'." }
        ]
      },
      {
        id: 66,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Pass Book",
        startingBalance: 13500,
        situation: "The bank paid the office rent of ₹1,200 directly under a standing instruction; this is not yet entered in the Cash Book. (Same situation as Case 13, but this time you are given the Balance as per Pass Book, not the Cash Book.)",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 14700,
        items: [
        { label: "Rent paid directly by bank (starting from Pass Book)", correctAnswer: "Add", amount: 1200, reasoning: "This is the same transaction as Case 13, but now we start from the Pass Book instead of the Cash Book, so the direction reverses. The bank has already debited the Pass Book for the rent it paid; the business hasn't recorded it in the Cash Book yet. Since we are starting from the (already-adjusted) Pass Book and moving towards the Cash Book, the treatment flips to 'Add'." }
        ]
      },
      {
        id: 67,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Pass Book",
        startingBalance: 22200,
        situation: "A bill of exchange for ₹1,700, held for collection, has been collected by the bank on maturity; this is not yet entered in the Cash Book. (Same situation as Case 14, but this time you are given the Balance as per Pass Book, not the Cash Book.)",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 20500,
        items: [
        { label: "Bill collected by bank (starting from Pass Book)", correctAnswer: "Less", amount: 1700, reasoning: "This is the same transaction as Case 14, but now we start from the Pass Book instead of the Cash Book, so the direction reverses. The bank has already credited the Pass Book on collecting the bill on maturity; the business hasn't recorded this yet. Since we are starting from the (already-adjusted) Pass Book and moving towards the Cash Book, the treatment flips to 'Less'." }
        ]
      },
      {
        id: 68,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Pass Book",
        startingBalance: 23010,
        situation: "The bank charged ₹90 as fees for collecting a bill of exchange on the business's behalf; this is not yet entered in the Cash Book. (Same situation as Case 15, but this time you are given the Balance as per Pass Book, not the Cash Book.)",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 23100,
        items: [
        { label: "Bank's bill-collection charges (starting from Pass Book)", correctAnswer: "Add", amount: 90, reasoning: "This is the same transaction as Case 15, but now we start from the Pass Book instead of the Cash Book, so the direction reverses. The bank has already debited the Pass Book for its collection charges; the business hasn't recorded this yet. Since we are starting from the (already-adjusted) Pass Book and moving towards the Cash Book, the treatment flips to 'Add'." }
        ]
      },
      {
        id: 69,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Pass Book",
        startingBalance: 38700,
        situation: "The maturity proceeds of ₹2,500 from an investment were credited by the bank directly; this is not yet entered in the Cash Book. (Same situation as Case 16, but this time you are given the Balance as per Pass Book, not the Cash Book.)",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 36200,
        items: [
        { label: "Other direct bank credit (investment proceeds) (starting from Pass Book)", correctAnswer: "Less", amount: 2500, reasoning: "This is the same transaction as Case 16, but now we start from the Pass Book instead of the Cash Book, so the direction reverses. The bank has already credited the Pass Book with the maturity proceeds; the business hasn't recorded this receipt yet. Since we are starting from the (already-adjusted) Pass Book and moving towards the Cash Book, the treatment flips to 'Less'." }
        ]
      },
      {
        id: 70,
        category: "Timing Differences & Bank Entries",
        difficulty: "Easy",
        startingPoint: "Pass Book",
        startingBalance: 12400,
        situation: "The bank debited ₹500 as locker rent for the year, as per standing instructions; this is not yet entered in the Cash Book. (Same situation as Case 17, but this time you are given the Balance as per Pass Book, not the Cash Book.)",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 12900,
        items: [
        { label: "Other direct bank debit (locker rent) (starting from Pass Book)", correctAnswer: "Add", amount: 500, reasoning: "This is the same transaction as Case 17, but now we start from the Pass Book instead of the Cash Book, so the direction reverses. The bank has already debited the Pass Book for the locker rent; the business hasn't recorded this payment yet. Since we are starting from the (already-adjusted) Pass Book and moving towards the Cash Book, the treatment flips to 'Add'." }
        ]
      },
      {
        id: 71,
        category: "Starting Balance & Overdraft",
        difficulty: "Medium",
        startingPoint: "Cash Book",
        startingBalance: 18000,
        situation: "A cheque of ₹2,500 deposited into the bank has not yet been collected/credited by the bank. (Favourable Cash Book balance.)",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 15500,
        items: [
        { label: "Cheque deposited, not yet collected (favourable, Cash Book start)", correctAnswer: "Less", amount: 2500, reasoning: "The Cash Book already increased its balance on deposit; the bank hasn't credited it yet, so the Cash Book is currently ahead of the Pass Book." }
        ]
      },
      {
        id: 72,
        category: "Starting Balance & Overdraft",
        difficulty: "Medium",
        startingPoint: "Pass Book",
        startingBalance: 15500,
        situation: "A cheque of ₹2,500 deposited into the bank has not yet been collected/credited by the bank. (Same transaction, but starting from the favourable Pass Book balance.)",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 18000,
        items: [
        { label: "Cheque deposited, not yet collected (favourable, Pass Book start)", correctAnswer: "Add", amount: 2500, reasoning: "This is the same transaction, reversed: starting from the Pass Book (which hasn't been credited yet), the item is added to reach the Cash Book figure." }
        ]
      },
      {
        id: 73,
        category: "Starting Balance & Overdraft",
        difficulty: "Medium",
        startingPoint: "Cash Book",
        startingBalance: -5000,
        situation: "A cheque of ₹2,500 deposited into the bank has not yet been collected/credited by the bank. (Overdrawn/overdraft Cash Book balance.)",
        targetLabel: "Balance as per Pass Book",
        finalBalance: -7500,
        items: [
        { label: "Cheque deposited, not yet collected (overdraft, Cash Book start)", correctAnswer: "Less", amount: 2500, reasoning: "The Cash Book already increased its balance on deposit; the bank hasn't credited it yet, so the Cash Book is currently ahead of the Pass Book. Even with an overdraft, the same Add/Less direction applies — only the sign of the balance is negative." }
        ]
      },
      {
        id: 74,
        category: "Starting Balance & Overdraft",
        difficulty: "Medium",
        startingPoint: "Pass Book",
        startingBalance: -7500,
        situation: "A cheque of ₹2,500 deposited into the bank has not yet been collected/credited by the bank. (Same transaction, overdraft, but starting from the Pass Book balance.)",
        targetLabel: "Balance as per Cash Book",
        finalBalance: -5000,
        items: [
        { label: "Cheque deposited, not yet collected (overdraft, Pass Book start)", correctAnswer: "Add", amount: 2500, reasoning: "This is the same transaction, reversed: starting from the Pass Book (which hasn't been credited yet), the item is added to reach the Cash Book figure. Even with an overdraft, the direction still reverses purely because the starting point changed." }
        ]
      },
      {
        id: 75,
        category: "Starting Balance & Overdraft",
        difficulty: "Medium",
        startingPoint: "Cash Book",
        startingBalance: 22000,
        situation: "Bank charges of ₹300 have been debited by the bank but not yet entered in the Cash Book. (Favourable Cash Book balance.)",
        targetLabel: "Balance as per Pass Book",
        finalBalance: 21700,
        items: [
        { label: "Bank charges, not yet in Cash Book (favourable, Cash Book start)", correctAnswer: "Less", amount: 300, reasoning: "The bank has already reduced the Pass Book for its charges; the Cash Book hasn't been reduced yet, so the Cash Book is currently ahead of the Pass Book." }
        ]
      },
      {
        id: 76,
        category: "Starting Balance & Overdraft",
        difficulty: "Medium",
        startingPoint: "Pass Book",
        startingBalance: 21700,
        situation: "Bank charges of ₹300 have been debited by the bank but not yet entered in the Cash Book. (Same transaction, but starting from the favourable Pass Book balance.)",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 22000,
        items: [
        { label: "Bank charges, not yet in Cash Book (favourable, Pass Book start)", correctAnswer: "Add", amount: 300, reasoning: "This is the same transaction, reversed: starting from the Pass Book (already reduced for the charge), the item is added to reach the Cash Book figure." }
        ]
      },
      {
        id: 77,
        category: "Starting Balance & Overdraft",
        difficulty: "Medium",
        startingPoint: "Cash Book",
        startingBalance: -4000,
        situation: "Bank charges of ₹300 have been debited by the bank but not yet entered in the Cash Book. (Overdrawn/overdraft Cash Book balance.)",
        targetLabel: "Balance as per Pass Book",
        finalBalance: -4300,
        items: [
        { label: "Bank charges, not yet in Cash Book (overdraft, Cash Book start)", correctAnswer: "Less", amount: 300, reasoning: "The bank has already reduced the Pass Book for its charges; the Cash Book hasn't been reduced yet, so the Cash Book is currently ahead of the Pass Book. Even with an overdraft, the same Add/Less direction applies — only the sign of the balance is negative." }
        ]
      },
      {
        id: 78,
        category: "Starting Balance & Overdraft",
        difficulty: "Medium",
        startingPoint: "Pass Book",
        startingBalance: -4300,
        situation: "Bank charges of ₹300 have been debited by the bank but not yet entered in the Cash Book. (Same transaction, overdraft, but starting from the Pass Book balance.)",
        targetLabel: "Balance as per Cash Book",
        finalBalance: -4000,
        items: [
        { label: "Bank charges, not yet in Cash Book (overdraft, Pass Book start)", correctAnswer: "Add", amount: 300, reasoning: "This is the same transaction, reversed: starting from the Pass Book (already reduced for the charge), the item is added to reach the Cash Book figure. Even with an overdraft, the direction still reverses purely because the starting point changed." }
        ]
      },

      /* ---- Pass Book + Favourable balance: Cash Book Errors ---- */
      {
        id: 79,
        category: "Cash Book Errors",
        difficulty: "Easy",
        startingPoint: "Pass Book",
        startingBalance: 29000,
        situation: "A cheque of ₹3,600 issued to a creditor (and already paid by the bank) was completely omitted from the Cash Book. You are given the Balance as per Pass Book.",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 32600,
        items: [
        { label: "Cheque issued, omitted from Cash Book (Pass Book start)", correctAnswer: "Add", amount: 3600, reasoning: "The Pass Book already reflects the payment, but the Cash Book never recorded it — so the Cash Book balance is too HIGH by the omitted amount. Starting from the (correct) Pass Book, add ₹3,600 to reach the Cash Book's overstated figure." }
        ]
      },
      {
        id: 80,
        category: "Cash Book Errors",
        difficulty: "Easy",
        startingPoint: "Pass Book",
        startingBalance: 21000,
        situation: "A cheque of ₹1,800 issued to a supplier was, by mistake, entered twice on the payments side of the Cash Book. You are given the Balance as per Pass Book.",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 19200,
        items: [
        { label: "Cheque issued, entered twice in Cash Book (Pass Book start)", correctAnswer: "Less", amount: 1800, reasoning: "The double entry made the Cash Book too LOW by one extra deduction. Starting from the correct Pass Book figure, deduct ₹1,800 to reach the Cash Book's understated balance." }
        ]
      },
      {
        id: 81,
        category: "Cash Book Errors",
        difficulty: "Easy",
        startingPoint: "Pass Book",
        startingBalance: 26500,
        situation: "A cheque of ₹2,200 deposited into the bank was completely omitted from the receipts side of the Cash Book. You are given the Balance as per Pass Book.",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 24300,
        items: [
        { label: "Cheque deposited, omitted from Cash Book (Pass Book start)", correctAnswer: "Less", amount: 2200, reasoning: "The Pass Book already reflects the collection, but the Cash Book never recorded the receipt — so the Cash Book balance is too LOW by the omitted amount. Starting from the Pass Book, deduct ₹2,200 to reach the Cash Book's understated figure." }
        ]
      },
      {
        id: 82,
        category: "Cash Book Errors",
        difficulty: "Easy",
        startingPoint: "Pass Book",
        startingBalance: 19600,
        situation: "A cheque deposited into the bank was recorded in the Cash Book ₹900 short of its actual amount. You are given the Balance as per Pass Book.",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 18700,
        items: [
        { label: "Cheque deposited, recorded short (Pass Book start)", correctAnswer: "Less", amount: 900, reasoning: "The Cash Book under-recorded the receipt, so it's too LOW by the shortfall. Starting from the correct Pass Book figure, deduct ₹900 to reach the Cash Book's understated balance." }
        ]
      },
      {
        id: 83,
        category: "Cash Book Errors",
        difficulty: "Easy",
        startingPoint: "Pass Book",
        startingBalance: 24300,
        situation: "A cheque issued to a supplier was recorded in the Cash Book ₹600 short of its actual amount. You are given the Balance as per Pass Book.",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 24900,
        items: [
        { label: "Cheque issued, recorded short (Pass Book start)", correctAnswer: "Add", amount: 600, reasoning: "The Cash Book under-recorded the payment, so it's too HIGH by the shortfall. Starting from the correct Pass Book figure, add ₹600 to reach the Cash Book's overstated balance." }
        ]
      },
      {
        id: 84,
        category: "Cash Book Errors",
        difficulty: "Medium",
        startingPoint: "Pass Book",
        startingBalance: 31200,
        situation: "The receipts side of the Cash Book was overcast (added up too high) by ₹700. You are given the Balance as per Pass Book.",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 31900,
        items: [
        { label: "Receipts side overcast (Pass Book start)", correctAnswer: "Add", amount: 700, reasoning: "An overcast receipts side makes the Cash Book balance too HIGH. Starting from the correct Pass Book figure, add ₹700 to reach the Cash Book's inflated balance." }
        ]
      },
      {
        id: 85,
        category: "Cash Book Errors",
        difficulty: "Medium",
        startingPoint: "Pass Book",
        startingBalance: 17400,
        situation: "A cash receipt of ₹2,500 was wrongly entered on the payments side of the Cash Book instead of the receipts side. You are given the Balance as per Pass Book.",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 14900,
        items: [
        { label: "Receipt wrongly entered on the payments side (Pass Book start)", correctAnswer: "Less", amount: 2500, reasoning: "Entering a receipt as a payment reduces the Cash Book balance twice over — once for the missed receipt, once for the wrongful deduction. Starting from the Pass Book, deduct ₹2,500 to reach the Cash Book's much lower balance." }
        ]
      },
      {
        id: 86,
        category: "Cash Book Errors",
        difficulty: "Medium",
        startingPoint: "Pass Book",
        startingBalance: 22900,
        situation: "The Cash Book's closing balance was carried forward ₹850 lower than it should have been. You are given the Balance as per Pass Book.",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 22050,
        items: [
        { label: "Incorrect balance carried forward (Pass Book start)", correctAnswer: "Less", amount: 850, reasoning: "The Cash Book itself now shows a balance ₹850 lower than correct. Starting from the (unaffected) Pass Book, deduct ₹850 to reach the Cash Book's understated figure." }
        ]
      },

      /* ---- Pass Book + Favourable balance: Bank Errors ---- */
      {
        id: 87,
        category: "Bank Errors",
        difficulty: "Easy",
        startingPoint: "Pass Book",
        startingBalance: 28100,
        situation: "The bank wrongly debited the business's account with ₹950 that actually belonged to another customer. You are given the Balance as per Pass Book.",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 29050,
        items: [
        { label: "Bank wrongly debited the account (Pass Book start)", correctAnswer: "Add", amount: 950, reasoning: "The Pass Book has been reduced by a debit that doesn't belong to this account, so — until the bank corrects it — the Pass Book is lower than the (correct) Cash Book. Starting from the Pass Book, add ₹950 to reach the Cash Book figure." }
        ]
      },
      {
        id: 88,
        category: "Bank Errors",
        difficulty: "Easy",
        startingPoint: "Pass Book",
        startingBalance: 20700,
        situation: "The bank wrongly credited the business's account with ₹600 that actually belonged to another customer. You are given the Balance as per Pass Book.",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 20100,
        items: [
        { label: "Bank wrongly credited the account (Pass Book start)", correctAnswer: "Less", amount: 600, reasoning: "The Pass Book has been inflated by a credit that doesn't belong to this account. Starting from the Pass Book, deduct ₹600 to reach the (correct, lower) Cash Book figure." }
        ]
      },
      {
        id: 89,
        category: "Bank Errors",
        difficulty: "Easy",
        startingPoint: "Pass Book",
        startingBalance: 33800,
        situation: "The bank debited the account with ₹500 more than the actual cheque amount by mistake. You are given the Balance as per Pass Book.",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 34300,
        items: [
        { label: "Bank debited an excess amount (Pass Book start)", correctAnswer: "Add", amount: 500, reasoning: "The excess debit makes the Pass Book lower than it should be until corrected. Starting from the Pass Book, add ₹500 to reach the (correct) Cash Book figure." }
        ]
      },
      {
        id: 90,
        category: "Bank Errors",
        difficulty: "Easy",
        startingPoint: "Pass Book",
        startingBalance: 16900,
        situation: "The bank credited the account with ₹450 more than the actual deposit amount by mistake. You are given the Balance as per Pass Book.",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 16450,
        items: [
        { label: "Bank credited an excess amount (Pass Book start)", correctAnswer: "Less", amount: 450, reasoning: "The excess credit makes the Pass Book higher than it should be until corrected. Starting from the Pass Book, deduct ₹450 to reach the (correct) Cash Book figure." }
        ]
      },
      {
        id: 91,
        category: "Bank Errors",
        difficulty: "Medium",
        startingPoint: "Pass Book",
        startingBalance: 25600,
        situation: "The bank entered another customer's cheque payment of ₹1,100 against this firm's account by mistake. You are given the Balance as per Pass Book.",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 26700,
        items: [
        { label: "Bank entered another customer's transaction (Pass Book start)", correctAnswer: "Add", amount: 1100, reasoning: "Someone else's payment being wrongly debited here has understated the Pass Book. Starting from the Pass Book, add ₹1,100 to reach the (correct) Cash Book figure." }
        ]
      },
      {
        id: 92,
        category: "Bank Errors",
        difficulty: "Medium",
        startingPoint: "Pass Book",
        startingBalance: 30400,
        situation: "The bank omitted to record a cheque payment of ₹800 that it should have debited to this account. You are given the Balance as per Pass Book.",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 29600,
        items: [
        { label: "Bank omitted a transaction it should have recorded (Pass Book start)", correctAnswer: "Less", amount: 800, reasoning: "The missing debit has overstated the Pass Book. Starting from the Pass Book, deduct ₹800 to reach the (correct, lower) Cash Book figure." }
        ]
      },

      /* ---- Pass Book + Favourable balance: Mixed Cases ---- */
      {
        id: 93,
        category: "Mixed Cases",
        difficulty: "Medium",
        startingPoint: "Pass Book",
        startingBalance: 36500,
        situation: "Prepare the reconciliation using BOTH of the following items, identified separately, starting from the Balance as per Pass Book: (1) A cheque of ₹5,500 issued has not yet been presented for payment. (2) Bank charges of ₹200 have been debited by the bank but not yet entered in the Cash Book.",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 31200,
        items: [
        { label: "Cheque issued, not yet presented (Pass Book start)", correctAnswer: "Less", amount: 5500, reasoning: "The Cash Book has already reduced its balance for this cheque; the Pass Book hasn't yet. Starting from the Pass Book, deduct ₹5,500 to reach the Cash Book figure." },
        { label: "Bank charges, not yet in Cash Book (Pass Book start)", correctAnswer: "Add", amount: 200, reasoning: "The Pass Book has already been reduced for the bank's charge; the Cash Book hasn't. Starting from the Pass Book, add ₹200 to reach the Cash Book figure." }
        ]
      },
      {
        id: 94,
        category: "Mixed Cases",
        difficulty: "Medium",
        startingPoint: "Pass Book",
        startingBalance: 28200,
        situation: "Prepare the reconciliation using BOTH of the following items, identified separately, starting from the Balance as per Pass Book: (1) A cheque of ₹3,100 deposited into the bank has not yet been collected. (2) Interest of ₹250 credited by the bank has not yet been entered in the Cash Book.",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 31050,
        items: [
        { label: "Cheque deposited, not yet collected (Pass Book start)", correctAnswer: "Add", amount: 3100, reasoning: "The Cash Book has already recorded the receipt of this cheque; the Pass Book hasn't credited it yet. Starting from the Pass Book, add ₹3,100 to reach the Cash Book figure." },
        { label: "Interest credited by bank, not yet in Cash Book (Pass Book start)", correctAnswer: "Less", amount: 250, reasoning: "The Pass Book already reflects the interest; the Cash Book hasn't recorded it yet. Starting from the Pass Book, deduct ₹250 to reach the Cash Book figure." }
        ]
      },
      {
        id: 95,
        category: "Mixed Cases",
        difficulty: "Medium",
        startingPoint: "Pass Book",
        startingBalance: 41000,
        situation: "Prepare the reconciliation using ALL THREE of the following items, identified separately, starting from the Balance as per Pass Book: (1) A cheque of ₹6,500 issued has not yet been presented for payment. (2) A cheque of ₹3,800 deposited has not yet been collected. (3) Interest of ₹300 credited by the bank has not yet been entered in the Cash Book.",
        targetLabel: "Balance as per Cash Book",
        finalBalance: 38000,
        items: [
        { label: "Cheque issued, not yet presented (Pass Book start)", correctAnswer: "Less", amount: 6500, reasoning: "The Cash Book has already reduced its balance for this cheque; the Pass Book hasn't. Deduct ₹6,500 starting from the Pass Book." },
        { label: "Cheque deposited, not yet collected (Pass Book start)", correctAnswer: "Add", amount: 3800, reasoning: "The Cash Book has already recorded the receipt; the Pass Book hasn't credited it yet. Add ₹3,800 starting from the Pass Book." },
        { label: "Interest credited by bank (Pass Book start)", correctAnswer: "Less", amount: 300, reasoning: "The Pass Book already reflects this interest; the Cash Book hasn't. Deduct ₹300 starting from the Pass Book." }
        ]
      },

      /* ---- Pass Book + Overdraft, spread across categories that
         previously had no overdraft coverage at all ---- */
      {
        id: 96,
        category: "Timing Differences & Bank Entries",
        difficulty: "Medium",
        startingPoint: "Pass Book",
        startingBalance: -9200,
        situation: "The Pass Book shows an OVERDRAFT of ₹9,200. A cheque of ₹2,800 deposited into the bank has not yet been collected/credited.",
        targetLabel: "Balance as per Cash Book",
        finalBalance: -6400,
        items: [
        { label: "Cheque deposited, not yet collected (overdraft, Pass Book start)", correctAnswer: "Add", amount: 2800, reasoning: "The Cash Book already recorded this receipt, reducing the overdraft in its own books; the Pass Book hasn't credited it yet. Starting from the Pass Book's deeper overdraft, add ₹2,800 to reach the Cash Book's smaller overdraft." }
        ]
      },
      {
        id: 97,
        category: "Timing Differences & Bank Entries",
        difficulty: "Medium",
        startingPoint: "Pass Book",
        startingBalance: -5600,
        situation: "The Pass Book shows an OVERDRAFT of ₹5,600. Interest of ₹180 credited by the bank has not yet been entered in the Cash Book.",
        targetLabel: "Balance as per Cash Book",
        finalBalance: -5780,
        items: [
        { label: "Interest credited by bank, not yet in Cash Book (overdraft, Pass Book start)", correctAnswer: "Less", amount: 180, reasoning: "The Pass Book's overdraft has already been reduced by this interest credit; the Cash Book hasn't recorded it yet. Starting from the Pass Book, deduct ₹180 to reach the Cash Book's deeper overdraft." }
        ]
      },
      {
        id: 98,
        category: "Cash Book Errors",
        difficulty: "Medium",
        startingPoint: "Pass Book",
        startingBalance: -7200,
        situation: "The Pass Book shows an OVERDRAFT of ₹7,200. A cheque of ₹1,400 issued to a creditor (and already paid by the bank) was completely omitted from the Cash Book.",
        targetLabel: "Balance as per Cash Book",
        finalBalance: -5800,
        items: [
        { label: "Cheque issued, omitted from Cash Book (overdraft, Pass Book start)", correctAnswer: "Add", amount: 1400, reasoning: "The Pass Book already reflects this payment; the Cash Book never recorded it, so the Cash Book's overdraft looks smaller (less negative) than it should be. Starting from the Pass Book, add ₹1,400 to reach the Cash Book's overdraft figure." }
        ]
      },
      {
        id: 99,
        category: "Cash Book Errors",
        difficulty: "Medium",
        startingPoint: "Pass Book",
        startingBalance: -4800,
        situation: "The Pass Book shows an OVERDRAFT of ₹4,800. A cheque of ₹1,100 deposited into the bank was completely omitted from the Cash Book.",
        targetLabel: "Balance as per Cash Book",
        finalBalance: -5900,
        items: [
        { label: "Cheque deposited, omitted from Cash Book (overdraft, Pass Book start)", correctAnswer: "Less", amount: 1100, reasoning: "The Pass Book already reflects this collection; the Cash Book never recorded it, so the Cash Book's overdraft is deeper than the Pass Book's. Starting from the Pass Book, deduct ₹1,100 to reach the Cash Book's deeper overdraft." }
        ]
      },
      {
        id: 100,
        category: "Bank Errors",
        difficulty: "Medium",
        startingPoint: "Pass Book",
        startingBalance: -6100,
        situation: "The Pass Book shows an OVERDRAFT of ₹6,100. The bank wrongly debited the account with ₹700 that actually belonged to another customer.",
        targetLabel: "Balance as per Cash Book",
        finalBalance: -5400,
        items: [
        { label: "Bank wrongly debited the account (overdraft, Pass Book start)", correctAnswer: "Add", amount: 700, reasoning: "The wrongful debit has made the Pass Book's overdraft deeper than the (correct) Cash Book. Starting from the Pass Book, add ₹700 to reach the Cash Book's smaller overdraft." }
        ]
      },
      {
        id: 101,
        category: "Bank Errors",
        difficulty: "Medium",
        startingPoint: "Pass Book",
        startingBalance: -8400,
        situation: "The Pass Book shows an OVERDRAFT of ₹8,400. The bank wrongly credited the account with ₹550 that actually belonged to another customer.",
        targetLabel: "Balance as per Cash Book",
        finalBalance: -8950,
        items: [
        { label: "Bank wrongly credited the account (overdraft, Pass Book start)", correctAnswer: "Less", amount: 550, reasoning: "The wrongful credit has made the Pass Book's overdraft look smaller than the (correct) Cash Book. Starting from the Pass Book, deduct ₹550 to reach the Cash Book's deeper overdraft." }
        ]
      },
      {
        id: 102,
        category: "Mixed Cases",
        difficulty: "Hard",
        startingPoint: "Pass Book",
        startingBalance: -10500,
        situation: "The Pass Book shows an OVERDRAFT of ₹10,500. Prepare the reconciliation using BOTH of the following items, identified separately: (1) A cheque of ₹2,200 issued has not yet been presented for payment. (2) Bank charges of ₹160 have been debited by the bank but not yet entered in the Cash Book.",
        targetLabel: "Balance as per Cash Book",
        finalBalance: -8460,
        items: [
        { label: "Cheque issued, not yet presented (overdraft, Pass Book start)", correctAnswer: "Add", amount: 2200, reasoning: "The Cash Book already reduced its (overdraft) balance further for this cheque; the Pass Book hasn't yet. Starting from the Pass Book, add ₹2,200 to move toward the Cash Book's deeper overdraft." },
        { label: "Bank charges, not yet in Cash Book (overdraft, Pass Book start)", correctAnswer: "Less", amount: 160, reasoning: "The Pass Book's overdraft already includes this charge; the Cash Book hasn't recorded it yet. Starting from the Pass Book, deduct ₹160 to reach the Cash Book's shallower overdraft." }
        ]
      }
    ]
  },

  gst: {

    theory: {
      /* ---- INTRODUCTION ---- */
      simple: [
        {
          h: "Meaning of GST",
          p: "GST stands for Goods and Services Tax. It is a single, comprehensive, indirect tax levied on the supply of goods and services in India. Instead of a business having to deal with several different indirect taxes at different stages, GST brings them together under one unified tax system.",
          p2: "GST is an indirect tax — it is collected by the seller from the buyer as part of the price, and the seller then deposits it with the government. It is not a tax on income or profit; it is a tax on the supply of goods and services."
        },
        {
          h: "Why GST Was Introduced",
          p: "Before GST, India had many separate indirect taxes — VAT, excise duty, service tax, and others — each with its own rules, rates, and forms. This created two big problems for businesses: complexity (keeping track of multiple taxes) and the cascading effect, where tax was often charged again on an amount that already included tax paid earlier ('tax on tax'). GST was introduced to replace these multiple taxes with a single, uniform tax, and to remove this cascading effect through a system called Input Tax Credit."
        },
        {
          h: "Main Characteristics of GST",
          list: [
            { term: "Multi-stage tax", def: "GST is levied at every stage of the supply chain — from the manufacturer, to the wholesaler, to the retailer, and finally to the consumer." },
            { term: "Value-added tax", def: "At each stage, tax is effectively charged only on the VALUE ADDED at that stage, not on the full price again — this is achieved through Input Tax Credit, which lets a business claim credit for the GST it already paid on its own purchases." },
            { term: "Destination-based tax", def: "GST revenue goes to the state where the goods or services are FINALLY CONSUMED, not the state where they were produced or manufactured." },
            { term: "Dual GST model", def: "India follows a dual structure: an intra-state sale (within the same state) is split equally into CGST (Central GST) and SGST (State GST); an inter-state sale (between two different states) attracts IGST (Integrated GST) instead." },
            { term: "Comprehensive tax", def: "GST subsumes (replaces) a number of earlier indirect taxes — such as VAT, excise duty, and service tax — into one single tax." },
            { term: "Uniform tax structure", def: "GST rates and rules are broadly uniform across the country, rather than varying widely from state to state as under the earlier system." }
          ]
        },
        {
          h: "Advantages of GST",
          list: [
            { term: "Removes the cascading effect", def: "Through Input Tax Credit, a business only effectively pays tax on the value it adds — not on tax already paid at an earlier stage." },
            { term: "Simplifies the tax structure", def: "One tax replaces many separate indirect taxes, making compliance easier for businesses." },
            { term: "Creates a common national market", def: "A uniform tax structure across states removes tax-related barriers to the free movement of goods — often summarised as 'One Nation, One Tax'." },
            { term: "Greater transparency", def: "Since GST is charged and tracked at every stage, it becomes harder to hide transactions, improving transparency." },
            { term: "Wider tax base", def: "By bringing more transactions into the formal tax system, GST widens the base of transactions on which tax is collected." },
            { term: "Eases doing business", def: "A simpler, more uniform tax system reduces the compliance burden on businesses operating across different states." }
          ]
        },
        {
          h: "Basic Idea of GST in Business Transactions",
          p: "When a business PURCHASES goods or services, it pays GST to its supplier — this is called Input GST, and it can later be claimed as credit. When a business SELLS goods or services, it collects GST from its customer — this is called Output GST, and it must eventually be paid to the government.",
          p2: "At the end of a tax period, the business calculates its Net GST Payable by adjusting the GST it collected against the GST it already paid:",
          formula: "Net GST Payable = Output GST − Input GST"
        }
      ],

      /* ---- FORMAT & RULES ---- */
      advanced: [
        {
          h: "The Core GST Calculation",
          p: "Every GST calculation in this chapter follows the same two-step logic: first work out the taxable value (the value on which GST is actually charged), then apply the GST rate to that taxable value.",
          formula: "GST Amount = Taxable Value × GST Rate / 100\n\nInvoice Value = Taxable Value + GST Amount"
        },
        {
          h: "Trade Discount — Always Deducted BEFORE GST",
          p: "A trade discount is a reduction offered on the list price of goods, usually to a wholesaler or a regular buyer. It must always be deducted from the list price FIRST, to arrive at the taxable (net) value — GST is then calculated only on this reduced taxable value, never on the original gross list price.",
          formula: "Taxable Value = List Price − Trade Discount"
        },
        {
          h: "Worked Example — Trade Discount + GST",
          p: "Goods with a list price of ₹10,000 are sold at a 10% trade discount. GST rate is 18%.",
          formula: "Trade Discount = ₹10,000 × 10% = ₹1,000\nTaxable (Net) Value = ₹10,000 − ₹1,000 = ₹9,000\nGST Amount = ₹9,000 × 18% = ₹1,620\nInvoice Value = ₹9,000 + ₹1,620 = ₹10,620"
        },
        {
          h: "Freight / Cartage — Read the Question Carefully",
          p: "Freight or cartage charges need careful attention, because their treatment depends entirely on what the question states. If a question specifically says that GST is ALSO chargeable on the freight, the freight amount is added to the taxable value BEFORE calculating GST. If a question is silent on this, or says freight is charged separately without GST, the freight is simply added to the invoice value AFTER GST has already been calculated on the goods alone.",
          list: [
            { term: "GST applicable on freight", def: "Taxable Value for GST = Value of Goods + Freight, then GST is calculated on this combined figure." },
            { term: "GST not applicable on freight", def: "GST is calculated only on the value of goods; the freight amount is added afterwards, directly to the final invoice value." }
          ]
        },
        {
          h: "CGST, SGST and IGST — Which One Applies?",
          p: "Whether GST is split into CGST + SGST, or charged fully as IGST, depends on where the buyer and seller are located.",
          list: [
            { term: "Intra-state sale (same state)", def: "The total GST is split EQUALLY into CGST (Central GST) and SGST (State GST). For example, at an 18% total rate: CGST = 9%, SGST = 9%." },
            { term: "Inter-state sale (different states)", def: "The FULL GST amount is charged as a single tax called IGST (Integrated GST) — there is no CGST/SGST split." }
          ]
        },
        {
          h: "Input GST vs. Output GST",
          p: "GST paid on PURCHASES is recorded as Input GST (an asset-like balance, since it can be claimed as credit). GST collected on SALES is recorded as Output GST (a liability, since it is owed to the government). At the end of the period, the two are adjusted against each other.",
          formula: "Net GST Payable = Output GST − Input GST\n\n(If Input GST exceeds Output GST, the excess carries forward as a credit rather than being 'payable'.)"
        },
        {
          h: "Journal Entries — Purchases with GST",
          p: "In the simplest Class 11 treatment (unless a question specifies intra-state or inter-state), GST paid on a purchase is recorded through a single 'Input GST A/c'.",
          formula: "Cash Purchase:\nPurchases A/c              Dr.\nInput GST A/c              Dr.\n      To Cash A/c\n\nCredit Purchase (from a supplier):\nPurchases A/c              Dr.\nInput GST A/c              Dr.\n      To Supplier's A/c"
        },
        {
          h: "Journal Entries — Sales with GST",
          p: "Similarly, GST collected on a sale is recorded through a single 'Output GST A/c' in the simplest treatment.",
          formula: "Cash Sale:\nCash A/c                   Dr.\n      To Sales A/c\n      To Output GST A/c\n\nCredit Sale (to a customer):\nCustomer's A/c              Dr.\n      To Sales A/c\n      To Output GST A/c"
        },
        {
          h: "Journal Entries — When Intra-State / Inter-State Is Specified",
          p: "When a question explicitly states that a transaction is intra-state or inter-state, split the GST accordingly instead of using a single Input/Output GST account.",
          formula: "Intra-state Purchase:\nPurchases A/c               Dr.\nInput CGST A/c              Dr.\nInput SGST A/c              Dr.\n      To Cash/Creditor's A/c\n\nInter-state Sale:\nCash/Debtor's A/c           Dr.\n      To Sales A/c\n      To Output IGST A/c"
        },
        {
          h: "Common Mistakes to Avoid",
          list: [
            { term: "Calculating GST before deducting trade discount", def: "Always deduct the trade discount from the list price first — GST is never calculated on the gross list price when a trade discount applies." },
            { term: "Mixing up Input GST and Output GST", def: "Input GST relates to purchases (what the business paid); Output GST relates to sales (what the business collected)." },
            { term: "Forgetting to check freight treatment", def: "Always check whether the question says GST applies to freight — the treatment (and the final invoice value) changes depending on this." },
            { term: "Confusing CGST/SGST with IGST", def: "CGST + SGST apply only within the same state; IGST applies only between different states — never mix the two for the same transaction." }
          ]
        }
      ]
    },

    concepts: [
      { title: "GST (Goods and Services Tax)", body: "A single, comprehensive, indirect tax levied on the supply of goods and services, replacing several earlier indirect taxes." },
      { title: "Input GST", body: "GST paid by a business on its own purchases, which can later be claimed as credit against Output GST." },
      { title: "Output GST", body: "GST collected by a business from its customers on sales, which is payable to the government after adjusting for Input GST." },
      { title: "Taxable Value", body: "The value on which GST is actually calculated — the list price after deducting any trade discount (and including freight, only if the question says GST applies to it)." },
      { title: "CGST & SGST", body: "Central GST and State GST — the two equal halves into which GST is split for an intra-state (same state) sale." },
      { title: "IGST", body: "Integrated GST — the single, full-rate tax charged on an inter-state (different states) sale, instead of splitting into CGST/SGST." },
      { title: "Trade Discount (GST context)", body: "Always deducted from the list price BEFORE calculating GST — GST is calculated only on the resulting taxable value." },
      { title: "Net GST Payable", body: "The amount a business actually owes the government after adjusting Output GST against Input GST already paid: Net GST Payable = Output GST − Input GST." }
    ],

    quickRevision: {
      definition: "GST (Goods and Services Tax) is a single, comprehensive, indirect, multi-stage, destination-based tax levied on the supply of goods and services, which replaced several earlier indirect taxes such as VAT, excise duty, and service tax.",
      keyPoints: [
        "GST is an indirect tax — collected by the seller from the buyer, then deposited with the government.",
        "It is multi-stage (charged at every stage of the supply chain) and value-added (tax is effectively charged only on the value added at each stage, via Input Tax Credit).",
        "It is destination-based — tax revenue goes to the state where goods/services are finally consumed.",
        "India follows a Dual GST model: CGST + SGST (equal split) for intra-state sales, IGST (full rate) for inter-state sales.",
        "Key advantages: removes the cascading effect of tax, simplifies the tax structure, and helps create a common national market."
      ],
      calculationSteps: [
        "Step 1 — Find the Taxable Value: deduct any trade discount from the list price first (Taxable Value = List Price − Trade Discount).",
        "Step 2 — Check freight treatment: add freight to the taxable value only if the question says GST applies to it; otherwise add freight after GST is calculated.",
        "Step 3 — Calculate GST Amount: Taxable Value × GST Rate / 100.",
        "Step 4 — Calculate Invoice Value: Taxable Value + GST Amount (+ freight, if not already included).",
        "Step 5 — For journal entries: use Input GST A/c for purchases and Output GST A/c for sales, unless the question specifies intra-state (CGST+SGST) or inter-state (IGST)."
      ],
      commonMistakes: [
        "Calculating GST on the gross list price instead of deducting the trade discount first.",
        "Adding freight to the taxable value even when the question doesn't say GST applies to it.",
        "Mixing up Input GST (on purchases) with Output GST (on sales).",
        "Applying both CGST/SGST AND IGST to the same transaction — only one applies, depending on intra-state vs inter-state.",
        "Forgetting that in a credit transaction, the customer's/supplier's account is debited or credited with the FULL invoice value (taxable value + GST), not just the taxable value."
      ],
      mnemonic: "Discount first, then GST. Freight only if the question says so. Input = purchases, Output = sales."
    },

    detective: [
      {
        id: 1,
        difficulty: "Easy",
        billText: { goods: "₹20,000", discount: "10%", gstRate: "18%", freight: "None" },
        options: [21240, 18000, 20740, 21740],
        answerValue: 21240,
        steps: ["List Price = ₹20,000", "Trade Discount (10%) = ₹2,000", "Taxable Value = List Price − Trade Discount = ₹20,000 − ₹2,000 = ₹18,000", "GST Amount = Taxable Value × 18% = ₹18,000 × 18/100 = ₹3,240", "Final Invoice Value = Taxable Value + GST = ₹18,000 + ₹3,240 = ₹21,240"]
      },
      {
        id: 2,
        difficulty: "Easy",
        billText: { goods: "₹5,000", discount: "None", gstRate: "12%", freight: "None" },
        options: [5600, 5000, 5500, 5700],
        answerValue: 5600,
        steps: ["List Price = ₹5,000", "Taxable Value = ₹5,000 (no trade discount)", "GST Amount = Taxable Value × 12% = ₹5,000 × 12/100 = ₹600", "Final Invoice Value = Taxable Value + GST = ₹5,000 + ₹600 = ₹5,600"]
      },
      {
        id: 3,
        difficulty: "Easy",
        billText: { goods: "₹8,000", discount: "5%", gstRate: "18%", freight: "None" },
        options: [8968, 7600, 8768, 9168],
        answerValue: 8968,
        steps: ["List Price = ₹8,000", "Trade Discount (5%) = ₹400", "Taxable Value = List Price − Trade Discount = ₹8,000 − ₹400 = ₹7,600", "GST Amount = Taxable Value × 18% = ₹7,600 × 18/100 = ₹1,368", "Final Invoice Value = Taxable Value + GST = ₹7,600 + ₹1,368 = ₹8,968"]
      },
      {
        id: 4,
        difficulty: "Medium",
        billText: { goods: "₹12,000", discount: "10%", gstRate: "12%", freight: "None" },
        options: [12096, 10800, 11796, 12396],
        answerValue: 12096,
        steps: ["List Price = ₹12,000", "Trade Discount (10%) = ₹1,200", "Taxable Value = List Price − Trade Discount = ₹12,000 − ₹1,200 = ₹10,800", "GST Amount = Taxable Value × 12% = ₹10,800 × 12/100 = ₹1,296", "Final Invoice Value = Taxable Value + GST = ₹10,800 + ₹1,296 = ₹12,096"]
      },
      {
        id: 5,
        difficulty: "Medium",
        billText: { goods: "₹15,000", discount: "20%", gstRate: "18%", freight: "None" },
        options: [14160, 12000, 13760, 14560],
        answerValue: 14160,
        steps: ["List Price = ₹15,000", "Trade Discount (20%) = ₹3,000", "Taxable Value = List Price − Trade Discount = ₹15,000 − ₹3,000 = ₹12,000", "GST Amount = Taxable Value × 18% = ₹12,000 × 18/100 = ₹2,160", "Final Invoice Value = Taxable Value + GST = ₹12,000 + ₹2,160 = ₹14,160"]
      },
      {
        id: 6,
        difficulty: "Medium",
        billText: { goods: "₹10,000", discount: "None", gstRate: "18%", freight: "₹500 (GST applicable)" },
        options: [12390, 10500, 12190, 12590],
        answerValue: 12390,
        steps: ["List Price = ₹10,000", "Taxable Value = ₹10,000 (no trade discount)", "Freight of ₹500 is also subject to GST, so it is added to the taxable value: ₹10,000 + ₹500 = ₹10,500", "GST Amount = Taxable Value × 18% = ₹10,500 × 18/100 = ₹1,890", "Final Invoice Value = Taxable Value + GST = ₹10,500 + ₹1,890 = ₹12,390"]
      },
      {
        id: 7,
        difficulty: "Medium",
        billText: { goods: "₹10,000", discount: "None", gstRate: "18%", freight: "₹500 (no GST)" },
        options: [12300, 10000, 12100, 12500],
        answerValue: 12300,
        steps: ["List Price = ₹10,000", "Taxable Value = ₹10,000 (no trade discount)", "Freight of ₹500 is charged separately and is NOT subject to GST — it is added only after GST is calculated.", "GST Amount = Taxable Value × 18% = ₹10,000 × 18/100 = ₹1,800", "Final Invoice Value = Taxable Value + GST + Freight = ₹10,000 + ₹1,800 + ₹500 = ₹12,300"]
      },
      {
        id: 8,
        difficulty: "Easy",
        billText: { goods: "₹6,000", discount: "None", gstRate: "5%", freight: "None" },
        options: [6300, 6000, 6200, 6400],
        answerValue: 6300,
        steps: ["List Price = ₹6,000", "Taxable Value = ₹6,000 (no trade discount)", "GST Amount = Taxable Value × 5% = ₹6,000 × 5/100 = ₹300", "Final Invoice Value = Taxable Value + GST = ₹6,000 + ₹300 = ₹6,300"]
      },
      {
        id: 9,
        difficulty: "Medium",
        billText: { goods: "₹25,000", discount: "15%", gstRate: "18%", freight: "None" },
        options: [25075, 21250, 24575, 25575],
        answerValue: 25075,
        steps: ["List Price = ₹25,000", "Trade Discount (15%) = ₹3,750", "Taxable Value = List Price − Trade Discount = ₹25,000 − ₹3,750 = ₹21,250", "GST Amount = Taxable Value × 18% = ₹21,250 × 18/100 = ₹3,825", "Final Invoice Value = Taxable Value + GST = ₹21,250 + ₹3,825 = ₹25,075"]
      },
      {
        id: 10,
        difficulty: "Medium",
        billText: { goods: "₹9,000", discount: "10%", gstRate: "12%", freight: "₹300 (no GST)" },
        options: [9372, 8100, 9172, 9572],
        answerValue: 9372,
        steps: ["List Price = ₹9,000", "Trade Discount (10%) = ₹900", "Taxable Value = List Price − Trade Discount = ₹9,000 − ₹900 = ₹8,100", "Freight of ₹300 is charged separately and is NOT subject to GST — it is added only after GST is calculated.", "GST Amount = Taxable Value × 12% = ₹8,100 × 12/100 = ₹972", "Final Invoice Value = Taxable Value + GST + Freight = ₹8,100 + ₹972 + ₹300 = ₹9,372"]
      },
      {
        id: 11, difficulty: "Easy",
        billText: { goods: "₹30,000", discount: "None", gstRate: "28%", freight: "None" },
        options: [38400, 30000, 33600, 8400],
        answerValue: 38400,
        steps: ["List Price = ₹30,000 (no trade discount)", "Taxable Value = ₹30,000", "GST Amount = Taxable Value × 28% = ₹30,000 × 28/100 = ₹8,400", "Final Invoice Value = Taxable Value + GST = ₹30,000 + ₹8,400 = ₹38,400"]
      },
      {
        id: 12, difficulty: "Medium",
        billText: { goods: "₹18,000", discount: "10%", gstRate: "28%", freight: "None" },
        options: [20736, 23040, 16200, 4536],
        answerValue: 20736,
        steps: ["List Price = ₹18,000", "Trade Discount (10%) = ₹1,800", "Taxable Value = ₹18,000 − ₹1,800 = ₹16,200", "GST Amount = Taxable Value × 28% = ₹16,200 × 28/100 = ₹4,536", "Final Invoice Value = ₹16,200 + ₹4,536 = ₹20,736"]
      },
      {
        id: 13, difficulty: "Easy",
        billText: { goods: "₹7,000", discount: "None", gstRate: "5%", freight: "None" },
        options: [7350, 7000, 350, 7700],
        answerValue: 7350,
        steps: ["List Price = ₹7,000 (no trade discount)", "Taxable Value = ₹7,000", "GST Amount = Taxable Value × 5% = ₹7,000 × 5/100 = ₹350", "Final Invoice Value = ₹7,000 + ₹350 = ₹7,350"]
      },
      {
        id: 14, difficulty: "Medium",
        billText: { goods: "₹14,000", discount: "5%", gstRate: "12%", freight: "None" },
        options: [14896, 15680, 13300, 1596],
        answerValue: 14896,
        steps: ["List Price = ₹14,000", "Trade Discount (5%) = ₹700", "Taxable Value = ₹14,000 − ₹700 = ₹13,300", "GST Amount = Taxable Value × 12% = ₹13,300 × 12/100 = ₹1,596", "Final Invoice Value = ₹13,300 + ₹1,596 = ₹14,896"]
      },
      {
        id: 15, difficulty: "Hard",
        billText: { goods: "₹22,000", discount: "10%", gstRate: "18%", freight: "₹800 (GST applicable)" },
        options: [24308, 24164, 23364, 26904],
        answerValue: 24308,
        steps: ["List Price = ₹22,000", "Trade Discount (10%) = ₹2,200", "Taxable Value of goods = ₹22,000 − ₹2,200 = ₹19,800", "GST on goods = ₹19,800 × 18% = ₹3,564", "Since freight is charged WITH GST, GST also applies on the ₹800 freight: ₹800 × 18% = ₹144", "Final Invoice Value = Taxable Value + GST on goods + Freight + GST on freight = ₹19,800 + ₹3,564 + ₹800 + ₹144 = ₹24,308"]
      },
      {
        id: 16, difficulty: "Medium",
        billText: { goods: "₹16,000", discount: "None", gstRate: "18%", freight: "₹400 (no GST)" },
        options: [19280, 18880, 19352, 16400],
        answerValue: 19280,
        steps: ["List Price = ₹16,000 (no trade discount)", "Taxable Value = ₹16,000", "GST Amount = ₹16,000 × 18% = ₹2,880", "Freight of ₹400 is charged separately with NO GST on it, added after GST", "Final Invoice Value = ₹16,000 + ₹2,880 + ₹400 = ₹19,280"]
      },
      {
        id: 17, difficulty: "Medium",
        billText: { goods: "₹40,000", discount: "20%", gstRate: "18%", freight: "None" },
        options: [37760, 47200, 42480, 5760],
        answerValue: 37760,
        steps: ["List Price = ₹40,000", "Trade Discount (20%) = ₹8,000", "Taxable Value = ₹40,000 − ₹8,000 = ₹32,000", "GST Amount = ₹32,000 × 18% = ₹5,760", "Final Invoice Value = ₹32,000 + ₹5,760 = ₹37,760"]
      },
      {
        id: 18, difficulty: "Easy",
        billText: { goods: "₹11,000", discount: "None", gstRate: "12%", freight: "None" },
        options: [12320, 11000, 1320, 12100],
        answerValue: 12320,
        steps: ["List Price = ₹11,000 (no trade discount)", "Taxable Value = ₹11,000", "GST Amount = ₹11,000 × 12% = ₹1,320", "Final Invoice Value = ₹11,000 + ₹1,320 = ₹12,320"]
      },
      {
        id: 19, difficulty: "Medium",
        billText: { goods: "₹26,000", discount: "15%", gstRate: "5%", freight: "None" },
        options: [23205, 27300, 22100, 1105],
        answerValue: 23205,
        steps: ["List Price = ₹26,000", "Trade Discount (15%) = ₹3,900", "Taxable Value = ₹26,000 − ₹3,900 = ₹22,100", "GST Amount = ₹22,100 × 5% = ₹1,105", "Final Invoice Value = ₹22,100 + ₹1,105 = ₹23,205"]
      },
      {
        id: 20, difficulty: "Hard",
        billText: { goods: "₹13,500", discount: "10%", gstRate: "28%", freight: "₹600 (GST applicable)" },
        options: [16320, 16152, 15552, 18048],
        answerValue: 16320,
        steps: ["List Price = ₹13,500", "Trade Discount (10%) = ₹1,350", "Taxable Value of goods = ₹13,500 − ₹1,350 = ₹12,150", "GST on goods = ₹12,150 × 28% = ₹3,402", "Freight is charged WITH GST, so GST also applies to the ₹600 freight: ₹600 × 28% = ₹168", "Final Invoice Value = ₹12,150 + ₹3,402 + ₹600 + ₹168 = ₹16,320"]
      }
    ],

    numericals: [
      {
        id: 1,
        difficulty: "Easy",
        question: "Goods worth ₹5,000 are sold, GST rate 12%. What is the GST amount?",
        options: ["₹600", "₹700", "₹500", "₹900"],
        answerIndex: 0,
        explanation: "GST Amount = Taxable Value × Rate/100 = ₹5,000 × 12/100 = ₹600."
      },
      {
        id: 2,
        difficulty: "Easy",
        question: "Goods worth ₹8,000 are sold, GST rate 18%, no trade discount. What is the total invoice value?",
        options: ["₹9,440", "₹8,000", "₹1,440", "₹9,640"],
        answerIndex: 0,
        explanation: "GST Amount = ₹8,000 × 18/100 = ₹1,440. Invoice Value = Taxable Value + GST = ₹8,000 + ₹1,440 = ₹9,440."
      },
      {
        id: 3,
        difficulty: "Easy",
        question: "List price of goods is ₹12,000. Trade discount allowed is 10%. What is the taxable value (net value) on which GST will be calculated?",
        options: ["₹10,800", "₹12,000", "₹10,600", "₹11,300"],
        answerIndex: 0,
        explanation: "Trade Discount = ₹12,000 × 10/100 = ₹1,200. Taxable Value = List Price − Trade Discount = ₹12,000 − ₹1,200 = ₹10,800."
      },
      {
        id: 4,
        difficulty: "Medium",
        question: "List price ₹15,000, trade discount 20%, GST rate 12%. What is the total invoice value?",
        options: ["₹13,440", "₹12,000", "₹10,440", "₹16,800"],
        answerIndex: 0,
        explanation: "Trade Discount = ₹15,000 × 20% = ₹3,000. Taxable Value = ₹15,000 − ₹3,000 = ₹12,000. GST = ₹12,000 × 12% = ₹1,440. Invoice Value = ₹12,000 + ₹1,440 = ₹13,440."
      },
      {
        id: 5,
        difficulty: "Medium",
        question: "Taxable value of goods is ₹6,000 and GST charged is ₹1,080. What is the rate of GST?",
        options: ["₹18", "₹12", "₹15", "₹20"],
        answerIndex: 0,
        explanation: "Rate of GST = (GST Amount / Taxable Value) × 100 = (₹1,080 / ₹6,000) × 100 = 18%."
      },
      {
        id: 6,
        difficulty: "Medium",
        question: "The total invoice value of goods (inclusive of 18% GST) is ₹10,620. What is the taxable value of the goods?",
        options: ["₹9,000", "₹10,620", "₹8,700", "₹9,500"],
        answerIndex: 0,
        explanation: "Invoice Value = Taxable Value + GST = Taxable Value × (1 + 18/100) = Taxable Value × 1.18. So Taxable Value = ₹10,620 / 1.18 = ₹9,000."
      },
      {
        id: 7,
        difficulty: "Medium",
        question: "Goods worth ₹20,000 are sold within the same state, GST rate 18% (split equally as CGST and SGST). What is the amount of CGST charged?",
        options: ["₹1,800", "₹3,600", "₹900", "₹2,100"],
        answerIndex: 0,
        explanation: "For an intra-state (within the same state) sale, GST is split equally into CGST and SGST. Total GST = ₹20,000 × 18% = ₹3,600. CGST = SGST = ₹3,600 / 2 = ₹1,800."
      },
      {
        id: 8,
        difficulty: "Easy",
        question: "Goods worth ₹25,000 are sold to a buyer in another state, GST rate 18%. Since this is an inter-state sale, what tax will be charged, and how much?",
        options: ["₹4,500", "₹2,250", "₹5,000", "₹4,000"],
        answerIndex: 0,
        explanation: "An inter-state sale (between two different states) attracts IGST (Integrated GST), not CGST/SGST. IGST = ₹25,000 × 18% = ₹4,500."
      },
      {
        id: 9,
        difficulty: "Easy",
        question: "Goods worth ₹7,000 are purchased for cash, GST rate 12%. How much total cash is paid?",
        options: ["₹7,840", "₹7,000", "₹840", "₹8,680"],
        answerIndex: 0,
        explanation: "GST = ₹7,000 × 12% = ₹840. Total cash paid = ₹7,000 + ₹840 = ₹7,840."
      },
      {
        id: 10,
        difficulty: "Medium",
        question: "Goods with a list price of ₹18,000 are sold on credit at a 15% trade discount, GST rate 18%. What amount will be debited to the Debtor's Account (total invoice value)?",
        options: ["₹18,054", "₹15,300", "₹18,000", "₹15,354"],
        answerIndex: 0,
        explanation: "Trade Discount = ₹18,000 × 15% = ₹2,700. Taxable Value = ₹18,000 − ₹2,700 = ₹15,300. GST = ₹15,300 × 18% = ₹2,754. Total invoice value debited to the Debtor's Account = ₹15,300 + ₹2,754 = ₹18,054."
      },
      {
        id: 11,
        difficulty: "Medium",
        question: "Goods worth ₹10,000 are sold, plus freight of ₹500 which is also chargeable to GST at 18% (i.e. GST applies on goods + freight together). What is the total invoice value?",
        options: ["₹12,390", "₹11,890", "₹10,500", "₹12,190"],
        answerIndex: 0,
        explanation: "Since GST applies on freight too here, Taxable Value for GST = Goods + Freight = ₹10,000 + ₹500 = ₹10,500. GST = ₹10,500 × 18% = ₹1,890. Invoice Value = ₹10,500 + ₹1,890 = ₹12,390."
      },
      {
        id: 12,
        difficulty: "Medium",
        question: "Goods worth ₹10,000 are sold, GST rate 18%. Freight of ₹500 is charged separately and is NOT subject to GST. What is the total invoice value?",
        options: ["₹12,300", "₹11,800", "₹2,300", "₹12,800"],
        answerIndex: 0,
        explanation: "Here freight is not part of the taxable value. GST = ₹10,000 × 18% = ₹1,800. Invoice Value = Taxable Value + GST + Freight = ₹10,000 + ₹1,800 + ₹500 = ₹12,300."
      },
      {
        id: 13,
        difficulty: "Easy",
        question: "GST stands for:",
        options: ["Goods and Services Tax", "General Sales Tax", "Government Service Tax", "Gross Supply Tax"],
        answerIndex: 0,
        explanation: "GST stands for Goods and Services Tax — a single indirect tax levied on the supply of goods and services."
      },
      {
        id: 14,
        difficulty: "Easy",
        question: "GST is best described as:",
        options: ["A single indirect tax on the supply of goods and services, replacing many earlier indirect taxes", "A direct tax on business profits", "A tax charged only on imported goods", "A tax charged only on services, not goods"],
        answerIndex: 0,
        explanation: "GST is a comprehensive, multi-stage, indirect tax levied on the supply of goods and services, which replaced a number of earlier indirect taxes like VAT, excise duty, and service tax."
      },
      {
        id: 15,
        difficulty: "Medium",
        question: "In an INTRA-STATE sale (buyer and seller in the same state), which taxes are charged?",
        options: ["CGST and SGST, split equally", "Only IGST", "Only CGST", "IGST and SGST together"],
        answerIndex: 0,
        explanation: "For an intra-state sale, GST is split equally between CGST (Central GST) and SGST (State GST) — for example, at an 18% rate, CGST = 9% and SGST = 9%."
      },
      {
        id: 16,
        difficulty: "Medium",
        question: "In an INTER-STATE sale (buyer and seller in different states), which tax is charged?",
        options: ["IGST", "CGST only", "SGST only", "CGST and SGST together"],
        answerIndex: 0,
        explanation: "For an inter-state sale, the full GST amount is charged as IGST (Integrated GST) — there is no CGST/SGST split."
      },
      {
        id: 17,
        difficulty: "Medium",
        question: "Which of these is an advantage of GST?",
        options: ["It removes the cascading effect of tax (tax on tax) through input tax credit", "It increases the number of indirect taxes a business has to pay", "It applies different rates in every state with no uniformity", "It removes the need for businesses to maintain any tax records"],
        answerIndex: 0,
        explanation: "One of GST's main advantages is eliminating the cascading effect — under the earlier system, tax was charged on an amount that already included tax; GST allows businesses to claim credit for GST already paid on purchases (Input GST), so tax is effectively charged only on the value added at each stage."
      },
      {
        id: 18,
        difficulty: "Easy",
        question: "'Input GST' refers to:",
        options: ["GST paid by a business on its purchases, which can be claimed as credit", "GST collected by a business on its sales", "GST paid directly to customers", "A discount given by the government"],
        answerIndex: 0,
        explanation: "Input GST is the GST a business pays when it purchases goods or services; this can be set off (claimed as credit) against the Output GST collected on sales."
      },
      {
        id: 19,
        difficulty: "Easy",
        question: "'Output GST' refers to:",
        options: ["GST collected by a business on its sales, which is payable to the government", "GST paid by a business on its purchases", "A refund given to customers", "The total invoice value of a sale"],
        answerIndex: 0,
        explanation: "Output GST is the GST a business collects from customers on its sales; after adjusting for Input GST already paid, the balance is payable to the government."
      },
      {
        id: 20,
        difficulty: "Medium",
        question: "Goods are purchased for cash, and GST is paid on the purchase. Which account is debited for the GST paid, in the simplest Class 11 treatment?",
        options: ["Input GST A/c", "Output GST A/c", "Purchases A/c only, GST is not shown separately", "GST Payable A/c"],
        answerIndex: 0,
        explanation: "GST paid on a purchase is recorded through 'Input GST A/c' (Dr.), since it represents tax credit the business can later claim against the GST it collects on sales."
      },
      {
        id: 21,
        difficulty: "Medium",
        question: "Goods are sold for cash, and GST is collected on the sale. Which account is credited for the GST collected, in the simplest Class 11 treatment?",
        options: ["Output GST A/c", "Input GST A/c", "Sales A/c only, GST is not shown separately", "Cash A/c"],
        answerIndex: 0,
        explanation: "GST collected on a sale is recorded through 'Output GST A/c' (Cr.), since it is tax collected from the customer that the business must eventually pay to the government."
      },
      {
        id: 22,
        difficulty: "Hard",
        question: "Goods worth ₹6,000 are purchased on credit from Mohan, GST rate 18%. What is the correct journal entry?",
        options: ["Purchases A/c Dr. ₹6,000; Input GST A/c Dr. ₹1,080; To Mohan's A/c ₹7,080", "Purchases A/c Dr. ₹7,080; To Mohan's A/c ₹7,080", "Mohan's A/c Dr. ₹7,080; To Purchases A/c ₹6,000; To Input GST A/c ₹1,080", "Purchases A/c Dr. ₹6,000; To Mohan's A/c ₹6,000"],
        answerIndex: 0,
        explanation: "GST = ₹6,000 × 18% = ₹1,080. Since this is a credit purchase, the full invoice value ₹7,080 is payable to Mohan (the creditor): Purchases A/c Dr. ₹6,000, Input GST A/c Dr. ₹1,080, To Mohan's A/c ₹7,080."
      }
    ]
  },

  tb: {

    theory: {
      /* ---- INTRODUCTION ---- */
      simple: [
        {
          h: "Meaning of Trial Balance",
          p: "A Trial Balance is a statement that lists the closing balance of every ledger account — both debit and credit balances — as on a particular date. It is prepared after all the ledger accounts have been balanced, and its purpose is to check whether the total of all debit balances equals the total of all credit balances.",
          p2: "A Trial Balance is not itself an 'account' in the accounting sense — it has no debit or credit side of its own. It is simply a list, or a statement, that brings together the final balance of every single ledger account onto one page."
        },
        {
          h: "Purpose of Preparing a Trial Balance",
          list: [
            { term: "Checking arithmetical accuracy", def: "Since every transaction is recorded with an equal debit and an equal credit (the dual aspect of accounting), the total of all debit balances should always equal the total of all credit balances — a Trial Balance confirms whether this holds true." },
            { term: "Locating errors", def: "If the Trial Balance does not agree, this signals that at least one error exists somewhere in the recording, posting, balancing, or totalling process, prompting a search for it." },
            { term: "Basis for final accounts", def: "The balances listed in an agreeing Trial Balance are used directly to prepare the Trading Account, the Profit & Loss Account, and the Balance Sheet." },
            { term: "A convenient summary", def: "Instead of flipping through every single ledger account, a Trial Balance brings every account's final position together in one place, on one date." }
          ]
        },
        {
          h: "Objectives / Features of a Trial Balance",
          list: [
            { term: "It is a statement, not an account", def: "A Trial Balance has no debit or credit 'side' of its own — it is simply a two-column list of balances." },
            { term: "Prepared on a particular date", def: "It always reflects the position as on one specific date, most commonly the end of an accounting period." },
            { term: "Lists every ledger balance", def: "Every account that has a non-zero closing balance should appear in the Trial Balance, exactly once." },
            { term: "Debit and Credit totals should match", def: "Because of the dual aspect (double entry) of every transaction, a correctly written-up set of books should produce equal Debit and Credit totals." },
            { term: "Not final proof of accuracy", def: "An agreeing Trial Balance is a useful check, but — as covered later in this chapter — it does not guarantee that the books are completely free of every possible kind of error." }
          ]
        },
        {
          h: "Debit and Credit Balances — What Normally Goes Where",
          p: "Whether an account's balance appears in the Debit or Credit column depends on the type of account it is. This follows directly from the rules of debit and credit you've already learned:",
          list: [
            { term: "Debit balances", def: "Assets (Cash, Machinery, Furniture, Debtors, Stock, Prepaid expenses), Expenses and Losses (Purchases, Wages, Rent Paid, Bad Debts), and Drawings." },
            { term: "Credit balances", def: "Liabilities (Creditors, Loans, Outstanding expenses), Capital, and Incomes and Gains (Sales, Commission Received, Discount Received, Interest Received)." },
            { term: "A helpful shortcut", def: "If an account increases with a debit entry under the rules of debit and credit, its normal closing balance is a debit balance — and the reverse for accounts that increase with a credit entry." }
          ]
        }
      ],

      /* ---- FORMAT & RULES ---- */
      advanced: [
        {
          h: "The Core Trial Balance Rule",
          p: "Every Trial Balance, once correctly prepared, must satisfy one simple equation:",
          formula: "Total of the Debit Balance Column = Total of the Credit Balance Column"
        },
        {
          h: "Preparation by the Balance Method — Step by Step",
          list: [
            { term: "Step 1", def: "Balance every single ledger account, so each one shows a single closing figure — either a debit balance or a credit balance (a few accounts may close to zero, and are simply left out)." },
            { term: "Step 2", def: "List the name of every account with a non-zero balance under 'Particulars'." },
            { term: "Step 3", def: "Enter each account's balance in the correct column — the Debit Balance column if it is a debit balance, the Credit Balance column if it is a credit balance." },
            { term: "Step 4", def: "Total both columns separately." },
            { term: "Step 5", def: "Compare the two totals — if they are equal, the Trial Balance agrees. If not, the difference must be traced and corrected." }
          ]
        },
        {
          h: "Format of a Trial Balance",
          formula: "Trial Balance as on [date]\n\n  Particulars (Name of Account)      Debit Balance (₹)      Credit Balance (₹)\n  ---------------------------------------------------------------------\n  Cash in Hand                             XXXX\n  Purchases                                XXXX\n  Capital                                                          XXXX\n  Sales                                                            XXXX\n  Sundry Debtors                           XXXX\n  Sundry Creditors                                                 XXXX\n  ---------------------------------------------------------------------\n  Total                                    XXXX                    XXXX\n  ======================================================================="
        },
        {
          h: "Worked Example",
          p: "Balances as on 31st March: Capital ₹40,000, Cash ₹10,000, Furniture ₹15,000, Creditors ₹5,000, Debtors ₹20,000.",
          formula: "Debit column: Cash ₹10,000 + Furniture ₹15,000 + Debtors ₹20,000 = ₹45,000\nCredit column: Capital ₹40,000 + Creditors ₹5,000 = ₹45,000\n\nBoth totals are ₹45,000 — the Trial Balance agrees."
        },
        {
          h: "Common Mistakes While Preparing a Trial Balance",
          list: [
            { term: "Omitting an account balance", def: "Forgetting to include one ledger account's balance entirely — a very common source of disagreement." },
            { term: "Posting a balance to the wrong side", def: "Writing a debit balance in the Credit column, or vice versa, which throws off both totals by twice that balance's amount." },
            { term: "Casting (totalling) errors", def: "Simply adding up one of the two columns incorrectly." },
            { term: "Wrong balance carried forward", def: "Bringing forward an incorrect closing balance from a ledger account, rather than its true, correctly balanced figure." },
            { term: "Recording an account twice", def: "Accidentally listing the same account's balance more than once in the Trial Balance." },
            { term: "Confusing similarly-named accounts", def: "Mixing up accounts like Discount Allowed (an expense, debit) with Discount Received (an income, credit), or Purchases Returns with Sales Returns." }
          ]
        },
        {
          h: "Limitations of a Trial Balance (Class 11 Level)",
          p: "Even when a Trial Balance agrees perfectly, it does NOT guarantee that the underlying books of accounts are completely free of errors. This is because certain kinds of errors simply don't disturb the equality of the Debit and Credit totals:",
          list: [
            { term: "Errors of omission", def: "A transaction that was never recorded anywhere at all — since neither side was ever affected, the Trial Balance is unaffected too." },
            { term: "Errors of principle", def: "A transaction recorded with the correct amount, but against the wrong accounting principle — for example, treating a capital expenditure (like buying furniture) as a revenue expense. The amount is still correctly debited, just to the wrong TYPE of account, so the Trial Balance still agrees." },
            { term: "Compensating errors", def: "Two or more errors that happen to exactly cancel out each other's effect on the Trial Balance's totals." },
            { term: "Certain errors of commission", def: "For example, posting the correct amount to the wrong PERSON's account of the same class (e.g. debiting the wrong debtor) — the Trial Balance totals remain correct even though the individual account is wrong." }
          ]
        }
      ]
    },

    concepts: [
      { title: "Trial Balance", body: "A statement listing the balance of every ledger account as on a particular date, used to check the arithmetical accuracy of the ledger." },
      { title: "Balance Method", body: "The method of preparing a Trial Balance by first balancing every ledger account, then listing each account's single closing balance." },
      { title: "Agreement of Trial Balance", body: "When the Total Debit column and Total Credit column of a Trial Balance are equal — the Trial Balance is said to 'agree' or 'tally'." },
      { title: "Error of Omission", body: "A transaction completely left out of the books — never recorded at all. Does not affect the agreement of the Trial Balance." },
      { title: "Error of Principle", body: "A transaction recorded with the correct amount but against the wrong accounting principle (e.g. capital expenditure treated as revenue expenditure). Does not affect the agreement of the Trial Balance." },
      { title: "Compensating Errors", body: "Two or more errors that happen to cancel out each other's effect on the Trial Balance totals, so it still agrees." },
      { title: "Casting Error", body: "A mistake made while totalling (adding up) a column of figures — a common one-sided error that DOES cause the Trial Balance to disagree." }
    ],

    quickRevision: {
      definition: "A Trial Balance is a statement listing the balance of every ledger account as on a particular date, prepared to check the arithmetical accuracy of the ledger by verifying that Total Debit balances equal Total Credit balances.",
      keyPoints: [
        "A Trial Balance is a STATEMENT, not an account — it has no debit or credit side of its own.",
        "Prepared using the Balance Method at Class 11 level: balance every ledger account first, then list each closing balance.",
        "Assets, Expenses/Losses, and Drawings normally carry DEBIT balances. Liabilities, Capital, and Incomes/Gains normally carry CREDIT balances.",
        "The Trial Balance is the basis for preparing the Trading Account, Profit & Loss Account, and Balance Sheet.",
        "An agreeing Trial Balance is a useful check, but NOT conclusive proof that the books are free of every kind of error."
      ],
      calculationSteps: [
        "Step 1 — Balance every ledger account so each shows one final debit or credit figure.",
        "Step 2 — List every account name with its balance under Particulars.",
        "Step 3 — Enter the balance in the correct column (Debit or Credit) based on the type of account.",
        "Step 4 — Total both columns separately.",
        "Step 5 — Compare the totals: equal means the Trial Balance agrees; unequal means an error needs to be traced."
      ],
      commonMistakes: [
        "Omitting an account balance entirely from the Trial Balance.",
        "Posting a balance to the wrong column (Debit instead of Credit, or vice versa).",
        "Casting (totalling) errors while adding up either column.",
        "Carrying forward the wrong closing balance from a ledger account.",
        "Assuming an agreeing Trial Balance proves the books have no errors at all — errors of omission, principle, and compensating errors can all slip through undetected."
      ],
      mnemonic: "Balance every account first. Debit column: Assets, Expenses, Drawings. Credit column: Liabilities, Capital, Incomes. Totals must match — but 'matching' isn't the same as 'error-free'."
    },

    checkpoint: [
      {
        id: 1,
        difficulty: "Easy",
        type: "classify",
        prompt: "Machinery A/c",
        amount: 45000,
        options: ["Debit", "Credit"],
        correctIndex: 0,
        reasoning: "Machinery is a fixed asset — assets always carry debit balances.",
        whereInTB: "Debit column of the Trial Balance, under Assets."
      },
      {
        id: 2,
        difficulty: "Easy",
        type: "classify",
        prompt: "Bank Loan A/c",
        amount: 30000,
        options: ["Debit", "Credit"],
        correctIndex: 1,
        reasoning: "A Bank Loan is money owed BY the business to the bank — a liability, which carries a credit balance.",
        whereInTB: "Credit column of the Trial Balance, under Liabilities."
      },
      {
        id: 3,
        difficulty: "Easy",
        type: "classify",
        prompt: "Wages A/c",
        amount: 12000,
        options: ["Debit", "Credit"],
        correctIndex: 0,
        reasoning: "Wages is an expense incurred in running the business — expenses always carry debit balances.",
        whereInTB: "Debit column of the Trial Balance, under Expenses."
      },
      {
        id: 4,
        difficulty: "Easy",
        type: "classify",
        prompt: "Commission Received A/c",
        amount: 3000,
        options: ["Debit", "Credit"],
        correctIndex: 1,
        reasoning: "Commission Received is an income earned by the business — incomes always carry credit balances.",
        whereInTB: "Credit column of the Trial Balance, under Incomes/Gains."
      },
      {
        id: 5,
        difficulty: "Medium",
        type: "classify",
        prompt: "Bad Debts A/c",
        amount: 1500,
        options: ["Debit", "Credit"],
        correctIndex: 0,
        reasoning: "Bad Debts represent a loss to the business (amount that could not be recovered from a debtor) — losses, like expenses, carry debit balances.",
        whereInTB: "Debit column of the Trial Balance, under Expenses/Losses."
      },
      {
        id: 6,
        difficulty: "Medium",
        type: "classify",
        prompt: "Discount Received A/c",
        amount: 800,
        options: ["Debit", "Credit"],
        correctIndex: 1,
        reasoning: "Discount Received is a gain to the business (a reduction the business got on what it owed) — gains carry credit balances.",
        whereInTB: "Credit column of the Trial Balance, under Incomes/Gains."
      },
      {
        id: 7,
        difficulty: "Medium",
        type: "classify",
        prompt: "Purchases Returns (Returns Outward) A/c",
        amount: 2200,
        options: ["Debit", "Credit"],
        correctIndex: 1,
        reasoning: "Purchases Returns reduces the business's purchases — it behaves like an income/reduction-of-expense item and carries a credit balance, opposite to Purchases itself.",
        whereInTB: "Credit column of the Trial Balance."
      },
      {
        id: 8,
        difficulty: "Medium",
        type: "classify",
        prompt: "Sales Returns (Returns Inward) A/c",
        amount: 1800,
        options: ["Debit", "Credit"],
        correctIndex: 0,
        reasoning: "Sales Returns reduces the business's sales — it behaves like an expense/reduction-of-income item and carries a debit balance, opposite to Sales itself.",
        whereInTB: "Debit column of the Trial Balance."
      },
      {
        id: 9,
        difficulty: "Medium",
        type: "classify",
        prompt: "Outstanding Rent A/c",
        amount: 2500,
        options: ["Debit", "Credit"],
        correctIndex: 1,
        reasoning: "Outstanding Rent is rent that is due but not yet paid — it is a liability of the business (money it still owes), so it carries a credit balance.",
        whereInTB: "Credit column of the Trial Balance, under Liabilities."
      },
      {
        id: 10,
        difficulty: "Medium",
        type: "classify",
        prompt: "Prepaid Insurance A/c",
        amount: 900,
        options: ["Debit", "Credit"],
        correctIndex: 0,
        reasoning: "Prepaid Insurance is an amount paid in advance for a future benefit — it is an asset of the business (a right to future service), so it carries a debit balance.",
        whereInTB: "Debit column of the Trial Balance, under Assets."
      },
      {
        id: 11,
        difficulty: "Hard",
        type: "classify",
        prompt: "Provision for Depreciation A/c",
        amount: 8000,
        options: ["Debit", "Credit"],
        correctIndex: 1,
        reasoning: "A provision account accumulates a reduction against an asset's value over time — like other provisions, it is carried forward as a credit balance, even though it relates to an asset.",
        whereInTB: "Credit column of the Trial Balance."
      },
      {
        id: 12,
        difficulty: "Hard",
        type: "classify",
        prompt: "Interest on Drawings A/c",
        amount: 600,
        options: ["Debit", "Credit"],
        correctIndex: 1,
        reasoning: "Interest on Drawings is income for the business (charged to the owner for withdrawing funds) — it is a gain, so it carries a credit balance, unlike Interest on Capital (an expense for the business, a debit balance).",
        whereInTB: "Credit column of the Trial Balance, under Incomes/Gains."
      },
      {
        id: 13,
        difficulty: "Easy",
        type: "balance-check",
        prompt: "A Trial Balance lists: Capital ₹40,000 (Cr), Cash ₹10,000 (Dr), Furniture ₹15,000 (Dr), Creditors ₹5,000 (Cr), Debtors ₹20,000 (Dr). Does this Trial Balance balance?",
        options: ["Yes — both columns total ₹45,000", "No — the columns differ by ₹40,000", "No — the columns differ by ₹5,000", "Yes — both columns total ₹90,000"],
        correctIndex: 0,
        reasoning: "Total Debit = ₹10,000 + ₹15,000 + ₹20,000 = ₹45,000. Total Credit = ₹40,000 + ₹5,000 = ₹45,000. The two totals match, so the Trial Balance balances.",
        whereInTB: ""
      },
      {
        id: 14,
        difficulty: "Medium",
        type: "balance-check",
        prompt: "A Trial Balance lists: Capital ₹50,000 (Cr), Building ₹30,000 (Dr), Cash ₹12,000 (Dr), Creditors ₹10,000 (Cr). Does this Trial Balance balance?",
        options: ["No — the columns differ by ₹18,000", "Yes — both columns total ₹42,000", "Yes — both columns total ₹60,000", "No — the columns differ by ₹36,000"],
        correctIndex: 0,
        reasoning: "Total Debit = ₹30,000 + ₹12,000 = ₹42,000. Total Credit = ₹50,000 + ₹10,000 = ₹60,000. The two totals do not match — they differ by ₹18,000, so the Trial Balance does NOT balance.",
        whereInTB: ""
      },
      {
        id: 15,
        difficulty: "Easy",
        type: "balance-check",
        prompt: "A Trial Balance lists: Capital ₹55,000 (Cr), Stock ₹22,000 (Dr), Debtors ₹18,000 (Dr), Bank ₹19,000 (Dr), Creditors ₹4,000 (Cr). Does this Trial Balance balance?",
        options: ["Yes — both columns total ₹59,000", "No — the columns differ by ₹55,000", "No — the columns differ by ₹4,000", "Yes — both columns total ₹118,000"],
        correctIndex: 0,
        reasoning: "Total Debit = ₹22,000 + ₹18,000 + ₹19,000 = ₹59,000. Total Credit = ₹55,000 + ₹4,000 = ₹59,000. The two totals match, so the Trial Balance balances.",
        whereInTB: ""
      },
      {
        id: 16,
        difficulty: "Medium",
        type: "balance-check",
        prompt: "A Trial Balance lists: Capital ₹70,000 (Cr), Stock ₹25,000 (Dr), Debtors ₹18,000 (Dr), Creditors ₹15,000 (Cr), Cash ₹42,000 (Dr). Does this Trial Balance balance?",
        options: ["Yes — both columns total ₹85,000", "No — the columns differ by ₹70,000", "No — the columns differ by ₹15,000", "Yes — both columns total ₹170,000"],
        correctIndex: 0,
        reasoning: "Total Debit = ₹25,000 + ₹18,000 + ₹42,000 = ₹85,000. Total Credit = ₹70,000 + ₹15,000 = ₹85,000. The two totals match, so the Trial Balance balances.",
        whereInTB: ""
      },
      {
        id: 17,
        difficulty: "Hard",
        type: "balance-check",
        prompt: "A Trial Balance lists: Capital ₹70,000 (Cr), Stock ₹25,000 (Dr), Debtors ₹18,000 (Dr), Creditors ₹15,000 (Dr), Cash ₹42,000 (Dr). Does this Trial Balance balance?",
        options: ["No — the columns differ by ₹30,000", "Yes — both columns total ₹100,000", "Yes — both columns total ₹70,000", "No — the columns differ by ₹60,000"],
        correctIndex: 0,
        reasoning: "Total Debit = ₹25,000 + ₹18,000 + ₹15,000 + ₹42,000 = ₹100,000. Total Credit = ₹70,000 = ₹70,000. The two totals do not match — they differ by ₹30,000, so the Trial Balance does NOT balance.",
        whereInTB: ""
      },
      {
        id: 18, difficulty: "Easy", type: "classify",
        prompt: "Sales Returns A/c", amount: 3000,
        options: ["Debit", "Credit"], correctIndex: 0,
        reasoning: "Sales Returns reduces the revenue earned from sales, so it carries a debit balance — the opposite of Sales.",
        whereInTB: "Debit column of the Trial Balance, usually shown as a deduction from Sales."
      },
      {
        id: 19, difficulty: "Easy", type: "classify",
        prompt: "Purchase Returns A/c", amount: 2000,
        options: ["Debit", "Credit"], correctIndex: 1,
        reasoning: "Purchase Returns reduces the cost of goods purchased, so it carries a credit balance — the opposite of Purchases.",
        whereInTB: "Credit column of the Trial Balance, usually shown as a deduction from Purchases."
      },
      {
        id: 20, difficulty: "Easy", type: "classify",
        prompt: "Bad Debts A/c", amount: 1500,
        options: ["Debit", "Credit"], correctIndex: 0,
        reasoning: "Bad Debts is a loss/expense to the business (a debtor's amount that could not be recovered), and all expenses and losses carry debit balances.",
        whereInTB: "Debit column of the Trial Balance, under Expenses/Losses."
      },
      {
        id: 21, difficulty: "Medium", type: "classify",
        prompt: "Discount Received A/c", amount: 800,
        options: ["Debit", "Credit"], correctIndex: 1,
        reasoning: "Discount Received is a gain to the business (a benefit received from a supplier), and all incomes and gains carry credit balances.",
        whereInTB: "Credit column of the Trial Balance, under Incomes/Gains."
      },
      {
        id: 22, difficulty: "Medium", type: "classify",
        prompt: "Outstanding Salary A/c", amount: 5000,
        options: ["Debit", "Credit"], correctIndex: 1,
        reasoning: "Outstanding Salary is an amount the business still OWES to employees — it is a liability, and liabilities carry credit balances.",
        whereInTB: "Credit column of the Trial Balance, under Liabilities."
      },
      {
        id: 23, difficulty: "Medium", type: "classify",
        prompt: "Prepaid Insurance A/c", amount: 2400,
        options: ["Debit", "Credit"], correctIndex: 0,
        reasoning: "Prepaid Insurance is an amount already paid for a benefit not yet consumed — it is an asset (a right to future service), and assets carry debit balances.",
        whereInTB: "Debit column of the Trial Balance, under Assets."
      },
      {
        id: 24, difficulty: "Medium", type: "balance-check",
        prompt: "A Trial Balance lists: Capital ₹50,000 (Cr), Building ₹30,000 (Dr), Stock ₹12,000 (Dr), Creditors ₹8,000 (Cr), Debtors ₹16,000 (Dr). Does this Trial Balance balance?",
        options: ["Yes — both columns total ₹58,000", "No — the columns differ by ₹8,000", "No — the columns differ by ₹16,000", "Yes — both columns total ₹66,000"],
        correctIndex: 0,
        reasoning: "Total Debit = ₹30,000 + ₹12,000 + ₹16,000 = ₹58,000. Total Credit = ₹50,000 + ₹8,000 = ₹58,000. The two totals match, so the Trial Balance balances.",
        whereInTB: ""
      },
      {
        id: 25, difficulty: "Medium", type: "balance-check",
        prompt: "A Trial Balance lists: Capital ₹40,000 (Cr), Cash ₹9,000 (Dr), Furniture ₹18,000 (Dr), Creditors ₹6,000 (Cr), Debtors ₹15,000 (Dr). Does this Trial Balance balance?",
        options: ["No — the columns differ by ₹4,000", "Yes — both columns total ₹46,000", "No — the columns differ by ₹6,000", "Yes — both columns total ₹42,000"],
        correctIndex: 0,
        reasoning: "Total Debit = ₹9,000 + ₹18,000 + ₹15,000 = ₹42,000. Total Credit = ₹40,000 + ₹6,000 = ₹46,000. The two totals do not match — they differ by ₹4,000, so the Trial Balance does NOT balance.",
        whereInTB: ""
      },
      {
        id: 26, difficulty: "Hard", type: "balance-check",
        prompt: "A Trial Balance lists: Purchases ₹25,000 (Dr), Sales ₹40,000 (Cr), Salaries ₹5,000 (Dr), Rent ₹3,000 (Dr), Capital ₹20,000 (Cr), Creditors ₹8,000 (Cr), Cash ₹35,000 (Dr). Does this Trial Balance balance?",
        options: ["Yes — both columns total ₹68,000", "No — the columns differ by ₹8,000", "No — the columns differ by ₹15,000", "Yes — both columns total ₹73,000"],
        correctIndex: 0,
        reasoning: "Total Debit = ₹25,000 + ₹5,000 + ₹3,000 + ₹35,000 = ₹68,000. Total Credit = ₹40,000 + ₹20,000 + ₹8,000 = ₹68,000. The two totals match, so the Trial Balance balances.",
        whereInTB: ""
      },
      {
        id: 27, difficulty: "Hard", type: "balance-check",
        prompt: "A Trial Balance lists: Capital ₹30,000 (Cr), Debtors ₹12,000 (Dr), Cash ₹5,000 (Dr), Creditors ₹4,000 (Cr), Machinery ₹18,000 (Dr). Does this Trial Balance balance?",
        options: ["No — the columns differ by ₹1,000", "Yes — both columns total ₹35,000", "No — the columns differ by ₹4,000", "Yes — both columns total ₹34,000"],
        correctIndex: 0,
        reasoning: "Total Debit = ₹12,000 + ₹5,000 + ₹18,000 = ₹35,000. Total Credit = ₹30,000 + ₹4,000 = ₹34,000. The two totals do not match — they differ by ₹1,000, so the Trial Balance does NOT balance.",
        whereInTB: ""
      }
    ],

    numericals: [
      {
        id: 1,
        difficulty: "Easy",
        question: "Purchases A/c generally shows a:",
        options: ["Debit balance", "Credit balance", "Either, depending on the year", "No balance at all"],
        answerIndex: 0,
        explanation: "Purchases is an expense-type account for goods bought — it normally carries a debit balance, placed in the Debit column of the Trial Balance."
      },
      {
        id: 2,
        difficulty: "Easy",
        question: "Sales A/c generally shows a:",
        options: ["Credit balance", "Debit balance", "Either, depending on the year", "No balance at all"],
        answerIndex: 0,
        explanation: "Sales represents income earned from selling goods — it normally carries a credit balance, placed in the Credit column of the Trial Balance."
      },
      {
        id: 3,
        difficulty: "Easy",
        question: "Sundry Debtors normally appear in the Trial Balance as a:",
        options: ["Debit balance", "Credit balance", "Neither — debtors don't appear in a Trial Balance", "Both columns simultaneously"],
        answerIndex: 0,
        explanation: "Sundry Debtors represent amounts owed TO the business (an asset) — assets carry debit balances."
      },
      {
        id: 4,
        difficulty: "Easy",
        question: "Sundry Creditors normally appear in the Trial Balance as a:",
        options: ["Credit balance", "Debit balance", "Neither — creditors don't appear in a Trial Balance", "Both columns simultaneously"],
        answerIndex: 0,
        explanation: "Sundry Creditors represent amounts owed BY the business (a liability) — liabilities carry credit balances."
      },
      {
        id: 5,
        difficulty: "Easy",
        question: "Capital A/c normally appears in the Trial Balance as a:",
        options: ["Credit balance", "Debit balance", "It never appears in a Trial Balance", "Both columns simultaneously"],
        answerIndex: 0,
        explanation: "Capital represents what the business owes back to its owner — like a liability, it carries a credit balance."
      },
      {
        id: 6,
        difficulty: "Easy",
        question: "Drawings A/c normally appears in the Trial Balance as a:",
        options: ["Debit balance", "Credit balance", "It never appears in a Trial Balance", "Both columns simultaneously"],
        answerIndex: 0,
        explanation: "Drawings reduce the owner's capital (money/goods withdrawn for personal use) — this reduction is recorded as a debit balance."
      },
      {
        id: 7,
        difficulty: "Medium",
        question: "Which of these normally carries a CREDIT balance in the Trial Balance?",
        options: ["Rent Received", "Rent Paid", "Furniture", "Cash in Hand"],
        answerIndex: 0,
        explanation: "Rent Received is an income — incomes and gains normally carry credit balances, unlike expenses (Rent Paid) and assets (Furniture, Cash), which carry debit balances."
      },
      {
        id: 8,
        difficulty: "Medium",
        question: "Which of these normally carries a DEBIT balance in the Trial Balance?",
        options: ["Carriage Inward", "Discount Received", "Bank Overdraft", "Outstanding Salary"],
        answerIndex: 0,
        explanation: "Carriage Inward is an expense connected with bringing goods into the business — expenses carry debit balances, unlike Discount Received (an income), Bank Overdraft (a liability), and Outstanding Salary (a liability)."
      },
      {
        id: 9,
        difficulty: "Medium",
        question: "Provision for Doubtful Debts normally appears in the Trial Balance as a:",
        options: ["Credit balance", "Debit balance", "It is never shown in a Trial Balance", "Both columns simultaneously"],
        answerIndex: 0,
        explanation: "A provision reduces the book value of an asset (debtors) but is itself recorded and carried forward as a credit balance, similar to how accumulated depreciation is a credit balance."
      },
      {
        id: 10,
        difficulty: "Easy",
        question: "A Trial Balance is prepared to check the:",
        options: ["Arithmetical accuracy of the ledger accounts", "Profit earned during the year", "Cash balance at the bank", "Value of closing stock"],
        answerIndex: 0,
        explanation: "The primary purpose of a Trial Balance is to verify that total debits equal total credits, confirming the arithmetical accuracy of the ledger postings."
      },
      {
        id: 11,
        difficulty: "Easy",
        question: "The Trial Balance is prepared:",
        options: ["By listing the balance of every ledger account, as on a particular date", "By listing every individual transaction of the year", "Only for accounts showing a debit balance", "Only once, when the business is first set up"],
        answerIndex: 0,
        explanation: "Under the Balance Method (the method used at Class 11 level), every ledger account is first balanced, and then that single closing balance is listed in the Trial Balance — not every individual transaction."
      },
      {
        id: 12,
        difficulty: "Easy",
        question: "In a Trial Balance, if Total Debit = ₹85,000 and Total Credit = ₹85,000, this means:",
        options: ["The Trial Balance agrees (tallies)", "There are definitely no errors in the books", "The business has made a profit of ₹85,000", "The Trial Balance does not balance"],
        answerIndex: 0,
        explanation: "When both columns total to the same figure, the Trial Balance is said to 'agree' or 'tally' — but this does NOT guarantee the books are completely free of errors (some errors don't affect the totals at all)."
      },
      {
        id: 13,
        difficulty: "Medium",
        question: "A Trial Balance with the following balances: Capital ₹50,000 (Cr), Furniture ₹20,000 (Dr), Cash ₹15,000 (Dr), Creditors ₹8,000 (Cr), Debtors ₹23,000 (Dr). What is the Total of the Debit column?",
        options: ["₹58,000", "₹50,000", "₹43,000", "₹65,000"],
        answerIndex: 0,
        explanation: "Total Debit = Furniture ₹20,000 + Cash ₹15,000 + Debtors ₹23,000 = ₹58,000."
      },
      {
        id: 14,
        difficulty: "Medium",
        question: "Continuing the same Trial Balance (Capital ₹50,000 Cr, Furniture ₹20,000 Dr, Cash ₹15,000 Dr, Creditors ₹8,000 Cr, Debtors ₹23,000 Dr): what is the Total of the Credit column, and does the Trial Balance agree?",
        options: ["₹58,000 — yes, it agrees", "₹50,000 — no, it does not agree", "₹8,000 — no, it does not agree", "₹65,000 — yes, it agrees"],
        answerIndex: 0,
        explanation: "Total Credit = Capital ₹50,000 + Creditors ₹8,000 = ₹58,000, which exactly matches the Total Debit of ₹58,000 — so the Trial Balance agrees."
      },
      {
        id: 15,
        difficulty: "Medium",
        question: "A Trial Balance shows Total Debit ₹1,24,500 and Total Credit ₹1,23,800. What is the difference, and what does it indicate?",
        options: ["₹700 — there is likely an error somewhere in the books", "₹700 — this is normal and can be ignored", "₹0 — the Trial Balance agrees", "₹1,700 — there is likely an error somewhere in the books"],
        answerIndex: 0,
        explanation: "Difference = ₹1,24,500 − ₹1,23,800 = ₹700. Since the two sides don't match, this signals that at least one error exists somewhere in the recording, posting, balancing, or totalling process."
      },
      {
        id: 16,
        difficulty: "Hard",
        question: "While preparing a Trial Balance, the balance of the Purchases Returns A/c (₹2,000, a credit balance) was completely left out. What effect does this have on the Trial Balance totals?",
        options: ["The Credit column will fall short by ₹2,000, so the Trial Balance will not agree", "The Debit column will fall short by ₹2,000, so the Trial Balance will not agree", "Both columns fall short equally, so the Trial Balance still agrees", "There is no effect, since Returns accounts are not shown in a Trial Balance"],
        answerIndex: 0,
        explanation: "Since Purchases Returns is a credit balance and it was left out entirely, only the Credit column is short by ₹2,000 — the Debit column is unaffected, so the two totals will now differ by ₹2,000."
      },
      {
        id: 17,
        difficulty: "Hard",
        question: "A Debtor's balance of ₹4,500 was correctly calculated but was listed in the Trial Balance as ₹5,400 (a transposition error) in the Debit column. By how much, and on which side, is the Trial Balance now overstated?",
        options: ["Debit column overstated by ₹900", "Credit column overstated by ₹900", "Debit column overstated by ₹9,900", "No effect — transposition errors don't affect the Trial Balance"],
        answerIndex: 0,
        explanation: "₹5,400 − ₹4,500 = ₹900 extra was entered on the Debit side by mistake, so the Debit column total is now overstated by ₹900 compared to the Credit column."
      },
      {
        id: 18,
        difficulty: "Medium",
        question: "A transaction is completely omitted from the books — never entered in the Journal or Ledger at all. Will this affect the agreement of the Trial Balance?",
        options: ["No — since the transaction was never recorded on either the debit or credit side, both sides remain equally (un)affected", "Yes — the Trial Balance will always disagree in this case", "Yes, but only if the transaction involves cash", "No — errors never affect the Trial Balance"],
        answerIndex: 0,
        explanation: "An error of complete omission affects neither the debit nor the credit side, since the transaction simply isn't recorded at all — so the Trial Balance can still agree even though the books are wrong."
      },
      {
        id: 19,
        difficulty: "Medium",
        question: "Furniture purchased for ₹10,000 was wrongly debited to the Purchases A/c instead of the Furniture A/c (an error of principle). Will the Trial Balance still agree?",
        options: ["Yes — both are debit entries of the same amount, just posted to the wrong type of account", "No — this will definitely cause a mismatch", "Yes, but only if Furniture is sold within the year", "No — errors of principle always affect the Trial Balance"],
        answerIndex: 0,
        explanation: "Since the amount was still correctly debited (just to the wrong account — an expense account instead of an asset account), the Trial Balance totals are unaffected. This is exactly why an agreeing Trial Balance is not conclusive proof that the books are error-free."
      },
      {
        id: 20,
        difficulty: "Medium",
        question: "Two errors occur in the same year: the Purchases A/c is overcast (over-totalled) by ₹500, and the Salaries A/c is also overcast by ₹500. What is this combination of errors called, and will the Trial Balance still agree?",
        options: ["Compensating errors — yes, the Trial Balance will still agree", "Errors of principle — no, the Trial Balance will not agree", "Errors of commission — no, the Trial Balance will not agree", "Errors of omission — yes, the Trial Balance will still agree"],
        answerIndex: 0,
        explanation: "When two (or more) errors of equal amount happen to cancel each other's effect on the Trial Balance totals, they are called compensating errors — even though both accounts are individually wrong, the Trial Balance still agrees."
      },
      {
        id: 21,
        difficulty: "Easy",
        question: "Which of these is a common cause of a Trial Balance not agreeing?",
        options: ["A ledger balance was posted to the wrong side (debit instead of credit)", "A transaction was recorded correctly in both the Journal and the Ledger", "Depreciation was correctly charged for the year", "Closing stock was correctly valued"],
        answerIndex: 0,
        explanation: "Posting a balance to the wrong side is a one-sided error — it throws off only one column, so the Debit and Credit totals no longer match."
      },
      {
        id: 22,
        difficulty: "Easy",
        question: "Which of these is a common cause of a Trial Balance not agreeing?",
        options: ["An account balance was carried forward incorrectly", "A sale was made for cash instead of on credit", "The business paid its rent on time", "A new asset was purchased during the year"],
        answerIndex: 0,
        explanation: "Carrying forward the wrong balance for any ledger account is a direct cause of the Trial Balance failing to agree, since that account's figure is now wrong on one side only."
      },
      {
        id: 23,
        difficulty: "Easy",
        question: "The agreement of a Trial Balance is:",
        options: ["Not conclusive proof that the books are free from all errors", "Absolute proof that the books are completely accurate", "Proof that the correct profit has been calculated", "Irrelevant to the accuracy of the books"],
        answerIndex: 0,
        explanation: "Certain errors — errors of omission, errors of principle, compensating errors, and some errors of commission — do not disturb the equality of the Debit and Credit totals, so an agreeing Trial Balance is not absolute proof of accuracy."
      }
    ]
  },

  dep: {

    theory: {
      /* ---- INTRODUCTION ---- */
      simple: [
        {
          h: "Meaning of Depreciation",
          p: "Depreciation is the gradual and permanent decrease in the value of a fixed (tangible) asset, due to its use in the business, the passage of time, or obsolescence. It is a continuous, non-cash charge against profit that reflects the fact that a fixed asset — like machinery, furniture, or a vehicle — wears out and loses part of its earning capacity every year it is used.",
          p2: "Depreciation is not a loss of cash; it is an accounting charge that spreads the original cost of an asset over the years it is expected to be useful to the business."
        },
        {
          h: "Features of Depreciation",
          list: [
            { term: "Continuous and gradual", def: "Depreciation happens bit by bit, year after year — it is never a sudden, one-time fall in value." },
            { term: "Permanent decrease", def: "Once the value has fallen due to depreciation, it cannot be restored, unlike a temporary fall in market price." },
            { term: "Applies to fixed (tangible) assets", def: "Depreciation is charged only on fixed assets used in the business over several years — machinery, furniture, buildings, vehicles — not on current assets like stock or debtors." },
            { term: "A charge against profit", def: "Depreciation is treated as a business expense and is debited to the Profit & Loss Account, reducing net profit, even though no cash actually leaves the business at the time it is charged." },
            { term: "Estimated, not exact", def: "The amount of depreciation is always an estimate, based on assumptions about useful life and residual value — it can never be calculated with complete precision in advance." }
          ]
        },
        {
          h: "Need for Depreciation",
          list: [
            { term: "Correct calculation of profit", def: "Since the fixed asset is used to earn revenue, its cost must be matched against the revenue it helps generate (the Matching Concept) — charging depreciation ensures profit is not overstated." },
            { term: "True and fair financial position", def: "If depreciation is ignored, the Balance Sheet would keep showing assets at their original cost even though their real worth has fallen, giving a misleading picture of the business's financial position." },
            { term: "Provision of funds for replacement", def: "Charging depreciation each year (as a non-cash expense) helps a business retain profits within the business, so that funds are effectively set aside to replace the asset when it wears out." },
            { term: "Legal necessity", def: "Depreciation must be charged under the Companies Act and for computing taxable income under the Income Tax Act, so it is also a statutory requirement, not merely good accounting practice." }
          ]
        },
        {
          h: "Causes of Depreciation",
          list: [
            { term: "Wear and tear", def: "Normal use of an asset — a machine running, a vehicle being driven — physically wears it out over time." },
            { term: "Effluxion of time", def: "Some assets (like a leasehold property) lose value simply with the passage of time, whether or not they are actually used." },
            { term: "Obsolescence", def: "An asset may become out of date and be replaced by newer technology or a better process, even though it still physically works — for example, an old computer replaced by a faster model." },
            { term: "Expiry of legal rights", def: "Assets like patents, leases, or licences held for a fixed period automatically lose value as that period runs out." },
            { term: "Accidents", def: "A fixed asset may be permanently damaged in an accident, fire, or similar mishap — though this specific type of sudden loss is usually treated separately from routine yearly depreciation." }
          ]
        },
        {
          h: "Factors Affecting the Amount of Depreciation",
          list: [
            { term: "Cost of the asset", def: "The original purchase price of the asset, plus all expenses necessary to bring it into working condition (freight, installation, etc.) — this total is called the Historical Cost." },
            { term: "Estimated useful life", def: "The number of years (or units of production) the asset is expected to be usable in the business before it needs replacing." },
            { term: "Estimated residual (scrap) value", def: "The amount the business expects to recover by selling the asset as scrap at the end of its useful life. The amount actually depreciated over the asset's life is Cost − Residual Value." }
          ]
        },
        {
          h: "Depreciable Assets",
          p: "Depreciable assets are fixed (tangible) assets that (a) are expected to be used for more than one accounting period, (b) have a limited useful life, and (c) are held by the business for use in producing goods or services, not for resale. Examples: machinery, furniture, buildings, vehicles, and computers. Land is a fixed asset but is normally NOT depreciated, since it does not typically have a limited useful life (unless it is a wasting asset like a mine or quarry, which is subject to depletion instead)."
        },
        {
          h: "Depletion",
          p: "Depletion is the term used specifically for the reduction in the value of natural resources / wasting assets — such as mines, quarries, and oil wells — as the resource is physically extracted and used up. Depletion is usually calculated on the basis of the actual quantity extracted during the period, as a proportion of the total estimated reserves."
        },
        {
          h: "Amortisation",
          p: "Amortisation is the term used specifically for writing off the cost of intangible assets — such as patents, copyrights, trademarks, and goodwill — over their useful or legal life. The underlying idea is exactly the same as depreciation (spreading cost over useful life); only the term used, and the type of asset it applies to, is different."
        },
        {
          h: "Depreciation vs. Depletion vs. Amortisation",
          list: [
            { term: "Depreciation", def: "Applies to tangible fixed assets used in the business (machinery, furniture, buildings, vehicles) — value falls due to use, time, or obsolescence." },
            { term: "Depletion", def: "Applies specifically to natural resources / wasting assets (mines, quarries, oil wells) — value falls as the resource is physically extracted." },
            { term: "Amortisation", def: "Applies specifically to intangible assets (patents, copyrights, trademarks, goodwill) — cost is written off over the asset's useful or legal life." }
          ]
        }
      ],

      /* ---- FORMAT & RULES ---- */
      advanced: [
        {
          h: "Straight Line Method (SLM) — Meaning",
          p: "Under the Straight Line Method (also called the Fixed Instalment Method or Original Cost Method), an equal amount of depreciation is charged every year throughout the asset's useful life. The book value of the asset falls by the same fixed amount each year, and can even reach zero (or the residual value) by the end of its useful life.",
          formula: "Annual Depreciation (SLM) = (Cost − Residual Value) / Useful Life\n\nor, when a rate is given:\n\nAnnual Depreciation (SLM) = (Cost − Residual Value) × Rate / 100"
        },
        {
          h: "Worked Example — SLM (using useful life)",
          p: "A machine is purchased for ₹80,000. Its estimated residual value at the end of 4 years is ₹8,000.",
          formula: "Annual Depreciation = (Cost − Residual Value) / Useful Life\n= (₹80,000 − ₹8,000) / 4 = ₹72,000 / 4 = ₹18,000 per year\n\nThe SAME ₹18,000 is charged as depreciation in Year 1, Year 2, Year 3, and Year 4."
        },
        {
          h: "Worked Example — SLM (using rate)",
          p: "A machine costing ₹40,000 (with an estimated residual value of ₹4,000) is depreciated at 10% p.a. under SLM.",
          formula: "Annual Depreciation = (Cost − Residual Value) × Rate / 100\n= (₹40,000 − ₹4,000) × 10/100 = ₹36,000 × 10/100 = ₹3,600 per year (same every year)"
        },
        {
          h: "Written Down Value Method (WDV) — Meaning",
          p: "Under the Written Down Value Method (also called the Diminishing Balance Method or Reducing Balance Method), depreciation is calculated every year at a fixed rate, but applied to the asset's BOOK VALUE at the start of that year (opening balance) — not to its original cost. Because the book value keeps shrinking, the amount of depreciation charged keeps getting smaller every year, though it never reaches exactly zero.",
          formula: "Depreciation for the year (WDV) = Book Value at the start of the year × Rate / 100\n\nBook Value at the end of the year = Book Value at the start of the year − Depreciation for the year"
        },
        {
          h: "Worked Example — WDV (year by year)",
          p: "A machine costing ₹1,00,000 is depreciated at 10% p.a. under the Written Down Value Method.",
          formula: "Year 1: Depreciation = ₹1,00,000 × 10% = ₹10,000 → Book Value at end of Year 1 = ₹1,00,000 − ₹10,000 = ₹90,000\nYear 2: Depreciation = ₹90,000 × 10% = ₹9,000 → Book Value at end of Year 2 = ₹90,000 − ₹9,000 = ₹81,000\nYear 3: Depreciation = ₹81,000 × 10% = ₹8,100 → Book Value at end of Year 3 = ₹81,000 − ₹8,100 = ₹72,900\n\nNotice how the depreciation amount keeps falling (₹10,000 → ₹9,000 → ₹8,100) as the book value shrinks, even though the RATE (10%) stays exactly the same."
        },
        {
          h: "SLM vs. WDV — Key Differences",
          list: [
            { term: "Basis of calculation", def: "SLM: calculated on the ORIGINAL COST every year (so the amount is fixed). WDV: calculated on the WRITTEN DOWN (book) VALUE every year (so the amount keeps falling)." },
            { term: "Amount of depreciation", def: "SLM: equal every year. WDV: highest in the first year, and keeps decreasing every year after that." },
            { term: "Book value at the end of useful life", def: "SLM: can reduce to zero (or exactly the residual value). WDV: can never become exactly zero — it keeps reducing by a percentage of a smaller and smaller balance." },
            { term: "Suitability", def: "SLM suits assets that depreciate fairly evenly over time (e.g. furniture, leasehold buildings). WDV suits assets where repair costs rise as the asset ages (e.g. machinery, vehicles) — since a smaller depreciation charge in later years balances the higher repair charges." }
          ]
        },
        {
          h: "Advantages of SLM",
          list: [
            { term: "Simple to understand and calculate", def: "The same formula and the same amount is used every single year." },
            { term: "Asset can be written down to zero", def: "Useful when the asset is expected to have little or no residual value at the end of its life." },
            { term: "Equal yearly charge to Profit & Loss A/c", def: "Makes it easier to compare profits across different years, since the depreciation expense doesn't fluctuate." }
          ]
        },
        {
          h: "Advantages of WDV",
          list: [
            { term: "Matches depreciation with repair costs", def: "As an asset gets older, repair and maintenance costs usually rise — WDV charges less depreciation in later years, balancing the combined depreciation + repairs burden across years." },
            { term: "Recognized under the Income Tax Act", def: "WDV is the method prescribed for calculating depreciation for income-tax purposes in India." },
            { term: "More realistic for fast-depreciating assets", def: "Many assets (like vehicles and machinery) genuinely lose most of their value in the earlier years of use — WDV reflects this more realistically than a flat SLM charge." }
          ]
        },
        {
          h: "Part-Year Depreciation — Asset Purchased During the Year",
          p: "When an asset is purchased partway through the accounting year (not on the very first day), depreciation for that first year is charged only for the period the asset was actually used/owned — not for the full 12 months.",
          formula: "Depreciation for a partial period = Annual Depreciation × (Number of months used / 12)"
        },
        {
          h: "Worked Example — Part-Year Depreciation",
          p: "A machine costing ₹60,000 is purchased on 1st July. The accounting year ends on 31st March. Depreciation is charged @10% p.a. under SLM (no residual value).",
          formula: "Period used = 1st July to 31st March = 9 months\nAnnual Depreciation (if used for a full year) = ₹60,000 × 10% = ₹6,000\nDepreciation for 9 months = ₹6,000 × 9/12 = ₹4,500\n\nSo only ₹4,500 (not the full ₹6,000) is charged as depreciation in the year of purchase."
        },
        {
          h: "Two Methods of Recording Depreciation",
          p: "Class 11 syllabus covers two ways of recording depreciation in the books:",
          list: [
            { term: "Method 1 — Charging depreciation directly to the Asset Account", def: "Depreciation is credited straight to the Asset Account, so the Asset Account itself always shows the current, reduced book value." },
            { term: "Method 2 — Creating a Provision for Depreciation (Accumulated Depreciation) Account", def: "The Asset Account is left unchanged at its ORIGINAL COST every year. Depreciation is instead accumulated separately in a Provision for Depreciation A/c. The asset's book value at any time = Balance of Asset A/c (at cost) − Balance of Provision for Depreciation A/c." }
          ]
        },
        {
          h: "Journal Entries — Method 1 (Charged directly to Asset A/c)",
          formula: "At the end of each year:\nDepreciation A/c              Dr.\n      To Asset A/c\n\n(Being depreciation charged on the asset for the year)\n\nDepreciation A/c is then closed by transfer to Profit & Loss A/c:\nProfit & Loss A/c             Dr.\n      To Depreciation A/c"
        },
        {
          h: "Journal Entries — Method 2 (Provision for Depreciation A/c)",
          formula: "At the end of each year:\nDepreciation A/c                        Dr.\n      To Provision for Depreciation A/c\n\n(Being depreciation for the year transferred to the Provision for Depreciation A/c; the Asset A/c itself is NOT touched and continues to show cost)\n\nDepreciation A/c is then closed by transfer to Profit & Loss A/c:\nProfit & Loss A/c                       Dr.\n      To Depreciation A/c"
        },
        {
          h: "Disposal of Assets — The Idea",
          p: "When a depreciable asset is sold, its Original Cost and the Accumulated Depreciation charged on it so far must both be removed from the books, and the difference between its Book Value and the actual Sale Proceeds must be recognized as either a profit or a loss on sale.",
          formula: "Book Value at the time of sale = Original Cost − Accumulated Depreciation to date\n\nProfit on Sale = Sale Proceeds − Book Value  (when Sale Proceeds > Book Value)\nLoss on Sale   = Book Value − Sale Proceeds  (when Book Value > Sale Proceeds)"
        },
        {
          h: "Disposal — When Provision for Depreciation A/c is Maintained",
          p: "An Asset Disposal A/c (sometimes called Sale of Asset A/c) is opened to work out the profit or loss on sale cleanly, without disturbing the main Asset A/c or the Provision for Depreciation A/c for the assets that are still in use.",
          formula: "Step 1 — Transfer the asset's original cost out:\nAsset Disposal A/c            Dr.  [Original Cost]\n      To Asset A/c                   [Original Cost]\n\nStep 2 — Transfer the accumulated depreciation on this asset out:\nProvision for Depreciation A/c Dr.  [Accumulated Depreciation]\n      To Asset Disposal A/c          [Accumulated Depreciation]\n\nStep 3 — Record the sale proceeds received:\nBank/Cash A/c                  Dr.  [Sale Proceeds]\n      To Asset Disposal A/c          [Sale Proceeds]\n\nStep 4a — If Asset Disposal A/c shows a PROFIT (credit side bigger):\nAsset Disposal A/c             Dr.  [Profit]\n      To Profit on Sale of Asset A/c  [Profit]\n\nStep 4b — If Asset Disposal A/c shows a LOSS (debit side bigger):\nLoss on Sale of Asset A/c      Dr.  [Loss]\n      To Asset Disposal A/c          [Loss]"
        },
        {
          h: "Disposal — When Depreciation is Charged Directly to the Asset A/c",
          p: "Since the Asset A/c itself already shows the reduced (written down) book value under this method, no separate Asset Disposal A/c is strictly needed for a straightforward sale — the profit or loss can be recorded in a single combined entry.",
          formula: "Bank/Cash A/c                   Dr.  [Sale Proceeds]\n      To Asset A/c                    [Book Value]\n      To Profit on Sale of Asset A/c  [Profit, if Sale Proceeds > Book Value]\n\n— OR, if it is a loss —\n\nBank/Cash A/c                   Dr.  [Sale Proceeds]\nLoss on Sale of Asset A/c        Dr.  [Loss]\n      To Asset A/c                    [Book Value]"
        },
        {
          h: "Worked Example — Disposal with Profit",
          p: "Machinery was purchased for ₹50,000 on 1st April. Depreciation is charged @10% p.a. under SLM (no residual value), using a Provision for Depreciation A/c. The machinery is sold for ₹40,000 exactly at the start of the 4th year (i.e. after being used for 3 full years).",
          formula: "Accumulated Depreciation (3 years) = ₹50,000 × 10% × 3 = ₹15,000\nBook Value at the time of sale = ₹50,000 − ₹15,000 = ₹35,000\nProfit on Sale = Sale Proceeds − Book Value = ₹40,000 − ₹35,000 = ₹5,000 (Profit)\n\nAsset Disposal A/c: Debit side — To Machinery A/c ₹50,000. Credit side — By Provision for Depreciation A/c ₹15,000; By Bank A/c ₹40,000 (total ₹55,000). Since credit total (₹55,000) exceeds debit total (₹50,000) by ₹5,000, this is a PROFIT of ₹5,000, transferred to Profit on Sale of Machinery A/c."
        },
        {
          h: "Worked Example — Disposal with Loss",
          p: "Using the same machinery as above (Book Value ₹35,000 after 3 years), suppose it is instead sold for only ₹28,000.",
          formula: "Book Value at the time of sale = ₹35,000 (unchanged)\nLoss on Sale = Book Value − Sale Proceeds = ₹35,000 − ₹28,000 = ₹7,000 (Loss)\n\nAsset Disposal A/c: Debit side — To Machinery A/c ₹50,000. Credit side — By Provision for Depreciation A/c ₹15,000; By Bank A/c ₹28,000 (total ₹43,000). Since debit total (₹50,000) exceeds credit total (₹43,000) by ₹7,000, this is a LOSS of ₹7,000, transferred from Loss on Sale of Machinery A/c."
        }
      ]
    },

    concepts: [
      { title: "Depreciation", body: "The gradual, continuous, and permanent fall in the value of a fixed (tangible) asset, caused by wear and tear, the passage of time, or obsolescence." },
      { title: "Depreciable Asset", body: "A fixed asset with a limited useful life, held for use in the business (not for resale) — e.g. machinery, furniture, buildings, vehicles." },
      { title: "Depletion", body: "The reduction in value of a natural resource / wasting asset (mine, quarry, oil well) as it is physically extracted and used up." },
      { title: "Amortisation", body: "Writing off the cost of an intangible asset (patent, copyright, trademark, goodwill) over its useful or legal life." },
      { title: "Straight Line Method (SLM)", body: "A method where an equal amount of depreciation — (Cost − Residual Value) ÷ Useful Life — is charged every year." },
      { title: "Written Down Value Method (WDV)", body: "A method where a fixed rate of depreciation is applied to the asset's book value at the start of each year, so the amount charged keeps falling year on year." },
      { title: "Residual (Scrap) Value", body: "The estimated amount recoverable by selling the asset at the end of its useful life — deducted from cost under SLM before dividing by useful life." },
      { title: "Provision for Depreciation A/c", body: "An account that accumulates depreciation separately, year after year, while the Asset A/c itself continues to show the asset at its original cost." },
      { title: "Book Value (Written Down Value)", body: "Original Cost minus Accumulated Depreciation to date — the value at which an asset currently stands in the books." },
      { title: "Asset Disposal Account", body: "A temporary account opened to work out the profit or loss on selling an asset, when a Provision for Depreciation A/c is being maintained." }
    ],

    quickRevision: {
      definition: "Depreciation is the gradual, continuous, and permanent decrease in the value of a fixed (tangible) asset due to wear and tear, the passage of time, or obsolescence — it is charged as an expense against profit every accounting period the asset is used.",
      keyPoints: [
        "Depreciation is a continuous, permanent, non-cash charge — it applies only to fixed (tangible) assets used in the business, not to current assets, land, or intangible assets.",
        "The reduction in value of natural resources is called Depletion; writing off intangible assets is called Amortisation — the underlying idea is the same as depreciation, only the term and the asset type differ.",
        "The amount of depreciation depends on three factors: the Cost of the asset, its estimated Useful Life, and its estimated Residual (Scrap) Value.",
        "Under SLM, depreciation is a fixed amount every year, calculated on the ORIGINAL COST. Under WDV, depreciation is a fixed RATE applied every year to the asset's shrinking BOOK VALUE, so the amount charged keeps falling.",
        "Depreciation can be recorded either by charging it directly to the Asset A/c (which then always shows book value) or by crediting a separate Provision for Depreciation A/c (which keeps the Asset A/c at original cost)."
      ],
      calculationSteps: [
        "Step 1 (SLM) — Depreciation = (Cost − Residual Value) ÷ Useful Life, or (Cost − Residual Value) × Rate ÷ 100.",
        "Step 2 (WDV) — Depreciation for the year = Opening Book Value × Rate ÷ 100; Closing Book Value = Opening Book Value − Depreciation.",
        "Step 3 (Part-year) — If the asset is purchased partway through the year, multiply the full year's depreciation by (months used ÷ 12).",
        "Step 4 (Disposal) — Find Book Value = Cost − Accumulated Depreciation; compare it with Sale Proceeds to find Profit (Sale Proceeds > Book Value) or Loss (Book Value > Sale Proceeds).",
        "Step 5 (Journal) — Use Depreciation A/c Dr. To Asset A/c (direct method) OR Depreciation A/c Dr. To Provision for Depreciation A/c (provision method), then close Depreciation A/c to Profit & Loss A/c."
      ],
      commonMistakes: [
        "Applying the WDV rate to the ORIGINAL COST every year instead of the reducing book value.",
        "Forgetting to deduct the residual value before dividing by useful life under SLM.",
        "Charging a full year's depreciation on an asset purchased partway through the accounting year.",
        "Mixing up the direct method (Asset A/c reduced every year) with the provision method (Asset A/c stays at cost, Provision A/c accumulates depreciation) within the same problem.",
        "On disposal, comparing Sale Proceeds with the ORIGINAL COST instead of the Book Value when working out profit or loss."
      ],
      mnemonic: "SLM = same amount every year, on cost. WDV = same rate every year, on a shrinking balance. Book Value = Cost − Accumulated Depreciation, always."
    },

    numericals: [
      { id: 1, difficulty: "Easy", question: "What is depreciation?", options: ["A gradual, permanent fall in the value of a fixed asset due to use, time, or obsolescence", "A sudden increase in the value of an asset", "The total cash a business has in hand", "A tax paid on the sale of goods"], answerIndex: 0, explanation: "Depreciation is the gradual, continuous, and permanent decrease in the value of a fixed (tangible) asset, caused by wear and tear, the passage of time, or obsolescence." },
      { id: 2, difficulty: "Easy", question: "Which of the following is NOT a feature of depreciation?", options: ["It is a sudden, one-time fall in value", "It is continuous and gradual", "It is a permanent decrease in value", "It is a charge against profit"], answerIndex: 0, explanation: "Depreciation is never sudden — it happens continuously and gradually, year after year, unlike a one-time write-off of value." },
      { id: 3, difficulty: "Easy", question: "Depreciation is charged on which type of asset?", options: ["Fixed (tangible) assets with a limited useful life", "Current assets like stock and debtors", "Cash and bank balances", "Prepaid expenses"], answerIndex: 0, explanation: "Depreciation applies only to fixed (tangible) assets that are used in the business over several years, such as machinery, furniture, and vehicles." },
      { id: 4, difficulty: "Easy", question: "Which of these is a cause of depreciation?", options: ["Wear and tear from normal use", "An increase in the market demand for the product", "A rise in the company's share price", "Extra sales made during a festival season"], answerIndex: 0, explanation: "Wear and tear from normal use of the asset is one of the main causes of depreciation, along with effluxion of time and obsolescence." },
      { id: 5, difficulty: "Easy", question: "An asset becoming 'obsolete' means:", options: ["It has been replaced by newer technology, even though it may still work", "It has increased in market value", "It has been fully paid for", "It has been insured"], answerIndex: 0, explanation: "Obsolescence occurs when an asset is out of date and replaced by a better or newer alternative, even if it is still physically functional." },
      { id: 6, difficulty: "Easy", question: "Which of the following is a factor affecting the amount of depreciation?", options: ["Estimated useful life of the asset", "The owner's personal savings", "The number of employees in the business", "The rate of GST charged on sales"], answerIndex: 0, explanation: "The three main factors affecting the amount of depreciation are the Cost of the asset, its estimated Useful Life, and its estimated Residual (Scrap) Value." },
      { id: 7, difficulty: "Easy", question: "The reduction in value of a mine or quarry as it is extracted is called:", options: ["Depletion", "Depreciation", "Amortisation", "Appreciation"], answerIndex: 0, explanation: "Depletion is the specific term used for the reduction in value of natural resources / wasting assets, such as mines, quarries, and oil wells, as they are physically extracted." },
      { id: 8, difficulty: "Easy", question: "Writing off the cost of a patent over its useful life is called:", options: ["Amortisation", "Depreciation", "Depletion", "Devaluation"], answerIndex: 0, explanation: "Amortisation is the specific term for writing off the cost of intangible assets, such as patents, copyrights, and trademarks, over their useful or legal life." },
      { id: 9, difficulty: "Medium", question: "Which statement correctly distinguishes depreciation from depletion?", options: ["Depreciation applies to tangible fixed assets; depletion applies specifically to natural resources", "Depreciation applies to intangible assets; depletion applies to fixed assets", "Depreciation and depletion mean exactly the same thing with no difference", "Depletion applies only to cash and bank balances"], answerIndex: 0, explanation: "Depreciation is charged on tangible fixed assets like machinery and furniture, while depletion is used specifically for natural resources / wasting assets such as mines and quarries." },
      { id: 10, difficulty: "Medium", question: "A machine costs ₹80,000 and its estimated residual value at the end of 4 years is ₹8,000. What is the annual depreciation under SLM?", options: ["₹18,000", "₹20,000", "₹8,000", "₹72,000"], answerIndex: 0, explanation: "Annual Depreciation (SLM) = (Cost − Residual Value) / Useful Life = (₹80,000 − ₹8,000) / 4 = ₹72,000 / 4 = ₹18,000." },
      { id: 11, difficulty: "Medium", question: "A machine costing ₹40,000 (residual value ₹4,000) is depreciated at 10% p.a. under SLM. What is the annual depreciation?", options: ["₹3,600", "₹4,000", "₹4,400", "₹3,200"], answerIndex: 0, explanation: "Annual Depreciation (SLM) = (Cost − Residual Value) × Rate/100 = (₹40,000 − ₹4,000) × 10/100 = ₹36,000 × 10/100 = ₹3,600." },
      { id: 12, difficulty: "Medium", question: "A machine costing ₹60,000 is depreciated @15% p.a. under SLM, with no residual value. What is the annual depreciation?", options: ["₹9,000", "₹6,000", "₹15,000", "₹9,900"], answerIndex: 0, explanation: "Annual Depreciation (SLM) = Cost × Rate/100 = ₹60,000 × 15/100 = ₹9,000." },
      { id: 13, difficulty: "Medium", question: "A machine costing ₹1,00,000 is depreciated @10% p.a. under WDV. What is the depreciation for Year 1?", options: ["₹10,000", "₹9,000", "₹1,00,000", "₹90,000"], answerIndex: 0, explanation: "Under WDV, Year 1 depreciation = Cost × Rate/100 = ₹1,00,000 × 10% = ₹10,000. (In Year 1 only, WDV and SLM-at-the-same-rate give the same figure, since the book value hasn't changed yet.)" },
      { id: 14, difficulty: "Medium", question: "A machine costing ₹1,00,000 is depreciated @10% p.a. under WDV. What is the depreciation for Year 2?", options: ["₹9,000", "₹10,000", "₹8,100", "₹19,000"], answerIndex: 0, explanation: "Year 1: Depreciation = ₹1,00,000 × 10% = ₹10,000; Book Value = ₹90,000. Year 2: Depreciation = ₹90,000 × 10% = ₹9,000." },
      { id: 15, difficulty: "Medium", question: "A machine costing ₹1,00,000 is depreciated @10% p.a. under WDV. What is the book value at the end of Year 2?", options: ["₹81,000", "₹80,000", "₹90,000", "₹72,900"], answerIndex: 0, explanation: "Year 1: Book Value = ₹1,00,000 − ₹10,000 = ₹90,000. Year 2: Depreciation = ₹90,000 × 10% = ₹9,000; Book Value = ₹90,000 − ₹9,000 = ₹81,000." },
      { id: 16, difficulty: "Medium", question: "A machine costing ₹50,000 is depreciated @20% p.a. under WDV. What is the book value at the end of Year 2?", options: ["₹32,000", "₹30,000", "₹40,000", "₹28,800"], answerIndex: 0, explanation: "Year 1: Depreciation = ₹50,000 × 20% = ₹10,000; Book Value = ₹40,000. Year 2: Depreciation = ₹40,000 × 20% = ₹8,000; Book Value = ₹40,000 − ₹8,000 = ₹32,000." },
      { id: 17, difficulty: "Medium", question: "Under which method does the amount of depreciation remain exactly equal every year?", options: ["Straight Line Method (SLM)", "Written Down Value Method (WDV)", "Both SLM and WDV give equal yearly amounts", "Neither method gives an equal amount"], answerIndex: 0, explanation: "Under SLM, the same fixed amount of depreciation is charged every year, since it is always calculated on the unchanging original cost." },
      { id: 18, difficulty: "Medium", question: "Under WDV, why does the depreciation amount fall every year even though the rate stays the same?", options: ["Because the rate is applied to a shrinking book value each year, not the original cost", "Because the rate itself decreases every year", "Because the useful life keeps increasing", "Because residual value increases every year"], answerIndex: 0, explanation: "WDV applies the fixed rate to the book value at the START of each year. Since this book value keeps shrinking, the resulting depreciation amount also keeps shrinking, even though the rate is unchanged." },
      { id: 19, difficulty: "Easy", question: "Which method of depreciation is prescribed for computing taxable income under the Income Tax Act in India?", options: ["Written Down Value Method (WDV)", "Straight Line Method (SLM)", "Units of Production Method", "Sum of the Years' Digits Method"], answerIndex: 0, explanation: "The Written Down Value (WDV) Method is the method prescribed under the Income Tax Act for computing depreciation for income-tax purposes in India." },
      { id: 20, difficulty: "Medium", question: "A machine costing ₹60,000 is purchased on 1st July. The accounting year ends 31st March. Depreciation is charged @10% p.a. under SLM (no residual value). What is the depreciation for this first year?", options: ["₹4,500", "₹6,000", "₹3,000", "₹1,500"], answerIndex: 0, explanation: "Full-year depreciation = ₹60,000 × 10% = ₹6,000. Since the machine was used for only 9 months (1st July to 31st March), Depreciation = ₹6,000 × 9/12 = ₹4,500." },
      { id: 21, difficulty: "Medium", question: "A machine costing ₹90,000 is purchased on 1st October. The accounting year ends 31st March. Depreciation is charged @20% p.a. under SLM (no residual value). What is the depreciation for this first year?", options: ["₹9,000", "₹18,000", "₹4,500", "₹13,500"], answerIndex: 0, explanation: "Full-year depreciation = ₹90,000 × 20% = ₹18,000. The machine was used for only 6 months (1st October to 31st March), so Depreciation = ₹18,000 × 6/12 = ₹9,000." },
      { id: 22, difficulty: "Hard", question: "A machine costing ₹1,20,000 is purchased on 1st August. The accounting year ends 31st March. Depreciation is charged @12% p.a. under SLM (no residual value). What is the depreciation for this first year?", options: ["₹9,600", "₹14,400", "₹4,800", "₹12,000"], answerIndex: 0, explanation: "Full-year depreciation = ₹1,20,000 × 12% = ₹14,400. The machine was used for 8 months (1st August to 31st March), so Depreciation = ₹14,400 × 8/12 = ₹9,600." },
      { id: 23, difficulty: "Easy", question: "Under which recording method does the Asset Account continue to show the asset at its original cost every year?", options: ["The Provision for Depreciation A/c method", "The direct-to-asset-account method", "Neither method — the asset always shows book value", "Both methods show book value"], answerIndex: 0, explanation: "When a Provision for Depreciation A/c is maintained, the Asset A/c itself is left untouched at its original cost; depreciation instead accumulates separately in the Provision A/c." },
      { id: 24, difficulty: "Medium", question: "Under the direct method (depreciation charged straight to the Asset A/c), what is the correct year-end journal entry?", options: ["Depreciation A/c Dr.; To Asset A/c", "Asset A/c Dr.; To Depreciation A/c", "Depreciation A/c Dr.; To Provision for Depreciation A/c", "Provision for Depreciation A/c Dr.; To Asset A/c"], answerIndex: 0, explanation: "Under the direct method, Depreciation A/c is debited and the Asset A/c is credited directly, reducing the asset's own balance to its new book value." },
      { id: 25, difficulty: "Medium", question: "Under the Provision for Depreciation method, what is the correct year-end journal entry?", options: ["Depreciation A/c Dr.; To Provision for Depreciation A/c", "Depreciation A/c Dr.; To Asset A/c", "Provision for Depreciation A/c Dr.; To Depreciation A/c", "Asset A/c Dr.; To Provision for Depreciation A/c"], answerIndex: 0, explanation: "Under this method, Depreciation A/c is debited and Provision for Depreciation A/c is credited — the Asset A/c itself is never touched, so it keeps showing original cost." },
      { id: 26, difficulty: "Medium", question: "Machinery costing ₹50,000 has Accumulated Depreciation of ₹15,000 to date. What is its Book Value?", options: ["₹35,000", "₹50,000", "₹15,000", "₹65,000"], answerIndex: 0, explanation: "Book Value = Original Cost − Accumulated Depreciation = ₹50,000 − ₹15,000 = ₹35,000." },
      { id: 27, difficulty: "Medium", question: "Machinery with a Book Value of ₹35,000 is sold for ₹40,000. What is the result?", options: ["Profit of ₹5,000", "Loss of ₹5,000", "No profit, no loss", "Profit of ₹40,000"], answerIndex: 0, explanation: "Profit on Sale = Sale Proceeds − Book Value = ₹40,000 − ₹35,000 = ₹5,000 (Profit), since Sale Proceeds exceed Book Value." },
      { id: 28, difficulty: "Medium", question: "Machinery with a Book Value of ₹35,000 is sold for ₹28,000. What is the result?", options: ["Loss of ₹7,000", "Profit of ₹7,000", "No profit, no loss", "Loss of ₹35,000"], answerIndex: 0, explanation: "Loss on Sale = Book Value − Sale Proceeds = ₹35,000 − ₹28,000 = ₹7,000 (Loss), since Book Value exceeds Sale Proceeds." },
      { id: 29, difficulty: "Hard", question: "Machinery costing ₹50,000 was purchased on 1st April and depreciated @10% p.a. under SLM using a Provision for Depreciation A/c. It is sold for ₹40,000 exactly at the start of the 4th year (after 3 full years of use). What entry correctly records the accumulated depreciation being removed from the books via the Asset Disposal A/c?", options: ["Provision for Depreciation A/c Dr. ₹15,000; To Asset Disposal A/c ₹15,000", "Asset Disposal A/c Dr. ₹15,000; To Provision for Depreciation A/c ₹15,000", "Provision for Depreciation A/c Dr. ₹5,000; To Asset Disposal A/c ₹5,000", "Machinery A/c Dr. ₹15,000; To Asset Disposal A/c ₹15,000"], answerIndex: 0, explanation: "Accumulated Depreciation for 3 years = ₹50,000 × 10% × 3 = ₹15,000. This is removed from the Provision for Depreciation A/c and credited to the Asset Disposal A/c: Provision for Depreciation A/c Dr. ₹15,000; To Asset Disposal A/c ₹15,000." },
      { id: 30, difficulty: "Hard", question: "Continuing the same machinery (cost ₹50,000, Accumulated Depreciation ₹15,000, sold for ₹40,000), what profit or loss appears in the Asset Disposal A/c?", options: ["Profit of ₹5,000", "Loss of ₹5,000", "Profit of ₹15,000", "No profit, no loss"], answerIndex: 0, explanation: "Asset Disposal A/c — Debit: To Machinery A/c ₹50,000. Credit: By Provision for Depreciation A/c ₹15,000, By Bank A/c ₹40,000 = ₹55,000. Since credit (₹55,000) exceeds debit (₹50,000) by ₹5,000, this is a Profit of ₹5,000." },
      { id: 31, difficulty: "Medium", question: "A machine's opening book value is ₹80,000, and ₹8,000 is charged as depreciation for the year under WDV. What rate of depreciation was used?", options: ["10%", "8%", "12%", "20%"], answerIndex: 0, explanation: "Rate of Depreciation = (Depreciation / Opening Book Value) × 100 = (₹8,000 / ₹80,000) × 100 = 10%." },
      { id: 32, difficulty: "Medium", question: "A machine costing ₹40,000 (no residual value) is depreciated ₹4,000 per year under SLM. What rate of depreciation is being used?", options: ["10%", "4%", "40%", "8%"], answerIndex: 0, explanation: "Rate of Depreciation (SLM) = (Annual Depreciation / Cost) × 100 = (₹4,000 / ₹40,000) × 100 = 10%." },
      { id: 33, difficulty: "Medium", question: "A machine costs ₹1,00,000, with residual value ₹10,000 and useful life of 5 years. What is the book value at the end of Year 2 under SLM?", options: ["₹64,000", "₹72,000", "₹60,000", "₹82,000"], answerIndex: 0, explanation: "Annual Depreciation (SLM) = (₹1,00,000 − ₹10,000) / 5 = ₹90,000 / 5 = ₹18,000. Book Value at end of Year 2 = ₹1,00,000 − (₹18,000 × 2) = ₹1,00,000 − ₹36,000 = ₹64,000." },
      { id: 34, difficulty: "Easy", question: "Which of these best explains why depreciation is charged even though no cash actually leaves the business at that moment?", options: ["It matches the cost of using the asset against the revenue it helps earn, giving a true picture of profit", "It is charged only to reduce the business's tax refund", "It increases the cash balance of the business", "It is a legal requirement with no accounting purpose"], answerIndex: 0, explanation: "Depreciation follows the Matching Concept — the cost of using a fixed asset to earn revenue must be recognized as an expense in the same period as that revenue, even though it is a non-cash charge." },
      { id: 35, difficulty: "Easy", question: "Which of the following is normally NOT depreciated, even though it is a fixed asset?", options: ["Land (unless it is a wasting asset like a mine)", "Machinery", "Furniture", "Motor vehicles"], answerIndex: 0, explanation: "Land is usually not depreciated because it does not have a limited useful life — unless it is a wasting asset such as a mine or quarry, in which case depletion (not depreciation) applies." }
    ]
  },

  /* ============================================================
     FLASHCARDS — across all three chapters
     ============================================================ */
  flashcards: [
  {
    "id": 1,
    "chapter": "eq",
    "front": "What is the Accounting Equation?",
    "back": "Assets = Capital + Liabilities"
  },
  {
    "id": 2,
    "chapter": "eq",
    "front": "What is an Asset?",
    "back": "Everything of value a business owns or controls — cash, stock, machinery, debtors, furniture, etc."
  },
  {
    "id": 3,
    "chapter": "eq",
    "front": "What is a Liability?",
    "back": "What a business owes to outsiders — creditors, bank loans, outstanding expenses."
  },
  {
    "id": 4,
    "chapter": "eq",
    "front": "What is Capital?",
    "back": "What the business owes to its own owner — investment adjusted for profit, loss, and drawings."
  },
  {
    "id": 5,
    "chapter": "eq",
    "front": "What is the expanded Accounting Equation?",
    "back": "Assets = Liabilities + Capital + Revenues − Expenses − Drawings"
  },
  {
    "id": 6,
    "chapter": "eq",
    "front": "Why does the Accounting Equation always balance?",
    "back": "Because of the Dual Aspect concept — every transaction affects two elements by the same amount."
  },
  {
    "id": 7,
    "chapter": "eq",
    "front": "What does 'Dual Aspect' mean?",
    "back": "Every transaction has two effects on the accounting equation, recorded simultaneously — the engine behind double-entry bookkeeping."
  },
  {
    "id": 8,
    "chapter": "eq",
    "front": "What is the Business Entity concept?",
    "back": "The business and its owner are treated as two separate accountable units, even in a sole proprietorship."
  },
  {
    "id": 9,
    "chapter": "eq",
    "front": "What is the Money Measurement concept?",
    "back": "Only transactions expressible in money enter the books — even valuable non-monetary events are excluded."
  },
  {
    "id": 10,
    "chapter": "eq",
    "front": "How does a cash sale at a profit affect the equation?",
    "back": "It increases an asset (cash) and increases capital (through the profit earned)."
  },
  {
    "id": 11,
    "chapter": "eq",
    "front": "How does paying a creditor by cheque affect the equation?",
    "back": "One asset (bank) decreases and one liability (creditor) decreases — equal amounts, both sides fall together."
  },
  {
    "id": 12,
    "chapter": "eq",
    "front": "How do drawings affect the equation?",
    "back": "They reduce both an asset (usually cash) and capital, by the same amount."
  },
  {
    "id": 13,
    "chapter": "eq",
    "front": "How does an outstanding expense affect the equation?",
    "back": "It increases a liability and simultaneously decreases capital (through the expense)."
  },
  {
    "id": 14,
    "chapter": "eq",
    "front": "Are debtors an asset or a liability?",
    "back": "An asset — a debtor owes money TO the business."
  },
  {
    "id": 15,
    "chapter": "eq",
    "front": "Are creditors an asset or a liability?",
    "back": "A liability — the business owes money TO the creditor."
  },
  {
    "id": 16,
    "chapter": "eq",
    "front": "Does buying furniture for cash change total assets?",
    "back": "No — it's an asset-for-asset swap; total assets remain the same, only composition changes."
  },
  {
    "id": 17,
    "chapter": "eq",
    "front": "What effect does additional capital introduced have?",
    "back": "It increases both an asset (usually cash) and capital, by the same amount."
  },
  {
    "id": 18,
    "chapter": "eq",
    "front": "What effect does a loss have on capital?",
    "back": "It reduces capital, exactly like drawings do."
  },
  {
    "id": 19,
    "chapter": "eq",
    "front": "Formula: Capital = ?",
    "back": "Capital = Assets − Liabilities"
  },
  {
    "id": 20,
    "chapter": "eq",
    "front": "Formula: Liabilities = ?",
    "back": "Liabilities = Assets − Capital"
  },
  {
    "id": 21,
    "chapter": "dc",
    "front": "What are the three types of accounts (Traditional Approach)?",
    "back": "Personal, Real, and Nominal accounts."
  },
  {
    "id": 22,
    "chapter": "dc",
    "front": "Golden Rule for Personal Accounts?",
    "back": "Debit the Receiver, Credit the Giver."
  },
  {
    "id": 23,
    "chapter": "dc",
    "front": "Golden Rule for Real Accounts?",
    "back": "Debit what comes in, Credit what goes out."
  },
  {
    "id": 24,
    "chapter": "dc",
    "front": "Golden Rule for Nominal Accounts?",
    "back": "Debit all expenses and losses, Credit all incomes and gains."
  },
  {
    "id": 25,
    "chapter": "dc",
    "front": "What is a Personal Account?",
    "back": "An account of a person, firm, company, or an artificial/representative entity — e.g. Ramesh's A/c, Bank A/c, Outstanding Salary A/c."
  },
  {
    "id": 26,
    "chapter": "dc",
    "front": "What is a Real Account?",
    "back": "An account of assets and properties — tangible (Cash, Machinery) or intangible (Goodwill, Patents)."
  },
  {
    "id": 27,
    "chapter": "dc",
    "front": "What is a Nominal Account?",
    "back": "An account of expenses, losses, incomes, and gains — e.g. Rent A/c, Salary A/c, Commission Received A/c."
  },
  {
    "id": 28,
    "chapter": "dc",
    "front": "What are the five categories under the Modern Approach?",
    "back": "Assets, Liabilities, Capital, Revenue, and Expenses."
  },
  {
    "id": 29,
    "chapter": "dc",
    "front": "Modern Rule: how is an increase in Assets recorded?",
    "back": "Debit."
  },
  {
    "id": 30,
    "chapter": "dc",
    "front": "Modern Rule: how is an increase in Liabilities recorded?",
    "back": "Credit."
  },
  {
    "id": 31,
    "chapter": "dc",
    "front": "Modern Rule: how is an increase in Capital recorded?",
    "back": "Credit."
  },
  {
    "id": 32,
    "chapter": "dc",
    "front": "Modern Rule: how is an increase in Expenses recorded?",
    "back": "Debit."
  },
  {
    "id": 33,
    "chapter": "dc",
    "front": "Modern Rule: how is an increase in Revenue recorded?",
    "back": "Credit."
  },
  {
    "id": 34,
    "chapter": "dc",
    "front": "Is Purchases A/c a Real or Nominal account?",
    "back": "Nominal — it is treated as an expense account."
  },
  {
    "id": 35,
    "chapter": "dc",
    "front": "Is Bank A/c a Personal or Real account?",
    "back": "Personal — the bank is treated as an artificial/legal person."
  },
  {
    "id": 36,
    "chapter": "dc",
    "front": "Is Drawings A/c a Personal account?",
    "back": "Yes — it represents the proprietor as the receiver of cash or goods withdrawn."
  },
  {
    "id": 37,
    "chapter": "dc",
    "front": "What is a Representative Personal Account?",
    "back": "An account that represents a group of persons or a specific claim, e.g. Outstanding Salary A/c or Prepaid Insurance A/c."
  },
  {
    "id": 38,
    "chapter": "dc",
    "front": "How is Depreciation on machinery recorded?",
    "back": "Depreciation A/c is debited and Machinery A/c (Real) is credited — no cash is involved."
  },
  {
    "id": 39,
    "chapter": "dc",
    "front": "How is a Bad Debt written off recorded?",
    "back": "Bad Debts A/c is debited and the Debtor's personal account is credited."
  },
  {
    "id": 40,
    "chapter": "dc",
    "front": "Is trade discount recorded in the books?",
    "back": "No — only the net, trade-discounted price is recorded. Cash discount, however, IS recorded."
  },
  {
    "id": 41,
    "chapter": "jr",
    "front": "What is a Journal?",
    "back": "The book of original/prime entry, where every transaction is first recorded in chronological order using debit-credit rules."
  },
  {
    "id": 42,
    "chapter": "jr",
    "front": "What are the columns of a Journal?",
    "back": "Date, Particulars, Ledger Folio (L.F.), Debit Amount, and Credit Amount."
  },
  {
    "id": 43,
    "chapter": "jr",
    "front": "What is 'Narration'?",
    "back": "A brief explanation written below each journal entry, in brackets, starting with 'Being...', describing the transaction."
  },
  {
    "id": 44,
    "chapter": "jr",
    "front": "What is the standard journal format for the debit line?",
    "back": "The account name followed by 'Dr.' on the left, with the amount in the Debit column."
  },
  {
    "id": 45,
    "chapter": "jr",
    "front": "What is the standard journal format for the credit line?",
    "back": "The account name, prefixed with 'To', slightly indented, with the amount in the Credit column."
  },
  {
    "id": 46,
    "chapter": "jr",
    "front": "What is a Compound Journal Entry?",
    "back": "A single journal entry involving more than two accounts — either multiple debits, multiple credits, or both."
  },
  {
    "id": 47,
    "chapter": "jr",
    "front": "What is 'Ledger Folio' (L.F.)?",
    "back": "The page number in the ledger where the account has been posted — filled in only at the time of posting, not while journalising."
  },
  {
    "id": 48,
    "chapter": "jr",
    "front": "What is the Journal's role in the accounting cycle?",
    "back": "It is the first place a transaction is recorded, before being posted to individual ledger accounts."
  },
  {
    "id": 49,
    "chapter": "jr",
    "front": "Why must total debits equal total credits in every journal entry?",
    "back": "Because of the dual aspect concept — every transaction affects at least two accounts by equal and opposite amounts."
  },
  {
    "id": 50,
    "chapter": "jr",
    "front": "How is a cash purchase of goods journalised?",
    "back": "Purchases A/c Dr. / To Cash A/c"
  },
  {
    "id": 51,
    "chapter": "jr",
    "front": "How is a cash sale of goods journalised?",
    "back": "Cash A/c Dr. / To Sales A/c"
  },
  {
    "id": 52,
    "chapter": "jr",
    "front": "How is a credit purchase journalised?",
    "back": "Purchases A/c Dr. / To Supplier's A/c"
  },
  {
    "id": 53,
    "chapter": "jr",
    "front": "How is a credit sale journalised?",
    "back": "Customer's A/c Dr. / To Sales A/c"
  },
  {
    "id": 54,
    "chapter": "jr",
    "front": "How is cash discount allowed treated in a journal entry?",
    "back": "Discount Allowed A/c is debited along with the cash/bank received, and the debtor's account is credited in full."
  },
  {
    "id": 55,
    "chapter": "jr",
    "front": "How is cash discount received treated in a journal entry?",
    "back": "Discount Received A/c is credited along with the cash/bank paid, and the creditor's account is debited in full."
  },
  {
    "id": 56,
    "chapter": "jr",
    "front": "How is a dishonoured cheque journalised?",
    "back": "The receiver's personal account is debited again, and Bank A/c is credited — reversing the earlier receipt."
  },
  {
    "id": 57,
    "chapter": "jr",
    "front": "How are goods given as charity or samples journalised?",
    "back": "Charity A/c or Advertisement A/c is debited, and Purchases A/c is credited, at cost."
  },
  {
    "id": 58,
    "chapter": "jr",
    "front": "How is an outstanding expense journalised?",
    "back": "The expense A/c is debited, and 'Outstanding [Expense] A/c' is credited."
  },
  {
    "id": 59,
    "chapter": "jr",
    "front": "How is a prepaid expense journalised?",
    "back": "'Prepaid [Expense] A/c' is debited, and Cash/Bank A/c is credited."
  },
  {
    "id": 60,
    "chapter": "jr",
    "front": "What comes right after journalising, in the accounting cycle?",
    "back": "Posting — transferring each journal entry into its respective ledger account."
  },
  {
    "id": 61,
    "chapter": "lg",
    "front": "What is a Ledger?",
    "back": "The principal book of accounts where all transactions relating to a particular account, first recorded in the Journal, are transferred (posted) in a classified, permanent form."
  },
  {
    "id": 62,
    "chapter": "lg",
    "front": "Why is the Ledger called the 'Book of Final Entry'?",
    "back": "Because it is the last stage where a transaction is recorded — nothing further happens to it after posting, unlike the Journal, which is only the first record."
  },
  {
    "id": 63,
    "chapter": "lg",
    "front": "What shape is a standard Ledger account drawn in?",
    "back": "A 'T' shape — a vertical line down the middle with the account name on top, Debit (Dr.) on the left and Credit (Cr.) on the right."
  },
  {
    "id": 64,
    "chapter": "lg",
    "front": "What does 'J.F.' stand for in a Ledger account?",
    "back": "Journal Folio — the page number of the Journal from which this particular entry was posted, creating a two-way trail between Journal and Ledger."
  },
  {
    "id": 65,
    "chapter": "lg",
    "front": "Posting rule: a Journal debit becomes a Ledger...?",
    "back": "Debit — posted to the debit (left) side of that same account, with the amount unchanged."
  },
  {
    "id": 66,
    "chapter": "lg",
    "front": "Posting rule: a Journal credit becomes a Ledger...?",
    "back": "Credit — posted to the credit (right) side of that same account, with the amount unchanged."
  },
  {
    "id": 67,
    "chapter": "lg",
    "front": "What word is written on the debit side of a Ledger posting?",
    "back": "'To' — for example 'To Sales A/c', showing what this account received value from."
  },
  {
    "id": 68,
    "chapter": "lg",
    "front": "What word is written on the credit side of a Ledger posting?",
    "back": "'By' — for example 'By Cash A/c', showing what this account gave value to."
  },
  {
    "id": 69,
    "chapter": "lg",
    "front": "What is the first step in balancing a Ledger account?",
    "back": "Total (foot) both the debit side and the credit side separately, adding up every amount posted to each."
  },
  {
    "id": 70,
    "chapter": "lg",
    "front": "What is 'Balance c/d'?",
    "back": "'Balance carried down' — the difference between the two sides, written on the smaller side so both sides show equal totals."
  },
  {
    "id": 71,
    "chapter": "lg",
    "front": "What is 'Balance b/d'?",
    "back": "'Balance brought down' — the same figure as Balance c/d, brought to the opposite side on the next date, becoming the opening balance for the following period."
  },
  {
    "id": 72,
    "chapter": "lg",
    "front": "If Balance b/d appears on the debit side, what kind of balance is it?",
    "back": "A Debit Balance — typical of Asset and Expense accounts."
  },
  {
    "id": 73,
    "chapter": "lg",
    "front": "If Balance b/d appears on the credit side, what kind of balance is it?",
    "back": "A Credit Balance — typical of Liability, Capital, and Income accounts."
  },
  {
    "id": 74,
    "chapter": "lg",
    "front": "What is a 'Nil balance' in a Ledger account?",
    "back": "When both sides total to exactly the same figure with nothing left over — common for Nominal accounts once closed off to the Profit & Loss Account at year-end."
  },
  {
    "id": 75,
    "chapter": "lg",
    "front": "Why must the Ledger be prepared before the Trial Balance?",
    "back": "The Trial Balance lists the closing balance of every Ledger account — without posting and balancing the Ledger first, there would be no balances to list."
  },
  {
    "id": 76,
    "chapter": "lg",
    "front": "In a compound Journal entry with two credits, how many postings result on the credit side?",
    "back": "Two separate postings — one to each credited account's own Ledger page, each referencing the debited account with 'By'."
  },
  {
    "id": 77,
    "chapter": "lg",
    "front": "Does a Ledger account's balance carry forward across accounting periods?",
    "back": "Yes, for Personal and Real accounts (Assets, Liabilities, Capital) — the closing Balance c/d becomes next period's opening Balance b/d. Nominal accounts instead close to zero via the Profit & Loss Account."
  },
  {
    "id": 78,
    "chapter": "lg",
    "front": "What is the relationship between the Journal and the Ledger, in one line?",
    "back": "The Journal records transactions in chronological (date) order; the Ledger reorganizes those same transactions by account, so each account's full history and balance can be seen together."
  },
  {
    "id": 79,
    "chapter": "lg",
    "front": "Mnemonic for Ledger posting sides?",
    "back": "'Debit — To; Credit — By' — say it as one phrase to recall which word goes with which side instantly."
  },
  {
    "id": 80,
    "chapter": "lg",
    "front": "What does posting mean, in the context of the accounting cycle?",
    "back": "Transferring each debit and credit from a Journal entry into its own account's page in the Ledger, preserving the account name, side, and amount exactly as journalised."
  },
  {
    "id": 81,
    "chapter": "jr",
    "front": "How is an Opening Journal Entry recorded?",
    "back": "Debit all assets, credit all liabilities, and let Capital A/c be the balancing figure — the difference between total assets and total liabilities. Capital is never given directly."
  },
  {
    "id": 82,
    "chapter": "jr",
    "front": "How is the sale of a fixed asset at a profit journalised?",
    "back": "Cash/Bank A/c Dr. (full amount received); To Asset A/c (its book value); To Gain (Profit) on Sale A/c (the excess). The asset account is only ever credited for its own book value, never the sale proceeds."
  },
  {
    "id": 83,
    "chapter": "jr",
    "front": "How is the sale of a fixed asset at a loss journalised?",
    "back": "Cash/Bank A/c Dr. (amount received); Loss on Sale A/c Dr. (the shortfall); To Asset A/c (its full book value). The asset is still removed at its complete book value regardless of what was actually received."
  },
  {
    "id": 84,
    "chapter": "jr",
    "front": "What is the difference between a Purchases Return and a Sales Return?",
    "back": "A Purchases Return (Returns Outward) is goods the business sends back to its own supplier. A Sales Return (Returns Inward) is goods a customer sends back to the business. They use separate accounts and move in opposite directions."
  },
  {
    "id": 85,
    "chapter": "jr",
    "front": "How is 'Bad Debts Recovered' journalised, and why not just reverse the write-off?",
    "back": "Cash/Bank A/c Dr.; To Bad Debts Recovered A/c. The original debtor's account was already closed to zero when written off, so it isn't reopened — the recovery is treated as fresh, unexpected income instead."
  },
  {
    "id": 86,
    "chapter": "jr",
    "front": "How is the insolvency of a debtor journalised?",
    "back": "Cash/Bank A/c Dr. (amount actually recovered); Bad Debts A/c Dr. (the unrecoverable balance); To Debtor's A/c (the full original amount owed) — closing the account completely."
  },
  {
    "id": 87,
    "chapter": "jr",
    "front": "What is a Bills Receivable, and how is receiving one journalised?",
    "back": "A Bills Receivable is a debtor's formal, legally enforceable promise to pay by a fixed date — an asset. Entry: Bills Receivable A/c Dr.; To Debtor's A/c, replacing the ordinary debtor balance."
  },
  {
    "id": 88,
    "chapter": "jr",
    "front": "How is a Bills Receivable honoured on its due date journalised?",
    "back": "Bank/Cash A/c Dr.; To Bills Receivable A/c — the bill is settled and closed once the acceptor actually pays as promised."
  },
  {
    "id": 89,
    "chapter": "jr",
    "front": "How are bank-initiated entries like bank charges or interest credited by the bank journalised?",
    "back": "Bank Charges A/c Dr.; To Bank A/c for a charge deducted by the bank. Bank A/c Dr.; To Interest Received A/c for interest the bank pays in — both are noticed only from the pass book, but still affect the real Bank A/c balance."
  },
  {
    "id": 90,
    "chapter": "jr",
    "front": "What is the difference between Accrued Income and Income Received in Advance?",
    "back": "Accrued Income is income already earned but not yet received (an asset). Income Received in Advance is cash already received for work not yet done (a liability) — they are mirror-image adjustment entries."
  },
  {
    "id": 91,
    "chapter": "jr",
    "front": "What is the difference between payment 'on account' and payment 'in full settlement'?",
    "back": "Payment on account is a partial payment — the creditor's account still shows a balance owed afterward. Payment in full settlement clears the account completely, often paired with a Discount Received."
  },
  {
    "id": 92,
    "chapter": "jr",
    "front": "What is the difference between Trade Discount and Cash Discount?",
    "back": "Trade Discount is deducted before any entry is made and is never recorded separately — only the net invoice value appears in the books. Cash Discount is recorded through its own account (Discount Allowed/Received) because it's a real cost of encouraging prompt payment, given at the time of settlement, not at the time of billing."
  },
  {
    "id": 93,
    "chapter": "jr",
    "front": "The business pays the proprietor's life insurance premium by cheque. What is debited?",
    "back": "Drawings A/c — never Insurance Premium A/c. A life insurance policy always belongs to the proprietor personally, so using business funds for it is treated exactly like any other personal withdrawal."
  },
  {
    "id": 94,
    "chapter": "jr",
    "front": "What is the difference between Carriage Inwards and Carriage Outwards?",
    "back": "Carriage Inwards is paid on goods being purchased/brought in — treated as part of the cost of purchases. Carriage Outwards is paid on goods already sold, being delivered to the customer — a selling expense, recorded separately in the Profit & Loss Account."
  },
  {
    "id": 95,
    "chapter": "jr",
    "front": "How does withdrawing cash from the bank for office use differ from withdrawing it for personal use?",
    "back": "Office use: Cash A/c Dr.; To Bank A/c — a contra entry, money stays inside the business. Personal use: Drawings A/c Dr.; To Bank A/c — the money leaves the business and reduces the owner's capital."
  },
  {
    "id": 96,
    "chapter": "jr",
    "front": "How is the dishonour of a Bills Receivable journalised?",
    "back": "Debtor's A/c Dr.; To Bills Receivable A/c. Since no cash was actually received, Bills Receivable A/c is closed and the debtor's personal account is reinstated for the same amount, as if the bill had never been accepted."
  },
  {
    "id": 97,
    "chapter": "jr",
    "front": "How is additional capital introduced during the year journalised?",
    "back": "Exactly like the original investment: Cash/Bank A/c Dr.; To Capital A/c — the only difference is timing, not the accounting treatment."
  },
  {
    "id": 98,
    "chapter": "jr",
    "front": "How does 'goods lost by theft, no claim admitted' differ from 'goods lost by fire, claim admitted'?",
    "back": "Theft with no claim: the entire cost is a straight loss (Loss by Theft A/c Dr.; To Purchases A/c). Fire with a claim: only the unrecovered portion is a loss — the recoverable amount goes to Insurance Claim A/c (an asset), not treated as a loss at all."
  },
  {
    "id": 99,
    "chapter": "jr",
    "front": "What is 'drawings of an asset other than cash or goods'?",
    "back": "Any business asset (furniture, equipment, etc.) taken by the proprietor for personal use — the specific asset account is credited directly and Drawings A/c is debited, just as with cash or goods drawings."
  },
  {
    "id": 100,
    "chapter": "jr",
    "front": "How is interest debited by the bank on an overdraft journalised, and how does it differ from interest the bank credits?",
    "back": "Interest on Overdraft A/c Dr.; To Bank A/c — a finance expense, since the business is paying the bank. This is the mirror image of interest the bank credits (Bank A/c Dr.; To Interest Received A/c), which is income for the business."
  },
  {
    "id": 101,
    "chapter": "jr",
    "front": "What is a Rebate, and how does it differ from Trade Discount and Cash Discount?",
    "back": "Rebate is an amount deducted for reasons like poor quality or wrong specification — not for buying in bulk (Trade Discount) or for prompt payment (Cash Discount). It's tracked in its own Rebate Allowed/Received account."
  },
  {
    "id": 102,
    "chapter": "jr",
    "front": "Life insurance premium paid for employees vs. for the proprietor — how do the entries differ?",
    "back": "For employees (a group scheme): a genuine business expense — Employees' Insurance Premium A/c Dr. For the proprietor personally: Drawings A/c Dr., since it protects him, not the business."
  },
  {
    "id": 103,
    "chapter": "jr",
    "front": "A cash discount is offered only if the full invoice is paid within a deadline. The customer pays half on time, half late. What discount is allowed?",
    "back": "None at all. A conditional cash discount tied to full payment by a deadline is all-or-nothing — it isn't prorated just because part of the payment arrived on time."
  },
  {
    "id": 104,
    "chapter": "jr",
    "front": "The proprietor sells a personal asset (e.g. a scooter) and puts the proceeds into the business. How is this recorded?",
    "back": "Cash/Bank A/c Dr.; To Capital A/c. The personal asset's sale itself is never journalised — only the moment the money actually enters the business matters, treated exactly like any other capital introduced."
  },
  {
    "id": 105,
    "chapter": "jr",
    "front": "Rent is paid for a building partly used for business and partly as the proprietor's residence. How is it split?",
    "back": "The business-use portion is debited to Rent A/c; the personal-use portion is debited to Drawings A/c — in the same proportion as the actual usage split."
  },
  {
    "id": 106,
    "chapter": "jr",
    "front": "How is a transfer of funds between two of the firm's own bank accounts journalised?",
    "back": "Bank A/c (receiving bank) Dr.; To Bank A/c (sending bank). A contra entry between two asset accounts — total assets don't change, only which account holds the money."
  },
  {
    "id": 107,
    "chapter": "jr",
    "front": "How does paying a creditor by Bank Draft differ from paying by cheque?",
    "back": "Mechanically the same for the creditor's account, but a draft usually costs a fee. Entry: Creditor's A/c Dr. (amount owed); Bank Charges A/c Dr. (the fee); To Bank A/c (the total drawn)."
  },
  {
    "id": 108,
    "chapter": "jr",
    "front": "How does Miscellaneous (Sundry) Expenses A/c differ from Petty Cash A/c?",
    "back": "Miscellaneous Expenses groups small, varied costs by their nature (postage, refreshment, etc.). Petty Cash is an imprest fund — about how small payments are administered, not what they're for."
  },
  {
    "id": 109,
    "chapter": "jr",
    "front": "How is closing stock brought into the books at year-end?",
    "back": "Closing Stock A/c Dr.; To Trading A/c. This lets the Trading Account correctly measure gross profit, since unsold goods shouldn't count as part of the cost of goods actually sold."
  },
  {
    "id": 110,
    "chapter": "jr",
    "front": "What is Amortisation, and how does it relate to Depreciation?",
    "back": "Amortisation is depreciation's counterpart for intangible assets (Goodwill, Patents, Trademarks) — Amortisation A/c Dr.; To the intangible asset's own account, the same logic as Depreciation A/c Dr.; To a tangible fixed asset."
  },
  {
    "id": 111,
    "chapter": "cb",
    "front": "What are Subsidiary Books (Special Purpose Books)?",
    "back": "Books of accounts maintained to record transactions of a particular nature — e.g. Cash Book for cash and bank, Purchases Book for credit purchases, Sales Book for credit sales."
  },
  {
    "id": 112,
    "chapter": "cb",
    "front": "Name the six Subsidiary Books (sub-divisions of the Journal).",
    "back": "Cash Book, Purchases Book, Sales Book, Purchases Return Book, Sales Return Book, and Journal Proper."
  },
  {
    "id": 113,
    "chapter": "cb",
    "front": "What does Journal Proper record?",
    "back": "Transactions which cannot be recorded in any of the other Subsidiary Books."
  },
  {
    "id": 114,
    "chapter": "cb",
    "front": "List three advantages of Subsidiary Books.",
    "back": "Division of Work, Specialisation & Efficiency, Saving of Time (also: Availability of Information, Facility in Checking, Responsibility)."
  },
  {
    "id": 115,
    "chapter": "cb",
    "front": "What is a Cash Book?",
    "back": "A book in which receipts and payments in Cash and through Bank are recorded, in chronological order."
  },
  {
    "id": 116,
    "chapter": "cb",
    "front": "On which side of the Cash Book are receipts written? Payments?",
    "back": "Receipts are written on the debit (left) side; payments are written on the credit (right) side."
  },
  {
    "id": 117,
    "chapter": "cb",
    "front": "Why is Cash Book called both a Subsidiary Book and a Principal Book?",
    "back": "Subsidiary Book because cash/bank transactions are first recorded here; Principal Book because it IS the Cash Account and Bank Account — its balances go directly into the Trial Balance."
  },
  {
    "id": 118,
    "chapter": "cb",
    "front": "What are the two main types of Cash Book?",
    "back": "Simple Cash Book (Single Column) — cash only; Two-Column/Double Column Cash Book — cash and bank columns."
  },
  {
    "id": 119,
    "chapter": "cb",
    "front": "In Simple Cash Book, what type of account is Cash, and what is the rule for recording it?",
    "back": "A Real Account (Traditional) / Asset Account (Modern). Rule: \"Debit what comes in, Credit what goes out\" or \"Increases in assets are debited, decreases are credited.\""
  },
  {
    "id": 120,
    "chapter": "cb",
    "front": "In Simple Cash Book, what does the 'V. No.' column record?",
    "back": "The Voucher number — the serial number of the Receipt Voucher or Payment Voucher supporting that transaction."
  },
  {
    "id": 121,
    "chapter": "cb",
    "front": "What three things does Simple Cash Book NOT record?",
    "back": "(a) Non-cash transactions, (b) cheques received or given, (c) cash discount allowed and received."
  },
  {
    "id": 122,
    "chapter": "cb",
    "front": "Can Cash Book ever show a credit balance?",
    "back": "No — Cash Book will not have a credit balance (i.e., Cash in Hand), because cash paid cannot exceed cash in hand."
  },
  {
    "id": 123,
    "chapter": "cb",
    "front": "Are the opening and closing balances of the Cash Book ever posted to a ledger account?",
    "back": "No — neither is posted. The closing balance is shown directly on the assets side of the Balance Sheet."
  },
  {
    "id": 124,
    "chapter": "cb",
    "front": "In a Two-Column Cash Book, what does the Bank column represent, and what rule applies to it?",
    "back": "It represents the Bank Account — an Asset Account (Modern)/Personal Account (Traditional). Rule: increase in assets is debited (bank is the receiver), decrease is credited (bank is the giver)."
  },
  {
    "id": 125,
    "chapter": "cb",
    "front": "Where is Cash Discount Allowed or Received recorded?",
    "back": "NEVER in the Cash Book itself — always through a Journal entry passed in Journal Proper."
  },
  {
    "id": 126,
    "chapter": "cb",
    "front": "Give the Journal Proper entry for Discount Allowed.",
    "back": "Discount Allowed A/c Dr. ...; To Party's A/c ..."
  },
  {
    "id": 127,
    "chapter": "cb",
    "front": "Give the Journal Proper entry for Discount Received.",
    "back": "Party's A/c Dr. ...; To Discount Received A/c ..."
  },
  {
    "id": 128,
    "chapter": "cb",
    "front": "If a cheque is dishonoured, how is Discount Allowed reversed?",
    "back": "Journal Proper entry: Party's A/c Dr.; To Discount Allowed A/c — written back, while the cheque amount itself is recorded in the Cash Book."
  },
  {
    "id": 129,
    "chapter": "cb",
    "front": "What are Contra Entries?",
    "back": "Entries which affect both cash and bank — one balance decreases while the other increases (e.g. cash deposited into bank, or cash withdrawn from bank for office use)."
  },
  {
    "id": 130,
    "chapter": "cb",
    "front": "How are Contra Entries marked, and are they posted to the Ledger?",
    "back": "Marked 'C' in the L.F. column on both sides of the Cash Book. They are NOT posted in any Ledger Account."
  },
  {
    "id": 131,
    "chapter": "cb",
    "front": "Is 'cash withdrawn from bank for personal use' a Contra Entry?",
    "back": "No — it is not a Contra Entry, since it does not represent a simple cash↔bank transfer for the business itself; it is recorded as Drawings, not marked 'C'."
  },
  {
    "id": 132,
    "chapter": "cb",
    "front": "How is a dishonoured cheque (deposited earlier) recorded in the Cash Book?",
    "back": "Written in the credit (payments) side, bank column, with the customer's name — the Customer's Account is effectively debited (still owes) and the Bank Account is credited (balance reduced)."
  },
  {
    "id": 133,
    "chapter": "cb",
    "front": "What is Cheques-in-Hand A/c used for?",
    "back": "To record a cheque received but NOT deposited in the bank on the same day: Cheques-in-Hand A/c Dr.; To Party's A/c (Journal Proper). On deposit, Cash Book bank column debit: To Cheques-in-Hand A/c."
  },
  {
    "id": 134,
    "chapter": "cb",
    "front": "What is a post-dated cheque?",
    "back": "A cheque issued or received of a future date — it can be presented to the bank for payment only on or after that date."
  },
  {
    "id": 135,
    "chapter": "cb",
    "front": "On what date is a post-dated cheque ISSUED entered in the Cash Book?",
    "back": "On the date it is actually issued — NOT on the future date written on the cheque."
  },
  {
    "id": 136,
    "chapter": "cb",
    "front": "What is Bank Overdraft?",
    "back": "The amount withdrawn from bank in excess of the available balance in the account — it is a liability, payable to the bank."
  },
  {
    "id": 137,
    "chapter": "cb",
    "front": "How is an opening Bank Overdraft shown in the Cash Book?",
    "back": "In the credit (payments) side as 'By Balance b/d', since it's a credit balance in the bank column."
  },
  {
    "id": 138,
    "chapter": "cb",
    "front": "What is a Petty Cash Book?",
    "back": "A book used for recording expenses involving petty/small amounts — maintained by the Petty Cashier, and is like a Petty Cash Account."
  },
  {
    "id": 139,
    "chapter": "cb",
    "front": "What is the Imprest System of Petty Cash?",
    "back": "The Petty Cashier is given a fixed, estimated amount (imprest money) at the start of a period, and is reimbursed exactly what he spent at the end — restoring him to the same original amount for the next period."
  },
  {
    "id": 140,
    "chapter": "cb",
    "front": "Name the two types of Petty Cash Books.",
    "back": "Simple Petty Cash Book and Analytical Petty Cash Book."
  },
  {
    "id": 141,
    "chapter": "cb",
    "front": "What makes an Analytical Petty Cash Book different from a Simple one?",
    "back": "It has a separate analysis column for each commonly occurring expense head (conveyance, cartage, stationery, courier, etc.) plus a 'sundries' column — so totals under each head can be found easily, unlike the Simple Petty Cash Book."
  },
  {
    "id": 142,
    "chapter": "cb",
    "front": "How is Petty Cash advanced, and how is it accounted for when the Petty Cashier submits his account?",
    "back": "Advance: Petty Cash A/c Dr.; To Cash A/c. On submission: each Expense A/c Dr. (individually); To Petty Cash A/c (total spent)."
  },
  {
    "id": 143,
    "chapter": "sp2",
    "front": "What is the Purchases Book used for?",
    "back": "To record CREDIT purchases of goods the firm trades in, or raw material used for manufacturing goods. Cash purchases and purchases of non-goods (assets) are excluded."
  },
  {
    "id": 144,
    "chapter": "sp2",
    "front": "What is the Sales Book used for?",
    "back": "To record CREDIT sales of goods the firm deals in. Cash sales, and credit sales of assets not traded in, are excluded."
  },
  {
    "id": 145,
    "chapter": "sp2",
    "front": "Where are cash purchases and cash sales of goods recorded?",
    "back": "In the Cash Book — never in the Purchases Book or Sales Book, no matter how large the amount."
  },
  {
    "id": 146,
    "chapter": "sp2",
    "front": "Where is the credit purchase of a fixed asset (e.g. furniture, computer) for office use recorded?",
    "back": "In Journal Proper — not the Purchases Book, since it isn't goods the firm trades in."
  },
  {
    "id": 147,
    "chapter": "sp2",
    "front": "How is Trade Discount treated in the Purchases Book or Sales Book?",
    "back": "It is deducted from the List Price BEFORE the entry is made. Only the net amount (List Price − Trade Discount) is recorded; Trade Discount never gets its own ledger account."
  },
  {
    "id": 148,
    "chapter": "sp2",
    "front": "What is a Debit Note, and who prepares it?",
    "back": "A document prepared by the PURCHASER when returning goods bought on credit, notifying the seller that a debit has been made to their account. It's the basis for a Purchases Return Book entry."
  },
  {
    "id": 149,
    "chapter": "sp2",
    "front": "What is a Credit Note, and who prepares it?",
    "back": "A document prepared by the SELLER when a customer returns goods sold on credit, evidencing that a credit has been made to the customer's account. It's the basis for a Sales Return Book entry."
  },
  {
    "id": 150,
    "chapter": "sp2",
    "front": "What column replaces 'Invoice No.' in the Purchases Return Book and Sales Return Book?",
    "back": "'Debit Note No.' in the Purchases Return Book, and 'Credit Note No.' in the Sales Return Book — otherwise the ruling is identical to the Purchases Book / Sales Book."
  },
  {
    "id": 151,
    "chapter": "sp2",
    "front": "How is the periodic total of the Purchases Book posted?",
    "back": "The Cost column total is debited to Purchases A/c; each individual supplier's account was already credited as the entries were made. Freight/Packing column totals, if any, are debited to their own accounts."
  },
  {
    "id": 152,
    "chapter": "sp2",
    "front": "How is the periodic total of the Sales Book posted?",
    "back": "The Sale Value column total is credited to Sales A/c; each individual customer's account was already debited as the entries were made. A Packing Charges column total, if recovered, is credited to Packing Charges A/c."
  },
  {
    "id": 153,
    "chapter": "sp2",
    "front": "How is the Purchases Return Book total posted?",
    "back": "Credited to Purchases Return A/c; each individual supplier's account was already debited as the return entries were made."
  },
  {
    "id": 154,
    "chapter": "sp2",
    "front": "How is the Sales Return Book total posted?",
    "back": "Debited to Sales Return A/c; each individual customer's account was already credited as the return entries were made."
  },
  {
    "id": 155,
    "chapter": "sp2",
    "front": "Name the six types of entries recorded through Journal Proper.",
    "back": "Opening Entries, Closing Entries, Rectification Entries, Transfer Entries, Adjustment Entries, and Miscellaneous Entries."
  },
  {
    "id": 156,
    "chapter": "sp2",
    "front": "Give three examples of Journal Proper's 'Miscellaneous Entries'.",
    "back": "Credit purchase of an asset not traded in; reversal of discount allowed/received on dishonour of a cheque; and capital brought in kind (e.g. an asset instead of cash)."
  },
  {
    "id": 157,
    "chapter": "sp2",
    "front": "Where is Bad Debts written off recorded?",
    "back": "In Journal Proper — Bad Debts A/c Dr.; To Customer's A/c."
  },
  {
    "id": 158,
    "chapter": "sp2",
    "front": "Where are Opening Entries and Closing Entries recorded?",
    "back": "Both are recorded in Journal Proper — Opening Entries at the start of the accounting year, Closing Entries at the end."
  },
  {
    "id": 159,
    "chapter": "sp2",
    "front": "A trader sells goods he deals in to a buyer who will use them personally, not resell them. Which book records this sale?",
    "back": "Still the Sales Book — what matters is that the SELLER deals in these goods; the buyer's intended use doesn't change how the seller records a credit sale."
  },
  {
    "id": 160,
    "chapter": "sp2",
    "front": "Where is freight paid IN CASH by the seller (an expense not recovered from the buyer) recorded?",
    "back": "In the Cash Book, as a cash payment — not in the Sales Book, since it was never billed to the customer as part of the invoice."
  },
  {
    "id": 161,
    "chapter": "sp2",
    "front": "Is Purchases Book a part of the Journal or the Ledger?",
    "back": "Part of the Journal — it's a Subsidiary Book (a book of original entry), not a Ledger account, even though it has no debit/credit columns like a ledger account either."
  },
  {
    "id": 162,
    "chapter": "sp2",
    "front": "What's the key difference between the Purchases Book and the Purchases Account?",
    "back": "Purchases Book (part of the Journal) records only CREDIT purchases of goods; Purchases Account (part of the Ledger) records both cash AND credit purchases, and its balance is transferred to the Trading Account."
  },
  {
    "id": 1,
    "chapter": "brs",
    "front": "What is a Bank Reconciliation Statement (BRS)?",
    "back": "A statement prepared on a given date to explain every item causing the Cash Book's bank balance and the Pass Book balance to differ, and to prove the two agree once adjusted."
  },
  {
    "id": 2,
    "chapter": "brs",
    "front": "Why is a BRS prepared? (name two purposes)",
    "back": "To locate and explain every difference between the two balances, and to detect errors or fraud — it also verifies the correct bank balance for the Balance Sheet."
  },
  {
    "id": 3,
    "chapter": "brs",
    "front": "What is 'Balance as per Cash Book'?",
    "back": "The bank balance shown by the firm's own record — the bank column of its Cash Book — reflecting only what the firm has recorded so far."
  },
  {
    "id": 4,
    "chapter": "brs",
    "front": "What is 'Balance as per Pass Book'?",
    "back": "The bank balance shown in the copy of the account the bank maintains and issues to the firm — reflecting only what the bank has recorded so far."
  },
  {
    "id": 5,
    "chapter": "brs",
    "front": "Why do the debit/credit labels in the Pass Book look reversed compared to the Cash Book?",
    "back": "The Pass Book is written from the BANK's point of view — money the bank holds for the firm is money the bank owes back, so it's a credit balance there, unlike in the firm's own Cash Book."
  },
  {
    "id": 6,
    "chapter": "brs",
    "front": "What is the single most common cause of difference between Cash Book and Pass Book?",
    "back": "Timing differences — one side has already recorded a transaction, the other side hasn't recorded it yet."
  },
  {
    "id": 7,
    "chapter": "brs",
    "front": "Cheque issued but not yet presented — treatment starting from Cash Book?",
    "back": "Add. (The Cash Book already reduced its balance; the bank hasn't reduced the Pass Book yet.)"
  },
  {
    "id": 8,
    "chapter": "brs",
    "front": "Cheque deposited but not yet collected — treatment starting from Cash Book?",
    "back": "Less (Deduct). (The Cash Book already increased its balance; the bank hasn't credited it yet.)"
  },
  {
    "id": 9,
    "chapter": "brs",
    "front": "Bank charges debited by the bank, not yet in the Cash Book — treatment starting from Cash Book?",
    "back": "Less (Deduct). (The Pass Book is already reduced; the Cash Book isn't, yet.)"
  },
  {
    "id": 10,
    "chapter": "brs",
    "front": "Interest allowed by the bank, not yet in the Cash Book — treatment starting from Cash Book?",
    "back": "Add. (The Pass Book is already increased; the Cash Book isn't, yet.)"
  },
  {
    "id": 11,
    "chapter": "brs",
    "front": "Direct collection by the bank (e.g. dividend), not yet in the Cash Book — treatment starting from Cash Book?",
    "back": "Add. (The Pass Book already reflects the collection; the Cash Book doesn't, yet.)"
  },
  {
    "id": 12,
    "chapter": "brs",
    "front": "Direct payment by the bank (e.g. insurance premium under standing instruction), not yet in the Cash Book — treatment starting from Cash Book?",
    "back": "Less (Deduct). (The Pass Book already reflects the payment; the Cash Book doesn't, yet.)"
  },
  {
    "id": 13,
    "chapter": "brs",
    "front": "A cheque deposited and recorded is later dishonoured, not yet updated in the Cash Book — treatment starting from Cash Book?",
    "back": "Less (Deduct). (The Cash Book still shows it as realised money, but the bank has already reversed the credit.)"
  },
  {
    "id": 14,
    "chapter": "brs",
    "front": "What happens to every item's Add/Less treatment if you switch the BRS's starting balance from Cash Book to Pass Book?",
    "back": "It reverses — every 'Add' becomes 'Less', and every 'Less' becomes 'Add', for the same transaction, because the direction of travel has reversed."
  },
  {
    "id": 15,
    "chapter": "brs",
    "front": "What single question decides Add or Less for any BRS item?",
    "back": "\"Is my starting balance SHORT of, or AHEAD of, the balance I'm trying to reach because of this item?\" Short → Add. Ahead → Less."
  },
  {
    "id": 16,
    "chapter": "brs",
    "front": "Format of a BRS starting from the Cash Book balance — what's the final line?",
    "back": "Balance as per Cash Book, Add:(items), Less:(items) → Balance as per Pass Book."
  },
  {
    "id": 17,
    "chapter": "brs",
    "front": "What's the important rule about errors in the Cash Book vs errors in the Pass Book?",
    "back": "Cash Book errors are corrected on the way to the (correct) Pass Book figure; Pass Book errors are corrected on the way to the (correct) Cash Book figure."
  },
  {
    "id": 18,
    "chapter": "brs",
    "front": "Common mistake: confusing which cheque type?",
    "back": "Confusing an UNPRESENTED cheque (issued by the firm, Cash Book already reduced) with an UNCOLLECTED cheque (deposited by the firm, Cash Book already increased) — they take opposite treatment."
  },
  {
    "id": 19,
    "chapter": "brs",
    "front": "Common mistake: do most BRS reconciling items need a Journal entry?",
    "back": "No — most are simple timing differences that resolve themselves once both books eventually record the same transaction; only genuine errors typically need correction."
  },
  {
    "id": 20,
    "chapter": "brs",
    "front": "If the Cash Book's receipts side is undercast (totalled ₹500 short), what's the correction, starting from the Cash Book?",
    "back": "Add ₹500 — the true balance is ₹500 higher than what the Cash Book currently shows."
  },
  {
    "id": 1,
    "chapter": "gst",
    "front": "What does GST stand for?",
    "back": "Goods and Services Tax."
  },
  {
    "id": 2,
    "chapter": "gst",
    "front": "What kind of tax is GST?",
    "back": "An indirect, multi-stage, destination-based tax levied on the supply of goods and services."
  },
  {
    "id": 3,
    "chapter": "gst",
    "front": "Why was GST introduced?",
    "back": "To replace multiple indirect taxes (VAT, excise duty, service tax, etc.) with a single, uniform tax and remove the cascading effect of tax on tax."
  },
  {
    "id": 4,
    "chapter": "gst",
    "front": "What does 'destination-based' mean for GST?",
    "back": "Tax revenue goes to the state where goods/services are finally consumed, not where they are produced."
  },
  {
    "id": 5,
    "chapter": "gst",
    "front": "What is the Dual GST model?",
    "back": "India splits GST into CGST (Central) + SGST (State) for intra-state sales, and IGST for inter-state sales."
  },
  {
    "id": 6,
    "chapter": "gst",
    "front": "What tax applies to an intra-state sale?",
    "back": "CGST and SGST, split equally (e.g. 18% total = 9% CGST + 9% SGST)."
  },
  {
    "id": 7,
    "chapter": "gst",
    "front": "What tax applies to an inter-state sale?",
    "back": "IGST (Integrated GST) — the full rate, with no CGST/SGST split."
  },
  {
    "id": 8,
    "chapter": "gst",
    "front": "Name one key advantage of GST.",
    "back": "It removes the cascading effect of tax (tax on tax) through Input Tax Credit."
  },
  {
    "id": 9,
    "chapter": "gst",
    "front": "What is Input GST?",
    "back": "GST paid by a business on its own purchases — can be claimed as credit against Output GST."
  },
  {
    "id": 10,
    "chapter": "gst",
    "front": "What is Output GST?",
    "back": "GST collected by a business on its sales — payable to the government after adjusting for Input GST."
  },
  {
    "id": 11,
    "chapter": "gst",
    "front": "How is Net GST Payable calculated?",
    "back": "Net GST Payable = Output GST − Input GST."
  },
  {
    "id": 12,
    "chapter": "gst",
    "front": "What is the formula for GST Amount?",
    "back": "GST Amount = Taxable Value × GST Rate / 100."
  },
  {
    "id": 13,
    "chapter": "gst",
    "front": "What is the formula for Invoice Value?",
    "back": "Invoice Value = Taxable Value + GST Amount."
  },
  {
    "id": 14,
    "chapter": "gst",
    "front": "How does trade discount affect GST calculation?",
    "back": "Trade discount is deducted from the list price FIRST; GST is calculated only on the resulting taxable (net) value — never on the gross list price."
  },
  {
    "id": 15,
    "chapter": "gst",
    "front": "Formula: Taxable Value with trade discount?",
    "back": "Taxable Value = List Price − Trade Discount."
  },
  {
    "id": 16,
    "chapter": "gst",
    "front": "When is freight included in the GST calculation?",
    "back": "Only when the question states GST also applies to freight — then it's added to the taxable value before calculating GST. Otherwise it's added separately, after GST."
  },
  {
    "id": 17,
    "chapter": "gst",
    "front": "Which account is debited for GST paid on a purchase?",
    "back": "Input GST A/c (simple Class 11 treatment)."
  },
  {
    "id": 18,
    "chapter": "gst",
    "front": "Which account is credited for GST collected on a sale?",
    "back": "Output GST A/c (simple Class 11 treatment)."
  },
  {
    "id": 19,
    "chapter": "gst",
    "front": "Common mistake to avoid with trade discount + GST?",
    "back": "Never calculate GST on the gross (list price) amount when a trade discount applies — always deduct the discount first."
  },
  {
    "id": 20,
    "chapter": "gst",
    "front": "In a credit sale with GST, what amount is debited to the Debtor's account?",
    "back": "The FULL invoice value (taxable value + GST), since that is the total amount owed by the customer."
  },
  {
    "id": 1,
    "chapter": "tb",
    "front": "What is a Trial Balance?",
    "back": "A statement listing the balances of all ledger accounts as on a particular date, used to check the arithmetical accuracy of the books."
  },
  {
    "id": 2,
    "chapter": "tb",
    "front": "Is a Trial Balance an account?",
    "back": "No — it is a statement/list, not an account. It has no debit or credit 'side' in the ledger sense."
  },
  {
    "id": 3,
    "chapter": "tb",
    "front": "What is the main purpose of a Trial Balance?",
    "back": "To check that Total Debit balances equal Total Credit balances — verifying the arithmetical accuracy of the ledger."
  },
  {
    "id": 4,
    "chapter": "tb",
    "front": "Which method is used to prepare a Trial Balance at Class 11 level?",
    "back": "The Balance Method — every ledger account is balanced first, then that single closing balance is listed."
  },
  {
    "id": 5,
    "chapter": "tb",
    "front": "How many amount columns does a Trial Balance have?",
    "back": "Two — a Debit Balance column and a Credit Balance column."
  },
  {
    "id": 6,
    "chapter": "tb",
    "front": "Name three types of accounts that normally have DEBIT balances.",
    "back": "Assets (e.g. Cash, Machinery), Expenses/Losses (e.g. Wages, Bad Debts), and Drawings."
  },
  {
    "id": 7,
    "chapter": "tb",
    "front": "Name three types of accounts that normally have CREDIT balances.",
    "back": "Liabilities (e.g. Creditors), Capital, and Incomes/Gains (e.g. Sales, Commission Received)."
  },
  {
    "id": 8,
    "chapter": "tb",
    "front": "Is 'the Trial Balance agrees' proof that the books have no errors?",
    "back": "No — some errors (omission, principle, compensating, certain commission errors) don't disturb the agreement of the Trial Balance."
  },
  {
    "id": 9,
    "chapter": "tb",
    "front": "What is an error of omission?",
    "back": "A transaction that is completely left out of the books — never recorded in the Journal or Ledger at all. It does NOT affect the Trial Balance's agreement."
  },
  {
    "id": 10,
    "chapter": "tb",
    "front": "What is an error of principle?",
    "back": "A transaction recorded with the correct amount but against the wrong accounting principle — e.g. capital expenditure treated as revenue expenditure. Does NOT affect Trial Balance agreement."
  },
  {
    "id": 11,
    "chapter": "tb",
    "front": "What are compensating errors?",
    "back": "Two or more errors that happen to cancel out each other's effect on the Trial Balance totals, so the Trial Balance still agrees despite both underlying mistakes."
  },
  {
    "id": 12,
    "chapter": "tb",
    "front": "Name a type of error that WOULD cause the Trial Balance to disagree.",
    "back": "A one-sided error — e.g. posting a balance to the wrong side, a wrong total (casting error), or an incorrect balance carried forward."
  },
  {
    "id": 13,
    "chapter": "tb",
    "front": "What is the Trial Balance used as the basis for?",
    "back": "Preparing the final accounts — the Trading and Profit & Loss Account, and the Balance Sheet."
  },
  {
    "id": 14,
    "chapter": "tb",
    "front": "How are Sundry Debtors shown in the Trial Balance?",
    "back": "As a Debit balance — they are an asset (money owed TO the business)."
  },
  {
    "id": 15,
    "chapter": "tb",
    "front": "How are Sundry Creditors shown in the Trial Balance?",
    "back": "As a Credit balance — they are a liability (money owed BY the business)."
  },
  {
    "id": 16,
    "chapter": "tb",
    "front": "How is Provision for Doubtful Debts shown in the Trial Balance?",
    "back": "As a Credit balance, even though it relates to an asset (debtors) — provisions are carried forward as credit balances."
  },
  {
    "id": 17,
    "chapter": "tb",
    "front": "Common mistake: forgetting to include an account.",
    "back": "Omitting an account balance entirely from the Trial Balance is one of the most frequent errors students make while preparing one."
  },
  {
    "id": 18,
    "chapter": "tb",
    "front": "Common mistake: placing a balance on the wrong side.",
    "back": "Listing a debit balance in the Credit column (or vice versa) throws off both totals and is a very common source of disagreement."
  },
  {
    "id": 19,
    "chapter": "tb",
    "front": "What does it mean if the Trial Balance does NOT agree?",
    "back": "There is at least one error somewhere in recording, posting, balancing, or totalling that needs to be located and corrected."
  },
  {
    "id": 20,
    "chapter": "tb",
    "front": "Key formula for a Trial Balance.",
    "back": "Total of the Debit column = Total of the Credit column."
  },
  {
    "id": 163,
    "chapter": "dep",
    "front": "What is Depreciation?",
    "back": "The gradual, continuous, and permanent fall in the value of a fixed (tangible) asset due to wear and tear, time, or obsolescence."
  },
  {
    "id": 164,
    "chapter": "dep",
    "front": "Name three causes of depreciation.",
    "back": "Wear and tear, effluxion of time, and obsolescence (also: expiry of legal rights, accidents)."
  },
  {
    "id": 165,
    "chapter": "dep",
    "front": "What are the three factors affecting the amount of depreciation?",
    "back": "Cost of the asset, its estimated useful life, and its estimated residual (scrap) value."
  },
  {
    "id": 166,
    "chapter": "dep",
    "front": "What is Depletion?",
    "back": "The reduction in value of a natural resource / wasting asset (mine, quarry, oil well) as it is physically extracted."
  },
  {
    "id": 167,
    "chapter": "dep",
    "front": "What is Amortisation?",
    "back": "Writing off the cost of an intangible asset (patent, copyright, trademark, goodwill) over its useful or legal life."
  },
  {
    "id": 168,
    "chapter": "dep",
    "front": "What is the formula for depreciation under the Straight Line Method (SLM)?",
    "back": "Depreciation = (Cost − Residual Value) ÷ Useful Life, or (Cost − Residual Value) × Rate ÷ 100."
  },
  {
    "id": 169,
    "chapter": "dep",
    "front": "What is the formula for depreciation under the Written Down Value Method (WDV)?",
    "back": "Depreciation for the year = Opening Book Value × Rate ÷ 100."
  },
  {
    "id": 170,
    "chapter": "dep",
    "front": "Under SLM, does the annual depreciation amount change from year to year?",
    "back": "No — it remains exactly the same every year, since it is always calculated on the original cost."
  },
  {
    "id": 171,
    "chapter": "dep",
    "front": "Under WDV, why does the depreciation amount fall each year even though the rate is fixed?",
    "back": "Because the fixed rate is applied to the book value at the start of each year, and that book value keeps shrinking."
  },
  {
    "id": 172,
    "chapter": "dep",
    "front": "Which method of depreciation is prescribed under the Income Tax Act in India?",
    "back": "The Written Down Value (WDV) Method."
  },
  {
    "id": 173,
    "chapter": "dep",
    "front": "State one advantage of SLM.",
    "back": "It is simple to calculate and the asset can be written down to zero (or its residual value) by the end of its useful life."
  },
  {
    "id": 174,
    "chapter": "dep",
    "front": "State one advantage of WDV.",
    "back": "It matches falling depreciation with rising repair costs as an asset ages, balancing the combined charge across years."
  },
  {
    "id": 175,
    "chapter": "dep",
    "front": "How do you calculate depreciation for an asset purchased partway through the year?",
    "back": "Full-year depreciation × (number of months the asset was used ÷ 12)."
  },
  {
    "id": 176,
    "chapter": "dep",
    "front": "What is the journal entry for depreciation under the direct (asset-account) method?",
    "back": "Depreciation A/c Dr.; To Asset A/c."
  },
  {
    "id": 177,
    "chapter": "dep",
    "front": "What is the journal entry for depreciation under the Provision for Depreciation method?",
    "back": "Depreciation A/c Dr.; To Provision for Depreciation A/c."
  },
  {
    "id": 178,
    "chapter": "dep",
    "front": "Under the Provision for Depreciation method, what happens to the Asset A/c every year?",
    "back": "Nothing — it stays at its original cost. Depreciation accumulates separately in the Provision for Depreciation A/c."
  },
  {
    "id": 179,
    "chapter": "dep",
    "front": "How is Book Value calculated?",
    "back": "Book Value = Original Cost − Accumulated Depreciation to date."
  },
  {
    "id": 180,
    "chapter": "dep",
    "front": "How do you know if there is a profit or loss on the sale of an asset?",
    "back": "If Sale Proceeds > Book Value, it's a Profit. If Book Value > Sale Proceeds, it's a Loss."
  },
  {
    "id": 181,
    "chapter": "dep",
    "front": "What is an Asset Disposal Account used for?",
    "back": "To work out the profit or loss on selling an asset, when a Provision for Depreciation A/c is being maintained."
  },
  {
    "id": 182,
    "chapter": "dep",
    "front": "Is land normally depreciated?",
    "back": "No — land is usually not depreciated, since it does not have a limited useful life (unless it is a wasting asset like a mine)."
  }
],

  /* ============================================================
     QUIZ BANK — across all three chapters
     ============================================================ */
  quiz: [
  {
    "id": 1,
    "chapter": "eq",
    "difficulty": "Easy",
    "q": "The accounting equation is expressed as:",
    "options": [
      "Assets = Capital − Liabilities",
      "Assets = Capital + Liabilities",
      "Capital = Assets + Liabilities",
      "Liabilities = Assets + Capital"
    ],
    "answerIndex": 1,
    "explanation": "Assets are funded by two sources only: the owner (Capital) and outsiders (Liabilities), so Assets = Capital + Liabilities."
  },
  {
    "id": 2,
    "chapter": "eq",
    "difficulty": "Easy",
    "q": "Which of these is NOT an asset?",
    "options": [
      "Debtors",
      "Machinery",
      "Creditors",
      "Cash"
    ],
    "answerIndex": 2,
    "explanation": "Creditors are amounts the business owes to outsiders — a liability, not an asset."
  },
  {
    "id": 3,
    "chapter": "eq",
    "difficulty": "Easy",
    "q": "If Assets = ₹1,20,000 and Liabilities = ₹30,000, Capital equals:",
    "options": [
      "₹90,000",
      "₹1,50,000",
      "₹30,000",
      "₹1,20,000"
    ],
    "answerIndex": 0,
    "explanation": "Capital = Assets − Liabilities = 1,20,000 − 30,000 = 90,000."
  },
  {
    "id": 4,
    "chapter": "eq",
    "difficulty": "Easy",
    "q": "Which concept explains why the owner's investment is shown as a liability of the business?",
    "options": [
      "Money Measurement",
      "Business Entity",
      "Going Concern",
      "Dual Aspect"
    ],
    "answerIndex": 1,
    "explanation": "The Business Entity concept treats the business and owner as separate units, so the owner's investment becomes something the business 'owes back'."
  },
  {
    "id": 5,
    "chapter": "eq",
    "difficulty": "Easy",
    "q": "Drawings by the owner cause:",
    "options": [
      "An increase in capital",
      "A decrease in capital",
      "No change in capital",
      "An increase in liabilities"
    ],
    "answerIndex": 1,
    "explanation": "Drawings represent the owner taking resources out of the business, reducing capital."
  },
  {
    "id": 6,
    "chapter": "eq",
    "difficulty": "Medium",
    "q": "A firm's capital is ₹80,000 and liabilities are ₹25,000. Total assets are:",
    "options": [
      "₹55,000",
      "₹1,05,000",
      "₹25,000",
      "₹80,000"
    ],
    "answerIndex": 1,
    "explanation": "Assets = Capital + Liabilities = 80,000 + 25,000 = 1,05,000."
  },
  {
    "id": 7,
    "chapter": "eq",
    "difficulty": "Medium",
    "q": "Profit earned during the year has what effect on capital?",
    "options": [
      "Decreases it",
      "Increases it",
      "No effect",
      "Converts it to a liability"
    ],
    "answerIndex": 1,
    "explanation": "Profit belongs to the owner and directly increases capital, just like drawings decrease it."
  },
  {
    "id": 8,
    "chapter": "eq",
    "difficulty": "Medium",
    "q": "Which of these transactions leaves total assets unchanged?",
    "options": [
      "Purchasing furniture on credit",
      "Purchasing furniture for cash",
      "Taking a bank loan",
      "Introducing additional capital"
    ],
    "answerIndex": 1,
    "explanation": "Buying furniture for cash simply swaps one asset (cash) for another (furniture) — total assets stay the same."
  },
  {
    "id": 9,
    "chapter": "eq",
    "difficulty": "Medium",
    "q": "An outstanding (unpaid) rent expense of ₹2,000 will:",
    "options": [
      "Increase assets and increase capital",
      "Increase liabilities and decrease capital",
      "Decrease assets and decrease liabilities",
      "Have no effect on the equation"
    ],
    "answerIndex": 1,
    "explanation": "Recognizing an unpaid expense increases a liability (amount owed) and reduces capital (through the expense)."
  },
  {
    "id": 10,
    "chapter": "eq",
    "difficulty": "Medium",
    "q": "Which item, if given, would NOT directly help you calculate Capital using the basic equation?",
    "options": [
      "Total Assets",
      "Total Liabilities",
      "Owner's date of birth",
      "Total Assets and Liabilities together"
    ],
    "answerIndex": 2,
    "explanation": "Capital depends only on Assets and Liabilities — personal, non-financial details are irrelevant."
  },
  {
    "id": 11,
    "chapter": "eq",
    "difficulty": "Hard",
    "q": "A firm's opening capital is ₹60,000. During the year, profit is ₹12,000, additional capital introduced is ₹5,000, and drawings are ₹8,000. Closing capital is:",
    "options": [
      "₹69,000",
      "₹85,000",
      "₹77,000",
      "₹65,000"
    ],
    "answerIndex": 0,
    "explanation": "Closing Capital = 60,000 + 12,000 + 5,000 − 8,000 = 69,000."
  },
  {
    "id": 12,
    "chapter": "eq",
    "difficulty": "Hard",
    "q": "Goods costing ₹5,000 were destroyed by fire and no insurance claim was received. This transaction:",
    "options": [
      "Increases assets, increases capital",
      "Decreases assets, decreases capital",
      "Decreases liabilities, increases capital",
      "Has no effect on the equation"
    ],
    "answerIndex": 1,
    "explanation": "An uninsured loss reduces an asset (stock) with nothing received in return, so capital absorbs the loss directly."
  },
  {
    "id": 13,
    "chapter": "eq",
    "difficulty": "Hard",
    "q": "If a debtor who owed ₹3,000 pays the full amount in cash, the accounting equation:",
    "options": [
      "Shows a net increase in assets",
      "Shows a net decrease in assets",
      "Remains balanced with no change in total assets",
      "Shows an increase in liabilities"
    ],
    "answerIndex": 2,
    "explanation": "One asset (debtors) decreases while another asset (cash) increases by the same amount — total assets don't change."
  },
  {
    "id": 14,
    "chapter": "eq",
    "difficulty": "Hard",
    "q": "A firm's assets are ₹4,50,000. Its capital consists of an opening balance of ₹3,00,000 plus profit of ₹70,000 minus drawings of ₹20,000. Liabilities are:",
    "options": [
      "₹1,50,000",
      "₹1,00,000",
      "₹80,000",
      "₹1,20,000"
    ],
    "answerIndex": 1,
    "explanation": "Effective Capital = 3,00,000 + 70,000 − 20,000 = 3,50,000. Liabilities = 4,50,000 − 3,50,000 = 1,00,000."
  },
  {
    "id": 15,
    "chapter": "eq",
    "difficulty": "Hard",
    "q": "Which sequence correctly shows a transaction that touches THREE elements of the equation at once?",
    "options": [
      "Paying a creditor by cash",
      "A cash sale of goods at a profit",
      "Buying furniture on credit",
      "Depositing cash into the bank"
    ],
    "answerIndex": 1,
    "explanation": "A profitable cash sale increases cash (asset), and the profit portion increases capital via revenue while the cost portion reduces the stock asset — touching multiple elements."
  },
  {
    "id": 16,
    "chapter": "eq",
    "difficulty": "Easy",
    "q": "Which of these best defines a Liability?",
    "options": [
      "Something a business owns",
      "Something a business owes to outsiders",
      "Cash held by the business",
      "The owner's personal property"
    ],
    "answerIndex": 1,
    "explanation": "A liability is an obligation the business owes to parties outside the business."
  },
  {
    "id": 17,
    "chapter": "eq",
    "difficulty": "Easy",
    "q": "The owner's stake in the business is called:",
    "options": [
      "An asset",
      "A liability",
      "Capital",
      "A debtor"
    ],
    "answerIndex": 2,
    "explanation": "Capital represents what the business owes back to its own owner."
  },
  {
    "id": 18,
    "chapter": "eq",
    "difficulty": "Medium",
    "q": "A business takes a loan of ₹40,000 to buy machinery outright. Immediately after, total assets:",
    "options": [
      "Increase by ₹40,000",
      "Decrease by ₹40,000",
      "Remain unchanged",
      "Increase by ₹80,000"
    ],
    "answerIndex": 0,
    "explanation": "Cash/machinery increases by the loan amount, and a matching liability is created — assets rise by the loan value."
  },
  {
    "id": 19,
    "chapter": "eq",
    "difficulty": "Medium",
    "q": "A firm's total assets are ₹2,00,000 and capital is ₹1,50,000. Its liabilities are:",
    "options": [
      "₹3,50,000",
      "₹50,000",
      "₹1,50,000",
      "₹2,00,000"
    ],
    "answerIndex": 1,
    "explanation": "Liabilities = Assets − Capital = 2,00,000 − 1,50,000 = 50,000."
  },
  {
    "id": 20,
    "chapter": "eq",
    "difficulty": "Hard",
    "q": "A trader's capital was ₹75,000. He introduced machinery worth ₹20,000 as additional capital and withdrew ₹6,000 cash. His capital now stands at:",
    "options": [
      "₹89,000",
      "₹1,01,000",
      "₹49,000",
      "₹95,000"
    ],
    "answerIndex": 0,
    "explanation": "Closing Capital = 75,000 + 20,000 − 6,000 = 89,000."
  },
  {
    "id": 21,
    "chapter": "dc",
    "difficulty": "Easy",
    "q": "Under the Traditional Approach, accounts are classified into:",
    "options": [
      "Assets, Liabilities, Capital",
      "Personal, Real, Nominal",
      "Debit, Credit, Balance",
      "Trading, Profit, Loss"
    ],
    "answerIndex": 1,
    "explanation": "The three traditional categories are Personal, Real, and Nominal accounts."
  },
  {
    "id": 22,
    "chapter": "dc",
    "difficulty": "Easy",
    "q": "The rule 'Debit the Receiver, Credit the Giver' applies to:",
    "options": [
      "Real Accounts",
      "Nominal Accounts",
      "Personal Accounts",
      "All accounts equally"
    ],
    "answerIndex": 2,
    "explanation": "This golden rule specifically governs Personal Accounts."
  },
  {
    "id": 23,
    "chapter": "dc",
    "difficulty": "Easy",
    "q": "The rule 'Debit what comes in, Credit what goes out' applies to:",
    "options": [
      "Personal Accounts",
      "Real Accounts",
      "Nominal Accounts",
      "Capital Accounts only"
    ],
    "answerIndex": 1,
    "explanation": "This is the golden rule for Real Accounts (assets and properties)."
  },
  {
    "id": 24,
    "chapter": "dc",
    "difficulty": "Easy",
    "q": "Rent A/c, Salary A/c, and Commission Received A/c are examples of:",
    "options": [
      "Real Accounts",
      "Personal Accounts",
      "Nominal Accounts",
      "Representative Accounts"
    ],
    "answerIndex": 2,
    "explanation": "All expense and income accounts fall under the Nominal Account category."
  },
  {
    "id": 25,
    "chapter": "dc",
    "difficulty": "Easy",
    "q": "Under the Modern Approach, an increase in an Asset is recorded as a:",
    "options": [
      "Credit",
      "Debit",
      "Neither debit nor credit",
      "Both debit and credit"
    ],
    "answerIndex": 1,
    "explanation": "Modern rule: increases in Assets and Expenses are debited."
  },
  {
    "id": 26,
    "chapter": "dc",
    "difficulty": "Medium",
    "q": "Under the Modern Approach, an increase in Capital is recorded as a:",
    "options": [
      "Debit",
      "Credit",
      "No entry needed",
      "Depends on the transaction"
    ],
    "answerIndex": 1,
    "explanation": "Increases in Liabilities, Capital, and Revenue are all credited under the Modern Approach."
  },
  {
    "id": 27,
    "chapter": "dc",
    "difficulty": "Medium",
    "q": "Bank A/c is classified, in the traditional system, as a:",
    "options": [
      "Real Account",
      "Nominal Account",
      "Personal Account",
      "None of these"
    ],
    "answerIndex": 2,
    "explanation": "A bank is treated as an artificial legal person, making Bank A/c a Personal Account."
  },
  {
    "id": 28,
    "chapter": "dc",
    "difficulty": "Medium",
    "q": "Purchases A/c is conventionally treated as a:",
    "options": [
      "Real Account",
      "Nominal Account",
      "Personal Account",
      "Representative Account"
    ],
    "answerIndex": 1,
    "explanation": "Purchases A/c is classified as a Nominal (expense-type) account in the traditional system."
  },
  {
    "id": 29,
    "chapter": "dc",
    "difficulty": "Medium",
    "q": "When goods are given away as free samples, which account is credited?",
    "options": [
      "Sales A/c",
      "Cash A/c",
      "Purchases A/c",
      "Advertisement A/c"
    ],
    "answerIndex": 2,
    "explanation": "Since no sale has occurred, the value of goods given away is simply removed from Purchases A/c."
  },
  {
    "id": 30,
    "chapter": "dc",
    "difficulty": "Medium",
    "q": "Depreciation on machinery is recorded by debiting Depreciation A/c and crediting:",
    "options": [
      "Cash A/c",
      "Machinery A/c",
      "Capital A/c",
      "Bank A/c"
    ],
    "answerIndex": 1,
    "explanation": "Depreciation reduces the book value of the asset directly, with no cash involved — Machinery A/c (a Real account) is credited."
  },
  {
    "id": 31,
    "chapter": "dc",
    "difficulty": "Hard",
    "q": "Outstanding Salary A/c is an example of a:",
    "options": [
      "Nominal Account",
      "Real Account",
      "Representative Personal Account",
      "None of these"
    ],
    "answerIndex": 2,
    "explanation": "It represents a group of people (employees) to whom the amount is owed, making it a Representative Personal Account."
  },
  {
    "id": 32,
    "chapter": "dc",
    "difficulty": "Hard",
    "q": "Trade discount received on a purchase is:",
    "options": [
      "Debited to Discount Received A/c",
      "Credited to Discount Received A/c",
      "Not recorded in the books at all",
      "Debited to Purchases A/c separately"
    ],
    "answerIndex": 2,
    "explanation": "Trade discount is deducted before the transaction is recorded — only the net billed amount ever enters the books."
  },
  {
    "id": 33,
    "chapter": "dc",
    "difficulty": "Hard",
    "q": "A cash discount allowed to a customer is recorded by:",
    "options": [
      "Debiting Discount Allowed A/c",
      "Crediting Discount Allowed A/c",
      "Ignoring it completely",
      "Debiting the customer's account only"
    ],
    "answerIndex": 0,
    "explanation": "Cash discount is a genuine cost of prompt settlement and is debited to Discount Allowed A/c."
  },
  {
    "id": 34,
    "chapter": "dc",
    "difficulty": "Hard",
    "q": "When a cheque received earlier is dishonoured, the customer's personal account is:",
    "options": [
      "Credited again",
      "Debited again",
      "Left unchanged",
      "Closed permanently"
    ],
    "answerIndex": 1,
    "explanation": "A dishonoured cheque reverses the original receipt, so the customer's account is debited again to reinstate the debt."
  },
  {
    "id": 35,
    "chapter": "dc",
    "difficulty": "Hard",
    "q": "Interest on Capital is treated, from the business's point of view, as a(n):",
    "options": [
      "Asset",
      "Liability only, never an expense",
      "Expense, debited to Interest on Capital A/c",
      "Reduction in Sales"
    ],
    "answerIndex": 2,
    "explanation": "Interest on Capital is a cost of using the owner's funds and is debited as an expense, while Capital A/c is credited."
  },
  {
    "id": 36,
    "chapter": "dc",
    "difficulty": "Easy",
    "q": "Which golden rule applies to Nominal Accounts?",
    "options": [
      "Debit the receiver, Credit the giver",
      "Debit what comes in, Credit what goes out",
      "Debit all expenses and losses, Credit all incomes and gains",
      "Debit all assets, Credit all liabilities"
    ],
    "answerIndex": 2,
    "explanation": "Nominal accounts follow: Debit all expenses and losses, Credit all incomes and gains."
  },
  {
    "id": 37,
    "chapter": "dc",
    "difficulty": "Easy",
    "q": "Furniture A/c is an example of a:",
    "options": [
      "Personal Account",
      "Real Account",
      "Nominal Account",
      "Representative Account"
    ],
    "answerIndex": 1,
    "explanation": "Furniture is a tangible asset, making Furniture A/c a Real Account."
  },
  {
    "id": 38,
    "chapter": "dc",
    "difficulty": "Medium",
    "q": "Drawings A/c is classified as a:",
    "options": [
      "Real Account",
      "Nominal Account",
      "Personal Account",
      "Neither of these"
    ],
    "answerIndex": 2,
    "explanation": "Drawings A/c represents the proprietor personally, so it is treated as a Personal Account."
  },
  {
    "id": 39,
    "chapter": "dc",
    "difficulty": "Medium",
    "q": "An increase in Expenses is recorded, under the Modern Approach, as a:",
    "options": [
      "Credit",
      "Debit",
      "Contra entry",
      "No entry"
    ],
    "answerIndex": 1,
    "explanation": "Just like Assets, increases in Expenses are debited under the Modern Approach."
  },
  {
    "id": 40,
    "chapter": "dc",
    "difficulty": "Hard",
    "q": "Goods lost by theft, partly covered by an insurance claim, requires crediting:",
    "options": [
      "Sales A/c for the insured portion only",
      "Purchases A/c for the full value of goods lost",
      "Insurance Claim A/c for the full value",
      "Loss by Theft A/c for the full value"
    ],
    "answerIndex": 1,
    "explanation": "The full value of the goods lost is removed from Purchases A/c, while the loss is then split between an Insurance Claim (asset) and Loss by Theft (expense)."
  },
  {
    "id": 41,
    "chapter": "jr",
    "difficulty": "Easy",
    "q": "The Journal is also known as the book of:",
    "options": [
      "Final entry",
      "Original entry",
      "Secondary entry",
      "Ledger entry"
    ],
    "answerIndex": 1,
    "explanation": "The Journal is called the 'book of original/prime entry' since transactions are recorded here first."
  },
  {
    "id": 42,
    "chapter": "jr",
    "difficulty": "Easy",
    "q": "Which column in the Journal is filled in only at the time of posting to the ledger?",
    "options": [
      "Date",
      "Particulars",
      "Ledger Folio (L.F.)",
      "Debit Amount"
    ],
    "answerIndex": 2,
    "explanation": "The L.F. column records the ledger page number, which is only known once the entry is actually posted."
  },
  {
    "id": 43,
    "chapter": "jr",
    "difficulty": "Easy",
    "q": "A brief explanation below a journal entry is called:",
    "options": [
      "A footnote",
      "A narration",
      "A ledger note",
      "A voucher"
    ],
    "answerIndex": 1,
    "explanation": "The narration, written in brackets and usually starting with 'Being...', explains the nature of the transaction."
  },
  {
    "id": 44,
    "chapter": "jr",
    "difficulty": "Easy",
    "q": "In journal format, the credited account is written:",
    "options": [
      "In capital letters only",
      "Prefixed with 'To', slightly indented",
      "Prefixed with 'By'",
      "On a separate page"
    ],
    "answerIndex": 1,
    "explanation": "By convention, the credit line is indented and prefixed with 'To' in the Particulars column."
  },
  {
    "id": 45,
    "chapter": "jr",
    "difficulty": "Easy",
    "q": "A journal entry involving more than two accounts is called a:",
    "options": [
      "Contra entry",
      "Compound entry",
      "Adjusting entry",
      "Opening entry"
    ],
    "answerIndex": 1,
    "explanation": "A Compound Journal Entry has multiple debits, multiple credits, or both, combined in a single entry."
  },
  {
    "id": 46,
    "chapter": "jr",
    "difficulty": "Medium",
    "q": "For 'Purchased goods from Ramesh on credit', the correct journal entry debits:",
    "options": [
      "Ramesh's A/c",
      "Purchases A/c",
      "Cash A/c",
      "Sales A/c"
    ],
    "answerIndex": 1,
    "explanation": "Purchases A/c Dr. / To Ramesh's A/c — the expense is recognized and Ramesh becomes a creditor."
  },
  {
    "id": 47,
    "chapter": "jr",
    "difficulty": "Medium",
    "q": "For 'Sold goods to Kavita on credit', which account is debited?",
    "options": [
      "Sales A/c",
      "Cash A/c",
      "Kavita's A/c",
      "Purchases A/c"
    ],
    "answerIndex": 2,
    "explanation": "Kavita's A/c Dr. / To Sales A/c — Kavita becomes a debtor for the value of goods received."
  },
  {
    "id": 48,
    "chapter": "jr",
    "difficulty": "Medium",
    "q": "In the entry for goods given as charity, which account is credited?",
    "options": [
      "Charity A/c",
      "Sales A/c",
      "Purchases A/c",
      "Cash A/c"
    ],
    "answerIndex": 2,
    "explanation": "Charity A/c Dr. / To Purchases A/c — the goods are removed from Purchases at cost."
  },
  {
    "id": 49,
    "chapter": "jr",
    "difficulty": "Medium",
    "q": "An entry for outstanding wages debits Wages A/c and credits:",
    "options": [
      "Cash A/c",
      "Outstanding Wages A/c",
      "Capital A/c",
      "Bank A/c"
    ],
    "answerIndex": 1,
    "explanation": "Wages A/c Dr. / To Outstanding Wages A/c — the expense is recognized while the payment remains a liability."
  },
  {
    "id": 50,
    "chapter": "jr",
    "difficulty": "Medium",
    "q": "For a prepaid rent payment, which account is debited?",
    "options": [
      "Rent A/c",
      "Prepaid Rent A/c",
      "Cash A/c",
      "Outstanding Rent A/c"
    ],
    "answerIndex": 1,
    "explanation": "Prepaid Rent A/c Dr. / To Cash A/c — the payment creates a future-benefit asset, not an immediate expense."
  },
  {
    "id": 51,
    "chapter": "jr",
    "difficulty": "Hard",
    "q": "When a cheque received from a debtor is dishonoured, the journal entry is:",
    "options": [
      "Bank A/c Dr. / To Debtor's A/c",
      "Debtor's A/c Dr. / To Bank A/c",
      "Debtor's A/c Dr. / To Discount Allowed A/c",
      "Bank A/c Dr. / To Discount Received A/c"
    ],
    "answerIndex": 1,
    "explanation": "The original receipt is reversed: Debtor's A/c Dr. / To Bank A/c, since the expected deposit failed to clear."
  },
  {
    "id": 52,
    "chapter": "jr",
    "difficulty": "Hard",
    "q": "₹30,000 machinery purchased, ₹10,000 paid by cheque and the rest on credit — total debit side of the entry equals:",
    "options": [
      "₹10,000",
      "₹20,000",
      "₹30,000",
      "₹40,000"
    ],
    "answerIndex": 2,
    "explanation": "Machinery A/c is debited in full for ₹30,000, matching the two credits (₹10,000 + ₹20,000) on the other side."
  },
  {
    "id": 53,
    "chapter": "jr",
    "difficulty": "Hard",
    "q": "Discount Allowed A/c appears on which side of a journal entry recording receipt of payment with a cash discount?",
    "options": [
      "Credit side, along with Bank A/c",
      "Debit side, along with Bank A/c",
      "It is never part of that entry",
      "Credit side only, alone"
    ],
    "answerIndex": 1,
    "explanation": "Bank A/c Dr. and Discount Allowed A/c Dr. together equal the full amount credited to the debtor's account."
  },
  {
    "id": 54,
    "chapter": "jr",
    "difficulty": "Hard",
    "q": "For 'Goods worth ₹5,000 destroyed by fire, insurer admitted claim of ₹3,000', the amount credited to Purchases A/c is:",
    "options": [
      "₹2,000",
      "₹3,000",
      "₹5,000",
      "₹8,000"
    ],
    "answerIndex": 2,
    "explanation": "The full cost value of goods lost (₹5,000) is removed from Purchases A/c, regardless of how much the insurer later admits."
  },
  {
    "id": 55,
    "chapter": "jr",
    "difficulty": "Hard",
    "q": "Trade discount deducted on a purchase invoice:",
    "options": [
      "Appears as a separate credit in the journal",
      "Is debited to Discount Allowed A/c",
      "Never appears anywhere in the journal entry",
      "Is credited to Purchases A/c separately"
    ],
    "answerIndex": 2,
    "explanation": "Trade discount is subtracted before the invoice value is finalized — only the net amount is journalised, with no separate discount entry."
  },
  {
    "id": 56,
    "chapter": "jr",
    "difficulty": "Easy",
    "q": "What follows Journalising in the accounting cycle?",
    "options": [
      "Preparing the Trial Balance",
      "Posting to the Ledger",
      "Preparing Financial Statements",
      "Balancing accounts"
    ],
    "answerIndex": 1,
    "explanation": "After a transaction is journalised, it is posted into the relevant ledger accounts."
  },
  {
    "id": 57,
    "chapter": "jr",
    "difficulty": "Easy",
    "q": "For 'Paid salary by cheque', the account credited is:",
    "options": [
      "Salary A/c",
      "Cash A/c",
      "Bank A/c",
      "Capital A/c"
    ],
    "answerIndex": 2,
    "explanation": "Since payment is by cheque, Bank A/c is credited instead of Cash A/c."
  },
  {
    "id": 58,
    "chapter": "jr",
    "difficulty": "Medium",
    "q": "For interest on capital allowed to the proprietor, the account credited is:",
    "options": [
      "Interest on Capital A/c",
      "Capital A/c",
      "Cash A/c",
      "Drawings A/c"
    ],
    "answerIndex": 1,
    "explanation": "Interest on Capital A/c Dr. / To Capital A/c — the amount increases what the business owes the owner."
  },
  {
    "id": 59,
    "chapter": "jr",
    "difficulty": "Medium",
    "q": "For interest charged on drawings, the account debited is:",
    "options": [
      "Interest on Drawings A/c",
      "Capital A/c",
      "Drawings A/c",
      "Cash A/c"
    ],
    "answerIndex": 2,
    "explanation": "Drawings A/c Dr. / To Interest on Drawings A/c — the interest adds to what the owner has effectively withdrawn."
  },
  {
    "id": 60,
    "chapter": "jr",
    "difficulty": "Hard",
    "q": "A compound entry for machinery bought partly by cheque and partly on credit will have:",
    "options": [
      "Two debit lines and one credit line",
      "One debit line and two credit lines",
      "Two debit lines and two credit lines",
      "Only one line in total"
    ],
    "answerIndex": 1,
    "explanation": "Machinery A/c is debited once for the full value, while Bank A/c and the Supplier's A/c are credited separately for their respective portions."
  },
  {
    "id": 61,
    "chapter": "lg",
    "difficulty": "Easy",
    "q": "The Ledger is also known as the:",
    "options": ["Book of Original Entry", "Book of Final Entry", "Book of Adjustments", "Book of Corrections"],
    "answerIndex": 1,
    "explanation": "The Ledger is called the 'Book of Final Entry' since posting to it is the last stage a transaction passes through before its balance is used further."
  },
  {
    "id": 62,
    "chapter": "lg",
    "difficulty": "Easy",
    "q": "A Ledger account is traditionally drawn in the shape of the letter:",
    "options": ["L", "T", "V", "Z"],
    "answerIndex": 1,
    "explanation": "The classic Ledger account format has a vertical line down the middle with the account name across the top, giving it a 'T' shape — Debit on the left, Credit on the right."
  },
  {
    "id": 63,
    "chapter": "lg",
    "difficulty": "Easy",
    "q": "In a Ledger account, the word used on the debit side of a posting is:",
    "options": ["By", "To", "From", "For"],
    "answerIndex": 1,
    "explanation": "'To' is written on the debit side, e.g. 'To Sales A/c', naming the account this one received value from."
  },
  {
    "id": 64,
    "chapter": "lg",
    "difficulty": "Easy",
    "q": "In a Ledger account, the word used on the credit side of a posting is:",
    "options": ["To", "By", "Via", "Of"],
    "answerIndex": 1,
    "explanation": "'By' is written on the credit side, e.g. 'By Cash A/c', naming the account this one gave value to."
  },
  {
    "id": 65,
    "chapter": "lg",
    "difficulty": "Easy",
    "q": "J.F. in a Ledger account stands for:",
    "options": ["Journal Figure", "Journal Folio", "Just Finalised", "Journal Format"],
    "answerIndex": 1,
    "explanation": "J.F. (Journal Folio) records the page number of the Journal the entry was posted from, linking the Ledger back to its source."
  },
  {
    "id": 66,
    "chapter": "lg",
    "difficulty": "Easy",
    "q": "If a Journal entry debits Furniture A/c, the Ledger posting for Furniture A/c goes on the:",
    "options": ["Credit side", "Debit side", "Either side", "Neither side"],
    "answerIndex": 1,
    "explanation": "A Journal debit is always posted to the debit side of that same account in the Ledger — the amount and account name carry across unchanged."
  },
  {
    "id": 67,
    "chapter": "lg",
    "difficulty": "Easy",
    "q": "Which of these is essential for preparing a Trial Balance?",
    "options": ["Journal narrations", "Ledger account balances", "Bank statements", "Purchase invoices"],
    "answerIndex": 1,
    "explanation": "A Trial Balance lists the closing balance of every Ledger account — without balancing the Ledger first, there is nothing to list."
  },
  {
    "id": 68,
    "chapter": "lg",
    "difficulty": "Medium",
    "q": "When totalling a Ledger account to find its balance, the difference between the two sides is called:",
    "options": ["Net Profit", "Balance c/d", "Trial Balance", "Suspense Amount"],
    "answerIndex": 1,
    "explanation": "The difference between the debit and credit totals is the 'Balance carried down' (c/d), written on the smaller side so both sides show equal totals."
  },
  {
    "id": 69,
    "chapter": "lg",
    "difficulty": "Medium",
    "q": "Balance c/d is written on the smaller side, and then Balance b/d is brought down on the:",
    "options": ["Same side, same date", "Opposite side, next date", "Same side, next date", "Opposite side, same date"],
    "answerIndex": 1,
    "explanation": "Balance b/d appears on the opposite side from where c/d was written, dated at the start of the next period — becoming that period's opening balance."
  },
  {
    "id": 70,
    "chapter": "lg",
    "difficulty": "Medium",
    "q": "An account whose Balance b/d appears on the debit side has a:",
    "options": ["Credit balance", "Debit balance", "Nil balance", "Suspended balance"],
    "answerIndex": 1,
    "explanation": "When the brought-down balance sits on the debit side, the account carries a Debit Balance — typical of Assets and Expenses."
  },
  {
    "id": 71,
    "chapter": "lg",
    "difficulty": "Medium",
    "q": "An account whose Balance b/d appears on the credit side has a:",
    "options": ["Debit balance", "Credit balance", "Zero balance", "Contra balance"],
    "answerIndex": 1,
    "explanation": "When the brought-down balance sits on the credit side, the account carries a Credit Balance — typical of Liabilities, Capital, and Income."
  },
  {
    "id": 72,
    "chapter": "lg",
    "difficulty": "Medium",
    "q": "A Nil balance in a Ledger account means:",
    "options": ["The account was never used", "Both sides total to exactly the same figure", "The account has been deleted", "There was a posting error"],
    "answerIndex": 1,
    "explanation": "A Nil balance occurs when debit and credit totals are exactly equal — common for Nominal accounts once closed off to the Profit & Loss Account at year-end."
  },
  {
    "id": 73,
    "chapter": "lg",
    "difficulty": "Medium",
    "q": "Cash A/c, being a Real account, will normally carry forward as a:",
    "options": ["Credit balance", "Debit balance", "Nil balance every year", "Suspense balance"],
    "answerIndex": 1,
    "explanation": "Cash is an asset, and assets normally carry a debit balance, since more cash typically comes in over time than goes fully out, leaving a balance on hand."
  },
  {
    "id": 74,
    "chapter": "lg",
    "difficulty": "Medium",
    "q": "A compound Journal entry with one debit and two credits results in, on posting:",
    "options": ["One posting in total", "Two postings in total", "Three postings in total", "Four postings in total"],
    "answerIndex": 2,
    "explanation": "Each account named — the one debit account plus each of the two credited accounts — gets its own separate posting, giving three postings from one journal entry."
  },
  {
    "id": 75,
    "chapter": "lg",
    "difficulty": "Medium",
    "q": "Which type of account does NOT normally carry its balance forward to the next accounting year?",
    "options": ["Real account (e.g. Machinery)", "Personal account (e.g. a debtor)", "Nominal account (e.g. Rent)", "Capital account"],
    "answerIndex": 2,
    "explanation": "Nominal accounts (expenses, losses, incomes, gains) are closed off to the Profit & Loss Account at year-end rather than carried forward — only Real, Personal, and Capital accounts continue with a brought-down balance."
  },
  {
    "id": 76,
    "chapter": "lg",
    "difficulty": "Hard",
    "q": "Rent A/c has total debits of ₹18,000 and no credit entries all year. On balancing, this account will show:",
    "options": ["A credit balance of ₹18,000", "A debit balance of ₹18,000, closed to Profit & Loss A/c", "A nil balance", "An error requiring correction"],
    "answerIndex": 1,
    "explanation": "Since only the debit side has entries, the account's balance is the full ₹18,000 debit — for a Nominal account like Rent, this balance is then transferred to the Profit & Loss Account rather than brought down to next year."
  },
  {
    "id": 77,
    "chapter": "lg",
    "difficulty": "Hard",
    "q": "A Debtor's account shows: Debit side total ₹45,000; Credit side total ₹32,000. The Balance c/d and its side are:",
    "options": ["₹13,000 on the credit side", "₹13,000 on the debit side", "₹77,000 on the credit side", "₹32,000 on the debit side"],
    "answerIndex": 0,
    "explanation": "The debit side (₹45,000) exceeds the credit side (₹32,000) by ₹13,000. Balance c/d is written on the smaller side — the credit side here — so both sides total ₹45,000, and this ₹13,000 then brings down as a debit balance (the debtor still owes this much)."
  },
  {
    "id": 78,
    "chapter": "lg",
    "difficulty": "Hard",
    "q": "Which of these correctly describes the relationship between the Journal and the Ledger?",
    "options": [
      "The Ledger records transactions first, and the Journal reorganizes them by account",
      "The Journal records transactions in date order; the Ledger reorganizes the same transactions by account",
      "The Journal and Ledger record entirely different transactions",
      "The Ledger replaces the need for a Journal entirely"
    ],
    "answerIndex": 1,
    "explanation": "The Journal is the book of original entry, recording transactions chronologically. The Ledger takes those same entries and groups them by account, so each account's full history and balance can be seen together — the two are sequential stages of the same underlying data, not separate records."
  },
  {
    "id": 79,
    "chapter": "lg",
    "difficulty": "Hard",
    "q": "A Creditor's account shows: Debit side total ₹12,000 (part-payment made); Credit side total ₹27,000 (goods purchased on credit). The account's balance carried down is:",
    "options": ["₹15,000, brought down on the debit side (a debit balance)", "₹15,000, brought down on the credit side (a credit balance)", "₹39,000 on the credit side", "Nil, since both sides had entries"],
    "answerIndex": 1,
    "explanation": "The credit side (₹27,000) exceeds the debit side (₹12,000) by ₹15,000. Balance c/d of ₹15,000 goes on the smaller (debit) side to equalize the totals, and then brings down on the credit side — confirming the business still owes this creditor ₹15,000."
  },
  {
    "id": 80,
    "chapter": "lg",
    "difficulty": "Hard",
    "q": "Why does posting a Journal entry always preserve the equality of total debits and total credits in the Ledger as a whole?",
    "options": [
      "Because the Ledger automatically corrects any imbalance",
      "Because every Journal entry itself has equal debits and credits, and posting simply distributes each side to its own account unchanged",
      "Because only correct entries are ever posted",
      "Because the Trial Balance forces the totals to match afterward"
    ],
    "answerIndex": 1,
    "explanation": "Since the dual aspect concept guarantees every Journal entry already has matching debit and credit amounts, and posting only relocates each side to its own account without changing any figure, the sum of all Ledger debits across every account must always equal the sum of all Ledger credits — this is exactly what a Trial Balance later confirms, not something it creates."
  },
  {
    "id": 81,
    "chapter": "jr",
    "difficulty": "Hard",
    "q": "Old machinery with a book value of ₹20,000 is sold for ₹25,000 cash. The ₹5,000 excess is credited to:",
    "options": [
      "Sales A/c",
      "Machinery A/c",
      "Gain (Profit) on Sale of Machinery A/c",
      "Capital A/c"
    ],
    "answerIndex": 2,
    "explanation": "Sale of a fixed asset never touches Sales A/c, which is reserved for stock-in-trade. Machinery A/c is credited only for its own book value (₹20,000); the ₹5,000 gained above that is credited to a separate Profit on Sale account."
  },
  {
    "id": 82,
    "chapter": "jr",
    "difficulty": "Medium",
    "q": "Which of these is correctly recorded as a Purchases Return (Returns Outward)?",
    "options": [
      "Goods sold to a customer are returned by them",
      "Goods purchased on credit are returned by us to the supplier",
      "Goods are withdrawn by the proprietor for personal use",
      "Goods are distributed as free samples"
    ],
    "answerIndex": 1,
    "explanation": "Purchases Return (Returns Outward) is specifically for goods the business itself sends back to a supplier. Goods coming back from a customer is a Sales Return (Returns Inward) instead — the two are opposite directions and use different accounts."
  },
  {
    "id": 83,
    "chapter": "jr",
    "difficulty": "Hard",
    "q": "Cash of ₹900 is received from Naresh, whose debt had already been written off as bad in an earlier year. The correct entry credits:",
    "options": [
      "Naresh's A/c",
      "Bad Debts A/c",
      "Bad Debts Recovered A/c",
      "Capital A/c"
    ],
    "answerIndex": 2,
    "explanation": "Naresh's personal account was already closed to zero when the debt was written off, so there's nothing left in it to credit. The unexpected recovery is credited to a separate Bad Debts Recovered account instead — pure income, unrelated to reopening the old debtor account."
  },
  {
    "id": 84,
    "chapter": "jr",
    "difficulty": "Medium",
    "q": "How does 'Bad Debts Recovered' differ from simply reversing a 'Bad Debts Written Off' entry?",
    "options": [
      "They are actually the same entry, just described differently",
      "Recovery is credited to a fresh income account, since the debtor's account was already closed and isn't reopened",
      "Recovery is debited to the original debtor's account to reopen it",
      "Recovery reduces Capital directly"
    ],
    "answerIndex": 1,
    "explanation": "Once written off, a debtor's account is closed permanently. A later recovery is treated as new, unexpected income (Bad Debts Recovered A/c credited) rather than undoing the earlier entry or reopening the closed personal account."
  },
  {
    "id": 85,
    "chapter": "jr",
    "difficulty": "Hard",
    "q": "A debtor owing ₹10,000 is declared insolvent; 60 paise in the rupee is received in cash, the rest is irrecoverable. Which entry is correct?",
    "options": [
      "Cash A/c Dr. 10,000; To Debtor's A/c 10,000",
      "Cash A/c Dr. 6,000; Bad Debts A/c Dr. 4,000; To Debtor's A/c 10,000",
      "Bad Debts A/c Dr. 10,000; To Debtor's A/c 10,000",
      "Cash A/c Dr. 6,000; To Debtor's A/c 6,000"
    ],
    "answerIndex": 1,
    "explanation": "The debtor's account must be credited and closed for the complete ₹10,000 owed — split between what was actually recovered in cash (₹6,000) and what could not be recovered, debited to Bad Debts A/c (₹4,000)."
  },
  {
    "id": 86,
    "chapter": "jr",
    "difficulty": "Medium",
    "q": "A Bills Receivable accepted by a debtor in settlement of his account is, from the seller's point of view, best described as:",
    "options": [
      "An expense",
      "A liability",
      "An asset, replacing the ordinary debtor balance",
      "Income"
    ],
    "answerIndex": 2,
    "explanation": "Bills Receivable A/c is a Real/asset account — accepting a bill converts an ordinary, less formal debtor balance into a legally enforceable promise to pay by a fixed date, but it remains something owed to the business."
  },
  {
    "id": 87,
    "chapter": "jr",
    "difficulty": "Medium",
    "q": "When a Bills Receivable is 'honoured' on its due date and the amount is collected through the bank, the entry is:",
    "options": [
      "Bank A/c Dr.; To Bills Receivable A/c",
      "Bills Receivable A/c Dr.; To Bank A/c",
      "Bank A/c Dr.; To Debtor's A/c",
      "Bills Payable A/c Dr.; To Bank A/c"
    ],
    "answerIndex": 0,
    "explanation": "Honouring a bill means the acceptor paid as promised. Bank A/c is debited for the cash received, and Bills Receivable A/c is credited and closed, having served its purpose."
  },
  {
    "id": 88,
    "chapter": "jr",
    "difficulty": "Medium",
    "q": "In an Opening Journal Entry, Capital A/c is:",
    "options": [
      "Given directly by the accountant, like any other balance",
      "Always equal to total assets, ignoring liabilities",
      "The balancing figure — total assets minus total liabilities",
      "Never included in an Opening Entry"
    ],
    "answerIndex": 2,
    "explanation": "The rule for an Opening Entry is: debit all assets, credit all liabilities, and let Capital be whatever figure makes both sides equal — it is never stated directly, only derived."
  },
  {
    "id": 89,
    "chapter": "jr",
    "difficulty": "Medium",
    "q": "Bank charges of ₹150 debited by the bank, as seen only in the pass book, should be journalised as:",
    "options": [
      "No entry needed until cash is actually paid",
      "Bank Charges A/c Dr.; To Bank A/c",
      "Bank A/c Dr.; To Bank Charges A/c",
      "Cash A/c Dr.; To Bank Charges A/c"
    ],
    "answerIndex": 1,
    "explanation": "Even though the firm didn't personally instruct this payment, the bank statement confirms the bank balance has genuinely reduced, so it must be journalised like any other expense: Bank Charges A/c debited, Bank A/c credited."
  },
  {
    "id": 90,
    "chapter": "jr",
    "difficulty": "Hard",
    "q": "Commission of ₹1,200 was earned during the year but not yet received by year-end. This is best described as:",
    "options": [
      "Income received in advance — a liability",
      "Accrued income — an asset, since it has been earned but not yet collected",
      "An outstanding expense",
      "No entry is needed since no cash moved"
    ],
    "answerIndex": 1,
    "explanation": "Accrued income is income genuinely earned during the period but not yet received in cash — it's recorded as an asset (a right to receive money), the mirror image of income received in advance, which is a liability for income not yet earned."
  },
  {
    "id": 91,
    "chapter": "jr",
    "difficulty": "Medium",
    "q": "What is the key difference between 'payment on account' to a creditor and 'payment in full settlement'?",
    "options": [
      "There is no real difference — both close the creditor's account completely",
      "Payment on account is a partial payment with the balance still owed; full settlement clears the entire balance, sometimes with a discount",
      "Payment on account always involves a discount; full settlement never does",
      "Payment on account is only ever made by cheque"
    ],
    "answerIndex": 1,
    "explanation": "A payment 'on account' is simply a part-payment — the creditor's account still shows a balance owed afterward. A payment 'in full settlement' clears the account completely, often because the creditor has agreed to accept a slightly smaller amount (recorded as Discount Received) in exchange for prompt payment."
  },
  {
    "id": 92,
    "chapter": "jr",
    "difficulty": "Hard",
    "q": "The proprietor's life insurance premium of ₹5,000 is paid by the business's cheque. The correct entry debits:",
    "options": [
      "Insurance Premium A/c",
      "Drawings A/c",
      "Capital A/c",
      "Bank A/c"
    ],
    "answerIndex": 1,
    "explanation": "A life insurance policy always belongs to the proprietor personally, never to the business, regardless of which account actually paid the premium. Since business funds were used for a personal obligation, Drawings A/c is debited — not Insurance Premium A/c."
  },
  {
    "id": 93,
    "chapter": "jr",
    "difficulty": "Medium",
    "q": "Carriage paid on goods purchased and brought into the godown is recorded in:",
    "options": [
      "Carriage Outwards A/c",
      "Carriage Inwards A/c",
      "Purchases A/c directly, with no separate account",
      "Drawings A/c"
    ],
    "answerIndex": 1,
    "explanation": "Carriage Inwards (on purchases) is kept separate because it's treated as part of the cost of bringing goods into a sellable condition, added to the cost of purchases in the Trading Account — unlike Carriage Outwards, which is a selling expense incurred after the sale."
  },
  {
    "id": 94,
    "chapter": "jr",
    "difficulty": "Medium",
    "q": "Cash withdrawn from the bank for the proprietor's personal use is journalised as:",
    "options": [
      "Cash A/c Dr.; To Bank A/c",
      "Drawings A/c Dr.; To Bank A/c",
      "Bank A/c Dr.; To Cash A/c",
      "Capital A/c Dr.; To Bank A/c"
    ],
    "answerIndex": 1,
    "explanation": "This is easy to confuse with withdrawing bank funds for office use (Cash A/c Dr.; To Bank A/c — a contra entry, money stays inside the business). For personal use, the money leaves the business entirely, so Drawings A/c is debited instead of Cash A/c."
  },
  {
    "id": 95,
    "chapter": "jr",
    "difficulty": "Hard",
    "q": "A Bills Receivable of ₹8,000 accepted by a debtor is dishonoured on its due date. The correct entry is:",
    "options": [
      "Bank A/c Dr.; To Bills Receivable A/c",
      "Debtor's A/c Dr.; To Bills Receivable A/c",
      "Bills Receivable A/c Dr.; To Debtor's A/c",
      "Bad Debts A/c Dr.; To Bills Receivable A/c"
    ],
    "answerIndex": 1,
    "explanation": "Since the bill was never actually paid, no cash or bank entry is made. Instead, Bills Receivable A/c is credited to close it out, and the debtor's personal account is debited, effectively reinstating them as an ordinary debtor again — as if the bill had never been accepted."
  },
  {
    "id": 96,
    "chapter": "jr",
    "difficulty": "Medium",
    "q": "How does 'goods lost by theft with no insurance claim admitted' differ from 'goods lost by fire with an insurance claim admitted'?",
    "options": [
      "There is no difference — both are recorded identically",
      "With theft and no claim, the entire cost is a straight loss; with fire and a claim, only the unrecovered portion is a loss, while the claimed amount is debited to an Insurance Claim (asset) account",
      "Theft is never recorded in the books",
      "Fire losses are always fully recoverable, so no loss is ever recorded for them"
    ],
    "answerIndex": 1,
    "explanation": "When nothing is recoverable (theft, no claim), the full cost is debited to a straight loss account. When part of the loss is recoverable (fire, claim admitted), that recoverable portion is debited to Insurance Claim A/c (a genuine asset — money owed by the insurer), and only the remaining shortfall is treated as an actual loss."
  },
  {
    "id": 97,
    "chapter": "jr",
    "difficulty": "Easy",
    "q": "The proprietor introduces additional capital of ₹20,000 by cheque partway through the year. This is recorded as:",
    "options": [
      "Bank A/c Dr.; To Capital A/c",
      "Capital A/c Dr.; To Bank A/c",
      "Bank A/c Dr.; To Loan A/c",
      "No entry — only the original capital is ever recorded"
    ],
    "answerIndex": 0,
    "explanation": "Additional capital is journalised exactly like the original investment — Bank A/c (or Cash A/c) is debited for the asset received, and Capital A/c is credited, regardless of when during the year it's introduced."
  },
  {
    "id": 98,
    "chapter": "jr",
    "difficulty": "Medium",
    "q": "Carriage paid on goods after they have already been sold and are being delivered to the customer belongs in:",
    "options": [
      "Carriage Inwards A/c",
      "Carriage Outwards A/c",
      "Sales A/c, reducing the sale value",
      "Purchases A/c"
    ],
    "answerIndex": 1,
    "explanation": "Carriage Outwards is incurred after the sale is already complete, delivering goods that are no longer the business's stock — it's a selling/distribution expense in the Profit & Loss Account, distinct from Carriage Inwards, which forms part of the cost of purchases."
  },
  {
    "id": 99,
    "chapter": "jr",
    "difficulty": "Hard",
    "q": "A Rebate allowed to a customer for accepting poor-quality goods differs from a Trade Discount because:",
    "options": [
      "Rebate is only ever given in cash, never adjusted against an account",
      "Rebate is given for reasons like quality complaints, not for buying in bulk — Trade Discount is for volume, and neither is the same as Cash Discount for prompt payment",
      "There is no real difference — both terms mean exactly the same thing",
      "Rebate can only be given by the buyer, never the seller"
    ],
    "answerIndex": 1,
    "explanation": "All three — Trade Discount, Cash Discount, and Rebate — reduce what a customer owes, but for entirely different reasons: Trade Discount for high purchase volume, Cash Discount for prompt payment, and Rebate for something like poor quality or a specification mismatch. Rebate gets its own account (Rebate Allowed/Received A/c) precisely to keep that reason distinct in the books."
  },
  {
    "id": 100,
    "chapter": "jr",
    "difficulty": "Hard",
    "q": "The business pays ₹5,000 as a life insurance premium covering its employees under a group scheme. This is:",
    "options": [
      "Drawings, exactly like the proprietor's own life insurance",
      "A genuine business expense (Employees' Insurance Premium A/c), since it's a staff welfare cost",
      "Not recorded at all",
      "Debited to Capital A/c"
    ],
    "answerIndex": 1,
    "explanation": "The deciding question is always whose risk is being insured. The proprietor's own life insurance protects him personally, so it's Drawings. Insuring employees is a genuine cost of running the business (staff welfare), so it's a real expense — the exact opposite treatment, despite both being 'life insurance premium.'"
  },
  {
    "id": 101,
    "chapter": "jr",
    "difficulty": "Hard",
    "q": "A sale offers a cash discount only if the full invoice is paid within 14 days. The customer pays 50% within 14 days and the rest later. What discount is allowed?",
    "options": [
      "50% of the normal discount, since half was paid on time",
      "The full discount, since some payment was made within the window",
      "No discount at all, since the condition was full payment within 14 days and that wasn't met",
      "Double the discount, as a penalty on the buyer"
    ],
    "answerIndex": 2,
    "explanation": "A conditional cash discount tied to full payment within a deadline is all-or-nothing — it is not prorated. Since the entire invoice wasn't settled within the window, no discount is earned at all, even on the portion that did arrive on time. This is different from a plain part-cash-part-credit sale, where discount is simply calculated on whatever is paid immediately with no such condition attached."
  },
  {
    "id": 102,
    "chapter": "jr",
    "difficulty": "Medium",
    "q": "The proprietor sells his personal scooter and deposits the proceeds into the business's bank account. This is recorded as:",
    "options": [
      "Bank A/c Dr.; To Sales A/c",
      "Bank A/c Dr.; To Capital A/c",
      "Not recorded, since the scooter was never a business asset",
      "Bank A/c Dr.; To Drawings A/c"
    ],
    "answerIndex": 1,
    "explanation": "The scooter itself was personal and never on the business's books, so its sale isn't journalised. What matters is that money has now entered the business from the proprietor — exactly like any other capital introduced, whether as cash, cheque, or (as here) proceeds from something personal."
  },
  {
    "id": 103,
    "chapter": "jr",
    "difficulty": "Hard",
    "q": "Rent of ₹15,000 is paid for a building, two-thirds used for business and one-third occupied by the proprietor as a residence. The correct entry:",
    "options": [
      "Debits the full ₹15,000 to Rent A/c",
      "Debits ₹10,000 to Rent A/c and ₹5,000 to Drawings A/c",
      "Debits the full ₹15,000 to Drawings A/c",
      "Debits ₹5,000 to Rent A/c and ₹10,000 to Drawings A/c"
    ],
    "answerIndex": 1,
    "explanation": "A payment that mixes genuine business use with personal use must be split in the same proportion. Only the two-thirds business-use portion (₹10,000) is a real expense; the remaining third, being the proprietor's own residence, is Drawings (₹5,000) even though business funds paid for it."
  },
  {
    "id": 104,
    "chapter": "jr",
    "difficulty": "Medium",
    "q": "₹50,000 is transferred from the firm's SBI account to its PNB account. This is recorded as:",
    "options": [
      "Bank A/c (PNB) Dr.; To Bank A/c (SBI)",
      "Capital A/c Dr.; To Bank A/c (SBI)",
      "Not recorded, since both are business bank accounts",
      "Drawings A/c Dr.; To Bank A/c (SBI)"
    ],
    "answerIndex": 0,
    "explanation": "This is a contra entry between two of the business's own asset accounts — total assets don't change, only which specific bank account the money sits in. When a business holds more than one bank account, each is tracked and named separately for exactly this reason."
  },
  {
    "id": 105,
    "chapter": "jr",
    "difficulty": "Medium",
    "q": "How does 'Miscellaneous (Sundry) Expenses A/c' differ from 'Petty Cash A/c'?",
    "options": [
      "They are two names for the same account",
      "Miscellaneous Expenses groups small, varied costs by their nature; Petty Cash is an imprest fund describing how small payments are administered",
      "Petty Cash is only used for personal expenses of the proprietor",
      "Miscellaneous Expenses can only be credited, never debited"
    ],
    "answerIndex": 1,
    "explanation": "Miscellaneous Expenses A/c is about the nature of the cost — small, varied items too minor to justify individual accounts. Petty Cash A/c is about administration — a fixed float handed to a petty cashier to make small payments from. A business can easily have both."
  },
  {
    "id": 106,
    "chapter": "jr",
    "difficulty": "Hard",
    "q": "Goods worth ₹80,000 are destroyed by fire, and an insurance claim is lodged but not yet admitted. At this point:",
    "options": [
      "No entry is needed until the claim is settled",
      "The full ₹80,000 is debited to Loss by Fire A/c, since nothing is confirmed recoverable yet",
      "₹80,000 is debited to Insurance Claim A/c immediately",
      "Half is debited to Loss by Fire A/c and half to Insurance Claim A/c automatically"
    ],
    "answerIndex": 1,
    "explanation": "Until the insurer actually admits the claim, none of it can be treated as a confirmed receivable — so the entire cost is provisionally recorded as a loss. Once (and only once) the insurer admits a specific amount, a follow-up entry reclassifies that portion out of the loss and into Insurance Claim A/c."
  },
  {
    "id": 107,
    "chapter": "jr",
    "difficulty": "Medium",
    "q": "Cartage of ₹150 is paid on a delivery to a customer, but is explicitly billed back to and recovered from that customer. This ₹150 is credited to:",
    "options": [
      "Carriage Outwards A/c",
      "Cartage Recovered A/c",
      "Sales A/c",
      "Drawings A/c"
    ],
    "answerIndex": 1,
    "explanation": "Because this cartage is passed straight through to the customer rather than absorbed as a selling expense, it isn't Carriage Outwards at all — it's added to what the customer owes and credited to Cartage Recovered A/c, which behaves like income rather than an expense."
  },
  {
    "id": 108,
    "chapter": "jr",
    "difficulty": "Medium",
    "q": "At the end of the year, unsold closing stock worth ₹85,000 is brought into the books. The entry is:",
    "options": [
      "Closing Stock A/c Dr.; To Trading A/c",
      "Trading A/c Dr.; To Purchases A/c",
      "Purchases A/c Dr.; To Closing Stock A/c",
      "No entry is needed — closing stock is only shown in the Balance Sheet"
    ],
    "answerIndex": 0,
    "explanation": "Closing Stock A/c (an asset — goods still on hand) is debited, and Trading A/c is credited. This is what allows the Trading Account to correctly measure gross profit, since unsold goods shouldn't be counted as part of the cost of what was actually sold during the year."
  },
  { "id": 109, "chapter": "cb", "difficulty": "Easy", "q": "In Cash Book,",
    "options": ["Cash receipts and payments are recorded.", "Cash and credit sales of goods are recorded.", "Cash and credit purchases are recorded.", "None of the above."],
    "answerIndex": 0, "explanation": "Cash Book records only cash and bank transactions — receipts on the debit side, payments on the credit side. Credit sales/purchases never touch cash or bank at the time of the transaction, so they never enter the Cash Book." },
  { "id": 110, "chapter": "cb", "difficulty": "Easy", "q": "Cash Book is an example of",
    "options": ["General Journal.", "Special Journal.", "Both (a) and (b).", "None of these."],
    "answerIndex": 1, "explanation": "Cash Book is a Subsidiary Book, i.e. a Special Journal — a special form of the Journal restricted to cash and bank transactions only." },
  { "id": 111, "chapter": "cb", "difficulty": "Medium", "q": "Cash Book is",
    "options": ["a Subsidiary Book.", "a Principal Book.", "both a Subsidiary Book and a Principal Book.", "a Ledger."],
    "answerIndex": 2, "explanation": "It is a Subsidiary Book because cash/bank transactions are first recorded here; it is also a Principal Book because it IS the Cash and Bank Account, with balances going straight into the Trial Balance." },
  { "id": 112, "chapter": "cb", "difficulty": "Easy", "q": "If Raman has sold goods for cash to Param, the entry will be recorded in the",
    "options": ["Cash Book.", "Sales Book.", "Journal Proper.", "Petty Cash Book."],
    "answerIndex": 0, "explanation": "Sales Book records only CREDIT sales of goods. A cash sale is a cash receipt, so it goes into the Cash Book." },
  { "id": 113, "chapter": "cb", "difficulty": "Easy", "q": "Ravi has purchased goods for cash from Girish for ₹10,000. It will be recorded in",
    "options": ["Cash Book.", "Journal Book.", "both Cash Book and Journal Book.", "Petty Cash Book."],
    "answerIndex": 0, "explanation": "A cash purchase is a cash payment — recorded directly in the Cash Book, with no separate Journal entry needed since Cash Book is itself a book of original entry." },
  { "id": 114, "chapter": "cb", "difficulty": "Medium", "q": "Mohit paid ₹9,800 in settlement of his account of ₹10,000. Discount Allowed will be recorded in",
    "options": ["Cash Book.", "Journal Book.", "Both Cash Book and Journal.", "Petty Cash Book."],
    "answerIndex": 1, "explanation": "The cash of ₹9,800 goes in the Cash Book, but Discount Allowed is never entered in the Cash Book — it is always recorded through a Journal entry in Journal Proper." },
  { "id": 115, "chapter": "cb", "difficulty": "Easy", "q": "Deposit of cash in bank is recorded in",
    "options": ["Debit of Bank Column and Credit of Cash Column.", "Debit of Cash Column and Credit of Bank Column.", "Debit of Cash Column and also Credit of Cash Column.", "Debit of Bank Column and also Credit of Bank Column."],
    "answerIndex": 0, "explanation": "Bank balance increases (bank is the receiver — debited); cash decreases (cash is the giver — credited) — a contra entry across the two columns." },
  { "id": 116, "chapter": "cb", "difficulty": "Easy", "q": "Withdrawal of Cash from Bank is recorded in",
    "options": ["Debit of Bank Column and Credit of Cash Column.", "Debit of Cash Column and Credit of Bank Column.", "Debit of Cash Column and also Credit of Cash Column.", "Debit of Bank Column and also Credit of Bank Column."],
    "answerIndex": 1, "explanation": "Cash in hand increases (debited); bank balance decreases (credited) — the mirror image of depositing cash into the bank." },
  { "id": 117, "chapter": "cb", "difficulty": "Medium", "q": "Contra entries are passed only when",
    "options": ["Double column cash book is prepared.", "Three-column cash book is prepared.", "Simple cash book is prepared.", "None of the above."],
    "answerIndex": 0, "explanation": "A contra entry needs both a cash column and a bank column to move an amount between — only the Two-Column (Double Column) Cash Book has both." },
  { "id": 118, "chapter": "cb", "difficulty": "Medium", "q": "If a cheque deposited is returned dishonoured, it is recorded in",
    "options": ["Cash column on the credit.", "Cash column on the debit.", "Bank column on the credit.", "Bank column on the debit."],
    "answerIndex": 2, "explanation": "The uncollected cheque reduces the bank balance, so it is written on the credit (payments) side in the bank column, with the customer's name." },
  { "id": 119, "chapter": "cb", "difficulty": "Easy", "q": "Double Column Cash Book records",
    "options": ["all transactions.", "cash and Bank transactions.", "only cash transactions.", "only credit transactions."],
    "answerIndex": 1, "explanation": "The two columns are cash and bank — nothing else. Credit transactions (no cash/bank movement yet) never enter it." },
  { "id": 120, "chapter": "cb", "difficulty": "Easy", "q": "Which Cash Book is prepared to record small amounts by cashier to save time of main cashier?",
    "options": ["Three Column Cash Book.", "Two Column Cash Book.", "Petty Cash Book.", "None of these."],
    "answerIndex": 2, "explanation": "Petty Cash Book exists specifically so the Petty Cashier handles small/petty payments, freeing the Chief Cashier's time." },
  { "id": 121, "chapter": "cb", "difficulty": "Hard", "q": "Which of the following will NOT be recorded as a Contra Entry in the Two Column Cash Book?",
    "options": ["Cash withdrew from bank for personal use.", "Cash withdrew from bank for office use.", "Cash deposited.", "Both (a) and (c)."],
    "answerIndex": 0, "explanation": "Withdrawing for OFFICE use is a genuine cash↔bank contra transfer. Withdrawing for PERSONAL use is Drawings — money is actually leaving the business, not just moving between cash and bank, so it is not a contra entry." },
  { "id": 122, "chapter": "cb", "difficulty": "Hard", "q": "Which of the following is NOT true?",
    "options": ["Cash book is a substitute for cash account in the ledger.", "A narration is required for a contra entry along with debit and credit of cash/bank.", "Cash book records only one aspect of a transaction.", "Like ledger, a cash book is also a book of final entry."],
    "answerIndex": 1, "explanation": "A contra entry is simply marked 'C' in the L.F. column on both sides — no separate narration is written for it the way an ordinary Journal entry needs one." },
  { "id": 123, "chapter": "cb", "difficulty": "Medium", "q": "Which of the following is true?",
    "options": ["Cash book is both Journal and Ledger at the same time.", "Debit balance in the bank column of the cash book means overdraft.", "Balance in the Cash Book shows net income.", "Cash column of the Cash Book may show a debit or credit balance."],
    "answerIndex": 0, "explanation": "It is a Journal (a book of original entry) and, at the same time, the Cash/Bank Ledger account itself — this dual nature is Cash Book's defining feature." },
  { "id": 124, "chapter": "cb", "difficulty": "Medium", "q": "When a firm maintains Two-column Cash Book, it does not maintain",
    "options": ["Purchases Book.", "Journal Proper.", "Sales Book.", "Bank and Cash Accounts in the Ledger."],
    "answerIndex": 3, "explanation": "Cash Book itself IS the Cash and Bank Account — maintaining a separate Cash Account/Bank Account in the ledger as well would be duplicating it." },
  { "id": 125, "chapter": "cb", "difficulty": "Easy", "q": "Which of the following is not recorded in the Cash Book?",
    "options": ["Credit Sales.", "Cash Receipts.", "Cash Payments.", "Opening Cash Balance."],
    "answerIndex": 0, "explanation": "Credit sales involve no immediate cash or bank movement — they belong in the Sales Book, not the Cash Book." },
  { "id": 126, "chapter": "cb", "difficulty": "Medium", "q": "Contra entries in the debit of the Cash Book",
    "options": ["are posted to Debit of Bank Account.", "are posted to Debit of Cash Account.", "are posted to Credit of Cash Account.", "Not posted in the Ledger."],
    "answerIndex": 3, "explanation": "Contra entries are marked 'C' and never posted to any separate Ledger account at all — that is exactly what makes them contra." },
  { "id": 127, "chapter": "cb", "difficulty": "Easy", "q": "Which of the following is both Journal and Ledger?",
    "options": ["Cash Book.", "General Journal.", "Purchases Journal.", "Sales Journal."],
    "answerIndex": 0, "explanation": "Only Cash Book carries this dual identity — a book of original entry AND the Cash/Bank ledger account itself." },
  { "id": 128, "chapter": "cb", "difficulty": "Easy", "q": "Balance in Petty Cash Book is",
    "options": ["an expense.", "a profit.", "an asset.", "a liability."],
    "answerIndex": 2, "explanation": "The balance is cash still physically in hand with the Petty Cashier — cash in hand is always an asset." },
  { "id": 129, "chapter": "cb", "difficulty": "Easy", "q": "The term 'Imprest System' is used in relation to",
    "options": ["Cash Book.", "Petty Cash Book.", "Purchase Book.", "Sales Book."],
    "answerIndex": 1, "explanation": "Imprest System describes how the Petty Cashier is funded — given a fixed amount, reimbursed exactly what was spent, specific to the Petty Cash Book." },
  { "id": 130, "chapter": "cb", "difficulty": "Easy", "q": "Petty Cash is used for meeting",
    "options": ["major revenue expenses.", "minor revenue expenses.", "capital expenditures.", "minor revenue and capital expenditure."],
    "answerIndex": 1, "explanation": "Petty Cash Book exists purely for small, everyday revenue expenses — postage, cartage, courier — never for capital expenditure or large amounts." },
  { "id": 131, "chapter": "cb", "difficulty": "Easy", "q": "Balance in the Petty Cash Book represents",
    "options": ["Expenses.", "Net income.", "Cash in hand with petty cashier.", "None of these."],
    "answerIndex": 2, "explanation": "It is simply the unspent portion of the imprest still physically held by the Petty Cashier." },
  { "id": 132, "chapter": "cb", "difficulty": "Medium", "q": "Assertion (A): In Simple Cash Book, cash receipts and payments only are recorded. Reason (R): Cash Book serves the purpose of Cash Account. Choose the correct option: (a) Both A and R are correct but R is not the correct explanation of A. (b) Both A and R are correct and R is the correct explanation of A. (c) Both A and R are not correct. (d) A is correct but R is not correct.",
    "options": ["Both A and R are correct but R is not the correct explanation of A.", "Both A and R are correct and R is the correct explanation of A.", "Both A and R are not correct.", "A is correct but R is not correct."],
    "answerIndex": 0, "explanation": "Both statements are true — A describes what Simple Cash Book records, and R describes Cash Book's own dual nature — but R doesn't actually explain WHY only cash receipts/payments are recorded; they are two separate, true facts." },
  { "id": 133, "chapter": "cb", "difficulty": "Hard", "q": "Assertion (A): Cash Book enables to know cash and bank balance at any time. Reason (R): Cash Book is maintained when all the transactions are recorded in the Journal, i.e., when subsidiary books are not maintained. Choose the correct option: (a) Both A and R are correct but R is not the correct explanation of A. (b) Both A and R are correct and R is the correct explanation of A. (c) Both A and R are not correct. (d) A is correct but R is not correct.",
    "options": ["Both A and R are correct but R is not the correct explanation of A.", "Both A and R are correct and R is the correct explanation of A.", "Both A and R are not correct.", "A is correct but R is not correct."],
    "answerIndex": 3, "explanation": "A is true — the running balance is always visible. But R is false: Cash Book is itself ONE of the Subsidiary Books, maintained precisely because subsidiary books ARE used, not because they aren't." },
  { "id": 134, "chapter": "cb", "difficulty": "Medium", "q": "Assertion (A): If Paresh has sold goods to Akash on credit, entry will not be recorded in the Cash Book. Reason (R): Transactions involving cash are recorded in the Cash Book. Choose the correct option: (a) Both A and R are correct but R is not the correct explanation of A. (b) Both A and R are correct and R is the correct explanation of A. (c) Both A and R are not correct. (d) A is correct but R is not correct.",
    "options": ["Both A and R are correct but R is not the correct explanation of A.", "Both A and R are correct and R is the correct explanation of A.", "Both A and R are not correct.", "A is correct but R is not correct."],
    "answerIndex": 1, "explanation": "A credit sale has no cash movement, so it's correctly excluded from the Cash Book — and R is exactly the reason why: only transactions involving cash (or bank) belong there." },
  { "id": 135, "chapter": "cb", "difficulty": "Hard", "q": "Assertion (A): Contra entries mean transactions involving cash and bank. Reason (R): Contra entries are posted to the respective ledger accounts. Choose the correct option: (a) Both A and R are correct but R is not the correct explanation of A. (b) Both A and R are correct and R is the correct explanation of A. (c) Both A and R are not correct. (d) A is correct but R is not correct.",
    "options": ["Both A and R are correct but R is not the correct explanation of A.", "Both A and R are correct and R is the correct explanation of A.", "Both A and R are not correct.", "A is correct but R is not correct."],
    "answerIndex": 3, "explanation": "A correctly defines contra entries. R is false — contra entries are specifically NOT posted to any separate ledger account; they're only marked 'C' in the L.F. column." },
  { "id": 136, "chapter": "cb", "difficulty": "Hard", "q": "Assertion (A): A deposited cheque dishonoured is recorded in the debit of the cash book. Reason (R): A deposited cheque dishonoured results in increase in bank balance. Choose the correct option: (a) Both A and R are correct but R is not the correct explanation of A. (b) Both A and R are correct and R is the correct explanation of A. (c) Both A and R are not correct. (d) A is correct but R is not correct.",
    "options": ["Both A and R are correct but R is not the correct explanation of A.", "Both A and R are correct and R is the correct explanation of A.", "Both A and R are not correct.", "A is correct but R is not correct."],
    "answerIndex": 2, "explanation": "Both are wrong: a dishonoured deposited cheque is recorded on the CREDIT side (bank column), and it DECREASES the bank balance (the amount that was never really collected is reversed out), not increases it." },
  { "id": 137, "chapter": "cb", "difficulty": "Medium", "q": "Assertion (A): If Cash Book is maintained, Cash Account is not opened in the ledger. Reason (R): Cash Book serves the purpose of Cash Account also. Choose the correct option: (a) Both A and R are correct but R is not the correct explanation of A. (b) Both A and R are correct and R is the correct explanation of A. (c) Both A and R are not correct. (d) A is correct but R is not correct.",
    "options": ["Both A and R are correct but R is not the correct explanation of A.", "Both A and R are correct and R is the correct explanation of A.", "Both A and R are not correct.", "A is correct but R is not correct."],
    "answerIndex": 1, "explanation": "A is true, and R is exactly why — since Cash Book already functions as the Cash Account (Principal Book), opening a duplicate Cash Account in the ledger would be redundant." },
  { "id": 138, "chapter": "cb", "difficulty": "Hard", "q": "Assertion (A): Bank Column in the Cash Book may have debit or credit balance. Reason (R): A cheque issued and dishonoured results in decrease in bank balance. Choose the correct option: (a) Both A and R are correct but R is not the correct explanation of A. (b) Both A and R are correct and R is the correct explanation of A. (c) Both A and R are not correct. (d) A is correct but R is not correct.",
    "options": ["Both A and R are correct but R is not the correct explanation of A.", "Both A and R are correct and R is the correct explanation of A.", "Both A and R are not correct.", "A is correct but R is not correct."],
    "answerIndex": 3, "explanation": "A is true — a debit balance means funds in bank, a credit balance means overdraft. But R is false: a cheque ISSUED and then dishonoured means the payment never actually left the account, so the bank balance is restored/increased, not decreased." },
  { "id": 139, "chapter": "cb", "difficulty": "Medium", "q": "Assertion (A): Cash Column in the Cash Book will not have credit balance. Reason (R): Cash balance in a firm cannot be credit balance, at the most it can have nil balance. Choose the correct option: (a) Both A and R are correct but R is not the correct explanation of A. (b) Both A and R are correct and R is the correct explanation of A. (c) Both A and R are not correct. (d) A is correct but R is not correct.",
    "options": ["Both A and R are correct but R is not the correct explanation of A.", "Both A and R are correct and R is the correct explanation of A.", "Both A and R are not correct.", "A is correct but R is not correct."],
    "answerIndex": 1, "explanation": "A is true, and R correctly explains why — cash paid out can never exceed cash actually held, so the cash column can only ever be a debit balance or exactly nil, never a credit (negative) balance." },
  { "id": 140, "chapter": "cb", "difficulty": "Medium", "q": "Assertion (A): Simple Petty Cash Book is like a Simple Cash Book in which payments of petty expenses are recorded. Reason (R): Maintaining Petty Cash Book lessens the work load on the main Cashier. Choose the correct option: (a) Both A and R are correct but R is not the correct explanation of A. (b) Both A and R are correct and R is the correct explanation of A. (c) Both A and R are not correct. (d) A is correct but R is not correct.",
    "options": ["Both A and R are correct but R is not the correct explanation of A.", "Both A and R are correct and R is the correct explanation of A.", "Both A and R are not correct.", "A is correct but R is not correct."],
    "answerIndex": 0, "explanation": "Both A and R are true statements about Petty Cash Book, but R (reduced workload for the Chief Cashier) doesn't actually explain WHY the Simple Petty Cash Book resembles a Simple Cash Book in format — that's a separate, structural fact." },
  { "id": 141, "chapter": "cb", "difficulty": "Medium", "q": "Assertion (A): In Petty Cash Book, petty expenses paid in cash are recorded. Reason (R): Payment of petty expenses by cheque may also be recorded in Petty Cash Book. Choose the correct option: (a) Both A and R are correct but R is not the correct explanation of A. (b) Both A and R are correct and R is the correct explanation of A. (c) Both A and R are not correct. (d) A is correct but R is not correct.",
    "options": ["Both A and R are correct but R is not the correct explanation of A.", "Both A and R are correct and R is the correct explanation of A.", "Both A and R are not correct.", "A is correct but R is not correct."],
    "answerIndex": 3, "explanation": "A is true — Petty Cash Book records small cash payments. R is false — petty expenses are, by definition, small CASH payments; cheque payments don't belong in the Petty Cash Book." },
  { "id": 142, "chapter": "cb", "difficulty": "Easy", "q": "When cash is deposited in bank, the recorded entry is termed as",
    "options": ["Double Entry.", "Single Entry.", "Opening Entry.", "Contra Entry."],
    "answerIndex": 3, "explanation": "Cash decreasing while bank increases by the same amount, within the same Cash Book, is precisely what defines a contra entry." },
  { "id": 143, "chapter": "cb", "difficulty": "Medium", "q": "A credit balance of ₹10,000 in the Bank Column of the Cash Book shows",
    "options": ["Balance at Bank.", "₹10,000 has been lost.", "Error or errors in recording.", "Bank Account has been overdrawn."],
    "answerIndex": 3, "explanation": "A normal balance in hand at the bank is a debit balance. A credit balance in the bank column means more was paid out than was ever deposited — an overdraft." },
  { "id": 144, "chapter": "cb", "difficulty": "Hard", "q": "Which of the following is classified as Contra Entry?",
    "options": ["Cheque received from a debtor and endorsed to a creditor.", "Withdrawal of cash from bank for personal use.", "Cheque received one day and deposited on another day.", "Withdrawal of cash from bank."],
    "answerIndex": 3, "explanation": "A bare 'withdrawal of cash from bank' (for the business's own use) is a straightforward cash↔bank contra transfer. Endorsement is a Journal entry, personal-use withdrawal is Drawings, and a delayed deposit involves Cheques-in-Hand A/c first — none of those three are contra entries." },
  { "id": 145, "chapter": "cb", "difficulty": "Hard", "q": "Payment made of ₹5,000 in cash to a mobile shop for repairing the proprietor's son's mobile should be recorded by",
    "options": ["Debiting Repairs Account in the credit (payment) side of Cash Book in Bank Column.", "Crediting Drawings Account in the credit (payment) side of Cash Book in Cash Column.", "Crediting Repairs Account in the debit (payment) side of Cash Book in Bank Column.", "Debiting Drawings Account in the credit (payment) side of Cash Book in Cash Column."],
    "answerIndex": 3, "explanation": "Repairing the proprietor's own son's mobile is a personal expense, not a business one — so it's Drawings, not Repairs. The cash payment is recorded on the credit/payment side of the Cash Book (Cash Column), and the corresponding ledger effect debits Drawings A/c." },
  { "id": 146, "chapter": "cb", "difficulty": "Medium", "q": "A cheque of ₹14,500 received from a debtor in settlement of his claim of ₹15,000 will be recorded in",
    "options": ["Journal Proper.", "Cash Book, Bank Column.", "Cash Book, Discount Column in the debit (Receipt) side.", "Cash Book in Discount Column in the credit (Payment) side."],
    "answerIndex": 0, "explanation": "The ₹14,500 cheque itself is recorded in the Cash Book's bank column — but the ₹500 discount allowed has nowhere to go in a two-column Cash Book, since it has no discount column at all; it must be recorded separately via Journal Proper." },
  { "id": 147, "chapter": "cb", "difficulty": "Hard", "q": "Assertion (A): When a cheque of ₹48,000 is received from a debtor in settlement of his claim of ₹50,000 and deposited in bank, it is recorded in a single-column Cash Book. Reason (R): Two-Column Cash Book has Cash and Discount columns. Choose the correct option: (a) Both A and R are correct but R is not the correct explanation of A. (b) Both A and R are correct and R is the correct explanation of A. (c) Both A and R are not correct. (d) A is correct but R is not correct.",
    "options": ["Both A and R are correct but R is not the correct explanation of A.", "Both A and R are correct and R is the correct explanation of A.", "Both A and R are not correct.", "A is correct but R is not correct."],
    "answerIndex": 2, "explanation": "Both are wrong. The cheque is deposited into the bank column of a Two-Column (Cash + Bank) Cash Book, not a 'single column' one — and this chapter's Two-Column Cash Book has Cash and BANK columns, not a discount column at all." },
  { "id": 148, "chapter": "cb", "difficulty": "Medium", "q": "An amount given to Petty Cashier equal to the estimated petty expenses for a period is",
    "options": ["Petty cash.", "Imprest money.", "Estimated expenses.", "None of these."],
    "answerIndex": 1, "explanation": "This fixed advance, given at the start of a period and reimbursed at the end, is exactly what defines the Imprest System's 'imprest money'." },
  { "id": 149, "chapter": "cb", "difficulty": "Medium", "q": "A debit balance of ₹5,000 in the cash column of the Cash Book shows",
    "options": ["₹5,000 is paid but not recorded.", "₹5,000 is a liability.", "Amount received exceeds the amount paid by ₹5,000.", "₹5,000 is credited in the bank account."],
    "answerIndex": 2, "explanation": "The cash column's debit balance is simply Receipts total minus Payments total — a debit balance of ₹5,000 means ₹5,000 more was received than paid out." },
  { "id": 150, "chapter": "cb", "difficulty": "Hard", "q": "Which of the following is not posted in the Ledger?",
    "options": ["Withdrew from bank for business purpose.", "Withdrew from bank for personal use.", "Withdrew cash for personal use.", "Cash paid to creditors."],
    "answerIndex": 0, "explanation": "Withdrawing from bank for the BUSINESS's own (office) use is a contra entry — and contra entries are never posted to any Ledger account. The other three are ordinary transactions (Drawings A/c or Creditors A/c) that ARE posted normally." },
  { "id": 151, "chapter": "cb", "difficulty": "Medium", "q": "Imprest amount is ₹5,000. What will be the amount of reimbursement if the Petty Cashier incurs the following expenses during the month — Cartage ₹800, Stationery ₹2,400, Postage ₹500, Miscellaneous Expenses ₹600?",
    "options": ["₹5,000.", "₹4,300.", "₹5,700.", "₹3,100."],
    "answerIndex": 1, "explanation": "Total spent = 800 + 2,400 + 500 + 600 = ₹4,300. Under the Imprest System, the reimbursement exactly equals what was actually spent, restoring the imprest back to ₹5,000 for next period." },
  { "id": 152, "chapter": "cb", "difficulty": "Easy", "q": "An amount of ₹500 was paid for postage. This transaction will typically be recorded in",
    "options": ["Journal.", "Purchases Book.", "Cash Book.", "Petty Cash Book."],
    "answerIndex": 3, "explanation": "Postage is a small, routine, petty expense — exactly the kind of payment the Petty Cash Book (not the main Cash Book) exists to record." },
  { "id": 153, "chapter": "cb", "difficulty": "Easy", "q": "The petty cash may be used",
    "options": ["to repay creditors towards the purchase of raw materials.", "to settle a bank loan.", "for the refreshment to customers.", "for the purchase of furniture and fixtures."],
    "answerIndex": 2, "explanation": "Only small, everyday revenue items like refreshments fit petty cash's purpose. Creditor settlements, bank loan repayment, and furniture purchase are all far too large and are capital/major items, never petty cash." },
  { "id": 154, "chapter": "cb", "difficulty": "Hard", "q": "Raj received a cheque from Sanjay after allowing a discount of ₹500, and it was sent to the bank on the same date. After two days the bank informed that Sanjay's cheque of ₹4,500 is dishonoured. For recording this dishonour of cheque,",
    "options": ["both ₹4,500 and ₹500 are to be recorded on the debit side of the Cash Book.", "both ₹4,500 and ₹500 are to be recorded on the credit side of the Cash Book.", "only ₹4,500 is to be recorded on the credit side of the Cash Book and ₹500 altogether to be ignored.", "₹4,500 is to be recorded on the credit side of the Cash Book and for ₹500 a Journal entry is to be passed in the Journal Proper."],
    "answerIndex": 3, "explanation": "The dishonoured cheque amount (₹4,500) is written back on the credit/bank column of the Cash Book. The discount that was allowed against it (₹500) must now be reversed too, but since discount never touches the Cash Book, its reversal is passed as a separate Journal Proper entry." },
  { "id": 155, "chapter": "cb", "difficulty": "Medium", "q": "Double Entry of which of the following transactions is completed in the Cash Book itself?",
    "options": ["Paid rent by cheque.", "Withdrew from bank for personal use.", "A cheque received from a customer deposited into the bank on the same day.", "Cash deposited into the bank."],
    "answerIndex": 3, "explanation": "Cash deposited into the bank is a contra entry — both aspects (cash decreasing, bank increasing) are recorded within the Cash Book itself, on its two columns, with nothing further to post anywhere else." },
  { "id": 156, "chapter": "cb", "difficulty": "Medium", "q": "A cheque of ₹36,000 is received on 1st March, dated 1st May, and is discounted by the bank the same day at 8% p.a. for the remaining period. What are the discounting charges?",
    "options": ["₹480.", "₹720.", "₹960.", "₹2,880."],
    "answerIndex": 0, "explanation": "Remaining period = 2 months. Discounting charges = 36,000 × 8/100 × 2/12 = ₹480 — the same formula used for the PDF's own ₹24,000-cheque, 10% p.a., 1-month example, just with different figures." },
  { "id": 157, "chapter": "cb", "difficulty": "Medium", "q": "A firm's Bank Column shows: opening balance b/d (overdraft) ₹8,000; total receipts during the month ₹25,000; total payments during the month ₹30,000 (excluding the opening balance). What is the closing balance of the Bank Column, and what kind of balance is it?",
    "options": ["₹13,000, debit balance.", "₹13,000, credit balance (overdraft).", "₹17,000, credit balance (overdraft).", "₹17,000, debit balance."],
    "answerIndex": 1, "explanation": "Credit side total = opening overdraft 8,000 + payments 30,000 = 38,000. Debit side total = receipts 25,000. Since credit is larger, the balance c/d = 38,000 − 25,000 = ₹13,000, written on the debit side — meaning it remains a credit (overdraft) balance carried forward." },
  { "id": 158, "chapter": "cb", "difficulty": "Easy", "q": "A cheque received from a customer and deposited in the bank on the same day is recorded in",
    "options": ["the debit (receipts) side, bank column, of the Cash Book.", "the credit (payments) side, bank column, of the Cash Book.", "Journal Proper, via Cheques-in-Hand A/c.", "the debit (receipts) side, cash column, of the Cash Book."],
    "answerIndex": 0, "explanation": "A cheque banked the same day it's received goes straight into the bank column on the receipts side — Cheques-in-Hand A/c is only needed when the cheque is NOT deposited on the same day." },
  { "id": 159, "chapter": "cb", "difficulty": "Medium", "q": "A firm's Simple Petty Cash Book has an imprest of ₹4,000. During the month it paid: Courier ₹350, Stationery ₹620, Cartage ₹180, Sundries ₹90. What amount will the Petty Cashier be reimbursed at the start of next month?",
    "options": ["₹4,000.", "₹1,240.", "₹2,760.", "₹3,760."],
    "answerIndex": 1, "explanation": "Total spent = 350 + 620 + 180 + 90 = ₹1,240. Under the Imprest System, the Petty Cashier is reimbursed exactly this spent amount, so his balance is topped back up to the full ₹4,000 imprest." },
  { "id": 160, "chapter": "sp2", "difficulty": "Easy", "q": "In the Purchases Book, transactions recorded are",
    "options": ["Cash purchases of goods.", "Credit purchases of goods.", "All purchases of goods.", "Credit purchase of assets."],
    "answerIndex": 1, "explanation": "Purchases Book records only CREDIT purchases of goods the firm trades in — cash purchases go to the Cash Book, and credit purchases of assets go to Journal Proper." },
  { "id": 161, "chapter": "sp2", "difficulty": "Easy", "q": "Sales Return Book records",
    "options": ["The return of goods purchased.", "The return of goods sold on credit.", "The return of goods sold for cash.", "The return of assets sold."],
    "answerIndex": 1, "explanation": "Sales Return Book (Returns Inward Book) records only goods that were sold on CREDIT and are now being returned by the customer." },
  { "id": 162, "chapter": "sp2", "difficulty": "Easy", "q": "The Sales Book",
    "options": ["is a part of Journal.", "is a part of Ledger.", "is a part of Balance Sheet.", "is a part of Trial Balance."],
    "answerIndex": 0, "explanation": "Like all Subsidiary Books, the Sales Book is a book of original entry — part of the Journal, not the Ledger." },
  { "id": 163, "chapter": "sp2", "difficulty": "Easy", "q": "The periodic (weekly/fortnightly/monthly) total of the Purchases Book is",
    "options": ["posted to the debit of Purchases Account.", "posted to the debit of Sales Account.", "posted to the credit of Purchases Account.", "posted to the debit of each Party's Account."],
    "answerIndex": 0, "explanation": "Individual suppliers are credited as entries are made; the periodic TOTAL of the whole book is posted to the debit of Purchases Account." },
  { "id": 164, "chapter": "sp2", "difficulty": "Medium", "q": "The total of the Sales Book is posted to the",
    "options": ["debit of Sales Account.", "credit of Sales Account.", "debit of Customers' Accounts.", "credit of Customers' Accounts."],
    "answerIndex": 1, "explanation": "Individual customers are debited as entries are made; the book's periodic total is posted to the credit of Sales Account." },
  { "id": 165, "chapter": "sp2", "difficulty": "Medium", "q": "The periodic total of the Sales Return Book is posted to the",
    "options": ["debit of Sales Account.", "credit of Sales Account.", "debit of Sales Return Account.", "credit of Sales Return Account."],
    "answerIndex": 2, "explanation": "The Sales Return Book's total is debited to Sales Return Account, since returns reduce what was previously recorded as a sale." },
  { "id": 166, "chapter": "sp2", "difficulty": "Easy", "q": "Goods purchased for cash are recorded in",
    "options": ["Purchases Book.", "Cash Book.", "Purchases Return Book.", "Purchases Account (directly, with no book of original entry)."],
    "answerIndex": 1, "explanation": "Cash purchases, of goods or otherwise, are always recorded in the Cash Book — never the Purchases Book." },
  { "id": 167, "chapter": "sp2", "difficulty": "Medium", "q": "The total of which of these transactions is posted to Purchases Account?",
    "options": ["Credit purchase of furniture.", "Purchases Return.", "Credit purchase of goods.", "Purchase of Stationery for office use."],
    "answerIndex": 2, "explanation": "Only credit purchases of goods dealt in flow through the Purchases Book and get posted to Purchases Account. Furniture and stationery for office use are assets, recorded via Journal Proper." },
  { "id": 168, "chapter": "sp2", "difficulty": "Easy", "q": "When goods are returned by a customer, the document the FIRM (seller) prepares is a",
    "options": ["Credit Note.", "Debit Note.", "Invoice.", "Voucher."],
    "answerIndex": 0, "explanation": "The seller prepares a Credit Note when a customer returns goods sold on credit — it is the basis for the Sales Return Book entry." },
  { "id": 169, "chapter": "sp2", "difficulty": "Medium", "q": "Sale of an asset (not goods dealt in) on credit is recorded in",
    "options": ["Sales Book.", "Journal Proper.", "Special Journal.", "Cash Book."],
    "answerIndex": 1, "explanation": "The Sales Book only records credit sales of goods the firm actually trades in — a credit sale of an asset it doesn't deal in goes through Journal Proper." },
  { "id": 170, "chapter": "sp2", "difficulty": "Easy", "q": "The Opening Entry — bringing forward last year's assets, liabilities and capital — is recorded",
    "options": ["in the beginning of the accounting year.", "at the end of the accounting year.", "in the middle of the accounting year.", "anytime during the year."],
    "answerIndex": 0, "explanation": "The Opening Entry, passed through Journal Proper, is made right at the start of a new financial year to bring forward the previous year's closing balances." },
  { "id": 171, "chapter": "sp2", "difficulty": "Medium", "q": "Goods taken by the proprietor for personal use will be recorded in",
    "options": ["Purchase Book.", "Sales Book.", "Cash Book.", "Journal Proper."],
    "answerIndex": 3, "explanation": "Goods withdrawn by the owner for personal use is neither a purchase, sale, nor cash transaction — it's a Drawings entry passed through Journal Proper." },
  { "id": 172, "chapter": "sp2", "difficulty": "Easy", "q": "Closing entries — which transfer nominal accounts to Trading A/c and Profit & Loss A/c — are passed",
    "options": ["in the beginning of the accounting year.", "at the end of the accounting year.", "in the middle of the accounting year.", "anytime during the year."],
    "answerIndex": 1, "explanation": "Closing Entries are passed at the end of the accounting year, closing off expense and revenue accounts by transferring their balances." },
  { "id": 173, "chapter": "sp2", "difficulty": "Hard", "q": "Which of the following is entered in the Journal Proper?",
    "options": ["Cash payment to an employee for expenses.", "Cash purchase of goods for resale.", "Correction of an error.", "Credit purchase of goods for resale."],
    "answerIndex": 2, "explanation": "Rectification of an error is a Journal Proper entry. Cash payments/purchases go through the Cash Book, and credit purchase of goods for resale goes through the Purchases Book." },
  { "id": 174, "chapter": "sp2", "difficulty": "Medium", "q": "Sachin returns goods to Sourav that he had purchased on credit. How is this recorded in Sachin's own books?",
    "options": ["Purchase Returns Book — debit Purchase Returns, credit Sourav.", "Purchase Returns Book — debit Sourav, credit Purchase Returns.", "Sales Returns Book — debit Sales Returns, credit Sourav.", "Sales Returns Book — debit Sourav, credit Sales Returns."],
    "answerIndex": 1, "explanation": "From Sachin's (the purchaser's) side, returning goods he'd bought is recorded in the Purchases Return Book: Sourav's account is debited, and Purchases Return Account is credited." },
  { "id": 175, "chapter": "sp2", "difficulty": "Easy", "q": "Mohan returns goods to Sohan (goods Mohan had purchased on credit from Sohan). Which document will Mohan send to Sohan?",
    "options": ["Credit Note.", "Debit Note.", "Invoice.", "Receipt."],
    "answerIndex": 1, "explanation": "As the purchaser returning goods, Mohan (not Sohan) prepares and sends a Debit Note, notifying Sohan that his account has been debited." },
  { "id": 176, "chapter": "sp2", "difficulty": "Hard", "q": "Assertion (A): In the Purchases Book, both cash and credit purchases of goods are recorded. Reason (R): The Purchases Book is maintained when credit purchase of goods is voluminous. Choose: (a) Both A and R are correct but R is not the correct explanation of A. (b) Both A and R are correct and R is the correct explanation of A. (c) Both A and R are not correct. (d) A is correct but R is not correct.",
    "options": ["Both A and R are correct but R is not the correct explanation of A.", "Both A and R are correct and R is the correct explanation of A.", "Both A and R are not correct.", "A is correct but R is not correct."],
    "answerIndex": 3, "explanation": "A is false — the Purchases Book records ONLY credit purchases of goods, not cash purchases. R on its own is a correct statement about why the book exists." },
  { "id": 177, "chapter": "sp2", "difficulty": "Hard", "q": "Assertion (A): In the Purchases Return Book, returns of goods purchased on credit are recorded. Reason (R): The periodic total of the Purchases Return Book is posted to the credit of Purchases Return Account. Choose: (a) Both A and R are correct but R is not the correct explanation of A. (b) Both A and R are correct and R is the correct explanation of A. (c) Both A and R are not correct. (d) A is correct but R is not correct.",
    "options": ["Both A and R are correct but R is not the correct explanation of A.", "Both A and R are correct and R is the correct explanation of A.", "Both A and R are not correct.", "A is correct but R is not correct."],
    "answerIndex": 0, "explanation": "Both statements are individually true, but R (about posting) doesn't explain WHY returns of credit purchases are what the book records — A's own definition explains itself." },
  { "id": 178, "chapter": "sp2", "difficulty": "Hard", "q": "Assertion (A): Purchases Book and Sales Book are part of the Journal. Reason (R): Purchases Book and Sales Book are independent subsidiary books. Choose: (a) Both A and R are correct but R is not the correct explanation of A. (b) Both A and R are correct and R is the correct explanation of A. (c) Both A and R are not correct. (d) A is correct but R is not correct.",
    "options": ["Both A and R are correct but R is not the correct explanation of A.", "Both A and R are correct and R is the correct explanation of A.", "Both A and R are not correct.", "A is correct but R is not correct."],
    "answerIndex": 1, "explanation": "Both are true, and being independent subsidiary books (each maintained separately for its own category of transaction) is precisely why they're both part of the Journal — books of original entry, not the Ledger." },
  { "id": 179, "chapter": "sp2", "difficulty": "Hard", "q": "Assertion (A): On goods being returned by the purchaser, the seller prepares a Credit Note. Reason (R): A Credit Note is evidence that the Purchaser's Account has been credited. Choose: (a) Both A and R are correct but R is not the correct explanation of A. (b) Both A and R are correct and R is the correct explanation of A. (c) Both A and R are not correct. (d) A is correct but R is not correct.",
    "options": ["Both A and R are correct but R is not the correct explanation of A.", "Both A and R are correct and R is the correct explanation of A.", "Both A and R are not correct.", "A is correct but R is not correct."],
    "answerIndex": 1, "explanation": "Both true — the whole reason a Credit Note is issued is that the seller has credited the purchaser's (customer's) account for the returned goods." },
  { "id": 180, "chapter": "sp2", "difficulty": "Medium", "q": "Purchases Book, Sales Book, Purchases Return Book, and Sales Return Book are maintained even if the number of such transactions is very small. Is this correct?",
    "options": ["Correct — every firm must maintain all four regardless of volume.", "Incorrect — they're maintained when the number of such transactions is large; otherwise transactions may simply be recorded through Journal Proper.", "Correct, but only for firms with credit sales exceeding ₹1 lakh.", "Incorrect — these books don't exist for firms with few transactions at all."],
    "answerIndex": 1, "explanation": "Subsidiary Books exist purely for convenience when transaction volume is high. If a particular type of transaction is rare, it can simply be recorded through Journal Proper instead of maintaining a dedicated book for it." },
  { "id": 181, "chapter": "sp2", "difficulty": "Medium", "q": "Freight payable on the purchase of a fixed asset (not goods dealt in) is recorded in",
    "options": ["Purchases Book.", "Sales Book.", "Journal Proper.", "None of these."],
    "answerIndex": 2, "explanation": "Since the asset purchase itself goes through Journal Proper (it isn't goods), any freight incurred to acquire it is added to the asset's cost through the same Journal Proper entry, not a subsidiary book." },
  { "id": 182, "chapter": "sp2", "difficulty": "Medium", "q": "Freight actually PAID IN CASH by the seller on goods already sold (not recovered from the buyer) is recorded in",
    "options": ["Sales Book.", "Purchases Book.", "Cash Book.", "Journal Book."],
    "answerIndex": 2, "explanation": "This is simply a cash expense the seller bears — it never touches the Sales Book at all, since it was never billed to the customer as part of the invoice." },
  { "id": 183, "chapter": "brs", "difficulty": "Easy", "q": "A Bank Reconciliation Statement is prepared to:",
    "options": ["Calculate the firm's total profit for the year.", "Explain the difference between the balance as per Cash Book and the balance as per Pass Book.", "Record all credit purchases of goods.", "Replace the need to maintain a Cash Book."],
    "answerIndex": 1, "explanation": "A BRS exists purely to explain, item by item, why the Cash Book's bank balance and the Pass Book balance differ on a given date, and to reconcile the two." },
  { "id": 184, "chapter": "brs", "difficulty": "Easy", "q": "The 'Balance as per Pass Book' is:",
    "options": ["The balance shown in the firm's own Cash Book.", "The balance shown in the copy of the account the bank maintains for the firm.", "The firm's total capital.", "The balance of the Petty Cash Book."],
    "answerIndex": 1, "explanation": "The Pass Book (or bank statement) is the bank's own record of the firm's account, issued to the firm — the Balance as per Pass Book is simply its closing figure." },
  { "id": 185, "chapter": "brs", "difficulty": "Easy", "q": "The main reason Cash Book and Pass Book balances usually differ is:",
    "options": ["The firm and the bank use different currencies.", "Timing differences — one side has recorded a transaction the other hasn't, yet.", "The Pass Book is prepared only once a year.", "Cash Book balances are always estimates."],
    "answerIndex": 1, "explanation": "Most differences arise simply because the firm and the bank record the same transaction at different points in time." },
  { "id": 186, "chapter": "brs", "difficulty": "Easy", "q": "A cheque issued by the firm but not yet presented for payment causes the:",
    "options": ["Cash Book balance to be higher than the Pass Book balance.", "Pass Book balance to be higher than the Cash Book balance.", "Two balances to remain unaffected.", "Cash Book to show a wrong total."],
    "answerIndex": 1, "explanation": "The firm has already reduced its Cash Book balance for the cheque, but the bank hasn't reduced the Pass Book yet since the cheque isn't presented — so the Pass Book balance stays higher for now." },
  { "id": 187, "chapter": "brs", "difficulty": "Easy", "q": "A cheque deposited by the firm but not yet collected by the bank causes the:",
    "options": ["Cash Book balance to be higher than the Pass Book balance.", "Pass Book balance to be higher than the Cash Book balance.", "Two balances to always become equal immediately.", "Firm's Capital Account to change."],
    "answerIndex": 0, "explanation": "The firm has already increased its Cash Book balance on deposit, but the bank will only credit it once the cheque clears — so the Cash Book balance stays higher for now." },
  { "id": 188, "chapter": "brs", "difficulty": "Easy", "q": "Bank charges debited by the bank, when not yet entered in the Cash Book, are treated in a BRS started from the Cash Book balance as:",
    "options": ["Added.", "Deducted.", "Ignored.", "Multiplied by the interest rate."],
    "answerIndex": 1, "explanation": "The Pass Book has already been reduced for the bank's charge; the Cash Book hasn't, so it currently overstates the balance — hence deducted, starting from the Cash Book." },
  { "id": 189, "chapter": "brs", "difficulty": "Easy", "q": "Interest allowed by the bank, when not yet entered in the Cash Book, is treated in a BRS started from the Cash Book balance as:",
    "options": ["Added.", "Deducted.", "Shown as a liability.", "Ignored, since it is too small an amount."],
    "answerIndex": 0, "explanation": "The Pass Book has already been increased for the interest; the Cash Book understates the balance until it records it too — hence added, starting from the Cash Book." },
  { "id": 190, "chapter": "brs", "difficulty": "Medium", "q": "A cheque deposited and recorded as received is later dishonoured by the bank. When preparing a BRS starting from the Cash Book, and the dishonour is not yet entered there, this item is:",
    "options": ["Added, since the cheque still exists physically.", "Deducted, since the Cash Book still shows it as realised money.", "Ignored — dishonoured cheques never affect a BRS.", "Shown only in the Petty Cash Book."],
    "answerIndex": 1, "explanation": "The Cash Book still shows the dishonoured cheque as good money received, but the bank has already reversed that credit — so the Cash Book currently overstates the balance and the item is deducted." },
  { "id": 191, "chapter": "brs", "difficulty": "Medium", "q": "A customer deposits money directly into the firm's bank account, and the firm has not yet recorded it. Starting a BRS from the Cash Book balance, this item is:",
    "options": ["Added.", "Deducted.", "Recorded as a bank overdraft.", "Not a valid reconciling item."],
    "answerIndex": 0, "explanation": "The bank has already credited this in the Pass Book; the firm's Cash Book understates the balance until it records the same receipt — hence added." },
  { "id": 192, "chapter": "brs", "difficulty": "Medium", "q": "Under a standing instruction, the bank directly pays the firm's insurance premium. If this is not yet in the Cash Book, a BRS starting from the Cash Book balance treats it as:",
    "options": ["Added.", "Deducted.", "Shown as capital introduced.", "Cancelled against bank charges."],
    "answerIndex": 1, "explanation": "The bank has already debited the Pass Book for this payment; the Cash Book overstates the balance until it records the same payment — hence deducted." },
  { "id": 193, "chapter": "brs", "difficulty": "Medium", "q": "If a BRS is started from the Balance as per Pass Book instead of the Cash Book, an item that was 'Added' when starting from the Cash Book will now be:",
    "options": ["Added again.", "Deducted.", "Ignored entirely.", "Multiplied by two."],
    "answerIndex": 1, "explanation": "Since the direction of travel reverses, every item's treatment reverses too — what was Add from one balance becomes Less from the other, for the exact same transaction." },
  { "id": 194, "chapter": "brs", "difficulty": "Medium", "q": "Which of the following causes a difference that originates from an error made by the firm itself, rather than a timing difference or a bank-initiated transaction?",
    "options": ["Cheque issued but not presented.", "Undercasting of the receipts side of the Cash Book's bank column.", "Interest credited by the bank.", "Direct collection by the bank."],
    "answerIndex": 1, "explanation": "Undercasting (under-totalling) the Cash Book is a mistake made by the firm in its own record, unlike the other options, which are all timing differences or bank-initiated entries." },
  { "id": 195, "chapter": "brs", "difficulty": "Medium", "q": "If the receipts side of the Cash Book's bank column has been overcast (totalled in excess), the Cash Book balance is:",
    "options": ["Understated, so the excess should be added.", "Overstated, so the excess should be deducted.", "Unaffected, since overcasting doesn't change totals.", "Corrected automatically by the bank."],
    "answerIndex": 1, "explanation": "Overcasting the receipts side inflates the balance by the excess amount, so the balance is overstated and the excess must be deducted to correct it." },
  { "id": 196, "chapter": "brs", "difficulty": "Medium", "q": "If the payments side of the Cash Book's bank column has been undercast (totalled short), the Cash Book balance is:",
    "options": ["Overstated, so the shortfall should be deducted.", "Understated, so the shortfall should be added.", "Unaffected.", "Corrected only in the Pass Book."],
    "answerIndex": 0, "explanation": "Undercasting the payments side means less was deducted than should have been, so the balance is overstated by the shortfall — which must therefore be deducted." },
  { "id": 197, "chapter": "brs", "difficulty": "Easy", "q": "Balance as per Cash Book is ₹20,000. A cheque of ₹3,000 issued has not been presented for payment. What is the Balance as per Pass Book?",
    "options": ["₹17,000", "₹20,000", "₹23,000", "₹26,000"],
    "answerIndex": 2, "explanation": "An unpresented cheque is added when starting from the Cash Book: ₹20,000 + ₹3,000 = ₹23,000." },
  { "id": 198, "chapter": "brs", "difficulty": "Easy", "q": "Balance as per Cash Book is ₹20,000. A cheque of ₹2,000 deposited has not been collected by the bank. What is the Balance as per Pass Book?",
    "options": ["₹22,000", "₹20,000", "₹18,000", "₹16,000"],
    "answerIndex": 2, "explanation": "An uncollected cheque is deducted when starting from the Cash Book: ₹20,000 − ₹2,000 = ₹18,000." },
  { "id": 199, "chapter": "brs", "difficulty": "Medium", "q": "Balance as per Cash Book is ₹15,000. Bank charges of ₹100 and interest allowed by the bank of ₹250 are both unrecorded in the Cash Book. What is the Balance as per Pass Book?",
    "options": ["₹15,150", "₹14,850", "₹15,350", "₹14,650"],
    "answerIndex": 0, "explanation": "Bank charges are deducted (−100) and interest allowed is added (+250): ₹15,000 − 100 + 250 = ₹15,150." },
  { "id": 200, "chapter": "brs", "difficulty": "Medium", "q": "Balance as per Pass Book is ₹28,000. A cheque of ₹6,000 issued has not been presented for payment. What is the Balance as per Cash Book?",
    "options": ["₹34,000", "₹28,000", "₹22,000", "₹20,000"],
    "answerIndex": 2, "explanation": "Starting from the Pass Book, an unpresented cheque is deducted (the reverse of starting from the Cash Book): ₹28,000 − ₹6,000 = ₹22,000." },
  { "id": 201, "chapter": "brs", "difficulty": "Medium", "q": "Balance as per Pass Book is ₹12,000. A cheque of ₹4,000 deposited has not yet been collected by the bank. What is the Balance as per Cash Book?",
    "options": ["₹8,000", "₹12,000", "₹16,000", "₹4,000"],
    "answerIndex": 2, "explanation": "Starting from the Pass Book, an uncollected cheque is added (the reverse of starting from the Cash Book): ₹12,000 + ₹4,000 = ₹16,000." },
  { "id": 202, "chapter": "brs", "difficulty": "Hard", "q": "Balance as per Cash Book is ₹60,000. Cheques of ₹10,000 issued are unpresented; cheques of ₹7,000 deposited are uncollected; bank charges of ₹200 are unrecorded in the Cash Book. What is the Balance as per Pass Book?",
    "options": ["₹62,800", "₹63,200", "₹57,200", "₹77,200"],
    "answerIndex": 0, "explanation": "₹60,000 + ₹10,000 (unpresented cheque, added) − ₹7,000 (uncollected cheque, deducted) − ₹200 (bank charges, deducted) = ₹62,800." },
  { "id": 203, "chapter": "brs", "difficulty": "Hard", "q": "Balance as per Cash Book is ₹35,000. A customer's cheque for ₹4,000, recorded as received, is dishonoured; a direct bank collection of ₹1,500 is unrecorded; both are missing from the Cash Book. What is the Balance as per Pass Book?",
    "options": ["₹32,500", "₹40,500", "₹31,000", "₹38,500"],
    "answerIndex": 0, "explanation": "Dishonoured cheque: deducted, −₹4,000. Direct collection by bank: added, +₹1,500. ₹35,000 − 4,000 + 1,500 = ₹32,500." },
  { "id": 204, "chapter": "brs", "difficulty": "Easy", "q": "In a Bank Reconciliation Statement, an item that makes the starting balance fall short of the target balance should be:",
    "options": ["Added.", "Deducted.", "Ignored.", "Shown as a footnote only."],
    "answerIndex": 0, "explanation": "The single Add/Less rule: if the starting balance is short of the target, that item is added to close the gap." },
  { "id": 205, "chapter": "brs", "difficulty": "Easy", "q": "In a Bank Reconciliation Statement, an item that makes the starting balance exceed the target balance should be:",
    "options": ["Added.", "Deducted.", "Doubled.", "Recorded twice, once on each side."],
    "answerIndex": 1, "explanation": "The single Add/Less rule: if the starting balance is ahead of the target, that item is deducted to close the gap." },
  { "id": 206, "chapter": "brs", "difficulty": "Medium", "q": "A Debit Note and a Credit Note, as used in the Purchases Return and Sales Return Books, are directly relevant to preparing a BRS. True or False?",
    "options": ["True — every BRS references Debit and Credit Notes.", "False — Debit/Credit Notes relate to Subsidiary Books for goods returns, not to bank reconciliation.", "True, but only for cash purchases.", "False, because BRS is only prepared once a year."],
    "answerIndex": 1, "explanation": "Debit and Credit Notes support entries in the Purchases/Sales Return Books, an entirely different topic from reconciling Cash Book and Pass Book balances." },
  { "id": 207, "chapter": "brs", "difficulty": "Easy", "q": "A BRS is usually prepared:",
    "options": ["Only once, when the business is first set up.", "Periodically, commonly every month, on a given date.", "Only when the firm closes down.", "Only when the Cash Book is lost."],
    "answerIndex": 1, "explanation": "Firms typically reconcile their bank balance regularly — commonly every month — to keep records accurate and catch errors or fraud early." },
  { "id": 208, "chapter": "brs", "difficulty": "Easy", "q": "Which of these is NOT normally a purpose of preparing a BRS?",
    "options": ["Locating and explaining the cause of every difference.", "Detecting errors in the Cash Book or Pass Book.", "Calculating the firm's net profit for the year.", "Verifying the correct bank balance for the Balance Sheet."],
    "answerIndex": 2, "explanation": "Net profit is calculated through the Trading and Profit & Loss Account, not a BRS — a BRS deals only with reconciling the bank balance." },
  { "id": 209, "chapter": "brs", "difficulty": "Medium", "q": "The bank's own error — wrongly crediting the firm's Pass Book with an amount that belongs to another customer's account — should, when starting a BRS from the Pass Book balance, be:",
    "options": ["Added, since the Pass Book balance is overstated.", "Deducted, since the Pass Book balance is overstated.", "Ignored, since bank errors self-correct.", "Added to the Cash Book directly, bypassing the BRS."],
    "answerIndex": 1, "explanation": "A wrong credit inflates the Pass Book balance beyond what it should be, so — starting from the (overstated) Pass Book — that excess amount must be deducted to reach the correct Cash Book figure." },
  { "id": 210, "chapter": "brs", "difficulty": "Medium", "q": "Balance as per Cash Book is a credit balance (i.e. the firm has overdrawn its account). In the firm's own Cash Book, this is shown as a:",
    "options": ["Debit balance.", "Credit balance (bank overdraft).", "Balance that is simply omitted.", "Capital balance."],
    "answerIndex": 1, "explanation": "A bank overdraft — money owed TO the bank — is a liability for the firm, and shows up as a credit balance in the bank column of the Cash Book." },
  { "id": 211, "chapter": "brs", "difficulty": "Hard", "q": "Assertion (A): The debit/credit language in a Pass Book is the exact reverse of the firm's own Cash Book. Reason (R): The Pass Book is written from the bank's point of view, where money owed back to the firm is a liability for the bank, hence a credit balance. Choose: (a) Both A and R are true, and R correctly explains A. (b) Both A and R are true, but R does not correctly explain A. (c) A is true, R is false. (d) A is false, R is true.",
    "options": ["Both A and R are true, and R correctly explains A.", "Both A and R are true, but R does not correctly explain A.", "A is true, R is false.", "A is false, R is true."],
    "answerIndex": 0, "explanation": "Both statements are true, and R correctly explains why: from the bank's viewpoint, money it holds for the firm is money it owes back — a liability — hence shown as a credit balance, the reverse of the firm's own Cash Book." },
  { "id": 212, "chapter": "brs", "difficulty": "Hard", "q": "Assertion (A): A cheque deposited but not yet collected always requires a Journal entry to correct the Cash Book. Reason (R): This is purely a timing difference that resolves itself once the bank collects the cheque, needing no correcting entry at all. Choose: (a) Both A and R are true, and R correctly explains A. (b) Both A and R are true, but R does not correctly explain A. (c) A is false, R is true. (d) A is true, R is false.",
    "options": ["Both A and R are true, and R correctly explains A.", "Both A and R are true, but R does not correctly explain A.", "A is false, R is true.", "A is true, R is false."],
    "answerIndex": 2, "explanation": "A is false — no Journal entry is needed for a timing difference like this; it is simply shown as a reconciling item in the BRS and resolves itself once the bank clears the cheque. R correctly states why." },
  { "id": 213, "chapter": "brs", "difficulty": "Medium", "q": "Which pair below correctly shows OPPOSITE treatment for the exact same underlying transaction?",
    "options": ["Bank charges: 'Less' from Cash Book, and 'Add' from Pass Book.", "Bank charges: 'Add' from Cash Book, and 'Add' from Pass Book.", "Bank charges: 'Less' from Cash Book, and 'Less' from Pass Book.", "Bank charges: only ever treated one way, regardless of starting balance."],
    "answerIndex": 0, "explanation": "Every reconciling item flips direction depending on which balance you start from — bank charges are deducted starting from the Cash Book, but added starting from the Pass Book, for the identical transaction." },
  { "id": 214, "chapter": "brs", "difficulty": "Medium", "q": "A firm's Cash Book shows a debit (favourable) balance of ₹9,000 at the bank. This means:",
    "options": ["The firm owes the bank ₹9,000.", "The firm has ₹9,000 available with the bank.", "The bank has overdrawn the firm's account.", "The firm's total capital is ₹9,000."],
    "answerIndex": 1, "explanation": "A debit (favourable) balance in the Cash Book's bank column means the firm has that much money available with the bank — an asset for the firm." },
  { "id": 215, "chapter": "brs", "difficulty": "Easy", "q": "Under a standing instruction, a bank collecting dividend income on the firm's investments and crediting the Pass Book is an example of:",
    "options": ["A cheque issued but not presented.", "A direct collection by the bank.", "An error in the Cash Book.", "A dishonoured cheque."],
    "answerIndex": 1, "explanation": "This is a direct collection made by the bank on the firm's behalf, credited straight to the Pass Book without the firm's immediate involvement." },
  { "id": 216, "chapter": "brs", "difficulty": "Easy", "q": "Under a standing instruction, a bank paying the firm's electricity bill directly and debiting the Pass Book is an example of:",
    "options": ["A direct payment by the bank.", "A cheque deposited but not collected.", "Interest allowed by the bank.", "An error in the Pass Book."],
    "answerIndex": 0, "explanation": "This is a payment the bank makes directly on the firm's behalf under a standing instruction — a direct payment by the bank." },
  { "id": 217, "chapter": "brs", "difficulty": "Medium", "q": "Balance as per Cash Book is ₹22,000 (overdrawn/credit balance). A cheque of ₹5,000 issued has not been presented for payment. Which treatment applies, starting from the Cash Book, and why?",
    "options": ["Added — because the Cash Book already shows the payment as made, but the bank hasn't reduced its own (overdraft) balance yet.", "Deducted — because overdrafts reverse every rule.", "Ignored — overdraft accounts don't need reconciliation.", "Treated as a direct bank collection."],
    "answerIndex": 0, "explanation": "The Add/Less logic for an unpresented cheque doesn't change with an overdraft — the Cash Book has already recorded the payment, the bank hasn't, so it is still added starting from the Cash Book." },
  { "id": 218, "chapter": "brs", "difficulty": "Hard", "q": "Assertion (A): Preparing a BRS regularly can help detect fraud or misuse of the firm's bank account. Reason (R): Comparing the Cash Book and Pass Book closely brings unexplained or unauthorised entries to light. Choose: (a) Both A and R are true, and R correctly explains A. (b) Both A and R are true, but R does not correctly explain A. (c) A is true, R is false. (d) A is false, R is true.",
    "options": ["Both A and R are true, and R correctly explains A.", "Both A and R are true, but R does not correctly explain A.", "A is true, R is false.", "A is false, R is true."],
    "answerIndex": 0, "explanation": "Both are true, and R explains exactly why: close comparison of the two records is precisely what surfaces unexplained entries that could indicate fraud." },
  { "id": 219, "chapter": "brs", "difficulty": "Medium", "q": "Balance as per Pass Book is ₹18,000. Bank charges of ₹300 (not yet in the Cash Book) and interest allowed of ₹500 (not yet in the Cash Book) both apply. What is the Balance as per Cash Book?",
    "options": ["₹18,200", "₹17,800", "₹18,800", "₹17,200"],
    "answerIndex": 1, "explanation": "Starting from the Pass Book, bank charges are added (reverse of Cash Book treatment: +300) and interest allowed is deducted (reverse: −500): ₹18,000 + 300 − 500 = ₹17,800." },
  { "id": 220, "chapter": "brs", "difficulty": "Hard", "q": "Balance as per Pass Book is ₹40,000. Items: cheque of ₹9,000 deposited but not collected; cheque of ₹6,000 issued but not presented; a dishonoured cheque of ₹1,000 not yet in the Cash Book — all missing from the Cash Book. What is the Balance as per Cash Book?",
    "options": ["₹44,000", "₹36,000", "₹42,000", "₹38,000"],
    "answerIndex": 0, "explanation": "Starting from the Pass Book (reverse of Cash Book treatment): uncollected cheque → Add ₹9,000; unpresented cheque → Less ₹6,000; dishonoured cheque → Add ₹1,000. ₹40,000 + 9,000 − 6,000 + 1,000 = ₹44,000." },
  { "id": 221, "chapter": "brs", "difficulty": "Easy", "q": "A firm's own error of entering ₹500 instead of ₹5,000 while recording a cheque deposit in its Cash Book is:",
    "options": ["An error in the Pass Book.", "An error in the Cash Book.", "Not a reconciling item at all.", "Automatically corrected by the bank."],
    "answerIndex": 1, "explanation": "Since the mistake was made while writing up the firm's own Cash Book, it is classified as an error in the Cash Book, corrected on the way to the (correct) Pass Book figure." },
  { "id": 222, "chapter": "brs", "difficulty": "Medium", "q": "Which of these items would NOT need any adjustment in next month's BRS, once this month's unpresented cheque of ₹5,000 finally gets presented and paid by the bank?",
    "options": ["The same ₹5,000 unpresented cheque, since it has now cleared and both books agree on it.", "A brand-new cheque issued this month but not yet presented.", "Bank charges debited this month but not yet recorded.", "A cheque deposited this month but not yet collected."],
    "answerIndex": 0, "explanation": "Once a previously-unpresented cheque is finally presented and paid, both the Cash Book and Pass Book now agree on it — it stops being a reconciling item from that point on." },
  { "id": 223, "chapter": "gst", "difficulty": "Easy", "q": "GST stands for:",
    "options": ["Goods and Services Tax", "General Sales Tax", "Government Service Tax", "Gross Supply Tax"], "answerIndex": 0, "explanation": "GST stands for Goods and Services Tax." },
  { "id": 224, "chapter": "gst", "difficulty": "Easy", "q": "GST is charged on:",
    "options": ["The supply of goods and services", "Only imported goods", "Only exported services", "Business profits"], "answerIndex": 0, "explanation": "GST is an indirect tax levied on the supply of goods and services, not on profits or only on imports/exports." },
  { "id": 225, "chapter": "gst", "difficulty": "Easy", "q": "GST is an example of:",
    "options": ["A direct tax", "An indirect tax", "A wealth tax", "A capital gains tax"], "answerIndex": 1, "explanation": "GST is an indirect tax — it is collected by the seller from the buyer and paid to the government, rather than being charged directly on income or wealth." },
  { "id": 226, "chapter": "gst", "difficulty": "Easy", "q": "GST is best described as a:",
    "options": ["Multi-stage, value-added, destination-based tax", "Single-stage tax charged only at the final sale", "Direct tax on the manufacturer's profit", "Tax charged only on services"], "answerIndex": 0, "explanation": "GST is levied at every stage of value addition (multi-stage), taxes only the value added at each stage (value-added), and is collected in the state where the goods/services are finally consumed (destination-based)." },
  { "id": 227, "chapter": "gst", "difficulty": "Easy", "q": "GST replaced several earlier indirect taxes such as:",
    "options": ["VAT, excise duty, and service tax", "Income tax and wealth tax", "Corporate tax and capital gains tax", "Customs duty on all imports"], "answerIndex": 0, "explanation": "GST subsumed a number of earlier indirect taxes like VAT, excise duty, and service tax into one comprehensive tax." },
  { "id": 228, "chapter": "gst", "difficulty": "Easy", "q": "Under the Dual GST model followed in India, an intra-state sale attracts:",
    "options": ["CGST and SGST", "Only IGST", "Only CGST", "Only SGST"], "answerIndex": 0, "explanation": "India follows a dual GST model: intra-state sales are split into CGST (Central) and SGST (State), while inter-state sales attract IGST." },
  { "id": 229, "chapter": "gst", "difficulty": "Easy", "q": "An inter-state sale (between two different states) attracts:",
    "options": ["IGST", "CGST and SGST", "Only SGST", "No GST at all"], "answerIndex": 0, "explanation": "Inter-state sales attract IGST (Integrated GST), collected by the Central Government and later apportioned between the states involved." },
  { "id": 230, "chapter": "gst", "difficulty": "Easy", "q": "GST is often called a 'destination-based' tax because:",
    "options": ["It is collected by the state where the goods/services are finally consumed", "It is collected by the state where the goods are manufactured", "It is charged only on goods sent abroad", "It depends on the buyer's income level"], "answerIndex": 0, "explanation": "Unlike the earlier origin-based tax system, GST revenue goes to the state where the goods or services are actually consumed, not where they are produced." },
  { "id": 231, "chapter": "gst", "difficulty": "Easy", "q": "Which of the following is a key advantage of GST?",
    "options": ["It removes the cascading effect of tax (tax on tax)", "It increases the number of taxes a business must pay", "It removes the requirement of any invoice", "It applies different rules in every state"], "answerIndex": 0, "explanation": "GST allows input tax credit, so tax already paid on purchases (Input GST) can be set off against tax collected on sales (Output GST) — eliminating tax being charged again on tax already paid." },
  { "id": 232, "chapter": "gst", "difficulty": "Easy", "q": "GST helps create a common national market mainly because:",
    "options": ["It applies a uniform tax structure across the country", "It is charged only in metro cities", "It removes GST entirely from essential goods", "It allows each state to set its own separate tax system"], "answerIndex": 0, "explanation": "A uniform GST rate structure across states removes tax-related barriers to the free movement of goods, helping create 'One Nation, One Tax'." },
  { "id": 233, "chapter": "gst", "difficulty": "Easy", "q": "Which of these is NOT typically cited as an advantage of GST?",
    "options": ["Increased cascading of taxes", "Simplification of the tax structure", "Wider tax base", "Greater transparency in taxation"], "answerIndex": 0, "explanation": "GST is meant to REDUCE cascading of tax through input tax credit, not increase it — so 'increased cascading' is the opposite of an actual advantage." },
  { "id": 234, "chapter": "gst", "difficulty": "Easy", "q": "Goods worth ₹4,000 are sold, GST rate 10%. The GST amount is:",
    "options": ["₹400", "₹40", "₹4,400", "₹360"], "answerIndex": 0, "explanation": "GST Amount = ₹4,000 × 10/100 = ₹400." },
  { "id": 235, "chapter": "gst", "difficulty": "Easy", "q": "Goods worth ₹9,000 are sold, GST rate 12%. The invoice value is:",
    "options": ["₹10,080", "₹9,000", "₹1,080", "₹9,900"], "answerIndex": 0, "explanation": "GST = ₹9,000 × 12% = ₹1,080. Invoice Value = ₹9,000 + ₹1,080 = ₹10,080." },
  { "id": 236, "chapter": "gst", "difficulty": "Easy", "q": "If the taxable value is ₹5,000 and GST charged is ₹900, the GST rate is:",
    "options": ["18%", "12%", "9%", "20%"], "answerIndex": 0, "explanation": "Rate = (900/5000) × 100 = 18%." },
  { "id": 237, "chapter": "gst", "difficulty": "Easy", "q": "List price ₹10,000, trade discount 10%. On what amount should GST be calculated?",
    "options": ["₹9,000 (List Price − Trade Discount)", "₹10,000 (the full list price)", "₹1,000 (the trade discount amount)", "₹11,000 (List Price + Trade Discount)"], "answerIndex": 0, "explanation": "Trade discount is always deducted from the list price BEFORE calculating GST: Taxable Value = List Price − Trade Discount = ₹10,000 − ₹1,000 = ₹9,000." },
  { "id": 238, "chapter": "gst", "difficulty": "Easy", "q": "Goods with list price ₹8,000 are sold at a 25% trade discount, GST rate 18%. The taxable value is:",
    "options": ["₹6,000", "₹8,000", "₹2,000", "₹7,000"], "answerIndex": 0, "explanation": "Trade Discount = ₹8,000 × 25% = ₹2,000. Taxable Value = ₹8,000 − ₹2,000 = ₹6,000." },
  { "id": 239, "chapter": "gst", "difficulty": "Easy", "q": "Goods worth ₹20,000, trade discount 10%, GST 18%. The total invoice value is:",
    "options": ["₹21,240", "₹23,600", "₹18,000", "₹20,000"], "answerIndex": 0, "explanation": "Trade Discount = ₹2,000. Taxable Value = ₹18,000. GST = ₹18,000 × 18% = ₹3,240. Invoice Value = ₹18,000 + ₹3,240 = ₹21,240." },
  { "id": 240, "chapter": "gst", "difficulty": "Easy", "q": "When freight is charged separately and is not subject to GST, it should be:",
    "options": ["Added to the invoice value only after GST has been calculated", "Included in the taxable value before calculating GST", "Deducted from the taxable value", "Ignored completely in the invoice"], "answerIndex": 0, "explanation": "If a question specifies that freight is not chargeable to GST, it is simply added on top of (Taxable Value + GST) to reach the final invoice value, not included in the GST calculation itself." },
  { "id": 241, "chapter": "gst", "difficulty": "Easy", "q": "When a question states that GST is also chargeable on freight, the freight amount should be:",
    "options": ["Added to the taxable value before calculating GST", "Ignored while calculating GST", "Deducted from the list price", "Treated as a separate expense not part of the invoice"], "answerIndex": 0, "explanation": "When freight is explicitly stated to attract GST, it must be added to the taxable value first, and GST calculated on goods + freight together." },
  { "id": 242, "chapter": "gst", "difficulty": "Easy", "q": "GST paid on a purchase of goods is recorded in which account (simple Class 11 treatment)?",
    "options": ["Input GST A/c", "Output GST A/c", "Purchases Return A/c", "Sales A/c"], "answerIndex": 0, "explanation": "GST paid on purchases is debited to 'Input GST A/c', since it can later be claimed as credit against Output GST." },
  { "id": 243, "chapter": "gst", "difficulty": "Easy", "q": "GST collected on a sale of goods is recorded in which account (simple Class 11 treatment)?",
    "options": ["Output GST A/c", "Input GST A/c", "Purchases A/c", "Discount Received A/c"], "answerIndex": 0, "explanation": "GST collected on sales is credited to 'Output GST A/c', representing tax collected from the customer that is payable to the government." },
  { "id": 244, "chapter": "gst", "difficulty": "Easy", "q": "For a cash purchase of goods worth ₹5,000 plus GST of ₹900, the journal entry debits:",
    "options": ["Purchases A/c ₹5,000 and Input GST A/c ₹900", "Purchases A/c ₹5,900 only", "Cash A/c ₹5,900", "Input GST A/c ₹5,900 only"], "answerIndex": 0, "explanation": "The Purchases A/c is debited with the taxable value (₹5,000) and Input GST A/c is debited separately with the GST amount (₹900); Cash A/c is credited with the total ₹5,900." },
  { "id": 245, "chapter": "gst", "difficulty": "Easy", "q": "For a credit sale of goods worth ₹6,000 plus GST of ₹1,080 to Ramesh, the account debited is:",
    "options": ["Ramesh's A/c, with the total invoice value of ₹7,080", "Sales A/c, with ₹6,000", "Output GST A/c, with ₹1,080", "Cash A/c, with ₹7,080"], "answerIndex": 0, "explanation": "In a credit sale, the customer's (Debtor's) account is debited with the FULL invoice value, since that is the amount owed by the customer: ₹6,000 + ₹1,080 = ₹7,080." },
  { "id": 246, "chapter": "gst", "difficulty": "Easy", "q": "Which tax does IGST replace the combination of, for an inter-state transaction?",
    "options": ["CGST and SGST together", "Only excise duty", "Only customs duty", "Only VAT"], "answerIndex": 0, "explanation": "For an inter-state transaction, instead of splitting the tax into CGST and SGST, the full amount is charged as a single IGST." },
  { "id": 247, "chapter": "gst", "difficulty": "Easy", "q": "'Input Tax Credit' under GST allows a business to:",
    "options": ["Set off GST already paid on purchases against GST collected on sales", "Get an automatic discount on all its purchases", "Avoid paying any GST at all", "Claim a refund of income tax paid"], "answerIndex": 0, "explanation": "Input Tax Credit lets a business reduce its GST liability by the amount of GST it has already paid on its own purchases (Input GST), so tax is effectively paid only on the value it adds." },
  { "id": 248, "chapter": "gst", "difficulty": "Easy", "q": "Which of the following is a simple, correct formula for calculating GST?",
    "options": ["GST Amount = Taxable Value × GST Rate / 100", "GST Amount = Taxable Value + GST Rate", "GST Amount = Invoice Value − GST Rate", "GST Amount = List Price × 100 / GST Rate"], "answerIndex": 0, "explanation": "GST Amount is calculated as a percentage of the taxable value: GST Amount = Taxable Value × Rate / 100." },
  { "id": 249, "chapter": "gst", "difficulty": "Easy", "q": "The correct formula for Invoice Value is:",
    "options": ["Invoice Value = Taxable Value + GST Amount", "Invoice Value = Taxable Value − GST Amount", "Invoice Value = List Price × GST Rate", "Invoice Value = GST Amount only"], "answerIndex": 0, "explanation": "The Invoice Value is simply the taxable value plus the GST charged on it." },
  { "id": 250, "chapter": "gst", "difficulty": "Easy", "q": "A trade discount of 10% on goods worth ₹15,000 amounts to:",
    "options": ["₹1,500", "₹150", "₹13,500", "₹1,650"], "answerIndex": 0, "explanation": "Trade Discount = ₹15,000 × 10% = ₹1,500." },
  { "id": 251, "chapter": "gst", "difficulty": "Easy", "q": "Which combination correctly represents an intra-state GST split at an 18% total rate?",
    "options": ["CGST 9% + SGST 9%", "CGST 18% + SGST 18%", "IGST 9% + SGST 9%", "CGST 12% + SGST 6%"], "answerIndex": 0, "explanation": "For intra-state transactions, the total GST rate is split EQUALLY between CGST and SGST — at 18% total, that's 9% CGST + 9% SGST." },
  { "id": 252, "chapter": "gst", "difficulty": "Easy", "q": "A cash sale of goods worth ₹10,000 at 12% GST (intra-state) results in Output CGST and Output SGST of:",
    "options": ["₹600 each", "₹1,200 each", "₹300 each", "₹1,200 for CGST and ₹0 for SGST"], "answerIndex": 0, "explanation": "Total GST = ₹10,000 × 12% = ₹1,200. Split equally for an intra-state sale: Output CGST = Output SGST = ₹600 each." },
  { "id": 253, "chapter": "gst", "difficulty": "Easy", "q": "Goods worth ₹7,500, GST 8%, no trade discount. The GST amount is closest to:",
    "options": ["₹600", "₹750", "₹500", "₹800"], "answerIndex": 0, "explanation": "GST = ₹7,500 × 8% = ₹600." },
  { "id": 254, "chapter": "gst", "difficulty": "Easy", "q": "A business has Input GST of ₹5,000 and Output GST of ₹8,000 for the month. The net GST payable to the government is:",
    "options": ["₹3,000", "₹13,000", "₹5,000", "₹8,000"], "answerIndex": 0, "explanation": "Net GST Payable = Output GST − Input GST = ₹8,000 − ₹5,000 = ₹3,000, since Input GST already paid can be claimed as credit." },
  { "id": 255, "chapter": "gst", "difficulty": "Easy", "q": "Before GST was introduced in India, indirect taxes suffered mainly from the problem of:",
    "options": ["Cascading effect (tax being charged on tax)", "Being charged only once at the final sale", "Being too simple and uniform", "Not applying to goods at all"], "answerIndex": 0, "explanation": "Under the earlier system, tax was often charged again on an amount that already included tax paid earlier, leading to a 'tax on tax' cascading effect — one of the main problems GST was designed to solve." },
  { "id": 256, "chapter": "gst", "difficulty": "Easy", "q": "A shopkeeper buys goods worth ₹4,000 (GST 12%) and later sells them for ₹6,000 (GST 12%) within the same month. His Input GST and Output GST respectively are:",
    "options": ["₹480 and ₹720", "₹720 and ₹480", "₹480 and ₹480", "₹720 and ₹720"], "answerIndex": 0, "explanation": "Input GST (on the ₹4,000 purchase) = ₹4,000 × 12% = ₹480. Output GST (on the ₹6,000 sale) = ₹6,000 × 12% = ₹720." },
  { "id": 282, "chapter": "tb", "difficulty": "Easy", "q": "A Trial Balance is a statement that lists:",
    "options": ["The balances of all ledger accounts as on a particular date", "Every individual transaction recorded during the year", "Only the debit balances of the ledger", "The profit or loss of the business"], "answerIndex": 0, "explanation": "A Trial Balance lists the closing balance of every ledger account as on a specific date, not individual transactions or only one type of balance." },
  { "id": 283, "chapter": "tb", "difficulty": "Easy", "q": "The main purpose of preparing a Trial Balance is to:",
    "options": ["Check the arithmetical accuracy of the ledger postings", "Calculate the exact profit of the business", "Replace the need for a Balance Sheet", "Record cash transactions"], "answerIndex": 0, "explanation": "A Trial Balance's core purpose is verifying that total debits equal total credits — an arithmetical accuracy check on the ledger." },
  { "id": 284, "chapter": "tb", "difficulty": "Easy", "q": "A Trial Balance is:",
    "options": ["A statement, not an account", "A type of ledger account", "A subsidiary book", "A legal document filed with the government"], "answerIndex": 0, "explanation": "A Trial Balance is simply a list/statement of balances — it is not itself an account and has no debit or credit side of its own in the accounting sense." },
  { "id": 285, "chapter": "tb", "difficulty": "Easy", "q": "Which method of preparing a Trial Balance is used at the Class 11 level, where each ledger account is first balanced and then that balance is listed?",
    "options": ["The Balance Method", "The Total Method", "The Trial Method", "The Ledger Method"], "answerIndex": 0, "explanation": "The Balance Method — balancing every ledger account first, then listing each closing balance — is the method covered at Class 11 level." },
  { "id": 286, "chapter": "tb", "difficulty": "Easy", "q": "In the Trial Balance format, how many main amount columns are there?",
    "options": ["Two — Debit and Credit", "One — a single Balance column", "Three — Debit, Credit, and Balance", "Four — Opening, Debit, Credit, Closing"], "answerIndex": 0, "explanation": "A Trial Balance under the Balance Method has two amount columns: Debit Balance and Credit Balance, alongside the Particulars (account name) column." },
  { "id": 287, "chapter": "tb", "difficulty": "Easy", "q": "Which of these normally has a DEBIT balance?",
    "options": ["Purchases A/c", "Sales A/c", "Capital A/c", "Creditors A/c"], "answerIndex": 0, "explanation": "Purchases is an expense-type account for goods bought and normally carries a debit balance; Sales, Capital, and Creditors normally carry credit balances." },
  { "id": 288, "chapter": "tb", "difficulty": "Easy", "q": "Which of these normally has a CREDIT balance?",
    "options": ["Capital A/c", "Cash A/c", "Machinery A/c", "Drawings A/c"], "answerIndex": 0, "explanation": "Capital represents what the business owes back to the owner and carries a credit balance; Cash, Machinery, and Drawings are all debit balances." },
  { "id": 289, "chapter": "tb", "difficulty": "Easy", "q": "Sundry Debtors are shown in the Trial Balance as a:",
    "options": ["Debit balance, since they are an asset", "Credit balance, since they are a liability", "They are never shown in a Trial Balance", "Either column, depending on the amount"], "answerIndex": 0, "explanation": "Debtors represent money owed TO the business — an asset — so they carry a debit balance." },
  { "id": 290, "chapter": "tb", "difficulty": "Easy", "q": "Sundry Creditors are shown in the Trial Balance as a:",
    "options": ["Credit balance, since they are a liability", "Debit balance, since they are an asset", "They are never shown in a Trial Balance", "Either column, depending on the amount"], "answerIndex": 0, "explanation": "Creditors represent money owed BY the business — a liability — so they carry a credit balance." },
  { "id": 291, "chapter": "tb", "difficulty": "Easy", "q": "Which of these is normally a credit balance?",
    "options": ["Outstanding Salary", "Prepaid Rent", "Stock in Trade", "Furniture"], "answerIndex": 0, "explanation": "Outstanding Salary is a liability (salary due but not yet paid) and carries a credit balance; Prepaid Rent, Stock, and Furniture are all assets with debit balances." },
  { "id": 292, "chapter": "tb", "difficulty": "Easy", "q": "If Total Debit and Total Credit in a Trial Balance are equal, this is called:",
    "options": ["The Trial Balance agrees (tallies)", "A balanced Balance Sheet", "A profit", "A closed account"], "answerIndex": 0, "explanation": "When both columns of a Trial Balance total to the same figure, it is said to agree or tally." },
  { "id": 293, "chapter": "tb", "difficulty": "Easy", "q": "An agreeing Trial Balance:",
    "options": ["Is not conclusive proof that the books are completely free of errors", "Is absolute proof that there are no errors in the books", "Guarantees the correct amount of profit has been calculated", "Means every ledger account has been correctly balanced with no exceptions possible"], "answerIndex": 0, "explanation": "Certain types of errors don't disturb the equality of the two columns, so an agreeing Trial Balance is not conclusive proof of complete accuracy." },
  { "id": 294, "chapter": "tb", "difficulty": "Easy", "q": "Which type of error does NOT affect the agreement of a Trial Balance?",
    "options": ["Error of complete omission (a transaction never recorded at all)", "A ledger balance posted to the wrong side", "A wrong total (casting error) in one column", "An account balance carried forward incorrectly"], "answerIndex": 0, "explanation": "If a transaction is never recorded anywhere, neither the debit nor the credit side is affected, so the Trial Balance can still agree; the other options are all one-sided errors that WOULD cause a mismatch." },
  { "id": 295, "chapter": "tb", "difficulty": "Easy", "q": "Furniture purchased for ₹8,000 is wrongly debited to the Purchases A/c instead of the Furniture A/c. This is an example of:",
    "options": ["An error of principle", "An error of omission", "A casting error", "A compensating error"], "answerIndex": 0, "explanation": "This is an error of principle — a capital expenditure (buying furniture, an asset) was wrongly treated as a revenue expense (purchases). Since the amount is still correctly debited, the Trial Balance still agrees." },
  { "id": 296, "chapter": "tb", "difficulty": "Easy", "q": "Two errors of ₹300 each occur in a way that cancels out their effect on the Trial Balance's totals. This combination is called:",
    "options": ["Compensating errors", "Errors of principle", "Errors of omission", "One-sided errors"], "answerIndex": 0, "explanation": "When two or more errors happen to offset each other's effect on the Trial Balance totals, they are called compensating errors — the Trial Balance can still agree despite both underlying errors." },
  { "id": 297, "chapter": "tb", "difficulty": "Easy", "q": "A Trial Balance shows Total Debit ₹95,000 and Total Credit ₹94,200. The difference of ₹800 indicates:",
    "options": ["There is likely at least one error somewhere in the books", "The business has made a loss of ₹800", "Nothing — small differences are always ignored", "The Trial Balance definitely agrees"], "answerIndex": 0, "explanation": "Any mismatch between the two column totals signals that an error exists somewhere in recording, posting, balancing, or totalling — here, a difference of ₹800." },
  { "id": 298, "chapter": "tb", "difficulty": "Easy", "q": "Which of these is a common mistake made while preparing a Trial Balance?",
    "options": ["Omitting an account balance altogether", "Correctly balancing every ledger account", "Listing every account exactly once", "Totalling both columns correctly"], "answerIndex": 0, "explanation": "Omitting an account balance is one of the most common Trial Balance mistakes, along with posting to the wrong side, casting errors, and wrong carry-forwards." },
  { "id": 299, "chapter": "tb", "difficulty": "Easy", "q": "A Trial Balance is normally prepared:",
    "options": ["On a particular date, usually at the end of an accounting period", "Only once, when a business first starts", "After the Balance Sheet is finalised", "Before any ledger accounts have been balanced"], "answerIndex": 0, "explanation": "A Trial Balance is a snapshot as on a specific date (commonly the end of a period) — and it can only be prepared AFTER the ledger accounts have been balanced." },
  { "id": 300, "chapter": "tb", "difficulty": "Easy", "q": "The Trial Balance is the basis for preparing:",
    "options": ["The Trading and Profit & Loss Account and the Balance Sheet", "Only the Cash Book", "Only the Journal", "The Bank Reconciliation Statement"], "answerIndex": 0, "explanation": "Once a Trial Balance is prepared and agrees, its balances are used to prepare the final accounts — the Trading and Profit & Loss Account, and the Balance Sheet." },
  { "id": 301, "chapter": "tb", "difficulty": "Easy", "q": "Which of these accounts would you expect to find in the Debit column of a Trial Balance?",
    "options": ["Wages and Salaries", "Sales", "Capital", "Creditors"], "answerIndex": 0, "explanation": "Wages and Salaries are expenses and carry debit balances; Sales, Capital, and Creditors are all credit balances." },
  { "id": 302, "chapter": "tb", "difficulty": "Easy", "q": "Which of these accounts would you expect to find in the Credit column of a Trial Balance?",
    "options": ["Discount Received", "Discount Allowed", "Cash in Hand", "Stock in Trade"], "answerIndex": 0, "explanation": "Discount Received is a gain/income and carries a credit balance; the other three are debit balances (Discount Allowed is an expense, Cash and Stock are assets)." },
  { "id": 303, "chapter": "tb", "difficulty": "Easy", "q": "Provision for Doubtful Debts appears in the Trial Balance as a:",
    "options": ["Credit balance", "Debit balance", "It is never shown in the Trial Balance", "Sometimes debit, sometimes credit, with no fixed rule"], "answerIndex": 0, "explanation": "A provision account, though related to an asset (debtors), is itself carried forward as a credit balance, similar to Provision for Depreciation." },
  { "id": 304, "chapter": "tb", "difficulty": "Easy", "q": "A Trial Balance total column being 'off' by exactly the amount of one account's balance most likely suggests:",
    "options": ["That account's balance was completely omitted from the Trial Balance", "The business made a profit equal to that amount", "A compensating error occurred", "Nothing is wrong — this is normal"], "answerIndex": 0, "explanation": "If the mismatch exactly equals one account's balance, the most likely explanation is that this specific account was left out of the Trial Balance altogether." },
  { "id": 305, "chapter": "tb", "difficulty": "Easy", "q": "Which of these is NOT one of the standard objectives of preparing a Trial Balance?",
    "options": ["To directly calculate the exact net profit for the year", "To check the arithmetical accuracy of the ledger", "To serve as the basis for preparing the final accounts", "To help in locating errors in the books"], "answerIndex": 0, "explanation": "Calculating net profit is done through the Trading and Profit & Loss Account, not directly by the Trial Balance itself — the Trial Balance only provides the balances used to prepare those later statements." },
  { "id": 306, "chapter": "tb", "difficulty": "Easy", "q": "A Debtor's balance of ₹3,600 was correctly calculated but listed in the Trial Balance as ₹6,300 (a transposition error), in the Debit column. By how much is the Debit column now overstated?",
    "options": ["₹2,700", "₹3,600", "₹6,300", "₹9,900"], "answerIndex": 0, "explanation": "₹6,300 − ₹3,600 = ₹2,700 extra was entered by mistake, so the Debit column is overstated by ₹2,700." },
  { "id": 307, "chapter": "tb", "difficulty": "Easy", "q": "If the Purchases A/c (a debit balance) is completely left out while preparing the Trial Balance, the effect is:",
    "options": ["The Debit column falls short by that amount, and the Trial Balance will not agree", "The Credit column falls short by that amount, and the Trial Balance will not agree", "Both columns are equally affected, so the Trial Balance still agrees", "There is no effect on the Trial Balance"], "answerIndex": 0, "explanation": "Since Purchases is a debit balance and it was left out entirely, only the Debit column falls short — the Trial Balance will not agree." },
  { "id": 308, "chapter": "tb", "difficulty": "Medium", "q": "A Trial Balance lists: Capital ₹45,000 (Cr), Furniture ₹12,000 (Dr), Cash ₹8,000 (Dr), Creditors ₹3,000 (Cr), Debtors ₹28,000 (Dr). Does this Trial Balance agree, and what is the total?",
    "options": ["Yes, both columns total ₹48,000", "No, the Debit total is ₹48,000 but Credit total is ₹45,000", "Yes, both columns total ₹45,000", "No, the Debit total is ₹40,000 but Credit total is ₹48,000"], "answerIndex": 0, "explanation": "Total Debit = 12,000 + 8,000 + 28,000 = ₹48,000. Total Credit = 45,000 + 3,000 = ₹48,000. Both match, so the Trial Balance agrees at ₹48,000." },
  { "id": 309, "chapter": "tb", "difficulty": "Medium", "q": "An error where a transaction is recorded with the correct amount but posted to the wrong person's account of the same class (e.g., debited to the wrong debtor) is called:",
    "options": ["An error of commission", "An error of principle", "An error of omission", "A compensating error"], "answerIndex": 0, "explanation": "Posting to the wrong account of the same class/type, despite the correct amount, is classified as an error of commission. Since both sides still have the correct amount, the Trial Balance can still agree." },
  { "id": 310, "chapter": "tb", "difficulty": "Medium", "q": "Which of the following would cause the Trial Balance to definitely NOT agree?",
    "options": ["The Sales A/c was posted with the wrong total due to a casting error", "A transaction was completely omitted from the books", "Furniture purchase was wrongly debited to Purchases A/c", "Two errors of equal value happened to cancel out"], "answerIndex": 0, "explanation": "A casting (totalling) error in just one account directly changes only one side of the Trial Balance, so the two totals will no longer match — unlike the other options, which don't disturb the agreement." },
  { "id": 311, "chapter": "tb", "difficulty": "Medium", "q": "Interest on Drawings appears in the Trial Balance as a:",
    "options": ["Credit balance, since it is income for the business", "Debit balance, since it is an expense for the business", "It does not appear in the Trial Balance", "Either column, depending on the rate of interest"], "answerIndex": 0, "explanation": "Interest on Drawings is charged BY the business TO the owner — it is income for the business, and therefore a credit balance (the reverse of Interest on Capital, which is an expense)." },
  { "id": 257, "chapter": "dep", "difficulty": "Easy", "q": "Depreciation is best described as:",
    "options": ["A gradual, continuous, and permanent fall in the value of a fixed asset", "A one-time write-off of an asset's entire value", "An increase in the market value of an asset", "The cash spent on repairing an asset"], "answerIndex": 0, "explanation": "Depreciation is the gradual, continuous, and permanent decrease in the value of a fixed (tangible) asset due to use, time, or obsolescence." },
  { "id": 258, "chapter": "dep", "difficulty": "Easy", "q": "Which of these is a feature of depreciation?",
    "options": ["It is charged as an expense against profit", "It increases the business's cash balance", "It is charged only once, when the asset is bought", "It applies only to current assets"], "answerIndex": 0, "explanation": "Depreciation is a non-cash expense charged against profit every year the fixed asset is used, reducing net profit even though no cash leaves the business." },
  { "id": 259, "chapter": "dep", "difficulty": "Easy", "q": "The main reason depreciation must be charged is to:",
    "options": ["Match the cost of using an asset against the revenue it helps earn", "Increase the reported profit of the business", "Avoid paying income tax altogether", "Reduce the number of assets on the Balance Sheet"], "answerIndex": 0, "explanation": "Depreciation follows the Matching Concept, ensuring the cost of using a fixed asset is recognized in the same period as the revenue it helps generate." },
  { "id": 260, "chapter": "dep", "difficulty": "Easy", "q": "Which of the following causes depreciation?",
    "options": ["Effluxion of time", "A rise in sales revenue", "A decrease in GST rates", "An increase in the number of customers"], "answerIndex": 0, "explanation": "Effluxion of time — the simple passage of time — is one of the recognized causes of depreciation, alongside wear and tear and obsolescence." },
  { "id": 261, "chapter": "dep", "difficulty": "Easy", "q": "Which of the following is a depreciable asset?",
    "options": ["Machinery used in production", "Debtors", "Cash in hand", "Prepaid insurance"], "answerIndex": 0, "explanation": "Machinery is a fixed (tangible) asset with a limited useful life used in the business, making it a depreciable asset. Debtors, cash, and prepaid expenses are current assets, not depreciated." },
  { "id": 262, "chapter": "dep", "difficulty": "Easy", "q": "The reduction in value of an oil well as oil is extracted from it is called:",
    "options": ["Depletion", "Depreciation", "Amortisation", "Appreciation"], "answerIndex": 0, "explanation": "Depletion is the term specifically used for the reduction in value of natural resources / wasting assets, like oil wells and mines, as they are extracted." },
  { "id": 263, "chapter": "dep", "difficulty": "Easy", "q": "Writing off the cost of a trademark over its legal life is an example of:",
    "options": ["Amortisation", "Depreciation", "Depletion", "Devaluation"], "answerIndex": 0, "explanation": "Amortisation is the term used for writing off the cost of intangible assets — such as trademarks, patents, and copyrights — over their useful or legal life." },
  { "id": 264, "chapter": "dep", "difficulty": "Medium", "q": "A machine costs ₹75,000, with an estimated residual value of ₹5,000 at the end of 7 years. What is the annual depreciation under SLM?",
    "options": ["₹10,000", "₹75,000", "₹5,000", "₹11,428"], "answerIndex": 0, "explanation": "Annual Depreciation (SLM) = (Cost − Residual Value) / Useful Life = (₹75,000 − ₹5,000) / 7 = ₹70,000 / 7 = ₹10,000." },
  { "id": 265, "chapter": "dep", "difficulty": "Medium", "q": "A machine costing ₹60,000 is depreciated @25% p.a. under WDV. What is the depreciation charged in Year 1?",
    "options": ["₹15,000", "₹12,000", "₹60,000", "₹45,000"], "answerIndex": 0, "explanation": "Year 1 Depreciation (WDV) = Opening Book Value × Rate = ₹60,000 × 25% = ₹15,000." },
  { "id": 266, "chapter": "dep", "difficulty": "Medium", "q": "A machine costing ₹60,000 is depreciated @25% p.a. under WDV. What is the book value at the end of Year 2?",
    "options": ["₹33,750", "₹45,000", "₹30,000", "₹36,000"], "answerIndex": 0, "explanation": "Year 1: Depreciation = ₹60,000 × 25% = ₹15,000; Book Value = ₹45,000. Year 2: Depreciation = ₹45,000 × 25% = ₹11,250; Book Value = ₹45,000 − ₹11,250 = ₹33,750." },
  { "id": 267, "chapter": "dep", "difficulty": "Medium", "q": "A machine costing ₹24,000 (no residual value) is purchased on 1st January. The accounting year ends 31st March. Depreciation is charged @20% p.a. under SLM. What is the depreciation for this year?",
    "options": ["₹1,200", "₹4,800", "₹2,400", "₹1,000"], "answerIndex": 0, "explanation": "Full-year depreciation = ₹24,000 × 20% = ₹4,800. The machine was used for only 3 months (1st January to 31st March), so Depreciation = ₹4,800 × 3/12 = ₹1,200." },
  { "id": 268, "chapter": "dep", "difficulty": "Easy", "q": "Which method calculates depreciation on the original cost every year, giving an equal yearly charge?",
    "options": ["Straight Line Method", "Written Down Value Method", "Both methods", "Neither method"], "answerIndex": 0, "explanation": "The Straight Line Method always applies its rate (or division) to the unchanging original cost, so the amount charged is equal every year." },
  { "id": 269, "chapter": "dep", "difficulty": "Easy", "q": "Which method calculates depreciation on the asset's reducing book value every year?",
    "options": ["Written Down Value Method", "Straight Line Method", "Both methods", "Neither method"], "answerIndex": 0, "explanation": "The Written Down Value Method applies a fixed rate to the book value at the start of each year, so the depreciation amount keeps falling as the book value shrinks." },
  { "id": 270, "chapter": "dep", "difficulty": "Medium", "q": "Which of the following is an advantage of the Written Down Value Method?",
    "options": ["It balances falling depreciation against rising repair costs as an asset ages", "It is the only method that can reduce book value to exactly zero", "It always gives a lower total depreciation than SLM over the asset's life", "It ignores the effect of the depreciation rate entirely"], "answerIndex": 0, "explanation": "Under WDV, the depreciation charge falls each year, which offsets the rising repair and maintenance costs typically seen as an asset gets older." },
  { "id": 271, "chapter": "dep", "difficulty": "Medium", "q": "Under the Provision for Depreciation method, the Asset Account:",
    "options": ["Continues to show the asset at its original cost", "Shows the reduced book value every year", "Is closed at the end of the first year", "Is never opened at all"], "answerIndex": 0, "explanation": "When a Provision for Depreciation A/c is maintained, the Asset A/c is left untouched at cost; depreciation accumulates separately in the Provision A/c instead." },
  { "id": 272, "chapter": "dep", "difficulty": "Medium", "q": "Under the Provision for Depreciation method, the correct year-end journal entry is:",
    "options": ["Depreciation A/c Dr.; To Provision for Depreciation A/c", "Provision for Depreciation A/c Dr.; To Depreciation A/c", "Depreciation A/c Dr.; To Asset A/c", "Asset A/c Dr.; To Depreciation A/c"], "answerIndex": 0, "explanation": "Depreciation A/c is debited and Provision for Depreciation A/c is credited, keeping the Asset A/c itself unchanged at original cost." },
  { "id": 273, "chapter": "dep", "difficulty": "Medium", "q": "Machinery costing ₹90,000 has no residual value and is depreciated ₹9,000 per year under SLM. The rate of depreciation being used is:",
    "options": ["10%", "9%", "11%", "12%"], "answerIndex": 0, "explanation": "Rate of Depreciation (SLM) = (Annual Depreciation / Cost) × 100 = (₹9,000 / ₹90,000) × 100 = 10%." },
  { "id": 274, "chapter": "dep", "difficulty": "Medium", "q": "Book Value of an asset is calculated as:",
    "options": ["Original Cost − Accumulated Depreciation", "Original Cost + Accumulated Depreciation", "Sale Proceeds − Original Cost", "Residual Value − Original Cost"], "answerIndex": 0, "explanation": "Book Value (Written Down Value) = Original Cost − Accumulated Depreciation to date." },
  { "id": 275, "chapter": "dep", "difficulty": "Medium", "q": "An asset with a Book Value of ₹50,000 is sold for ₹55,000. This results in:",
    "options": ["A profit of ₹5,000", "A loss of ₹5,000", "No profit, no loss", "A profit of ₹55,000"], "answerIndex": 0, "explanation": "Profit on Sale = Sale Proceeds − Book Value = ₹55,000 − ₹50,000 = ₹5,000." },
  { "id": 276, "chapter": "dep", "difficulty": "Medium", "q": "An asset with a Book Value of ₹50,000 is sold for ₹42,000. This results in:",
    "options": ["A loss of ₹8,000", "A profit of ₹8,000", "No profit, no loss", "A loss of ₹50,000"], "answerIndex": 0, "explanation": "Loss on Sale = Book Value − Sale Proceeds = ₹50,000 − ₹42,000 = ₹8,000." },
  { "id": 277, "chapter": "dep", "difficulty": "Hard", "q": "Machinery costing ₹2,00,000 is depreciated @20% p.a. under WDV using a Provision for Depreciation A/c. It is sold after exactly 2 years for ₹1,30,000. What is the result?",
    "options": ["Profit of ₹2,000", "Loss of ₹2,000", "Loss of ₹32,000", "No profit, no loss"], "answerIndex": 0, "explanation": "Year 1: Depreciation = ₹2,00,000 × 20% = ₹40,000; Book Value = ₹1,60,000. Year 2: Depreciation = ₹1,60,000 × 20% = ₹32,000; Book Value = ₹1,28,000. Since Sale Proceeds (₹1,30,000) exceed the Book Value (₹1,28,000), this is a Profit of ₹1,30,000 − ₹1,28,000 = ₹2,000." },
  { "id": 278, "chapter": "dep", "difficulty": "Easy", "q": "Which account is opened to work out the profit or loss on selling an asset when a Provision for Depreciation A/c is used?",
    "options": ["Asset Disposal Account", "Profit & Loss Appropriation Account", "Suspense Account", "Trading Account"], "answerIndex": 0, "explanation": "An Asset Disposal Account is opened specifically to compute the profit or loss on sale, without disturbing the main Asset A/c or Provision for Depreciation A/c." },
  { "id": 279, "chapter": "dep", "difficulty": "Easy", "q": "Under the direct method (no Provision for Depreciation A/c), what does the Asset Account show at any point in time?",
    "options": ["The asset's current book value", "The asset's original cost, always", "Zero, once depreciation begins", "The asset's residual value only"], "answerIndex": 0, "explanation": "Under the direct method, depreciation is credited straight to the Asset A/c each year, so its balance always reflects the current, reduced book value." },
  { "id": 280, "chapter": "dep", "difficulty": "Medium", "q": "Which of these is generally NOT depreciated, even though it is a fixed asset?",
    "options": ["Land (unless it is a wasting asset like a mine)", "Furniture", "Plant and machinery", "Motor vehicles"], "answerIndex": 0, "explanation": "Land typically has an unlimited useful life and is not depreciated, unless it is a wasting asset such as a mine or quarry, which is subject to depletion instead." },
  { "id": 281, "chapter": "dep", "difficulty": "Easy", "q": "Depreciation, depletion, and amortisation all share the same underlying idea of:",
    "options": ["Spreading the cost of an asset over its useful life", "Increasing an asset's value over time", "Recording a one-time cash payment", "Calculating GST on an asset's purchase"], "answerIndex": 0, "explanation": "All three terms describe the same underlying idea — systematically writing off an asset's cost over its useful life — just applied to different types of assets (fixed, natural resource, and intangible, respectively)." }
],

/* ============================================================
   IMPORTANT QUESTIONS — board-pattern practice, organized by
   chapter and by question type: Short Answer, Long Answer,
   Case-Based, and Assertion-Reason. All original.
   ============================================================ */
importantQuestions: {
  eq: [
    { type: "Short Answer", marks: 3, q: "State the accounting equation and explain, with one example, why it can never be out of balance.",
      answer: "The accounting equation is Assets = Capital + Liabilities. It can never be out of balance because of the dual aspect concept — every transaction is recorded with two equal and offsetting effects. For example, if a business takes a loan of ₹50,000, cash (an asset) increases by ₹50,000 and the loan (a liability) also increases by ₹50,000 — both sides move together by the same amount, so the equation stays balanced." },
    { type: "Short Answer", marks: 3, q: "Differentiate between a liability and capital, giving one example of each.",
      answer: "Liability is an amount the business owes to outsiders — for example, a bank loan or amount owed to a creditor. Capital is the amount the business owes to its own owner — for example, the cash or assets the proprietor invests to start the business. Both appear on the same side of the accounting equation, but liability represents an external claim while capital represents the owner's own claim." },
    { type: "Short Answer", marks: 4, q: "Explain how the sale of goods at a profit affects the three elements of the accounting equation, using an example.",
      answer: "Selling goods at a profit affects two elements: assets increase (cash or debtors go up by the sale amount) while stock, also an asset, decreases by the cost of goods sold. The net effect on assets is positive by the amount of profit, and capital increases by that same profit amount, since profit belongs to the owner. Example: goods costing ₹5,000 sold for ₹7,000 cash — cash increases ₹7,000, stock decreases ₹5,000 (net asset increase ₹2,000), and capital increases ₹2,000." },
    { type: "Long Answer", marks: 6, q: "Prepare an accounting equation table showing the effect of the following transactions on Assets, Liabilities, and Capital: (a) Started business with cash ₹80,000; (b) Purchased goods on credit ₹20,000; (c) Sold goods costing ₹12,000 for ₹16,000 cash; (d) Paid creditors ₹15,000; (e) Withdrew ₹5,000 cash for personal use.",
      answer: "(a) Cash +80,000, Capital +80,000 → Assets 80,000 = Capital 80,000. (b) Stock +20,000, Creditors +20,000 → Assets 1,00,000 = Capital 80,000 + Liabilities 20,000. (c) Cash +16,000, Stock −12,000 (net asset +4,000, profit), Capital +4,000 → Assets 1,04,000 = Capital 84,000 + Liabilities 20,000. (d) Cash −15,000, Creditors −15,000 → Assets 89,000 = Capital 84,000 + Liabilities 5,000. (e) Cash −5,000, Capital −5,000 (drawings) → Assets 84,000 = Capital 79,000 + Liabilities 5,000. Final check: 84,000 = 79,000 + 5,000 ✓" },
    { type: "Long Answer", marks: 6, q: "\"The Business Entity concept is what makes the accounting equation possible.\" Explain this statement with reference to how capital is treated in the books of a sole proprietorship.",
      answer: "The Business Entity concept treats the business as an accounting unit entirely separate from its owner, even though legally a sole proprietorship has no separate legal existence from its owner. Because of this separation, whatever the owner invests into the business is treated as something the business owes back to the owner — recorded as Capital, a liability-like figure from the business's own point of view. Without this concept, the owner's investment would simply be ignored or merged with the business's own resources, and the accounting equation — which depends on tracking exactly what the business owes to its owner as distinct from what it owes to outsiders — would not be possible to construct at all. This is also why an owner's personal expenses (Drawings) reduce capital rather than being ignored: the business is keeping a running account of its debt to the person who owns it." },
    { type: "Case-Based", marks: 4, q: "Rohan started a small tutoring business on 1st April with ₹40,000 cash. During the month he bought a whiteboard for ₹3,000 cash, took a loan of ₹10,000 for equipment, and earned tutoring fees of ₹12,000, all received in cash. Calculate his capital at the end of the month and show your working.",
      answer: "Opening capital = ₹40,000 (all cash). Buying the whiteboard is an asset-for-asset swap (cash down, whiteboard up) — capital unaffected. The loan increases both cash and liabilities equally — capital still unaffected. Tutoring fees of ₹12,000 is income, which increases capital directly. So closing capital = 40,000 + 12,000 = ₹52,000. (Total assets by month end = 40,000 − 3,000 + 3,000 + 10,000 + 12,000 = 62,000; liabilities = 10,000; capital = 62,000 − 10,000 = 52,000 ✓.)" },
    { type: "Assertion-Reason", marks: 1, q: "Assertion (A): Purchasing furniture for cash does not change total assets. Reason (R): This is because the transaction only converts one form of asset into another. Choose: (a) Both A and R are true, and R correctly explains A. (b) Both A and R are true, but R does not correctly explain A. (c) A is true, R is false. (d) A is false, R is true.",
      answer: "(a) Both A and R are true, and R correctly explains A. Cash decreases and furniture increases by the same amount, so total assets remain unchanged — exactly the situation R describes." },
    { type: "Assertion-Reason", marks: 1, q: "Assertion (A): Drawings reduce the accounting equation's total assets and total capital equally. Reason (R): Drawings are treated as a liability of the business. Choose: (a) Both A and R are true, and R correctly explains A. (b) Both A and R are true, but R does not correctly explain A. (c) A is true, R is false. (d) A is false, R is true.",
      answer: "(c) A is true, R is false. Drawings do reduce both assets and capital by the same amount when the owner withdraws cash or goods — but Drawings is not a liability; it is a reduction in the owner's own capital, recorded as a deduction from Capital, not as an amount owed to an outsider." }
  ],
  dc: [
    { type: "Short Answer", marks: 3, q: "State the Golden Rule applicable to Real accounts and Nominal accounts, with one example of each.",
      answer: "For Real accounts: Debit what comes in, Credit what goes out — for example, when Machinery is purchased, Machinery A/c (a Real account) is debited because the asset is coming into the business. For Nominal accounts: Debit all expenses and losses, Credit all incomes and gains — for example, when Rent is paid, Rent A/c (a Nominal account) is debited because it is an expense." },
    { type: "Short Answer", marks: 3, q: "What is a representative personal account? Give two examples.",
      answer: "A representative personal account is an account that, although not named after an actual person, effectively stands in for one because it tracks an amount owed to or by someone. Examples: Outstanding Salary A/c represents the employees who are owed money, and Prepaid Insurance A/c represents the insurance company that has been paid in advance and now 'owes' the business a future benefit." },
    { type: "Short Answer", marks: 4, q: "Explain the Modern (American) approach to the rules of debit and credit and state how it differs from the Golden Rules approach.",
      answer: "The Modern approach classifies every account into one of five categories — Assets, Liabilities, Capital, Revenue, and Expenses — rather than into Personal, Real, or Nominal. It then applies a single consistent logic: increases in Assets and Expenses are debited, decreases are credited; increases in Liabilities, Capital, and Revenue are credited, decreases are debited. It differs from the Golden Rules approach in its classification step, but always produces the identical journal entry — the two approaches are simply two different ways of reaching the same answer." },
    { type: "Long Answer", marks: 6, q: "Classify the following accounts under Personal, Real, or Nominal, and state whether each would normally be debited or credited when it increases: (a) Cash; (b) Rent Paid; (c) Ramesh's Account (a debtor); (d) Commission Received; (e) Outstanding Wages; (f) Furniture.",
      answer: "(a) Cash — Real; debited when it increases (comes in). (b) Rent Paid — Nominal; debited, since it's an expense. (c) Ramesh's Account — Personal; debited when it increases, since as a debtor he owes more to the business (he's the receiver of value). (d) Commission Received — Nominal; credited, since it's income. (e) Outstanding Wages — Personal (representative); credited when it increases, since it represents a growing amount owed to employees. (f) Furniture — Real; debited when it increases (comes in)." },
    { type: "Long Answer", marks: 6, q: "\"Both the Golden Rules and the Modern Rules always lead to the same journal entry.\" Justify this statement using the example of a cash purchase of machinery worth ₹50,000.", 
      answer: "Under the Golden Rules: Machinery A/c is a Real account, and it is coming into the business, so it is debited (Debit what comes in). Cash A/c is also Real, and it is going out, so it is credited (Credit what goes out). Entry: Machinery A/c Dr. 50,000, To Cash A/c 50,000. Under the Modern Rules: Machinery is an Asset increasing, so it is debited (Assets increase = Debit). Cash is also an Asset, but decreasing, so it is credited (Assets decrease = Credit). Entry: Machinery A/c Dr. 50,000, To Cash A/c 50,000 — identical. This confirms that the two approaches are different classification routes arriving at the same recorded entry, since Real accounts and Assets refer to the same underlying group of accounts, just labelled differently by each approach." },
    { type: "Case-Based", marks: 4, q: "A shopkeeper made the following transactions: paid salary ₹8,000 in cash, received commission ₹2,000 in cash, and purchased goods worth ₹15,000 on credit from a supplier. Identify the account type (Personal/Real/Nominal) for each account involved, and state which side each is recorded on.",
      answer: "Salary A/c — Nominal, debited (expense). Cash A/c (in the salary payment) — Real, credited (going out). Commission Received A/c — Nominal, credited (income). Cash A/c (in the commission receipt) — Real, debited (coming in). Purchases A/c — Real, debited (goods coming in). Supplier's A/c — Personal, credited (he is the giver of goods, and the business now owes him, making him a creditor)." },
    { type: "Assertion-Reason", marks: 1, q: "Assertion (A): Discount Allowed is debited when a debtor's account is settled. Reason (R): Discount Allowed is treated as an expense to the business. Choose: (a) Both A and R are true, and R correctly explains A. (b) Both A and R are true, but R does not correctly explain A. (c) A is true, R is false. (d) A is false, R is true.",
      answer: "(a) Both A and R are true, and R correctly explains A. Discount Allowed reduces the business's income when a debtor is given a concession to settle early, so it is treated as a Nominal expense/loss account and debited — exactly as R states." },
    { type: "Assertion-Reason", marks: 1, q: "Assertion (A): A bank overdraft is treated as an asset in the books of the account holder. Reason (R): Money held in a bank account is always a Real account debited when it increases. Choose: (a) Both A and R are true, and R correctly explains A. (b) Both A and R are true, but R does not correctly explain A. (c) A is true, R is false. (d) A is false, R is true.",
      answer: "(d) A is false, R is true. A bank overdraft means the account balance has gone negative — the business now owes the bank, making it a liability, not an asset. R on its own is a true general statement about bank accounts increasing normally, but it does not make A true, since an overdraft is a decrease below zero, not an increase." }
  ],
  jr: [
    { type: "Short Answer", marks: 3, q: "What is meant by the Journal being called the 'Book of Original Entry'? Why is this significant?",
      answer: "The Journal is called the Book of Original Entry because it is the very first place any business transaction is formally recorded, in chronological order, based on a source document like an invoice or receipt. This is significant because nothing is posted to the ledger without first passing through the journal — it creates the initial, dated, narrated record that all later accounting records are built from and can be traced back to." },
    { type: "Short Answer", marks: 3, q: "Distinguish between a simple journal entry and a compound journal entry, with one example of each.",
      answer: "A simple journal entry involves exactly one account debited and one account credited — for example, 'Rent A/c Dr. 5,000, To Cash A/c 5,000' for a straightforward cash rent payment. A compound journal entry involves more than two accounts, where several accounts may be debited against one credit, one debit against several credits, or several of both — for example, when machinery worth ₹60,000 is bought with ₹20,000 paid by cheque and the rest on credit: 'Machinery A/c Dr. 60,000, To Bank A/c 20,000, To Supplier's A/c 40,000.'" },
    { type: "Short Answer", marks: 4, q: "Explain why narration is a compulsory part of every journal entry.",
      answer: "Narration is a short explanation written below every journal entry describing what the transaction actually was. It is compulsory because the debit and credit account names alone don't always make the nature of a transaction clear — for instance, 'Cash A/c Dr., To Sales A/c' could represent a normal sale, or could need more context if unusual. Narration provides an audit trail, helps anyone reviewing the books later (including auditors) understand the transaction without needing the original source document, and reduces the chance of the entry being misinterpreted." },
    { type: "Long Answer", marks: 6, q: "Journalise the following transactions, with narration: (a) Started business with cash ₹1,00,000; (b) Purchased goods for cash ₹30,000; (c) Sold goods costing ₹18,000 for ₹25,000 cash; (d) Paid rent ₹5,000; (e) Withdrew ₹4,000 cash for personal use.",
      answer: "(a) Cash A/c Dr. 1,00,000, To Capital A/c 1,00,000 (Being business started with cash). (b) Purchases A/c Dr. 30,000, To Cash A/c 30,000 (Being goods purchased for cash). (c) Cash A/c Dr. 25,000, To Sales A/c 25,000 (Being goods sold for cash). (d) Rent A/c Dr. 5,000, To Cash A/c 5,000 (Being rent paid in cash). (e) Drawings A/c Dr. 4,000, To Cash A/c 4,000 (Being cash withdrawn by proprietor for personal use)." },
    { type: "Long Answer", marks: 6, q: "Explain, with a worked example, how a transaction involving a cash discount is journalised differently from one involving a trade discount.",
      answer: "Trade discount is deducted before the entry is even made — it never appears as a separate account anywhere in the journal. Example: goods listed at ₹20,000 sold with a 10% trade discount are simply recorded at the net figure of ₹18,000: 'Customer's A/c Dr. 18,000, To Sales A/c 18,000.' Cash discount, by contrast, is recorded through its own Nominal account, since it represents an actual reduction given at the time of settlement rather than at the time of billing. Example: a debtor owing ₹10,000 pays ₹9,500 in cash, with ₹500 allowed as cash discount: 'Cash A/c Dr. 9,500, Discount Allowed A/c Dr. 500, To Debtor's A/c 10,000.' The debtor's account is closed in full (₹10,000), split between the cash actually received and the discount recognized as an expense — this three-line compound entry is the key difference from how trade discount is handled." },
    { type: "Case-Based", marks: 4, q: "On 5th July, a firm purchased goods worth ₹40,000 from Meera Traders, paying ₹15,000 immediately by cheque and taking the rest on credit. On 20th July, the firm returned defective goods worth ₹3,000 to Meera Traders. Journalise both transactions with narration.",
      answer: "5th July: Purchases A/c Dr. 40,000, To Bank A/c 15,000, To Meera Traders A/c 25,000 (Being goods purchased, part paid by cheque and balance on credit). 20th July: Meera Traders A/c Dr. 3,000, To Purchases Return A/c 3,000 (Being defective goods returned to Meera Traders)." },
    { type: "Assertion-Reason", marks: 1, q: "Assertion (A): Every journal entry must have equal total debits and total credits. Reason (R): This follows directly from the dual aspect concept of accounting. Choose: (a) Both A and R are true, and R correctly explains A. (b) Both A and R are true, but R does not correctly explain A. (c) A is true, R is false. (d) A is false, R is true.",
      answer: "(a) Both A and R are true, and R correctly explains A. The dual aspect concept requires every transaction to be recorded with two equal and opposite effects, which is precisely why total debits must always equal total credits in every journal entry, whether simple or compound." },
    { type: "Assertion-Reason", marks: 1, q: "Assertion (A): Goods sent to a customer 'on approval' are recorded as a credit sale immediately on dispatch. Reason (R): Ownership of goods transfers to the customer only once they formally accept the goods. Choose: (a) Both A and R are true, and R correctly explains A. (b) Both A and R are true, but R does not correctly explain A. (c) A is true, R is false. (d) A is false, R is true.",
      answer: "(d) A is false, R is true. Goods sent on approval remain the seller's property until the customer confirms acceptance, so no sale — and therefore no journal entry crediting Sales — is recorded at the point of dispatch. R correctly states the underlying principle (ownership transfer determines the sale), which is exactly why A is false." },
    { type: "Long Answer", marks: 6, q: "A firm commenced business on 1st April with the following: Cash ₹20,000; Bank ₹40,000; Stock ₹30,000; Furniture ₹25,000; Debtors ₹15,000; Creditors ₹18,000; Bank Loan ₹12,000. Pass the Opening Journal Entry.",
      answer: "Cash A/c Dr. 20,000; Bank A/c Dr. 40,000; Stock A/c Dr. 30,000; Furniture A/c Dr. 25,000; Debtors A/c Dr. 15,000; To Creditors A/c 18,000; To Bank Loan A/c 12,000; To Capital A/c 1,00,000 (Being balances of assets and liabilities brought forward). The rule is: debit all assets, credit all liabilities, and Capital is the balancing figure — here, total assets (₹1,30,000) minus total liabilities (₹30,000) gives Capital of ₹1,00,000." },
    { type: "Short Answer", marks: 4, q: "Old machinery with a book value of ₹20,000 was sold for ₹25,000 cash. Journalise this, and explain why Sales A/c is not used.",
      answer: "Cash A/c Dr. 25,000; To Machinery A/c 20,000; To Gain (Profit) on Sale of Machinery A/c 5,000 (Being old machinery sold at a profit). Sales A/c is reserved exclusively for goods held for resale (stock-in-trade). A fixed asset like machinery is not stock — Machinery A/c is credited only for its own book value, and the excess received is a separate capital gain, credited to its own Profit on Sale account." },
    { type: "Case-Based", marks: 6, q: "A debtor, Suresh, owed a firm ₹10,000. He was declared insolvent, and a first and final payment of 60 paise in the rupee was received in cash from his estate. Some weeks later, the firm accepted a Bills Receivable of ₹8,000 from another debtor, Vikram, in settlement of his account. Journalise both events.",
      answer: "Suresh's insolvency: Cash A/c Dr. 6,000; Bad Debts A/c Dr. 4,000; To Suresh's A/c 10,000 (Being 60 paise in the rupee received on insolvency, balance written off). Vikram's Bills Receivable: Bills Receivable A/c Dr. 8,000; To Vikram's A/c 8,000 (Being a Bills Receivable accepted in settlement of his account). In the first, Suresh's account is closed by splitting the amount owed between what was recovered and what is genuinely lost; in the second, Vikram's ordinary debtor balance is simply converted into a more formal, legally enforceable asset." },
    { type: "Short Answer", marks: 3, q: "Distinguish between Accrued Income and Income Received in Advance, with one journal entry example for each.",
      answer: "Accrued Income is income already earned during the period but not yet received in cash — it is an asset. Example: Accrued Commission A/c Dr. 1,200; To Commission Received A/c 1,200 (commission earned but uncollected at year-end). Income Received in Advance is cash already collected for work not yet performed — it is a liability. Example: Cash A/c Dr. 4,000; To Commission Received in Advance A/c 4,000 (commission collected for work to be done next year). The two are mirror images: one recognizes income before cash arrives, the other delays recognizing income even though cash has already arrived." }
  ],
  lg: [
    { type: "Short Answer", marks: 3, q: "Define the Ledger, and explain why it is called the 'Book of Final Entry'.",
      answer: "The Ledger is the principal book of accounts in which all transactions relating to a particular account, first recorded in the Journal, are transferred (posted) in a classified and permanent form, so that the net effect on that account and its balance can be seen together. It is called the 'Book of Final Entry' because posting is the last stage a transaction passes through in the books — nothing further is done to that transaction after it lands in the Ledger, unlike the Journal, which is only the first, unsorted record." },
    { type: "Short Answer", marks: 3, q: "State the four key posting rules that connect a Journal entry to its Ledger accounts.",
      answer: "(1) Whichever account is debited in the Journal is posted to the debit (left) side of that same account in the Ledger. (2) Whichever account is credited in the Journal is posted to the credit (right) side of that same account. (3) On the debit side, the word 'To' is written before the name of the account that was credited in the original entry. (4) On the credit side, the word 'By' is written before the name of the account that was debited in the original entry." },
    { type: "Short Answer", marks: 4, q: "Explain the relationship between the Journal and the Ledger, and why both are needed rather than just one.",
      answer: "The Journal records transactions in chronological (date) order, exactly as they occur, with a narration explaining each one. The Ledger takes those same entries and reorganizes them by account, so that everything affecting, say, Cash A/c or a particular debtor's account can be seen together in one place with a running balance. The Journal alone cannot show how much cash is on hand or what a debtor currently owes without hunting through every date; the Ledger alone would have no reliable, dated, narrated original record to build from. Together they form successive, complementary stages of the same accounting cycle." },
    { type: "Long Answer", marks: 6, q: "From the following Journal entries, prepare the Ledger account for Cash A/c only, and balance it: (a) Cash A/c Dr. 60,000, To Capital A/c 60,000; (b) Purchases A/c Dr. 15,000, To Cash A/c 15,000; (c) Cash A/c Dr. 22,000, To Sales A/c 22,000; (d) Rent A/c Dr. 4,000, To Cash A/c 4,000.",
      answer: "Cash A/c — Debit side: 'To Capital A/c' ₹60,000; 'To Sales A/c' ₹22,000 — Debit total ₹82,000. Credit side: 'By Purchases A/c' ₹15,000; 'By Rent A/c' ₹4,000 — Credit total ₹19,000. Since the debit side is larger, Balance c/d of ₹63,000 (₹82,000 − ₹19,000) is written on the credit side, making both sides total ₹82,000. This ₹63,000 then brings down as 'Balance b/d' on the debit side for the next period — confirming Cash A/c carries a debit balance of ₹63,000, exactly as an asset account should." },
    { type: "Long Answer", marks: 6, q: "Explain, with a worked numerical example, how a Ledger account is balanced when it has entries on both the debit and credit sides, covering every step from totalling to bringing down the balance.",
      answer: "Take a Debtor's account with Debit side total ₹50,000 (goods sold on credit) and Credit side total ₹36,000 (part-payment received). Step 1 — Total both sides separately: Debit ₹50,000, Credit ₹36,000. Step 2 — Compare: the debit side is larger by ₹14,000 (₹50,000 − ₹36,000). Step 3 — Write this difference, 'By Balance c/d ₹14,000', on the smaller (credit) side, so both sides now total ₹50,000 and can be ruled off with a line. Step 4 — Immediately below, bring the same ₹14,000 down to the opposite (debit) side as 'To Balance b/d', dated at the start of the next period. Step 5 — Since this balance sits on the debit side, it is a debit balance, correctly showing that the debtor still owes the business ₹14,000 going into the next period." },
    { type: "Case-Based", marks: 4, q: "A firm's Journal for the week shows: Purchased goods on credit from Kabir ₹18,000; Paid Kabir ₹10,000 by cheque. Prepare Kabir's Ledger account and state its balance.",
      answer: "Kabir's A/c — Credit side: 'By Purchases A/c' ₹18,000 (goods bought on credit, so Kabir is the giver and is credited). Debit side: 'To Bank A/c' ₹10,000 (part-payment made, reducing what is owed to him). Credit total ₹18,000, Debit total ₹10,000. The credit side is larger by ₹8,000, so 'To Balance c/d ₹8,000' is written on the debit side, and this ₹8,000 brings down as 'By Balance b/d' on the credit side — confirming the firm still owes Kabir ₹8,000, a credit balance, exactly as a creditor's account should show." },
    { type: "Assertion-Reason", marks: 1, q: "Assertion (A): Every Journal entry results in exactly two Ledger postings. Reason (R): A compound Journal entry with several debits or credits is still just one transaction. Choose: (a) Both A and R are true, and R correctly explains A. (b) Both A and R are true, but R does not correctly explain A. (c) A is true, R is false. (d) A is false, R is true.",
      answer: "(d) A is false, R is true. A compound Journal entry — with more than one debit or credit account — results in more than two postings, one for every account named on either side. For example, one debit against two credits produces three separate postings, not two. R is true in that a compound entry is still recorded as a single Journal entry, but this does not make A true." },
    { type: "Assertion-Reason", marks: 1, q: "Assertion (A): A Nominal account's Balance c/d is always brought down to the next accounting year as an opening balance. Reason (R): Nominal accounts track expenses, losses, incomes, and gains for a specific period only. Choose: (a) Both A and R are true, and R correctly explains A. (b) Both A and R are true, but R does not correctly explain A. (c) A is true, R is false. (d) A is false, R is true.",
      answer: "(d) A is false, R is true. Nominal accounts are closed off to the Profit & Loss Account at the end of each year rather than carried forward with a brought-down balance — only Real, Personal, and Capital accounts continue into the next year in this way. R correctly explains why: since Nominal accounts track only the current period's expenses, losses, incomes, and gains, carrying their balance forward would mix one year's results into the next, which is exactly why A is false." }
  ]
  ,
  cb: [
    { type: "Short Answer", marks: 3, q: "What are Subsidiary Books? Name any four Subsidiary Books maintained by a firm.",
      answer: "Subsidiary Books or Special Purpose Books are books of accounts maintained to record transactions of a particular nature, so that a large volume of transactions doesn't all have to be recorded in one Journal. The six Subsidiary Books are: (1) Cash Book — for receipts and payments of cash, including receipts into and payments from the bank; (2) Purchases Book — for credit purchases of goods; (3) Sales Book — for credit sales of goods; (4) Purchases Return Book; (5) Sales Return Book; and (6) Journal Proper — for transactions that fit none of the above." },
    { type: "Short Answer", marks: 3, q: "State three advantages of maintaining Subsidiary Books instead of one single Journal.",
      answer: "(1) Division of Work — accounting work can be divided among several people, since a subsidiary book is maintained for each category of transactions. (2) Saving of Time — several accounting processes can proceed simultaneously through different books. (3) Facility in Checking — if the Trial Balance doesn't match, locating the error is easier, since each Subsidiary Book has fewer transactions than one combined Journal would." },
    { type: "Short Answer", marks: 4, q: "Explain why Cash Book is regarded as both a Subsidiary Book and a Principal Book.",
      answer: "Cash Book is a Subsidiary Book because cash and bank transactions are first recorded there directly, and transactions other than cash/bank are separately posted to Ledger Accounts. It is also a Principal Book because Cash Book, by itself, IS the Cash Account and the Bank Account — no separate Cash Account or Bank Account is opened in the Ledger, and its balances are placed directly in the Trial Balance. Being both at once is what makes Cash Book unique among the Subsidiary Books." },
    { type: "Long Answer", marks: 6, q: "Distinguish between a Simple (Single Column) Cash Book and a Two-Column (Double Column) Cash Book. In your answer, cover what each records and what a Two-Column Cash Book represents.",
      answer: "A Simple Cash Book has only one amount column on each side and records CASH transactions only — it does not record cheques received or given, or cash discount. A Two-Column (Double Column) Cash Book has two amount columns on each side, one for cash and one for bank — it records both cash AND bank transactions, and therefore represents two ledger accounts at once: the Cash Account and the Bank Account. In the bank column, the rule 'increase in assets is debited, decrease is credited' applies, exactly as it would to a Bank Account maintained separately in the ledger." },
    { type: "Long Answer", marks: 6, q: "What are Contra Entries? Explain, with the two standard examples, why they are marked 'C' and never posted to the Ledger.",
      answer: "Contra Entries are entries which affect both cash and bank at the same time — the balance of one decreases while the balance of the other increases by the same amount. Example (a): Cash deposited in Bank ₹20,000 — Bank A/c is debited (asset increases) in the bank column, and Cash A/c is credited (asset decreases) in the cash column. Example (b): Cash withdrawn from Bank for Office Use ₹10,000 — Cash A/c is debited in the cash column and Bank A/c is credited in the bank column. Both aspects of each transaction are recorded within the SAME Cash Book, on its two columns — so there is nothing left to post anywhere else. This is why they are marked 'C' in the L.F. column on both sides, and are never posted to any separate Ledger Account." },
    { type: "Case-Based", marks: 4, q: "Rehan received a cheque of ₹9,500 from a debtor in settlement of a claim of ₹10,000, and deposited it in the bank on the same day. Two days later the bank informed him that the cheque was dishonoured. Explain how each part of this situation is recorded, and in which book.",
      answer: "When the cheque is first received and deposited on the same day, ₹9,500 is recorded on the debit (receipts) side of the Cash Book in the bank column, since a same-day deposit goes straight into the bank column. The ₹500 discount allowed does not appear in the Cash Book at all (a two-column Cash Book has no discount column) — it is recorded separately via a Journal Proper entry: Discount Allowed A/c Dr. ₹500; To Debtor's A/c ₹500. On dishonour, the ₹9,500 is written back on the credit (payments) side of the Cash Book, bank column, with the debtor's name — and the ₹500 discount that was allowed is also reversed by a Journal Proper entry: Debtor's A/c Dr. ₹500; To Discount Allowed A/c ₹500." },
    { type: "Short Answer", marks: 3, q: "What is a post-dated cheque? On what date is a post-dated cheque issued by a firm entered in its Cash Book?",
      answer: "A post-dated cheque is a cheque issued or received bearing a future date — it can only be presented to the bank for payment on or after that date. A post-dated cheque ISSUED by the firm is entered in the bank column of the Cash Book on the date it is actually issued, not on the future date written on the cheque, since the transaction itself takes place on the day it is handed over. Until its due date, it is shown as a cheque outstanding for payment in the Bank Reconciliation Statement." },
    { type: "Long Answer", marks: 6, q: "A cheque of ₹24,000 is received on 1st May and is dated 1st June. The firm gets it discounted by the bank on 1st May itself, at a discounting rate of 10% p.a. for the remaining period. Show how this is recorded, with your working for the discounting charges.",
      answer: "Remaining period from 1st May to 1st June = 1 month. Discounting charges = ₹24,000 × 10/100 × 1/12 = ₹200. The net amount actually received, ₹23,800 (24,000 − 200), is recorded on the debit (receipts) side of the Cash Book, bank column, as 'To [Party] ₹23,800'. Separately, a Journal Proper entry records the charge itself: Discounting Charges A/c Dr. ₹200; To [Party] ₹200." },
    { type: "Case-Based", marks: 4, q: "A firm's Petty Cash Book is run on the Imprest System with an imprest of ₹6,000. During the week the Petty Cashier paid: Conveyance ₹450, Postage ₹280, Stationery ₹700, Cartage ₹320. What Journal entry is passed to record these expenses, and how much will the Petty Cashier be reimbursed to restore the imprest?",
      answer: "Each expense head is debited individually with the Petty Cash Account credited for the total: Conveyance A/c Dr. 450; Postage A/c Dr. 280; Stationery A/c Dr. 700; Cartage A/c Dr. 320; To Petty Cash A/c 1,750 (total spent = 450+280+700+320 = ₹1,750). Under the Imprest System, the Petty Cashier is reimbursed exactly the amount spent — ₹1,750 — so his balance is restored back up to the original ₹6,000 imprest for the next period." },
    { type: "Short Answer", marks: 3, q: "Distinguish between a Simple Petty Cash Book and an Analytical Petty Cash Book.",
      answer: "A Simple Petty Cash Book does not maintain a separate record of each kind of petty expense — it is written exactly like an ordinary Cash Book, with the page divided down the centre into one receipts column and one payments column, so at the end of a period, total expenses under different heads cannot easily be determined. An Analytical Petty Cash Book instead provides a separate analysis column for each commonly occurring expense (conveyance, cartage, stationery, courier, etc.) plus a 'sundries' column for infrequent ones, so expenses under each head can be determined easily and posting to the Ledger becomes simple, since each column's total is posted as one figure." },
    { type: "Assertion-Reason", marks: 1, q: "Assertion (A): Bank Overdraft is shown as a credit balance in the bank column of the Cash Book. Reason (R): Bank Overdraft means the amount withdrawn from bank in excess of the available balance in the account, and is a liability payable to the bank. Choose: (a) Both A and R are true, and R correctly explains A. (b) Both A and R are true, but R does not correctly explain A. (c) A is true, R is false. (d) A is false, R is true.",
      answer: "(a) Both A and R are true, and R correctly explains A. Because an overdraft means the firm owes the bank money rather than the bank owing the firm, it naturally appears as a credit balance (a liability) in the bank column, rather than the usual debit balance for money in hand at the bank." },
    { type: "Assertion-Reason", marks: 1, q: "Assertion (A): A cheque received and not deposited on the same day is recorded directly in the bank column of the Cash Book on the date it is received. Reason (R): Such a cheque is first recorded through a Journal entry in Cheques-in-Hand A/c, and only entered in the Cash Book's bank column on the date it is actually deposited. Choose: (a) Both A and R are true, and R correctly explains A. (b) Both A and R are true, but R does not correctly explain A. (c) A is true, R is false. (d) A is false, R is true.",
      answer: "(d) A is false, R is true. A cheque not banked the same day is NOT entered in the Cash Book on the day it is received — it is instead recorded via Cheques-in-Hand A/c Dr. To Party's A/c in Journal Proper, and only enters the Cash Book's bank column later, on the day it is actually deposited, as 'To Cheques-in-Hand A/c'." }
  ],
  sp2: [
    { type: "Short Answer", marks: 3, q: "What is the Purchases Book? State one transaction that is never recorded in it even though it involves goods the firm deals in.",
      answer: "Purchases Book (Purchases Journal) is a Subsidiary Book used to record credit purchases of goods the firm trades in, or raw material it uses for manufacturing — entered net of trade discount, on the basis of invoices received. A CASH purchase of such goods, however, is never recorded in the Purchases Book — it goes to the Cash Book instead, however large the amount." },
    { type: "Short Answer", marks: 3, q: "Distinguish between a Debit Note and a Credit Note — who prepares each, and which book each supports.",
      answer: "A Debit Note is prepared by the PURCHASER when returning goods bought on credit, notifying the seller that their account has been debited — it is the basis for an entry in the Purchases Return Book. A Credit Note is prepared by the SELLER when a customer returns goods sold on credit, evidencing that the customer's account has been credited — it is the basis for an entry in the Sales Return Book." },
    { type: "Short Answer", marks: 4, q: "State the treatment of Trade Discount and of Freight/Carriage charges in the Purchases Book, with a brief example of each.",
      answer: "Trade Discount is deducted from the List Price BEFORE the entry is made — only the net figure is recorded, and Trade Discount never gets its own ledger account. Example: List Price ₹10,000 less 10% Trade Discount (₹1,000) = ₹9,000 recorded. Freight/Carriage charged by the seller, on the other hand, IS recorded — but in its own separate column, not merged into the cost of goods. Example: Goods ₹9,000 plus Freight ₹300 = Total ₹9,300 credited to the supplier; ₹9,000 debited to Purchases A/c and ₹300 debited to Freight Inwards A/c." },
    { type: "Long Answer", marks: 6, q: "From the following credit transactions of M/s Kavya Traders (a dealer in stationery), prepare the Purchases Book for the month of June: June 3 — Purchased from Om Stationers: 50 dozen notebooks @ ₹180 per dozen, less trade discount 10%; June 10 — Purchased from Bright Papers: 100 reams of paper @ ₹250 per ream, less trade discount 5%, plus freight of ₹200 payable to Bright Papers; June 18 — Purchased a computer printer for office use from Tech World for ₹18,000, on credit.",
      answer: "PURCHASES BOOK OF M/S KAVYA TRADERS — June 3, Om Stationers: List Price 50×180 = 9,000; Less Trade Discount 10% = 900; Net = ₹8,100. June 10, Bright Papers: List Price 100×250 = 25,000; Less Trade Discount 5% = 1,250; Cost = 23,750; Add Freight 200; Total payable = ₹23,950. Total of Purchases Book (cost only) = 8,100 + 23,750 = ₹31,850, posted Dr. to Purchases A/c; Freight column total ₹200 posted Dr. to Freight Inwards A/c. Note: The June 18 computer printer purchase is NOT entered in the Purchases Book at all — Kavya Traders deals in stationery, not computers, and the printer is for office use, not resale, so it is recorded through Journal Proper instead (Office Equipment A/c Dr. 18,000; To Tech World 18,000)." },
    { type: "Long Answer", marks: 6, q: "Explain, step by step, how the Sales Book is posted to the Ledger — covering both the individual entries and the periodic total — using a numerical example where goods worth ₹14,000 are sold on credit to Rahul with packing charges of ₹200 recovered from him.",
      answer: "Step 1 — As the entry is made in the Sales Book, Rahul's account is immediately debited with the full invoice amount: ₹14,000 (Sale Value) + ₹200 (Packing Charges) = ₹14,200. Step 2 — At the end of the period, the Sale Value column is totalled, and this total (which would include ₹14,000 from this transaction, plus all others in the period) is posted to the CREDIT of Sales Account. Step 3 — Similarly, the Packing Charges column is totalled and posted to the CREDIT of Packing Charges Account (₹200 from this transaction, plus others). This way, Rahul's account correctly shows the full amount he owes, while Sales Account and Packing Charges Account each receive only their own share, keeping the books in double-entry balance." },
    { type: "Case-Based", marks: 4, q: "Ananya runs a boutique selling readymade garments. During the month she: (i) sold garments worth ₹22,000 on credit to a regular customer, Meher; (ii) sold garments for cash worth ₹9,000; (iii) sold an old sewing machine (not stock-in-trade) on credit for ₹4,000 to a neighbouring tailor. Identify, with reasons, which book records each transaction.",
      answer: "(i) Sales Book — a credit sale of garments, which is exactly what Ananya's boutique deals in. (ii) Cash Book — cash sales are never entered in the Sales Book, regardless of the goods involved. (iii) Journal Proper — the sewing machine is a fixed asset Ananya uses in her business, not stock she trades in, so its sale (even on credit) cannot go through the Sales Book; it is recorded as Tailor's A/c Dr. 4,000; To Sewing Machine A/c 4,000, adjusting for any profit or loss on sale separately if the book value differs from ₹4,000." },
    { type: "Short Answer", marks: 3, q: "List the six types of entries recorded in the Journal Proper, with one line on each.",
      answer: "(1) Opening Entries — bring forward last year's assets, liabilities and capital at the start of the year. (2) Closing Entries — transfer nominal accounts to Trading A/c and Profit & Loss A/c at year end. (3) Rectification Entries — correct errors made in books of original entry or the Ledger. (4) Transfer Entries — move an amount from one account to another. (5) Adjustment Entries — outstanding/prepaid expenses, accrued/advance income, interest on capital, depreciation. (6) Miscellaneous Entries — e.g. credit purchase of an asset, discount reversal on dishonour, bad debts, loss by fire/theft, and capital brought in kind." },
    { type: "Case-Based", marks: 6, q: "A firm's ledger balances on 1st April were: Building ₹6,00,000; Debtors ₹1,50,000; Cash ₹40,000; Creditors ₹90,000; Bank Overdraft ₹30,000. Pass the Opening Entry to bring these forward, and state which of the six Journal Proper categories this belongs to.",
      answer: "This is an Opening Entry, the first of the six Journal Proper categories. Building A/c Dr. 6,00,000; Debtors A/c Dr. 1,50,000; Cash A/c Dr. 40,000; To Creditors A/c 90,000; To Bank Overdraft A/c 30,000; To Capital A/c 6,70,000 (balancing figure: total assets 7,90,000 − total liabilities 1,20,000 = capital 6,70,000), being last year's balances of assets, liabilities and capital brought forward." },
    { type: "Assertion-Reason", marks: 1, q: "Assertion (A): A trader who deals in furniture, buying office furniture on credit for his own use, records this in the Purchases Book. Reason (R): The Purchases Book records credit purchases of goods the firm deals in. Choose: (a) Both A and R are true, and R correctly explains A. (b) Both A and R are true, but R does not correctly explain A. (c) A is true, R is false. (d) A is false, R is true.",
      answer: "(d) A is false, R is true. Even though the trader deals in furniture, this particular piece is bought for the firm's OWN office use, not for resale — making it a fixed-asset purchase recorded through Journal Proper, not the Purchases Book. R is a true general statement about the Purchases Book, but it does not make A correct in this specific case." },
    { type: "Assertion-Reason", marks: 1, q: "Assertion (A): Cash discount received for prompt payment is recorded directly in the Purchases Book. Reason (R): The Purchases Book has no discount column at all — cash discount is journalised separately through Journal Proper. Choose: (a) Both A and R are true, and R correctly explains A. (b) Both A and R are true, but R does not correctly explain A. (c) A is true, R is false. (d) A is false, R is true.",
      answer: "(d) A is false, R is true. The Purchases Book only ever records the net, trade-discount-adjusted purchase amount — it has no discount column at all. Cash discount received for prompt payment is recorded separately, through Journal Proper (Creditor's A/c Dr.; To Discount Received A/c), entirely independent of the Purchases Book." }
  ],
  brs: [
    { type: "Short Answer", marks: 3, q: "Define Bank Reconciliation Statement. Why is it prepared?",
      answer: "A Bank Reconciliation Statement (BRS) is a statement prepared on a given date to explain, item by item, every difference between the balance as per Cash Book and the balance as per Pass Book, and to prove that both balances agree once these items are adjusted for. It is prepared to locate the cause of the difference, detect errors or fraud, and verify the correct bank balance before finalising the accounts." },
    { type: "Short Answer", marks: 3, q: "State any three reasons why the Cash Book balance and the Pass Book balance may differ on a given date.", 
      answer: "(1) Cheques issued by the firm but not yet presented for payment at the bank. (2) Cheques deposited by the firm but not yet collected/credited by the bank. (3) Bank charges or interest debited/credited directly by the bank, which the firm has not yet recorded in its Cash Book." },
    { type: "Explain Why", marks: 4, q: "\"A cheque issued but not presented for payment is added to the Cash Book balance when preparing a BRS, but the very same cheque is deducted if the BRS starts from the Pass Book balance instead.\" Explain why the treatment is opposite.",
      answer: "The firm has already reduced its own Cash Book balance the moment the cheque was issued, but the bank has not yet reduced the Pass Book balance since the payee hasn't presented the cheque — so, right now, the Cash Book is the smaller of the two figures. Starting from the Cash Book and moving towards the (larger) Pass Book figure, the item must be added. Starting from the Pass Book and moving towards the (smaller) Cash Book figure, the very same item must be deducted. The transaction itself hasn't changed — only the direction in which the reconciliation is travelling has." },
    { type: "Explain Why", marks: 4, q: "Explain why bank charges debited by the bank cause the Cash Book balance to be temporarily higher than the Pass Book balance.",
      answer: "The bank deducts its charges directly from the firm's account and immediately reduces the Pass Book balance. The firm, however, only learns of this charge when it later checks its Pass Book or bank statement, so its own Cash Book stays un-reduced in the meantime — making the Cash Book balance temporarily higher (overstated) compared to the Pass Book, until the firm records the charge." },
    { type: "Add/Less Treatment", marks: 4, q: "State, with one line of reasoning each, whether the following items are Added or Deducted when preparing a BRS starting from the Cash Book balance: (a) Interest allowed by the bank, not yet in the Cash Book. (b) A cheque deposited but not yet collected. (c) A dishonoured cheque, not yet in the Cash Book. (d) A direct payment made by the bank on the firm's behalf, not yet in the Cash Book.",
      answer: "(a) Added — the Pass Book is already higher since the bank has credited the interest, so the Cash Book needs to catch up. (b) Deducted — the Cash Book is already higher since the firm recorded the receipt on deposit, but the bank hasn't credited it yet. (c) Deducted — the Cash Book still shows the dishonoured cheque as realised money, so it overstates the true balance. (d) Deducted — the Pass Book is already lower since the bank has debited the payment, so the Cash Book needs to catch down." },
    { type: "Numerical", marks: 6, q: "From the following, prepare a Bank Reconciliation Statement as on 31st March, starting with the balance as per Cash Book: Balance as per Cash Book ₹45,000. Cheques of ₹8,000 issued but not yet presented for payment. Cheques of ₹5,500 deposited but not yet collected by the bank. Bank charges of ₹250 debited by the bank but not entered in the Cash Book. Interest of ₹400 credited by the bank but not entered in the Cash Book.",
      answer: "Balance as per Cash Book = ₹45,000. Add: Cheques issued but not presented ₹8,000; Interest credited by bank ₹400. Less: Cheques deposited but not collected ₹5,500; Bank charges ₹250. Balance as per Pass Book = 45,000 + 8,000 + 400 − 5,500 − 250 = ₹47,650." },
    { type: "Numerical", marks: 6, q: "From the following, prepare a Bank Reconciliation Statement as on 31st March, starting with the balance as per Pass Book: Balance as per Pass Book ₹38,000. A cheque of ₹6,000 issued by the firm has not yet been presented for payment. A cheque of ₹3,000 deposited by the firm has not yet been credited by the bank. The bank has directly collected ₹1,200 as dividend on the firm's investments, not yet entered in the Cash Book.",
      answer: "Balance as per Pass Book = ₹38,000. Add: Cheque deposited but not yet collected ₹3,000 (reverse treatment, since starting from Pass Book). Less: Cheque issued but not presented ₹6,000 (reverse treatment); Dividend directly collected by bank ₹1,200 (reverse treatment). Balance as per Cash Book = 38,000 + 3,000 − 6,000 − 1,200 = ₹33,800." },
    { type: "Numerical (Missing Figure)", marks: 6, q: "The Balance as per Cash Book of a firm is ₹28,000. On preparing the BRS, the following were found: a cheque of ₹4,000 issued but not presented; bank charges of ₹150 not recorded in the Cash Book; and one more item, X, which is added, resulting in a final Balance as per Pass Book of ₹34,850. Find the amount of item X and suggest what it could be.",
      answer: "Balance as per Cash Book ₹28,000 + Unpresented cheque ₹4,000 − Bank charges ₹150 = ₹31,850 before considering item X. Since the Balance as per Pass Book is ₹34,850, item X must contribute an additional ₹34,850 − ₹31,850 = ₹3,000, and since it is an 'Add' item, X is most likely a direct collection by the bank (e.g. dividend or interest collected), or a direct deposit made by a customer into the bank account, not yet entered in the Cash Book, amounting to ₹3,000." },
    { type: "Long Answer", marks: 6, q: "Explain the format of a Bank Reconciliation Statement prepared by starting with the Balance as per Cash Book, and state clearly what 'Add' and 'Less' represent in this format.",
      answer: "The statement begins by writing down the Balance as per Cash Book. Under an 'Add' heading, every item that makes this starting balance fall SHORT of the target Pass Book balance is listed and added — for example, a cheque issued but not yet presented (the Cash Book has already reduced its balance, but the bank hasn't yet), or interest allowed and direct collections the bank has already recorded but the firm hasn't. Under a 'Less' heading, every item that makes the starting balance EXCEED the target Pass Book balance is listed and deducted — for example, a cheque deposited but not yet collected (the Cash Book has already increased its balance, but the bank hasn't yet), or bank charges and direct payments the bank has already recorded but the firm hasn't. The final figure obtained, after all additions and deductions, should exactly equal the Balance as per Pass Book." },
    { type: "Common Exam Pattern", marks: 4, q: "A student prepared a BRS starting from the Cash Book balance and, for a cheque deposited but not yet collected, wrote 'Add ₹2,000' instead of 'Less ₹2,000'. Identify the error and explain the correct reasoning.",
      answer: "This is a reversed Add/Less treatment — a common student mistake. The correct reasoning: on depositing the cheque, the firm already increased its Cash Book balance, but the bank will only credit its Pass Book once the cheque is actually collected. So, right now, the Cash Book balance is higher (ahead) of the Pass Book balance for this reason, and the item must be DEDUCTED (Less), not added, to bring the Cash Book figure down to the Pass Book figure." }
  ],
  gst: [
    { type: "Short Answer", marks: 3, q: "What is GST? State its full form.",
      answer: "GST stands for Goods and Services Tax. It is a single, comprehensive, indirect tax levied on the supply of goods and services, which replaced a number of earlier indirect taxes such as VAT, excise duty, and service tax." },
    { type: "Explain", marks: 4, q: "Explain any three characteristics of GST.",
      answer: "(1) Multi-stage tax — levied at every stage of value addition, from manufacture to final sale. (2) Value-added tax — tax is effectively charged only on the value added at each stage, through Input Tax Credit. (3) Destination-based — the tax revenue accrues to the state where the goods/services are finally consumed, not where they are produced. (Other valid points: dual GST model with CGST/SGST/IGST; comprehensive tax replacing many earlier indirect taxes.)" },
    { type: "Explain", marks: 4, q: "Explain any three advantages of GST.",
      answer: "(1) Removes the cascading effect of tax (tax on tax) through Input Tax Credit. (2) Simplifies the tax structure by replacing multiple indirect taxes with one uniform tax. (3) Helps create a common national market by applying uniform tax rates across states, removing tax-related barriers to the movement of goods. (Other valid points: greater transparency, wider tax base, reduced tax evasion.)" },
    { type: "Explain Why", marks: 3, q: "Why is trade discount deducted before calculating GST, and not after?",
      answer: "GST is meant to be charged only on the actual value at which goods are being supplied — the taxable value. Since a trade discount reduces the real selling price, it must be deducted from the list price FIRST to arrive at the correct taxable value; calculating GST on the gross list price would overstate the tax and the final invoice value." },
    { type: "Numerical", marks: 4, q: "Goods with a list price of ₹15,000 are sold at a trade discount of 20%. GST rate is 18%. Calculate the taxable value, GST amount, and total invoice value.",
      answer: "Trade Discount = ₹15,000 × 20% = ₹3,000. Taxable Value = ₹15,000 − ₹3,000 = ₹12,000. GST Amount = ₹12,000 × 18% = ₹2,160. Total Invoice Value = ₹12,000 + ₹2,160 = ₹14,160." },
    { type: "Numerical", marks: 4, q: "Goods worth ₹10,000 are sold along with freight of ₹500. If GST at 18% is also chargeable on the freight, calculate the total invoice value.",
      answer: "Taxable Value (goods + freight) = ₹10,000 + ₹500 = ₹10,500. GST Amount = ₹10,500 × 18% = ₹1,890. Total Invoice Value = ₹10,500 + ₹1,890 = ₹12,390." },
    { type: "Journal Entry", marks: 4, q: "Pass the journal entry for: Goods purchased for cash, ₹8,000, GST 12%.",
      answer: "GST = ₹8,000 × 12% = ₹960. Entry: Purchases A/c Dr. ₹8,000; Input GST A/c Dr. ₹960; To Cash A/c ₹8,960." },
    { type: "Journal Entry", marks: 4, q: "Pass the journal entry for: Goods sold on credit to Suresh, ₹12,000, GST 18%.",
      answer: "GST = ₹12,000 × 18% = ₹2,160. Entry: Suresh's A/c Dr. ₹14,160; To Sales A/c ₹12,000; To Output GST A/c ₹2,160." },
    { type: "Application", marks: 4, q: "A trader in Delhi sells goods worth ₹10,000 to a buyer in Delhi (intra-state), GST 18%. Calculate CGST and SGST separately, and pass the journal entry (cash sale).",
      answer: "Total GST = ₹10,000 × 18% = ₹1,800. Since this is intra-state, it is split equally: CGST = SGST = ₹900 each. Entry: Cash A/c Dr. ₹11,800; To Sales A/c ₹10,000; To Output CGST A/c ₹900; To Output SGST A/c ₹900." },
    { type: "Application", marks: 3, q: "Distinguish between Input GST and Output GST with an example.",
      answer: "Input GST is the GST a business pays on its own purchases (e.g. GST paid while buying raw materials) and can be claimed as credit. Output GST is the GST a business collects from customers on its sales (e.g. GST charged on the selling price) and is payable to the government. Net GST Payable = Output GST − Input GST." }
  ],
  tb: [
    { type: "Short Answer", marks: 3, q: "What is a Trial Balance? State its main purpose.",
      answer: "A Trial Balance is a statement listing the balances of all ledger accounts as on a particular date. Its main purpose is to check the arithmetical accuracy of the ledger by verifying that the total of all debit balances equals the total of all credit balances." },
    { type: "Explain", marks: 4, q: "Explain any three objectives/features of a Trial Balance.",
      answer: "(1) Checking arithmetical accuracy — confirming Total Debit equals Total Credit. (2) Basis for final accounts — the Trial Balance's figures are used to prepare the Trading and Profit & Loss Account and Balance Sheet. (3) Helps locate errors — a disagreement signals that an error exists somewhere and needs to be traced. (Other valid points: it is a statement, not an account; it is prepared as on a specific date, usually periodically.)" },
    { type: "Explain", marks: 3, q: "Describe the Balance Method of preparing a Trial Balance.",
      answer: "Under the Balance Method, every ledger account is first balanced individually. Then, each account's single closing balance (either a debit or a credit balance) is listed against its name in the Trial Balance, in the appropriate column. Finally, both columns are totalled — they should be equal if the ledger is arithmetically accurate." },
    { type: "Explain Why", marks: 4, q: "\"An agreeing Trial Balance is not conclusive proof that the books of accounts are free from errors.\" Explain with examples.",
      answer: "Certain errors do not disturb the equality of the Debit and Credit totals. For example: an error of omission (a transaction never recorded at all affects neither side); an error of principle (e.g. furniture purchase wrongly debited to Purchases A/c — the amount is still correctly debited, just to the wrong type of account); and compensating errors (two errors of equal value that cancel out each other's effect on the totals). In all these cases, the Trial Balance can still agree even though the books contain real errors." },
    { type: "Classification", marks: 4, q: "Classify the following as Debit or Credit balances in a Trial Balance: (a) Sundry Debtors (b) Sundry Creditors (c) Purchases (d) Sales (e) Capital (f) Drawings (g) Wages (h) Discount Received.",
      answer: "(a) Sundry Debtors — Debit. (b) Sundry Creditors — Credit. (c) Purchases — Debit. (d) Sales — Credit. (e) Capital — Credit. (f) Drawings — Debit. (g) Wages — Debit. (h) Discount Received — Credit." },
    { type: "Numerical", marks: 4, q: "From the following balances, prepare a Trial Balance and verify that it agrees: Capital ₹60,000, Machinery ₹25,000, Cash ₹10,000, Debtors ₹20,000, Creditors ₹8,000, Sales ₹30,000, Purchases ₹33,000.",
      answer: "Debit column: Machinery ₹25,000 + Cash ₹10,000 + Debtors ₹20,000 + Purchases ₹33,000 = ₹88,000. Credit column: Capital ₹60,000 + Creditors ₹8,000 + Sales ₹30,000 = ₹98,000. Since ₹88,000 ≠ ₹98,000, this Trial Balance as given does NOT agree — there is a difference of ₹10,000, indicating an error somewhere in the figures or in a missing balance." },
    { type: "Explain Why", marks: 3, q: "Why is Provision for Doubtful Debts shown as a credit balance in the Trial Balance, even though it relates to an asset (Debtors)?",
      answer: "A provision represents an amount set aside in anticipation of a possible future loss (some debtors may not pay). It is not a reduction made directly to the Debtors account itself, but a separate account that accumulates this anticipated reduction — like other provisions and reserves, it is carried forward as a credit balance, to be shown as a deduction from Debtors when the Balance Sheet is prepared." },
    { type: "Common Exam Pattern", marks: 4, q: "A student found that the Debit column of a Trial Balance totals ₹1,05,000 while the Credit column totals ₹1,02,500. Identify possible reasons for this difference and how the student should proceed.",
      answer: "The difference of ₹2,500 indicates at least one one-sided error, such as: a credit balance being omitted, a debit balance being entered twice or in excess, an account being posted to the wrong side, or a casting (totalling) error in one of the columns. The student should recheck each ledger balance against the Trial Balance figures, re-verify the totalling of both columns, and trace the ₹2,500 difference systematically (often by checking whether any single account's balance equals or relates to this amount) until the error is found and corrected." },
    { type: "Distinguish", marks: 3, q: "Distinguish between an error of omission and an error of commission, with one example each.",
      answer: "An error of omission is a transaction left out of the books completely — e.g. a credit sale never recorded at all. An error of commission is a transaction recorded, but incorrectly in some way (wrong amount, or posted to the wrong account of the same class) — e.g. a payment of ₹500 recorded as ₹50, or a debtor's account debited instead of a different debtor's account of the same amount. An error of omission never affects the Trial Balance's agreement; certain errors of commission (like posting to the wrong account of the same class, with the correct amount) also don't affect agreement, while others (like a wrong amount) do." },
    { type: "Application", marks: 3, q: "State any three limitations of a Trial Balance, as relevant at the Class 11 level.",
      answer: "(1) It does not prove complete accuracy — several types of errors (omission, principle, compensating errors, and some commission errors) don't affect its agreement. (2) It is only a summary of balances as on one date — it does not show individual transactions. (3) Even when it agrees, mistakes in the original recording (e.g. a wrong account entirely, but with correct debit-credit treatment) can go undetected." }
  ],
  dep: [
    { type: "Short Answer", marks: 3, q: "Define depreciation and state any two of its features.",
      answer: "Depreciation is the gradual, continuous, and permanent decrease in the value of a fixed (tangible) asset due to wear and tear, the passage of time, or obsolescence. Two features: (1) it is continuous and gradual, never a sudden fall; (2) it is a charge against profit, debited to the Profit & Loss Account." },
    { type: "Explain", marks: 4, q: "Explain any three causes of depreciation.",
      answer: "(1) Wear and tear — normal use physically wears an asset out over time. (2) Effluxion of time — some assets lose value simply with the passage of time, whether used or not. (3) Obsolescence — an asset becomes outdated and is replaced by newer technology even though it may still work. (Other valid points: expiry of legal rights, accidents.)" },
    { type: "Explain", marks: 3, q: "State the three factors that affect the amount of depreciation charged on an asset.",
      answer: "(1) Cost of the asset — the original purchase price plus all expenses to bring it into working condition. (2) Estimated useful life — the number of years the asset is expected to remain usable. (3) Estimated residual (scrap) value — the amount expected to be recovered by selling the asset at the end of its useful life." },
    { type: "Explain Why", marks: 3, q: "Why must depreciation be charged even though it does not involve any immediate cash outflow?", 
      answer: "Depreciation follows the Matching Concept: since a fixed asset helps earn revenue over several years, part of its cost must be treated as an expense in each of those years, matched against the revenue it helps generate. Without charging depreciation, profit would be overstated and the Balance Sheet would continue showing the asset at a value higher than its real worth." },
    { type: "Difference", marks: 4, q: "Distinguish between Depreciation, Depletion, and Amortisation.",
      answer: "Depreciation applies to tangible fixed assets used in the business (machinery, furniture, buildings) — value falls due to use, time, or obsolescence. Depletion applies specifically to natural resources / wasting assets (mines, quarries, oil wells) — value falls as the resource is physically extracted. Amortisation applies specifically to intangible assets (patents, copyrights, trademarks, goodwill) — cost is written off over the asset's useful or legal life. All three represent the same underlying idea of spreading an asset's cost over its useful life." },
    { type: "Difference", marks: 6, q: "Distinguish between the Straight Line Method and the Written Down Value Method of depreciation (any four points).",
      answer: "(1) Basis: SLM is calculated on original cost every year; WDV is calculated on the written-down (book) value every year. (2) Amount: SLM gives an equal amount every year; WDV gives a decreasing amount every year. (3) Book value at the end of useful life: under SLM it can become zero (or exactly the residual value); under WDV it can never become exactly zero. (4) Suitability: SLM suits assets that wear out fairly evenly (e.g. furniture); WDV suits assets whose repair costs rise with age (e.g. machinery), since its falling depreciation charge balances the rising repair charge." },
    { type: "Numerical", marks: 4, q: "A machine is purchased for ₹1,20,000. Its estimated residual value at the end of 5 years is ₹20,000. Calculate the annual depreciation under the Straight Line Method.",
      answer: "Annual Depreciation (SLM) = (Cost − Residual Value) / Useful Life = (₹1,20,000 − ₹20,000) / 5 = ₹1,00,000 / 5 = ₹20,000 per year." },
    { type: "Numerical", marks: 6, q: "A machine costing ₹1,00,000 is depreciated @10% p.a. under the Written Down Value Method. Calculate the depreciation and book value for each of the first three years.",
      answer: "Year 1: Depreciation = ₹1,00,000 × 10% = ₹10,000; Book Value = ₹1,00,000 − ₹10,000 = ₹90,000. Year 2: Depreciation = ₹90,000 × 10% = ₹9,000; Book Value = ₹90,000 − ₹9,000 = ₹81,000. Year 3: Depreciation = ₹81,000 × 10% = ₹8,100; Book Value = ₹81,000 − ₹8,100 = ₹72,900." },
    { type: "Numerical", marks: 4, q: "A machine costing ₹90,000 is purchased on 1st October. The accounting year closes on 31st March. Depreciation is charged @20% p.a. under SLM, with no residual value. Calculate the depreciation for this first (part) year.",
      answer: "Full-year depreciation = ₹90,000 × 20% = ₹18,000. The machine was used for only 6 months (1st October to 31st March), so Depreciation for the year = ₹18,000 × 6/12 = ₹9,000." },
    { type: "Journal Entry", marks: 4, q: "Pass the journal entry for charging depreciation of ₹8,000 on Machinery for the year, using (a) the direct method, and (b) the Provision for Depreciation method.",
      answer: "(a) Direct method: Depreciation A/c Dr. ₹8,000; To Machinery A/c ₹8,000. (b) Provision for Depreciation method: Depreciation A/c Dr. ₹8,000; To Provision for Depreciation A/c ₹8,000. In both cases, Depreciation A/c is then closed by transfer to the Profit & Loss A/c: Profit & Loss A/c Dr. ₹8,000; To Depreciation A/c ₹8,000." },
    { type: "Numerical", marks: 6, q: "Machinery costing ₹50,000 was purchased on 1st April and depreciated @10% p.a. under SLM using a Provision for Depreciation A/c. It was sold for ₹40,000 at the start of the 4th year (after 3 full years of use). Show the working for Accumulated Depreciation, Book Value, and Profit/Loss on sale, and pass the necessary journal entries.",
      answer: "Accumulated Depreciation (3 years) = ₹50,000 × 10% × 3 = ₹15,000. Book Value = ₹50,000 − ₹15,000 = ₹35,000. Profit on Sale = Sale Proceeds − Book Value = ₹40,000 − ₹35,000 = ₹5,000 (Profit). Journal entries: (1) Asset Disposal A/c Dr. ₹50,000; To Machinery A/c ₹50,000. (2) Provision for Depreciation A/c Dr. ₹15,000; To Asset Disposal A/c ₹15,000. (3) Bank A/c Dr. ₹40,000; To Asset Disposal A/c ₹40,000. (4) Asset Disposal A/c Dr. ₹5,000; To Profit on Sale of Machinery A/c ₹5,000." },
    { type: "Common Exam Pattern", marks: 4, q: "A student calculated depreciation under WDV by applying the given rate to the ORIGINAL COST every year, instead of the reducing book value. Identify the error and show the correct calculation for a machine costing ₹80,000 depreciated @10% p.a. for two years.",
      answer: "This is a common error — under WDV, the rate must be applied to the book value at the START of each year, not the unchanging original cost. Correct calculation: Year 1: Depreciation = ₹80,000 × 10% = ₹8,000; Book Value = ₹72,000. Year 2: Depreciation = ₹72,000 × 10% = ₹7,200 (NOT ₹8,000 again); Book Value = ₹72,000 − ₹7,200 = ₹64,800." }
  ]
}
};
