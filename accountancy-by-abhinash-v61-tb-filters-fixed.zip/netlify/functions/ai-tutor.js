// netlify/functions/ai-tutor.js
//
// OPTIONAL upgrade path for the AI Tutor feature.
//
// The site works completely without this file — the frontend
// (see the AI Tutor section of app.js) tries to call this function
// first, and silently falls back to a local, rule-based tutor built
// from the site's own content if this function is missing, fails,
// or times out. Nothing breaks either way.
//
// Deploy this file to get real, open-ended AI answers instead of the
// local fallback. Setup:
//   1. In the Netlify dashboard: Site settings -> Environment variables
//      -> add ANTHROPIC_API_KEY (or OPENAI_API_KEY, see below) with
//      your real key. NEVER put the key in frontend code or commit it
//      to a public repo.
//   2. Netlify auto-detects any .js file under netlify/functions/ at
//      your repo root (this folder sits next to, not inside, the
//      accountancy-by-abhinash/ site folder). No extra config needed
//      for most sites; if your netlify.toml sets a custom
//      "functions" directory, move this file there instead.
//   3. Redeploy. The frontend will automatically start using this
//      function — no frontend changes needed.
//
// This template calls Anthropic's Claude API, including vision support —
// if the student attaches a photo of a question, it's sent to the model
// as an image content block so Claude can actually read it. To use OpenAI
// instead, see the commented alternative block near the bottom (note:
// you'd need to add image support to that branch separately, as GPT's
// image_url format differs from Claude's base64 source format).

const SYSTEM_PROMPT = `You are the Accountancy AI Tutor, built into the "Accountancy By Abhinash" learning website for CBSE Class 11 Commerce students.

Scope: Accounting Equation, Rules of Debit & Credit, Journal, Ledger, Trial Balance, Final Accounts, and related Class 11 Accountancy topics — including calculations such as trade/cash discount, GST, SLM/WDV depreciation, bad debts, provision for doubtful debts, outstanding/prepaid expenses, accrued/advance income, interest on capital & drawings, and manager's commission. If asked something clearly outside this scope, politely redirect back to Accountancy.

Conversational behaviour:
- Respond naturally to greetings, "how are you", and "what can you help me with" — don't treat these as errors just because they aren't numerical problems.
- Understand short, long, informal, or misspelled questions ("what is journl entry" → treat as "What is a journal entry?"). Don't call out the spelling mistake — just answer what was clearly meant.
- Handle multiple transactions given in one message individually, in order, without mixing accounts or amounts between them.

Never invent information:
- Never invent amounts, dates, names, tax rates, depreciation rates, methods, or any missing transaction detail.
- If required information is missing (e.g. "Calculate depreciation" with no cost/rate/method given), ask exactly what's missing rather than guessing.
- If a treatment is genuinely ambiguous (e.g. GST intra-state vs inter-state, or manager's commission before/after charging), either ask the student to confirm, or clearly label your choice as an assumption.

Answer modes: the student may ask for a Hint (a clue only, not the answer), Step-by-Step (full reasoning), or the Final Answer directly. Respect whichever the student is currently asking for.

Step-by-step structure for a transaction or numerical problem, when giving the full explanation:
1. What transaction happened
2. Which accounts are involved
3. Type of each account (Personal / Real / Nominal) and its rule
4. Which account is debited, and why
5. Which account is credited, and why
6. Any calculation, shown explicitly (e.g. trade discount, GST, depreciation) before the final figure
7. The journal entry, in proper format:
   Account Name A/c   Dr.   ₹____
        To Account Name A/c        ₹____
   (Being ...)
   Always use complete, meaningful account names — never placeholders like "Account1" or "Txn1". Keep the debit and credit amounts aligned and "To" properly positioned.
8. The narration
9. The final answer
Before presenting any journal entry, verify Total Debit = Total Credit; if it doesn't balance, recheck and correct it before answering.

Checking a student's own answer: identify specifically what's right or wrong — wrong account, reversed debit/credit, wrong amount, missing/extra account, missing narration, or incorrect calculation/treatment — and explain what's wrong, why, and the correct answer. Never just say "wrong". If the student says an answer "seems wrong", genuinely recheck the transaction, accounts, treatment, calculation, and narration before responding — don't change a correct answer just because they doubt it.

Formatting: use short paragraphs, bullet points, and numbered steps. Explanations should be understandable to a Class 11 Commerce student — avoid unnecessary professional jargon, and briefly explain any technical term you do need to use.

Images: a student may attach a photo of a handwritten or printed question. Read it carefully and work from what's actually visible. If the image is blurry, cropped, or you genuinely cannot make out the text, say so plainly and ask the student to retype the question rather than guessing at numbers or wording.`;

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ error: "Method not allowed" }) };
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    // Graceful, explicit failure — the frontend will catch this non-2xx
    // response and fall back to the local tutor automatically.
    return {
      statusCode: 501,
      body: JSON.stringify({ error: "AI backend not configured. Set ANTHROPIC_API_KEY in Netlify environment variables to enable real AI answers." })
    };
  }

  let payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch (e) {
    return { statusCode: 400, body: JSON.stringify({ error: "Invalid request body" }) };
  }

  const { message, history, chapterContext, answerMode, image } = payload;
  const hasText = typeof message === "string" && message.trim().length > 0;
  const hasImage = typeof image === "string" && image.startsWith("data:image/");
  if (!hasText && !hasImage) {
    return { statusCode: 400, body: JSON.stringify({ error: "Empty message" }) };
  }

  const MODE_NOTE = {
    hint: "\n\nThe student currently has Hint mode selected: give only a clue or direction, not the full answer, unless they explicitly ask for steps or the final answer.",
    final: "\n\nThe student currently has Final Answer mode selected: give the complete solution directly (calculation + journal entry), without the full step-by-step reasoning, unless they explicitly ask for steps.",
    steps: ""
  };
  const contextNote = (chapterContext
    ? `\n\nThe student is currently studying: ${chapterContext}. Prefer examples from this chapter when relevant.`
    : "") + (MODE_NOTE[answerMode] || "");

  const messages = (Array.isArray(history) ? history : [])
    .filter(m => m && m.text)
    .slice(-8)
    .map(m => ({ role: m.role === "assistant" ? "assistant" : "user", content: String(m.text).slice(0, 4000) }));

  // Build the final user turn. If an image is attached, send it as a
  // vision content block alongside any typed text so Claude can actually
  // read the photographed question rather than just being told about it.
  if (hasImage) {
    const match = /^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/.exec(image);
    if (!match) {
      return { statusCode: 400, body: JSON.stringify({ error: "Invalid image format" }) };
    }
    const [, mediaType, base64Data] = match;
    const allowedTypes = ["image/jpeg", "image/png", "image/gif", "image/webp"];
    if (!allowedTypes.includes(mediaType)) {
      return { statusCode: 400, body: JSON.stringify({ error: "Unsupported image type. Please use JPEG, PNG, GIF, or WEBP." }) };
    }
    // Roughly bound the request size (base64 is ~33% larger than raw bytes).
    if (base64Data.length > 8 * 1024 * 1024) {
      return { statusCode: 400, body: JSON.stringify({ error: "Image too large" }) };
    }
    messages.push({
      role: "user",
      content: [
        { type: "image", source: { type: "base64", media_type: mediaType, data: base64Data } },
        { type: "text", text: (hasText ? message.slice(0, 4000) : "Please read this photo of my Accountancy question and help me with it.") }
      ]
    });
  } else {
    messages.push({ role: "user", content: message.slice(0, 4000) });
  }

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-5-20250929",
        max_tokens: 1000,
        system: SYSTEM_PROMPT + contextNote,
        messages
      })
    });

    if (!response.ok) {
      const errText = await response.text().catch(() => "");
      console.error("AI Tutor backend error:", response.status, errText);
      return { statusCode: 502, body: JSON.stringify({ error: "AI service error" }) };
    }

    const data = await response.json();
    const reply = (data.content || []).filter(b => b.type === "text").map(b => b.text).join("\n").trim();
    if (!reply) return { statusCode: 502, body: JSON.stringify({ error: "Empty AI response" }) };

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reply })
    };
  } catch (err) {
    console.error("AI Tutor function error:", err);
    return { statusCode: 500, body: JSON.stringify({ error: "Internal error" }) };
  }
};

/* ---------------------------------------------------------------
   ALTERNATIVE: using OpenAI instead of Anthropic.
   Swap the fetch block above for this one, and set OPENAI_API_KEY
   in Netlify's environment variables instead.
   ---------------------------------------------------------------

const response = await fetch("https://api.openai.com/v1/chat/completions", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`
  },
  body: JSON.stringify({
    model: "gpt-4o-mini",
    max_tokens: 1000,
    messages: [{ role: "system", content: SYSTEM_PROMPT + contextNote }, ...messages]
  })
});
const data = await response.json();
const reply = data.choices?.[0]?.message?.content?.trim();

--------------------------------------------------------------- */
