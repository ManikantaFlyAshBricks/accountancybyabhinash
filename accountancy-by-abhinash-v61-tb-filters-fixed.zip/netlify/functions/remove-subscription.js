// netlify/functions/remove-subscription.js
//
// Called when the student turns notifications OFF, or when a push send
// fails with a "gone" status (the browser/device unsubscribed on its own —
// e.g. the PWA was uninstalled). Deletes the stored record so no further
// sends are attempted for that device.

const { keyFor, getSubscriptionStore } = require("./lib/push-utils");

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  let payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch {
    return { statusCode: 400, body: "Invalid JSON" };
  }

  const { endpoint } = payload;
  if (!endpoint) return { statusCode: 400, body: "Missing endpoint" };

  const store = getSubscriptionStore();
  await store.delete(keyFor(endpoint));

  return {
    statusCode: 200,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ok: true }),
  };
};
