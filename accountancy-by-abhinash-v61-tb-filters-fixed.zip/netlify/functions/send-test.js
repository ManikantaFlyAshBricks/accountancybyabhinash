// netlify/functions/send-test.js
//
// Sends a single push notification right now, so a student can confirm
// notifications actually work on their device before relying on the daily
// scheduled one. Does not touch lastNotifiedDate — a test send never
// counts as, or blocks, today's real daily notification.

const webpush = require("web-push");

const VAPID_PUBLIC_KEY = process.env.VAPID_PUBLIC_KEY;
const VAPID_PRIVATE_KEY = process.env.VAPID_PRIVATE_KEY;
const VAPID_SUBJECT = process.env.VAPID_SUBJECT || "mailto:admin@example.com";

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }
  if (!VAPID_PUBLIC_KEY || !VAPID_PRIVATE_KEY) {
    return { statusCode: 500, body: "Server is missing VAPID_PUBLIC_KEY / VAPID_PRIVATE_KEY environment variables." };
  }

  let payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch {
    return { statusCode: 400, body: "Invalid JSON" };
  }

  const { subscription, name } = payload;
  if (!subscription || !subscription.endpoint) {
    return { statusCode: 400, body: "Missing subscription" };
  }

  webpush.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY);

  const notif = {
    title: `Test notification ✅`,
    body: `Looks good${name ? `, ${name}` : ""} — your daily reminder will look like this.`,
    url: "./#home",
  };

  try {
    await webpush.sendNotification(
      subscription,
      JSON.stringify(notif)
    );
    return { statusCode: 200, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ok: true }) };
  } catch (err) {
    return {
      statusCode: 502,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ok: false, error: String(err && err.message || err) }),
    };
  }
};
