// netlify/functions/daily-notify.js
//
// This is the actual "runs every day even if nobody has the site open"
// piece. Netlify runs this on a server-side cron schedule (configured in
// netlify.toml, not in this file) — it has nothing to do with the
// student's browser being open.
//
// HONEST LIMITATION: Netlify Scheduled Functions run on a single global
// UTC cron schedule, not a separate schedule per user. There is no
// per-user-timezone cron on Netlify's free/standard scheduling. The most
// reliable secure workaround (used here) is: run this function every hour,
// and for each subscriber independently check "is it currently their
// chosen local hour, and have they NOT already been notified today (in
// their own local date)?" That gives every subscriber a notification
// within their chosen hour, once per local day, regardless of timezone —
// at the cost of up to ~59 minutes of drift from their exact chosen
// minute, and it will not perfectly track DST transitions (it uses the
// fixed UTC-offset reported when they subscribed).
//
// netlify.toml schedules this to run at the top of every hour.

const webpush = require("web-push");
const { getSubscriptionStore, localDateString, localHour, dayOfYear, buildNotification } = require("./lib/push-utils");

const VAPID_PUBLIC_KEY = process.env.VAPID_PUBLIC_KEY;
const VAPID_PRIVATE_KEY = process.env.VAPID_PRIVATE_KEY;
const VAPID_SUBJECT = process.env.VAPID_SUBJECT || "mailto:admin@example.com";

exports.handler = async () => {
  if (!VAPID_PUBLIC_KEY || !VAPID_PRIVATE_KEY) {
    console.error("daily-notify: missing VAPID_PUBLIC_KEY / VAPID_PRIVATE_KEY env vars — skipping run.");
    return { statusCode: 200, body: "skipped: missing VAPID env vars" };
  }
  webpush.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY);

  const store = getSubscriptionStore();
  const now = Date.now();

  let listing;
  try {
    listing = await store.list();
  } catch (err) {
    console.error("daily-notify: failed to list subscriptions", err);
    return { statusCode: 500, body: "failed to list subscriptions" };
  }

  let sent = 0, skipped = 0, removed = 0, failed = 0;

  for (const item of listing.blobs || []) {
    const key = item.key;
    let record;
    try {
      record = await store.get(key, { type: "json" });
    } catch {
      continue;
    }
    if (!record || !record.subscription) continue;

    const offset = record.tzOffsetMinutes || 0;
    const hourNow = localHour(now, offset);
    const targetHour = Number.isInteger(record.notifyHour) ? record.notifyHour : 8;
    const todayLocal = localDateString(now, offset);

    if (hourNow !== targetHour) { skipped++; continue; }
    if (record.lastNotifiedDate === todayLocal) { skipped++; continue; }

    const notif = buildNotification({
      name: record.name,
      chapterContext: record.chapterContext,
      streak: record.streak,
      dayIndex: dayOfYear(now, offset),
    });
    notif.url = "./#home";

    try {
      await webpush.sendNotification(record.subscription, JSON.stringify(notif));
      record.lastNotifiedDate = todayLocal;
      record.updatedAt = new Date().toISOString();
      await store.setJSON(key, record);
      sent++;
    } catch (err) {
      const code = err && err.statusCode;
      if (code === 404 || code === 410) {
        // Subscription no longer valid (uninstalled / permission revoked
        // at the OS level) — clean it up so we stop trying forever.
        await store.delete(key);
        removed++;
      } else {
        console.error("daily-notify: send failed for", key, err && err.message);
        failed++;
      }
    }
  }

  return {
    statusCode: 200,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ok: true, sent, skipped, removed, failed, ranAtUtc: new Date(now).toISOString() }),
  };
};
