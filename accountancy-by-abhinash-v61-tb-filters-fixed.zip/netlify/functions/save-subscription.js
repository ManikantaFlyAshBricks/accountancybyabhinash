// netlify/functions/save-subscription.js
//
// Called by the frontend right after the browser creates a Push
// Subscription (PushManager.subscribe). Stores it in Netlify Blobs so the
// scheduled daily-notify.js function can find it later — even if the site
// is closed, the tab is gone, and the phone is locked.
//
// Required Netlify env vars (Site settings -> Environment variables):
//   VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY, VAPID_SUBJECT (e.g. "mailto:you@example.com")
// Netlify Blobs requires no separate setup on Netlify — it's available to
// any Netlify Function automatically once the site is deployed.

const { keyFor, getSubscriptionStore } = require("./lib/push-utils");

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  let payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch {
    return { statusCode: 400, body: "Invalid JSON" };
  }

  const { subscription, name, tzOffsetMinutes, notifyHour, chapterContext, streak } = payload;
  if (!subscription || !subscription.endpoint || typeof tzOffsetMinutes !== "number") {
    return { statusCode: 400, body: "Missing subscription or tzOffsetMinutes" };
  }

  const store = getSubscriptionStore();
  const key = keyFor(subscription.endpoint);

  // Preserve lastNotifiedDate across an update (e.g. the student just
  // changed their notification time) so they don't get double-notified
  // the same day they change a setting.
  let existing = null;
  try {
    existing = await store.get(key, { type: "json" });
  } catch {
    existing = null;
  }

  const record = {
    subscription,
    name: typeof name === "string" ? name.slice(0, 40) : null,
    tzOffsetMinutes,
    notifyHour: Number.isInteger(notifyHour) ? notifyHour : 8,
    chapterContext: chapterContext || null,
    streak: typeof streak === "number" ? streak : 0,
    lastNotifiedDate: existing ? existing.lastNotifiedDate : null,
    createdAt: existing ? existing.createdAt : new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  await store.setJSON(key, record);

  return {
    statusCode: 200,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ok: true }),
  };
};
