// Accountancy By Abhinash — service worker
// Bump CACHE_NAME whenever a deploy should force-refresh cached app files.
const CACHE_NAME = "aba-cache-v21";
const APP_SHELL = [
  "./",
  "./index.html",
  "./styles.css",
  "./app.js",
  "./data.js",
  "./accounting-cycle.js",
  "./certificate.js",
  "./manifest.json",
  "./assets/icon-192.png",
  "./assets/icon-512.png",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL)).catch(() => {})
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// Stale-while-revalidate: serve from cache instantly if we have it (so the
// app opens even with a flaky connection), but always fetch a fresh copy in
// the background and update the cache — so a student never gets stuck on a
// months-old version just because a service worker is installed.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin && !url.hostname.includes("unpkg.com") && !url.hostname.includes("fonts.g")) return;

  event.respondWith(
    caches.match(event.request).then((cached) => {
      const network = fetch(event.request)
        .then((response) => {
          if (response && response.status === 200 && event.request.url.startsWith(self.location.origin)) {
            const copy = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
          }
          return response;
        })
        .catch(() => cached);
      return cached || network;
    })
  );
});

// ---------------------------------------------------------------------
// Daily reminder push notifications. This fires when the server-side
// daily-notify.js function sends a push via the Push API — the browser
// wakes this service worker up to handle it even if the site itself is
// completely closed and the phone is locked. This is the actual delivery
// mechanism; nothing in the page's own JS needs to be running.
// ---------------------------------------------------------------------
self.addEventListener("push", (event) => {
  let data = {};
  try {
    data = event.data ? event.data.json() : {};
  } catch {
    data = { title: "Accountancy By Abhinash", body: event.data ? event.data.text() : "" };
  }
  const title = data.title || "Accountancy By Abhinash";
  const options = {
    body: data.body || "Ready to continue your Accountancy learning journey today?",
    icon: "assets/icon-192.png",
    badge: "assets/icon-192.png",
    tag: "daily-reminder",
    renotify: true,
    data: { url: data.url || "./#home" },
  };
  event.waitUntil(self.registration.showNotification(title, options));
});

// Tapping the notification focuses an already-open tab/PWA window if one
// exists, instead of piling up duplicate windows, and otherwise opens one.
self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const targetPath = (event.notification.data && event.notification.data.url) || "./#home";
  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if ("focus" in client) {
          if ("navigate" in client) client.navigate(targetPath).catch(() => {});
          return client.focus();
        }
      }
      if (self.clients.openWindow) return self.clients.openWindow(targetPath);
    })
  );
});
