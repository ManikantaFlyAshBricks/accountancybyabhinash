/* ============================================================
   GOOGLE SHEETS RESULT SYNC — Accountancy by Abhinash
   ------------------------------------------------------------
   Upgrades the existing Exam Mode / certificate result flow so
   the already-calculated final result is ALSO mirrored to a
   Google Sheet through a Google Apps Script Web App.

   This file does not calculate anything and does not touch
   certificate generation, eligibility, or IDs — it only reads
   the finished result object that renderExamResults() builds
   (in app.js) after submission/grading/certificate-generation
   are already complete, and forwards it. The single call site
   is in app.js, inside renderExamResults().

   Sync is best-effort and is explicitly a synchronization
   layer, not the source of truth: it never blocks, delays, or
   alters what the student sees on the results page, and it
   never generates or duplicates a certificate.
   ============================================================ */

/* ---------- 0. Configuration --------------------------------
   Single, clearly-defined constant — replace this one line if
   the Apps Script Web App URL ever changes.
   ------------------------------------------------------------ */
const GOOGLE_SHEET_URL = "https://script.google.com/macros/s/AKfycbwdAR3nH6hd3j5xMvX3n459_Lr30KltEI3x0hWd9C-QubeL6ge91TK8N3fAWeIsqN7ToQ/exec";

/* ---------- 1. Local dedupe + retry storage -------------------
   Isolated from every other storage key in the app (its own
   namespace, like certificate.js's CERT_* keys). Two things are
   tracked:
   - which result "keys" have already been sent successfully
     (so the exact same final result is never sent twice)
   - a small retry queue for results that failed to send because
     of a genuine network-level problem (offline, DNS, blocked
     host) — retried automatically on next load / reconnect,
     never silently dropped.
   ------------------------------------------------------------ */
const SHEET_SYNCED_KEY = "abhinash_sheet_synced_v1";
const SHEET_QUEUE_KEY = "abhinash_sheet_sync_queue_v1";

function sheetLoadSyncedSet() {
  try { return new Set(JSON.parse(localStorage.getItem(SHEET_SYNCED_KEY) || "[]")); }
  catch (e) { return new Set(); }
}
function sheetSaveSyncedSet(set) {
  try { localStorage.setItem(SHEET_SYNCED_KEY, JSON.stringify(Array.from(set))); } catch (e) { /* storage full/blocked */ }
}
function sheetMarkSynced(key) {
  const set = sheetLoadSyncedSet();
  set.add(key);
  sheetSaveSyncedSet(set);
}
function sheetAlreadySynced(key) {
  return sheetLoadSyncedSet().has(key);
}

function sheetLoadQueue() {
  try { return JSON.parse(localStorage.getItem(SHEET_QUEUE_KEY) || "[]"); }
  catch (e) { return []; }
}
function sheetSaveQueue(queue) {
  try { localStorage.setItem(SHEET_QUEUE_KEY, JSON.stringify(queue)); } catch (e) { /* storage full/blocked */ }
}
function sheetQueueForRetry(key, payload) {
  const queue = sheetLoadQueue().filter(item => item.key !== key);
  queue.push({ key, payload, queuedAt: new Date().toISOString() });
  sheetSaveQueue(queue);
}
function sheetRemoveFromQueue(key) {
  sheetSaveQueue(sheetLoadQueue().filter(item => item.key !== key));
}

/* ---------- 2. Dedupe key -------------------------------------
   Uses the EXISTING certificate ID as the unique identifier
   whenever a certificate was issued — no second ID is invented.
   For exams that aren't certificate-eligible (no certificateId
   exists to key off), a composite of that attempt's own timing
   and result figures is used instead, purely as a local dedupe
   key — this is never sent as, or confused with, a certificate
   ID.
   ------------------------------------------------------------ */
function sheetBuildSyncKey(result) {
  if (result.certificateId) return "cert:" + result.certificateId;
  return "exam:" + [result._examStartTime, result.totalQuestions, result.correctAnswers, result.wrongAnswers, result.marks].join("|");
}

function sheetBuildPayload(result) {
  const payload = {};
  Object.keys(result).forEach((k) => { if (k.charAt(0) !== "_") payload[k] = result[k]; });
  return payload;
}

/* ---------- 3. Transport ---------------------------------------
   text/plain (not application/json) keeps this a CORS "simple
   request" so Apps Script's doPost() receives it without a
   preflight OPTIONS request, which plain Apps Script web apps
   don't handle. The tradeoff: the response is opaque to this
   page (mode: "no-cors"), so a resolved promise means the
   request was dispatched, not that Apps Script/Sheets confirmed
   the write. Only genuine network-level failures (offline, DNS,
   blocked host) cause this to reject — that's the only failure
   signal available client-side against an Apps Script Web App,
   so it's what duplicate-prevention and the retry queue key off.
   ------------------------------------------------------------ */
function sheetPostResult(payload) {
  return fetch(GOOGLE_SHEET_URL, {
    method: "POST",
    mode: "no-cors",
    headers: { "Content-Type": "text/plain;charset=utf-8" },
    body: JSON.stringify(payload),
  });
}

/* ---------- 4. Main entry point ---------------------------------
   Call once per finished result (app.js guards this per exam
   attempt). Safe to call again for the same result — already-
   synced and already-queued results are skipped, never resent.
   Returns a promise so the caller can reflect real status in the
   UI instead of assuming success.
   ------------------------------------------------------------ */
function sheetSyncExamResult(result) {
  const key = sheetBuildSyncKey(result);
  if (sheetAlreadySynced(key)) return Promise.resolve({ status: "already-synced" });
  if (sheetLoadQueue().some((item) => item.key === key)) return Promise.resolve({ status: "queued" });

  const payload = sheetBuildPayload(result);
  return sheetPostResult(payload).then(() => {
    sheetMarkSynced(key);
    sheetRemoveFromQueue(key);
    return { status: "sent" };
  }).catch((err) => {
    console.error("[Sheet Sync] Failed to send exam result to Google Sheets — will retry later.", err);
    sheetQueueForRetry(key, payload);
    return { status: "failed", error: err };
  });
}

/* ---------- 5. Retry queue processing ---------------------------
   Runs at load and whenever the browser regains connectivity.
   Never touches results that already synced; never invents or
   duplicates a certificate — it only resends the exact payload
   that failed to send the first time.
   ------------------------------------------------------------ */
function sheetProcessQueue() {
  const queue = sheetLoadQueue();
  if (!queue.length) return;
  queue.forEach((item) => {
    if (sheetAlreadySynced(item.key)) { sheetRemoveFromQueue(item.key); return; }
    sheetPostResult(item.payload).then(() => {
      sheetMarkSynced(item.key);
      sheetRemoveFromQueue(item.key);
    }).catch((err) => {
      console.error("[Sheet Sync] Retry failed — still queued.", err);
    });
  });
}

if (document.readyState !== "loading") sheetProcessQueue();
else document.addEventListener("DOMContentLoaded", sheetProcessQueue);
window.addEventListener("online", sheetProcessQueue);
