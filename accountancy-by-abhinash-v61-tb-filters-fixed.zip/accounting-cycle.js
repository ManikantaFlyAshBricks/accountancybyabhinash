/* ============================================================
   ACCOUNTING CYCLE ENGINE — draft / test harness
   ============================================================ */

function acRound2(n) { return Math.round((n + Number.EPSILON) * 100) / 100; }
function acFmt(n) {
  if (n === null || n === undefined || isNaN(n)) return "0";
  const r = acRound2(n);
  return r % 1 === 0 ? r.toLocaleString("en-IN") : r.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

/* ---------- DATE RECOGNITION ----------
   Dates (1-Apr, 01/04/2026, 1st April, etc.) must never leak into amount
   extraction — "1-Apr" has no business becoming ₹1. Every date pattern is
   stripped out before acExtractAmounts ever looks at the text. */
const AC_MONTH_RE = "(jan(uary)?|feb(ruary)?|mar(ch)?|apr(il)?|may|jun(e)?|jul(y)?|aug(ust)?|sep(t|tember)?|oct(ober)?|nov(ember)?|dec(ember)?)";
const AC_DATE_RE = new RegExp(
  "\\b\\d{1,2}(st|nd|rd|th)?[\\s\\-/.]{1,2}" + AC_MONTH_RE + "\\b" +          // 1-Apr, 01 April, 1st April
  "|\\b" + AC_MONTH_RE + "[\\s\\-/.]{1,2}\\d{1,2}(st|nd|rd|th)?\\b" +          // Apr 1, April 1st
  "|\\b\\d{1,2}[\\-/.]\\d{1,2}[\\-/.]\\d{2,4}\\b" +                            // 01/04/2026, 1-4-2026, 1.4.2026
  "|\\b\\d{1,2}[\\-/]\\d{1,2}\\b(?!\\d)",                                      // 1/4 (day/month, no year)
  "gi"
);
function acExtractDate(text) {
  const re = new RegExp(AC_DATE_RE.source, "gi");
  const m = re.exec(text);
  return m ? m[0].trim() : null;
}
function acStripDates(text) {
  return text.replace(new RegExp(AC_DATE_RE.source, "gi"), " ");
}
const AC_MONTH_NAMES = { jan: "January", feb: "February", mar: "March", apr: "April", may: "May", jun: "June", jul: "July", aug: "August", sep: "September", oct: "October", nov: "November", dec: "December" };
const AC_MONTH_LIST = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
// Turns whatever date form was actually typed ("1-Apr", "01/04/2026",
// "1st April") into a consistent "Month Day[, Year]" display — never
// inventing a year that wasn't stated.
function acNormalizeDate(raw) {
  const s = raw.trim();
  let m = /^(\d{1,2})(?:st|nd|rd|th)?[\s\-/.]{1,2}([a-z]+)/i.exec(s);
  if (m) {
    const key = m[2].slice(0, 3).toLowerCase();
    if (AC_MONTH_NAMES[key]) return `${AC_MONTH_NAMES[key]} ${parseInt(m[1], 10)}`;
  }
  m = /^([a-z]+)[\s\-/.]{1,2}(\d{1,2})/i.exec(s);
  if (m) {
    const key = m[1].slice(0, 3).toLowerCase();
    if (AC_MONTH_NAMES[key]) return `${AC_MONTH_NAMES[key]} ${parseInt(m[2], 10)}`;
  }
  m = /^(\d{1,2})[\-/.](\d{1,2})[\-/.](\d{2,4})$/.exec(s);
  if (m) {
    const day = parseInt(m[1], 10), monNum = parseInt(m[2], 10);
    const monName = AC_MONTH_LIST[monNum - 1];
    let year = m[3]; if (year.length === 2) year = "20" + year;
    if (monName) return `${monName} ${day}, ${year}`;
  }
  m = /^(\d{1,2})[\-/](\d{1,2})$/.exec(s);
  if (m) {
    const day = parseInt(m[1], 10), monNum = parseInt(m[2], 10);
    const monName = AC_MONTH_LIST[monNum - 1];
    if (monName) return `${monName} ${day}`;
  }
  return s;
}

/* ---------- SIGNAL EXTRACTION ---------- */

// Find every "N%" token together with a short window of text around it,
// so the caller can decide *which* percentage (GST / trade discount /
// cash discount / profit / depreciation / interest / claim) it is from
// context words, rather than assuming positional order.
function acExtractPercents(text) {
  const clean = acStripDates(text);
  const out = [];
  const re = /([\d]+(?:\.\d+)?)\s*%/g;
  let m;
  while ((m = re.exec(clean))) {
    const value = parseFloat(m[1]);
    const start = Math.max(0, m.index - 28);
    const end = Math.min(clean.length, m.index + m[0].length + 12);
    out.push({ value, window: clean.slice(start, end).toLowerCase(), index: m.index });
  }
  return out;
}

function acPercentFor(percents, keywords) {
  for (const p of percents) {
    if (keywords.some(k => p.window.includes(k))) return p.value;
  }
  return 0;
}

// Like acPercentFor but for plain amounts — picks whichever extracted
// amount sits closest to one of the given keywords, so a sentence with
// two figures (e.g. "existing provision ₹2,000 ... new provision
// ₹3,000") can tell them apart by proximity rather than raw order.
function acAmountNear(text, amounts, keywords) {
  const lower = text.toLowerCase();
  let best = null, bestDist = Infinity;
  keywords.forEach(k => {
    const idx = lower.indexOf(k);
    if (idx === -1) return;
    const kwEnd = idx + k.length;
    amounts.forEach(a => {
      // Strongly prefer an amount that follows the keyword (its natural
      // position — "new provision required ₹3,000") over one that
      // merely happens to sit fewer characters away in an earlier
      // sentence ("...was ₹2,000. New provision...").
      const dist = a.index >= kwEnd ? (a.index - kwEnd) : (idx - a.index) + 100000;
      if (dist < bestDist) { bestDist = dist; best = a.value; }
    });
  });
  return best;
}

// Money amounts: ₹ / Rs prefixed, or bare Indian-grouped numbers of at
// least 3 digits. Percentage tokens are stripped first so "18%" never
// gets mistaken for an amount.
function acStripDurations(text) {
  // "after 15 days" / "in 3 months" / "within 2 years" is a time period,
  // never a monetary amount — without this, "balance after 15 days on
  // credit" was extracting ₹15 as a second transaction amount.
  return text.replace(/\b\d+\s*(days?|d\.|months?|mos?\.|years?|yrs?\.|weeks?|wks?\.)\b/gi, " ");
}
function acExtractAmounts(text) {
  const noDates = acStripDates(text);
  const noDurations = acStripDurations(noDates);
  const stripped = noDurations.replace(/[\d.]+\s*%/g, " ");
  const re = /(?:₹|rs\.?\s*|inr\s*)?([\d][\d,]*(?:\.\d+)?)/gi;
  const out = [];
  let m;
  while ((m = re.exec(stripped))) {
    const num = parseFloat(m[1].replace(/,/g, ""));
    if (isNaN(num)) continue;
    if (num < 1) continue; // ignore stray "1" from things like "a/c"
    out.push({ value: num, index: m.index });
  }
  return out;
}

const AC_STOPWORDS = new Set(["Cash","Bank","Rent","Salary","Sold","Paid","Received","Purchased","Goods","Credit","The","A","An","Furniture",
  "Machinery","Loan","Interest","Discount","Depreciation","Insurance","Started","Business","Old","Book","Value","Full","Settlement","Bill",
  "Balance","Bought","Cheque","Advance","Later","Compensation","Amount","Commission","Payment","Official","Receiver","Computer","Building",
  "Deposited","Withdrew","Issued","Given","Introduced","Sent","Supplied","Placed","Charged","Made","Returned","Gave","Took","Transferred",
  "GST","CGST","SGST","IGST","Fire","Theft","Charity","Donation","Wages","Carriage","Freight","Electricity","Stationery","Printing",
  "Advertisement","Vehicle","Land","Stock","Investment","Drawings","Capital","Debtor","Creditor","Provision","Bad","Debts","Recovered",
  "Outstanding","Prepaid","Accrued","Opened","Account","Personal","Use","Rs","Claim","Admitted","Commenced","Introduced","Total",
  "Recovered","Wrote","Written","Off","Him","Her","Them","Their","His","Its","Repaid","Dishonoured","Dishonored","Insolvent","Marked",
  "Trade","Installation","Charges","Welfare","Employees","Office","Purposes","Free","Samples","Distributed","Destroyed","Stolen",
  "Company","Prepare","Opening","Following","Beginning","Year","Assets","Liabilities","Repairs","Allowed","Settled","Sales","Purchases"]);
function acIsMonthWord(w) {
  const lw = w.toLowerCase();
  return AC_MONTH_NAMES.hasOwnProperty(lw) || AC_MONTH_LIST.some(m => m.toLowerCase() === lw);
}
function acExtractParty(text) {
  // Strip dates first — "6-Apr: Paid Ram..." was otherwise picking up
  // "Apr" as the party name (it's capitalised and not a stopword), which
  // silently broke every date-prefixed transaction involving a party.
  const cleaned = acStripDates(text);
  const words = cleaned.replace(/[₹,]/g, " ").split(/\s+/);
  for (let i = 0; i < words.length; i++) {
    const w = words[i].replace(/[^a-zA-Z]/g, "");
    if (w.length > 2 && /^[A-Z]/.test(w) && !AC_STOPWORDS.has(w) && !acIsMonthWord(w)) {
      const w2 = (words[i + 1] || "").replace(/[^a-zA-Z]/g, "");
      if (w2.length > 2 && /^[A-Z]/.test(w2) && !AC_STOPWORDS.has(w2) && !acIsMonthWord(w2)) return w + " " + w2;
      return w;
    }
  }
  return null;
}

function acHasAny(text, list) { return list.some(k => text.includes(k)); }

const AC_ASSET_WORDS = [
  ["furniture", "Furniture"], ["machinery", "Machinery"], ["plant", "Plant"], ["building", "Building"],
  ["computer", "Computer"], ["laptop", "Computer"], ["vehicle", "Vehicle"], ["motor car", "Vehicle"], ["car", "Vehicle"],
  ["land", "Land"], ["investment", "Investment"], ["goodwill", "Goodwill"],
  ["office equipment", "Office Equipment"], ["equipment", "Equipment"]
];
const AC_EXPENSE_WORDS = [
  ["salary", "Salary"], ["salaries", "Salary"], ["wages", "Wages"], ["rent", "Rent"], ["electricity", "Electricity Charges"],
  ["telephone", "Telephone Charges"], ["printing", "Printing & Stationery"], ["stationery", "Printing & Stationery"],
  ["advertisement", "Advertisement"], ["fire insurance premium", "Insurance Premium"], ["insurance premium", "Insurance Premium"], ["insurance", "Insurance Premium"],
  ["carriage inward", "Carriage Inwards"], ["carriage outward", "Carriage Outwards"], ["carriage", "Carriage"],
  ["freight", "Freight"], ["repair", "Repairs"], ["postage", "Postage & Courier"], ["conveyance", "Conveyance"],
  ["travelling", "Travelling Expenses"], ["legal charges", "Legal Charges"], ["audit fee", "Audit Fee"],
  ["general expenses", "General Expenses"], ["miscellaneous expenses", "Miscellaneous Expenses"], ["donation", "Donation"],
  ["charity", "Charity"], ["interest on loan", "Interest on Loan"], ["bank service charges", "Bank Charges"], ["collection charges", "Bank Charges"], ["bank charges", "Bank Charges"],
  ["renewal charges", "Renewal Charges"], ["commission", "Commission Paid"],
  ["municipal tax", "Municipal Tax"], ["property tax", "Property Tax"], ["road tax", "Vehicle Registration & Road Tax"],
  ["vehicle registration", "Vehicle Registration & Road Tax"], ["vehicle servicing", "Vehicle Running & Maintenance"],
  ["vehicle repair", "Vehicle Running & Maintenance"], ["vehicle running", "Vehicle Running & Maintenance"],
  ["internet", "Internet & Broadband Expenses"], ["broadband", "Internet & Broadband Expenses"],
  ["provident fund", "Staff Provident Fund Contribution"],
  ["office expenses", "Office Expenses"], ["loading charges", "Loading Charges"], ["unloading charges", "Unloading Charges"],
  ["delivery charges", "Delivery Charges"], ["cartage", "Cartage"], ["water charges", "Water Charges"],
  ["cleaning charges", "Cleaning Charges"], ["packing charges", "Packing Charges"], ["octroi", "Octroi"],
  ["import duty", "Import Duty"], ["custom duty", "Custom Duty"], ["entertainment expenses", "Entertainment Expenses"]
];
const AC_INCOME_WORDS = [
  ["commission received", "Commission Received"], ["commission", "Commission Received"],
  ["interest received", "Interest Received"], ["interest", "Interest Received"],
  ["rent received", "Rent Received"], ["rent", "Rent Received"],
  ["dividend received", "Dividend Received"], ["dividend", "Dividend Received"], ["discount received", "Discount Received"],
  ["subscription received", "Subscription Received"], ["subscription", "Subscription Received"]
];

function acFindLabel(text, dict) {
  for (const [kw, label] of dict) if (text.includes(kw)) return label;
  return null;
}

// Business name / opening-balance line normalisation for the "opening
// journal entry" pattern (a comma-separated list of assets & liabilities,
// not a single-transaction sentence — handled entirely separately from
// the main rule chain below).
const AC_OPENING_LIABILITY_KEYWORDS = ["creditor", "loan", "overdraft", "payable", "outstanding", "provision for doubtful", "provision for bad", "provision for depreciation", "accumulated depreciation", "income received in advance"];
const AC_OPENING_NAME_MAP = {
  "cash": "Cash", "cash in hand": "Cash", "cash balance": "Cash",
  "bank balance": "Bank", "bank": "Bank", "cash at bank": "Bank", "bank overdraft": "Bank Overdraft",
  "stock": "Stock", "closing stock": "Stock", "opening stock": "Stock", "furniture": "Furniture",
  "debtors": "Debtors", "sundry debtors": "Debtors", "creditors": "Creditors", "sundry creditors": "Creditors",
  "loan": "Loan", "machinery": "Machinery", "building": "Building", "investment": "Investment",
  "goodwill": "Goodwill", "computer": "Computer", "vehicle": "Vehicle", "bills receivable": "Bills Receivable",
  "bills payable": "Bills Payable", "plant": "Plant"
};
// Section headers ("Assets:", "Liabilities:", "Debtors:", "Creditors:",
// "Capital:") that a textbook opening-balances paragraph is built from.
// Recognising these directly — rather than requiring the phrase "opening
// entry" to appear literally — is what lets a question phrased purely as
// "Assets: ...; Liabilities: ...;" (with no such phrase at all) still be
// understood as opening balances instead of failing as an ordinary,
// unparseable transaction line.
const AC_OPENING_HEADER_RE = /\b(assets|liabilities|debtors|sundry debtors|creditors|sundry creditors|capital)\s*:/gi;
// A plain list of "AccountName ₹Amount" lines — no verbs, no sentence
// structure — with no "Assets:"/"Liabilities:" headers and no "opening
// entry" phrase anywhere, e.g. a student just typing:
//   Cash ₹40,000
//   Bank ₹60,000
//   Creditors ₹35,000
// This is still unambiguously an opening-balances list; the only
// question is whether each line is a bare "name + amount" and there are
// enough of them that it can't reasonably be anything else.
const AC_BARE_OPENING_LINE_RE = /^[A-Za-z][A-Za-z &.'/]*\s+(?:₹|rs\.?|inr)?\s*[\d,]+(?:\.\d+)?\s*\.?\s*$/i;
// Excludes ordinary transaction sentences that happen to also fit the
// bare "words + trailing amount" shape (e.g. "Paid rent ₹5,000") — an
// opening-balance line is just an account name, never a verb-led
// sentence, so any of these words disqualifies it.
const AC_TRANSACTION_VERB_RE = /\b(paid|pay|sold|purchased|bought|received|receive|deposited|withdrew|withdrawn|withdraw|returned|allowed|charged|settled|started|commenced|introduced|issued|given|transferred|wrote|written|took|taken|spent|donated|distributed|destroyed|lost|damaged|insured|posted)\b/i;
function acIsBareOpeningLine(s) {
  return AC_BARE_OPENING_LINE_RE.test(s) && !AC_TRANSACTION_VERB_RE.test(s);
}
function acLooksLikeBareOpeningList(rawText) {
  const segments = rawText.split(/[;\n]+/).map(s => s.trim()).filter(Boolean);
  if (segments.length < 3) return false;
  // A leading date segment ("1-Apr") is fine and doesn't count against
  // the "every segment must be an account line" check — it carries no
  // amount, so the item-extraction step further down just skips it.
  const accountSegments = segments.filter(s => !acIsDateOnlyLine(s));
  if (accountSegments.length < 3) return false;
  return accountSegments.every(s => acIsBareOpeningLine(s));
}
// Matches a line that's ONLY a date (optionally with a trailing colon),
// e.g. "1-Apr:", "1-Apr", "On 1 April:" — used so a date line that
// precedes an opening-balance list gets folded into the entry instead
// of standing alone as its own unparseable "transaction".
function acIsDateOnlyLine(s) {
  const stripped = s.replace(/^on\s+/i, "").replace(/[:\-–]\s*$/, "").trim();
  const found = acExtractDate(stripped);
  return found !== null && found === stripped;
}
function acParseOpeningEntry(rawText, idx) {
  const hasHeader = new RegExp(AC_OPENING_HEADER_RE.source, "i").test(rawText);
  const hasTriggerPhrase = /opening journal entry|opening entry|assets and liabilities at the beginning/i.test(rawText);
  const isBareList = acLooksLikeBareOpeningList(rawText);
  if (!hasHeader && !hasTriggerPhrase && !isBareList) return null;

  const cleaned = rawText.replace(/^.*?(?:beginning of the year|as follows)\s*:?\s*/i, "");

  // Split the text into section chunks on each recognised header, so
  // every item is classified by the heading that actually introduced it
  // (an item like "Ashok ₹13,500" carries no liability keyword of its
  // own — it only reads as a liability because it sits under
  // "Liabilities: Creditors:").
  const headerMatches = [...cleaned.matchAll(AC_OPENING_HEADER_RE)];
  const parts = [];
  if (!headerMatches.length) {
    parts.push({ header: "assets", text: cleaned });
  } else {
    if (headerMatches[0].index > 0) {
      const lead = cleaned.slice(0, headerMatches[0].index).trim();
      if (lead) parts.push({ header: "assets", text: lead });
    }
    headerMatches.forEach((mm, i) => {
      const start = mm.index + mm[0].length;
      const end = i + 1 < headerMatches.length ? headerMatches[i + 1].index : cleaned.length;
      parts.push({ header: mm[1].toLowerCase(), text: cleaned.slice(start, end) });
    });
  }

  const items = [];
  let explicitCapital = null;
  parts.forEach(p => {
    if (p.header === "capital") {
      const numMatch = p.text.match(/([\d][\d,]*(?:\.\d+)?)/);
      if (numMatch) explicitCapital = parseFloat(numMatch[1].replace(/,/g, ""));
      return;
    }
    const isLiabSection = /^(liabilit|creditor)/.test(p.header);
    const re = /([A-Za-z][A-Za-z ]*?)\s*(?:of\s*)?₹\s*([\d,]+(?:\.\d+)?)/g;
    let im;
    while ((im = re.exec(p.text))) {
      let label = im[1].trim().replace(/^(and|of)\s+/i, "").trim().toLowerCase();
      const amount = parseFloat(im[2].replace(/,/g, ""));
      if (!label || isNaN(amount)) continue;
      items.push({ label, amount, isLiabSection });
    }
  });
  if (items.length < 2) return null; // not actually this pattern — fall through to normal parsing

  const lines = [];
  let totalAssets = 0, totalLiabs = 0;
  items.forEach(it => {
    const name = AC_OPENING_NAME_MAP[it.label] || (it.label.charAt(0).toUpperCase() + it.label.slice(1));
    const isLiab = it.isLiabSection || AC_OPENING_LIABILITY_KEYWORDS.some(k => it.label.includes(k));
    if (isLiab) { lines.push({ account: name + " A/c", cr: it.amount }); totalLiabs = acRound2(totalLiabs + it.amount); }
    else { lines.push({ account: name + " A/c", dr: it.amount }); totalAssets = acRound2(totalAssets + it.amount); }
  });

  // Capital = Assets − Liabilities, auto-calculated — unless the question
  // already gives a capital figure that's consistent with that
  // arithmetic, in which case the stated figure is used as-is rather
  // than silently recomputing over it.
  const derivedCapital = acRound2(totalAssets - totalLiabs);
  const capital = (explicitCapital !== null && Math.abs(explicitCapital - derivedCapital) < 0.5) ? explicitCapital : derivedCapital;
  if (capital >= 0) lines.push({ account: "Capital A/c", cr: capital });
  else lines.push({ account: "Capital A/c", dr: -capital });

  return { ok: true, index: idx, text: rawText, lines, narration: "Opening entry", tag: "opening" };
}

// A textbook opening-balances paragraph is sometimes typed as several
// separate lines (one for Assets, one for Debtors, one for
// Liabilities/Creditors) rather than one block. Each such line is
// meaningless as a standalone transaction, so consecutive lines that
// each start with a recognised opening-balance header are merged into a
// single combined line before per-line parsing — this is purely about
// grouping the *input*; acParseOpeningEntry above still does all the
// actual accounting.
// A line is "all bare items" if every semicolon-separated piece of it
// looks like a plain "AccountName ₹Amount" — this is what lets a line
// like "Cash ₹60,000; Bank ₹90,000; Stock ₹1,20,000;" (several items
// packed onto one line, as students often paste them) be recognised,
// not just one bare item per line.
function acAllBareItems(s) {
  const segs = s.split(";").map(x => x.trim()).filter(Boolean);
  if (!segs.length) return false;
  return segs.every(x => acIsBareOpeningLine(x));
}
function acCountItems(s) {
  return s.split(";").map(x => x.trim()).filter(Boolean).length;
}
// A "leader" line carries no account/amount data of its own — just a
// date and/or the phrase "Opening balances:" — e.g. "1-Apr: Opening
// balances:". It gets folded into whatever opening-balance content
// follows rather than standing alone as its own empty transaction.
function acIsLeaderLine(s) {
  const withoutDate = acStripDates(s).replace(/[:\-–]/g, " ").trim();
  const hasDate = acExtractDate(s) !== null;
  const isJustOpeningPhrase = /^(on\s+)?(opening\s+(balances?|entry|journal entry))?$/i.test(withoutDate);
  return isJustOpeningPhrase && (hasDate || /opening/i.test(s));
}
function acMergeOpeningBalanceLines(rawLines) {
  const headerStartRe = /^\s*(assets|liabilities|debtors|sundry debtors|creditors|sundry creditors)\s*:/i;
  const out = [];
  let i = 0;
  while (i < rawLines.length) {
    let datePrefix = "";
    let startIdx = i;
    if (acIsLeaderLine(rawLines[i]) && i + 1 < rawLines.length && (headerStartRe.test(rawLines[i + 1]) || acAllBareItems(rawLines[i + 1]))) {
      const d = acExtractDate(rawLines[i]);
      datePrefix = (d ? d : "") + "; ";
      startIdx = i + 1;
    }
    if (headerStartRe.test(rawLines[startIdx])) {
      const group = [rawLines[startIdx]];
      let j = startIdx + 1;
      while (j < rawLines.length && headerStartRe.test(rawLines[j])) { group.push(rawLines[j]); j++; }
      out.push(datePrefix + group.join("; "));
      i = j;
    } else if (acAllBareItems(rawLines[startIdx])) {
      // A run of lines that are each entirely made of "AccountName
      // ₹Amount" items (one item per line, or several packed onto one
      // line) — merge the whole run into a single opening entry once
      // there are at least 3 items total.
      const group = [rawLines[startIdx]];
      let itemCount = acCountItems(rawLines[startIdx]);
      let j = startIdx + 1;
      while (j < rawLines.length && acAllBareItems(rawLines[j])) { group.push(rawLines[j]); itemCount += acCountItems(rawLines[j]); j++; }
      if (itemCount >= 3) {
        out.push(datePrefix + group.join("; "));
        i = j;
      } else {
        out.push(rawLines[i]);
        i++;
      }
    } else {
      out.push(rawLines[i]);
      i++;
    }
  }
  return out;
}

/* ---------- ONE-LINE PARSER ---------- */
// ctx (optional) carries state across the transactions in one run — the
// only cases that need it are ones later lines rely on without repeating
// a figure (e.g. "Deposited the cheque into bank." after an earlier
// "received a cheque ... ₹X" line).
function acParseTransaction(rawText, idx, ctx) {
  const original = rawText.trim();
  if (!original) return null;

  ctx = ctx || {};
  ctx.assetBook = ctx.assetBook || {};
  // A date stated on this line becomes "the current date" for any
  // following undated lines too, the same way a real journal only
  // writes a new date when it actually changes.
  const foundDate = acExtractDate(original);
  if (foundDate) ctx.lastDate = acNormalizeDate(foundDate);
  const date = ctx.lastDate || null;

  const openingResult = acParseOpeningEntry(original, idx);
  if (openingResult) { openingResult.date = date; return openingResult; }
  let text = " " + original.toLowerCase() + " ";
  text = text.replace(/\brs\.?\s*(?=[\d₹])/g, "₹").replace(/\binr\b/g, "₹");

  const percents = acExtractPercents(text);
  const amounts = acExtractAmounts(text);
  let party = acExtractParty(original);
  let partyFromContext = false;
  // Contextual resolution: "Allowed her discount ₹500" or "Later paid
  // ₹42,750 in full settlement" (no name, no pronoun at all) both refer
  // back to whoever the previous transaction was about — a very common
  // exam-question convention where a follow-up settlement line doesn't
  // re-name the party. ctx.lastParty is only ever set from a party this
  // engine genuinely just transacted with, never guessed, so this stays
  // safe even without a pronoun to trigger on.
  if (!party && ctx.lastParty && (/\b(her|his|their|him|them)\b/.test(text) || /full settlement|final settlement|\bsettled\b|in settlement/.test(text))) {
    party = ctx.lastParty;
    partyFromContext = true;
  }

  const isGstInclusive = /including gst|inclusive of gst|gst inclusive|incl\.?\s*gst|gst incl\.?/.test(text);
  const cgstPctExplicit = acPercentFor(percents, ["cgst"]);
  const sgstPctExplicit = acPercentFor(percents, ["sgst"]);
  const igstPctExplicit = acPercentFor(percents, ["igst"]);
  const gstPct = acPercentFor(percents, ["gst"]);
  const isIGST = text.includes("igst") || text.includes("inter-state") || text.includes("interstate") || text.includes("outside the state") || text.includes("other state");
  const tradeDiscPct = acPercentFor(percents, ["trade discount", "trade disc"]);
  const cashDiscPct = acPercentFor(percents, ["cash discount", "cash disc"]);
  const depPct = acPercentFor(percents, ["depreciat", "written down", "wdv"]);
  const claimPct = acPercentFor(percents, ["claim", "admitted", "accepted by insurance", "insurance company admitted"]);
  const provPct = acPercentFor(percents, ["provision", "doubtful"]);

  // Mode: an explicit "in cash/by cash/for cash", "cheque", or "credit"
  // phrase wins over a bare mention of "bank" — a sentence can say
  // "loan from the bank in cash" where "bank" is naming the lender, not
  // the mode, so the more specific phrasing must take priority.
  const mode =
    /\bon credit\b|\bcredit\b/.test(text) ? "credit" :
    /\bcheque\b|\bchq\b/.test(text) ? "cheque" :
    /\bin cash\b|\bby cash\b|\bfor cash\b/.test(text) ? "cash" :
    /\bbank\b/.test(text) ? "bank" :
    /\bcash\b/.test(text) ? "cash" :
    (party ? "credit" : "cash");

  const isBadDebtRecovered = /recovered/.test(text) && /(bad debt|written off|wrote off)/.test(text) && !/could not|unable to|not recoverable|declared insolvent/.test(text);
  const isInsolvent = /insolvent/.test(text);
  const partyReturned = party && new RegExp("\\b" + party.toLowerCase().split(" ")[0] + "\\s+returned").test(text);

  const flags = {
    isReturn: /\breturn/.test(text),
    isPurchaseReturn: /\breturn/.test(text) && (/return(ed)?\b[\s\S]{0,40}\bto\s+(?!₹|rs\.?\s*\d|\d)/.test(text) || /purchase return/.test(text) || /returned.*(supplier|creditor)/.test(text) || (/return/.test(text) && /purchas/.test(text))),
    isSalesReturn: /\breturn/.test(text) && (/return(ed)?\b[\s\S]{0,40}\bby\b/.test(text) || /sales return/.test(text) || /returned.*(customer|debtor)/.test(text) || partyReturned || (/return/.test(text) && !/purchas/.test(text) && !/return(ed)?\b[\s\S]{0,40}\bto\s+(?!₹|rs\.?\s*\d|\d)/.test(text) && /sold|sale|customer|debtor/.test(text))),
    isManagersCommission: /manager/.test(text) && /commission/.test(text),
    isGstSetOff: /set.?off|adjust(ed|ing)?\s+(the\s+)?(input|output)?\s*gst/.test(text) && /gst/.test(text),
    isGstLiabilityPayment: /gst/.test(text) && /liabilit/.test(text) && /\bpaid\b|\bpay\b/.test(text),
    isProvisionDiscountCreditors: /provision for discount on creditors/.test(text),
    isFireTheft: (/\bfire\b|\btheft\b|\bstolen\b|\bburgl|\baccident\b|\bgoods lost\b|\bflood\b/.test(text)) && !/premium/.test(text),
    isCharity: /\bcharity\b|\bdonat/.test(text) && /goods/.test(text),
    isFreeSamples: (/free sample|free gift|\bsamples?\b|market research/.test(text)) && /goods/.test(text),
    isStaffWelfare: (/welfare|staff gift|canteen/.test(text) || (/distributed/.test(text) && /employees/.test(text))) && /goods/.test(text),
    isOfficeUse: /(office purpose|for office use|used for office)/.test(text) && /goods/.test(text),
    isDrawingsGoods: /goods.*(personal use|own use|personal purpose|drawings)|withdrew goods|goods withdrawn/.test(text),
    // Broad enough to catch "for the proprietor's personal use" / "for
    // his own personal expenses" etc — not just the narrower "for
    // personal use" phrased with nothing in between — since a
    // possessive noun between "for" and "personal/own/private" is
    // common exam phrasing and must not fall through undetected.
    isDrawingsCash: /(withdrew|drew|took)\b[\s\S]{0,40}\b(personal|own|private)\b[\s\S]{0,15}\b(use|expenses?|purposes?)\b|cash withdrawn for personal|drawings/.test(text) && !/goods/.test(text),
    isBadDebtRecovered,
    isBadDebt: (/written off|wrote off|could not be recovered|unable to recover|irrecoverable|insolvent|became (a )?bad debt|is a bad debt|as bad debt/.test(text)) && !isBadDebtRecovered && !isInsolvent,
    isInsolvent,
    isProvisionDD: /provision for doubtful debts|provision for bad/.test(text),
    isProvisionDiscount: /provision for discount/.test(text) && !/provision for discount on creditors/.test(text),
    isDepreciation: /depreciat/.test(text) && !(/\bsold\b/.test(text) && /(furniture|machinery|plant|computer|building|vehicle|land|investment|goodwill|equipment|\basset\b|car)/.test(text)),
    isSettlingOutstanding: /outstanding/.test(text) && /\bpaid\b|\bpay\b/.test(text),
    isOutstanding: /outstanding|unpaid|due but not paid|yet to be paid/.test(text),
    isPrepaid: /prepaid/.test(text) || (/in advance/.test(text) && /\bpaid\b|\bpay\b/.test(text)),
    isAccruedIncome: /accrued|earned but not received|due but not received|due but was not received|became due/.test(text),
    isIncomeAdvance: /received in advance|advance received/.test(text) || (/in advance/.test(text) && /\breceived\b|\breceive\b/.test(text)),
    isContraDeposit: (/deposited.*(bank|into bank)/.test(text) && /bank/.test(text) && !/cheque/.test(text)) || (/\bpaid\b.*(into|to) (the )?bank/.test(text) && /\bcash\b/.test(text) && !/cheque/.test(text)),
    isContraWithdrawBank: /withdr\w*[\s\S]{0,25}bank|bank[\s\S]{0,15}withdr\w*/.test(text) && !/personal|own use|private use|for himself|for herself|\bdrawings\b/.test(text),
    isOpenedBank: /opened a?\s*(bank|current|savings) account/.test(text),
    isCapitalIntro: /commenced business|business commenced|started business|business started|started (his|her|the)? ?business|business (was )?started|introduced.*capital|capital introduced|brought in.*capital/.test(text),
    isAdditionalCapital: /additional capital|further capital/.test(text),
    isInterestOnCapital: /interest on capital/.test(text),
    isInterestOnDrawings: /interest on drawings/.test(text),
    isBankInterestAllowed: /bank allowed interest|interest allowed by bank|bank credited interest/.test(text),
    isLoanTaken: /loan (taken|obtained|borrowed)|took (a )?loan|borrowed.*loan|loan from/.test(text) && !/repaid|repayment/.test(text),
    isLoanGiven: /loan given|granted a loan|loan to\b|advanced a loan|gave a loan/.test(text),
    isLoanRepaymentReceived: /received/.test(text) && /repayment/.test(text) && /loan/.test(text),
    isLoanRepaid: /repaid.*loan|loan repaid|repayment of (a |the )?loan/.test(text),
    isFullSettlement: /full settlement|in full settlement|settled?\s+(his|her|their|the)?\s*account|final settlement/.test(text),
    isAssetSale: /\bsold\b/.test(text) && /(furniture|machinery|plant|computer|building|vehicle|land|investment|goodwill|equipment|\basset\b|car)/.test(text),
    isInstallationCapitalize: /installation|legal charges|brokerage|registration charges|stamp duty/.test(text),
    isClaimAdmitted: /admitted (a )?claim|claim (was |is )?admitted/.test(text),
    isClaimReceived: /received the insurance claim|insurance claim received|received.*claim.*(cheque|cash|bank)/.test(text),
    isClaimRejected: /claim.*rejected|rejected.*claim/.test(text),
    isPartialClaim: /insurance claim/.test(text) && /goods lost/.test(text),
    isDishonoured: /dishonour|dishonor/.test(text),
    isChequeReceived: /cheque/.test(text) && /received/.test(text) && /from/.test(text) && !/dishonour|dishonor/.test(text) && !/full settlement|final settlement/.test(text),
    // "Bank directly credited interest..." / "Bank charges were debited
    // directly by the bank" — the money movement happens inside the
    // bank statement itself, with no cash/cheque changing hands, so
    // these need their own recognition distinct from an ordinary
    // "paid"/"received" transaction.
    isBankDirectCredit: /\bbank\b/.test(text) && /directly/.test(text) && /credit/.test(text) && !/charges?\b/.test(text),
    isBankDirectDebit: /\bbank\b/.test(text) && (/directly/.test(text) && /debit/.test(text) || (/charges?\b/.test(text) && /\bdebited\b/.test(text))),
    isChequeDeposited: /deposited/.test(text) && /cheque/.test(text) && /bank/.test(text),
    isChequeIssued: /issued (a |the )?cheque/.test(text) && /\bto\b/.test(text),
    isDebtorDepositedBank: /debtor/.test(text) && /deposited/.test(text) && /bank/.test(text),
    isChequeEndorsed: /endorsed/.test(text) && /cheque/.test(text),
    isChequeSentForCollection: /sent (a |the )?cheque/.test(text) && /collection/.test(text) && !/collected/.test(text),
    isChequeCollected: /collected/.test(text) && /collection/.test(text),
    isGift: /gift/.test(text) && /received/.test(text),
    isGoodsSentApproval: /sent on approval/.test(text) && !/accepted/.test(text) && !/returned/.test(text),
    isGoodsApprovalAccepted: /approval/.test(text) && /accepted/.test(text),
    isGoodsApprovalReturned: /approval/.test(text) && /returned/.test(text),
    isAdvancePaidSupplier: /\bpaid\b/.test(text) && /advance/.test(text) && /supplier/.test(text) && !/against/.test(text),
    isAdvanceReceivedCustomer: /received/.test(text) && /advance/.test(text) && /customer/.test(text) && !/against/.test(text),
    isGoodsAgainstAdvancePaid: /goods/.test(text) && /supplier/.test(text) && /advance/.test(text) && /against/.test(text),
    isGoodsAgainstAdvanceReceived: /goods/.test(text) && /customer/.test(text) && /advance/.test(text) && /against/.test(text),
    isBillReceivableReceived: /bill receivable/.test(text) && /received/.test(text) && !/dishonour|dishonor/.test(text),
    isBillPayableAccepted: /bill payable/.test(text) && /accepted/.test(text),
    isBillReceivableDishonoured: /bill receivable/.test(text) && /dishonour|dishonor/.test(text),
    isBillPayablePaid: /bill payable/.test(text) && (/\bpaid\b/.test(text) || /maturity/.test(text)) && !/accepted/.test(text) && !/charges/.test(text) && !/renewal/.test(text),
    isBillDiscounted: /bill receivable/.test(text) && /discount/.test(text) && /received/.test(text) && /bank/.test(text),
    isDiscountedBillDishonoured: /discounted bill/.test(text) && /dishonour|dishonor/.test(text),
    isRebateByCreditor: /creditor/.test(text) && /rebate/.test(text),
    isRebateToCustomer: /customer/.test(text) && /rebate/.test(text),
    isExpensePaidPersonally: /(proprietor|owner)/.test(text) && /(personally|personal account|personal fund)/.test(text) && /paid/.test(text) && !/income tax/.test(text),
    // An item that is inherently the *proprietor's own* — their life
    // insurance, personal school fees, personal shopping — paid for out
    // of business cash is a withdrawal of business funds for personal
    // use (Drawings), never a business expense, even though the item
    // itself (e.g. "insurance premium") would otherwise map to a normal
    // expense account.
    isProprietorPersonalItem: /(life insurance|insurance premium|\binsurance\b|school fees|tuition fees|college fees|household expenses|personal expenses|personal shopping|medical expenses|medical bills)/.test(text)
      && /(of the proprietor|of the owner|proprietor'?s|owner'?s|for the proprietor|for the owner|for himself|for herself)/.test(text)
      && !/income tax/.test(text),
    isMiscIncomeSale: /\bsold\b/.test(text) && /(old newspapers?|newspapers?|scrap|waste paper|empty (bags|bottles|cartons|tins)|packing material)/.test(text),
    isIncomeTaxFromPersonal: /income tax/.test(text) && /(personal account|personal fund)/.test(text),
    isIncomeTaxFromBusiness: /income tax/.test(text) && /\bpaid\b/.test(text) && !/(personal account|personal fund)/.test(text)
  };

  const isGoods = /\bgoods\b/.test(text);
  // Bare "cash sales"/"credit purchases" style shorthand — common exam
  // phrasing that names no "goods" at all — is still an ordinary goods
  // transaction, not an ambiguous one.
  // Broad enough to catch "purchased"/"bought"/"sold" as verbs too, not
  // just the bare "sales"/"purchases" nouns — "Purchased from Ram
  // ₹50,000..." has neither "goods" nor the noun form "purchases", but
  // is unambiguously a goods purchase.
  const isBareSaleOrPurchase = /\bpurchas\w*\b|\bbought\b|\bsold\b|\bsales?\b/.test(text) && !/purchases? return|sales? return/.test(text);
  const assetLabel = acFindLabel(text, AC_ASSET_WORDS);
  const expenseLabel = acFindLabel(text, AC_EXPENSE_WORDS);
  const incomeLabel = acFindLabel(text, AC_INCOME_WORDS);

  const amt = amounts.length ? amounts[0].value : null;
  const amt2 = amounts.length > 1 ? amounts[1].value : null;
  // A percentage of the total described as what was "paid"/"received" —
  // computed early since several of the flags below need it to decide
  // whether a split payment/receipt was expressed as a percentage
  // rather than (or in addition to) an absolute rupee figure.
  // Deliberately tight: only matches "paid 50%" / "received 40%" where
  // the percentage directly follows the verb — NOT the loose
  // nearest-percent search used elsewhere, because a sentence can
  // legitimately have an unrelated percentage (a GST rate, a trade
  // discount) sitting close to the word "paid" without being the
  // portion paid (e.g. "...GST 18%, paid ₹50,000 by bank..." must not
  // read "18%" as the paid portion just because "paid" follows nearby).
  const partialPortionMatch = /\b(?:paid|received)\s+(\d+(?:\.\d+)?)\s*%/i.exec(text);
  const partialPortionPct = partialPortionMatch ? parseFloat(partialPortionMatch[1]) : 0;
  // "...paid ₹50,000 by bank and the balance on credit" — the second
  // extracted amount is the portion actually paid now; the rest of the
  // total stays with the party as a credit balance, split across two
  // credit lines instead of dumping the whole amount onto one account.
  const isSplitPayment = /\bpaid\b/.test(text) && /(balance|remaining|rest|difference)/.test(text) && /credit/.test(text) && (amt2 !== null || (partialPortionPct > 0 && partialPortionPct < 100));
  const isSplitReceipt = /received\b/.test(text) && /(balance|remaining|rest|difference)/.test(text) && /credit/.test(text) && (amt2 !== null || (partialPortionPct > 0 && partialPortionPct < 100));
  // For a split payment/receipt, the sentence often legitimately contains
  // both "bank" (how the paid portion moved) AND "credit" (describing the
  // unpaid remainder) — the general `mode` variable above prioritises
  // "credit" in that case, so the paid portion's own cash/bank mode is
  // detected separately, scoped to just the "paid ... by ..." phrase.
  const splitPaidAcc = /paid\b[\s\S]{0,20}\b(bank|cheque|chq)\b/.test(text) ? "Bank A/c" : "Cash A/c";
  const splitReceivedAcc = /received\b[\s\S]{0,20}\b(bank|cheque|chq)\b/.test(text) ? "Bank A/c" : "Cash A/c";
  // "...12% trade discount. Paid 40% immediately and received 6% cash
  // discount on that portion." — a percentage of the (already
  // trade-discounted) net amount is paid now, with cash discount on
  // just that paid slice; the rest stays owed to the party. This is a
  // distinct pattern from isSplitPayment above, which uses an absolute
  // rupee figure and no cash discount on the partial.
  const isPartialPortionWithCashDisc = partialPortionPct > 0 && partialPortionPct < 100 && cashDiscPct > 0;
  const isTwoWaySplitPay = amt2 !== null && /\bpaid\b/.test(text) && /\bbank\b/.test(text) && /\bcash\b/.test(text) && !/full settlement|final settlement|discount/.test(text);

  /* ---------- General payment-split engine ----------------------
     Used by BOTH fixed-asset and goods purchases so the same
     transaction shape ("paid p% cash, q% bank/cheque, balance on
     credit", with or without trade/cash discount) resolves correctly
     for any asset, amount, percentage, or payment-method combination
     instead of only a fixed set of sample wordings.

     Percentages already claimed by trade discount / cash discount
     (matched by object identity, not value, so a coincidental equal
     value never causes a false exclusion) are excluded first, so a
     "10% trade discount" mentioned earlier in the sentence never gets
     misread as a cash/bank payment percentage just because the word
     "discount" sits inside its lookup window.
     ------------------------------------------------------------ */
  const tradeDiscObj = percents.find(p => ["trade discount", "trade disc"].some(k => p.window.includes(k))) || null;
  const cashDiscObj = percents.find(p => ["cash discount", "cash disc"].some(k => p.window.includes(k))) || null;
  // A payment percentage's mode word often sits well past the fixed
  // ±28/+12-char window used for GST/discount-rate lookups — "50%
  // immediately by cash" puts "cash" ~20 chars after the "%" sign. So
  // each percent here gets its own forward-scanning window instead,
  // bounded by wherever the NEXT percent in the sentence starts (so a
  // dual "40% by cheque, 30% by cash" never bleeds into each other's
  // clause), capped at 60 chars for a lone percent.
  function acForwardModeKeyword(p, keywords) {
    const i = percents.indexOf(p);
    const nextIdx = i >= 0 && i + 1 < percents.length ? percents[i + 1].index : text.length;
    const windowEnd = Math.min(nextIdx, p.index + 60, text.length);
    let fwd = text.slice(p.index, windowEnd).toLowerCase();
    // "the balance" starts a new clause describing the REMAINDER's mode
    // (handled separately via balanceMode below) — never part of what
    // this specific percent itself was paid in, so it must not leak a
    // false cash/bank match onto this percent (e.g. "50% by cash and
    // balance by cheque" must not also read this same 50% as a bank %).
    const balanceIdx = fwd.indexOf("balance");
    if (balanceIdx !== -1) fwd = fwd.slice(0, balanceIdx);
    return keywords.some(k => fwd.includes(k));
  }
  const splitCashPct = (percents.find(p => p !== tradeDiscObj && p !== cashDiscObj && acForwardModeKeyword(p, ["cash"])) || { value: 0 }).value;
  const splitBankPct = (percents.find(p => p !== tradeDiscObj && p !== cashDiscObj && acForwardModeKeyword(p, ["bank", "cheque", "chq"])) || { value: 0 }).value;
  // "Balance on credit" / "balance after 15 days" / "balance after one
  // month" (Rule 6) all mean the remainder is a creditor/debtor balance.
  // "Balance by cheque"/"balance by bank"/"balance in cash" instead mean
  // the *remainder* — not a further percentage — is settled immediately
  // through that specific mode, with no credit portion at all.
  const balanceModeMatch = /balance[\s\S]{0,25}?\b(on credit|after|by cheque|by chq|through bank|by bank|in cash|by cash|credit)\b/.exec(text);
  const balanceMode = balanceModeMatch
    ? (/cheque|chq|bank/.test(balanceModeMatch[1]) ? "bank" : /in cash|by cash/.test(balanceModeMatch[1]) ? "cash" : "credit")
    : null;
  // Returns null when no cash/bank payment percentage was stated at all,
  // so callers keep their existing single full-mode / full-credit
  // handling for those (unchanged) cases. Only engages once at least one
  // explicit cash%/bank% is present in the sentence.
  function acSplitPaymentPortions(total) {
    if (splitCashPct <= 0 && splitBankPct <= 0) return null;
    let cashAmt = acRound2(total * splitCashPct / 100);
    let bankAmt = acRound2(total * splitBankPct / 100);
    let creditAmt = 0;
    const explicitSum = splitCashPct + splitBankPct;
    if (explicitSum < 100) {
      const remainder = acRound2(total - cashAmt - bankAmt);
      if (balanceMode === "bank") bankAmt = acRound2(bankAmt + remainder);
      else if (balanceMode === "cash") cashAmt = acRound2(cashAmt + remainder);
      else creditAmt = remainder; // default: a stated remainder with no other mode named is a credit balance
    }
    return { cashAmt, bankAmt, creditAmt };
  }

  const lines = [];
  let narration = original;
  let tag = "unclassified";

  function bothSidesOk() {
    const dr = acRound2(lines.reduce((s, l) => s + (l.dr || 0), 0));
    const cr = acRound2(lines.reduce((s, l) => s + (l.cr || 0), 0));
    return Math.abs(dr - cr) < 0.01;
  }

  function gstSplitLines(baseAmount, forPurchase) {
    // "₹11,800 including GST @18%" — the stated figure already contains
    // GST, so it must be backed out to the taxable value first rather
    // than adding GST on top of it a second time.
    let workingBase = baseAmount;
    if (isGstInclusive) {
      const inclusiveRate = isIGST ? (igstPctExplicit || gstPct)
        : (cgstPctExplicit > 0 || sgstPctExplicit > 0) ? (cgstPctExplicit || sgstPctExplicit) + (sgstPctExplicit || cgstPctExplicit)
        : gstPct;
      if (inclusiveRate) workingBase = acRound2(baseAmount / (1 + inclusiveRate / 100));
    }
    if (isIGST) {
      const pct = igstPctExplicit || gstPct;
      if (!pct) return { total: baseAmount, gstLines: [] };
      const gstAmt = isGstInclusive ? acRound2(baseAmount - workingBase) : acRound2(workingBase * pct / 100);
      return { total: isGstInclusive ? baseAmount : acRound2(workingBase + gstAmt), gstLines: [{ account: forPurchase ? "Input IGST A/c" : "Output IGST A/c", amount: gstAmt }], taxableValue: workingBase };
    }
    if (cgstPctExplicit > 0 || sgstPctExplicit > 0 || (isGstInclusive && gstPct)) {
      // CGST and SGST were each stated as their own explicit rate (e.g.
      // "CGST 9% and SGST 9%") — apply each directly. This must never be
      // halved again on top of an already-per-side rate, which was the
      // earlier bug: a bare combined "GST 18%" gets split in half below,
      // but two explicitly-separate 9% rates are not a combined rate.
      const cPct = cgstPctExplicit || acRound2(gstPct / 2);
      const sPct = sgstPctExplicit || acRound2(gstPct / 2);
      const cAmt = acRound2(workingBase * cPct / 100);
      const sAmt = acRound2(workingBase * sPct / 100);
      return { total: isGstInclusive ? baseAmount : acRound2(workingBase + cAmt + sAmt), gstLines: [
        { account: forPurchase ? "Input CGST A/c" : "Output CGST A/c", amount: cAmt },
        { account: forPurchase ? "Input SGST A/c" : "Output SGST A/c", amount: sAmt }
      ], taxableValue: workingBase };
    }
    if (!gstPct) return { total: baseAmount, gstLines: [] };
    const gstAmt = acRound2(workingBase * gstPct / 100);
    const half = acRound2(gstAmt / 2);
    return { total: acRound2(workingBase + gstAmt), gstLines: [
      { account: forPurchase ? "Input CGST A/c" : "Output CGST A/c", amount: half },
      { account: forPurchase ? "Input SGST A/c" : "Output SGST A/c", amount: acRound2(gstAmt - half) }
    ], taxableValue: workingBase };
  }

  const cashOrBank = (mode === "bank" || mode === "cheque") ? "Bank A/c" : "Cash A/c";
  const paidToTargetHasTo = /paid\b[\s\S]{0,25}\bto\b/.test(text) || (/issued\b[\s\S]{0,15}\bcheque\b[\s\S]{0,15}\bto\b/.test(text));
  const paidPartyDirect = party && new RegExp("\\bpaid\\b[\\s\\S]{0,15}\\b" + party.toLowerCase().split(" ")[0] + "\\b").test(text);
  // "Anas settled his account by cheque" — Anas is the grammatical
  // subject of "settled"/"paid", meaning Anas is the one paying the
  // business (a debtor receipt), the mirror image of "Paid to Ashok..."
  // where the business is doing the paying (a creditor payment). This is
  // what lets the two be told apart without needing "received...from".
  const partySettledSelf = party && new RegExp("^\\s*" + party.split(" ")[0] + "\\s+(settled|paid|has paid|has settled)\\b", "i").test(original);

  // ---- RULE MATCHING (ordered — most specific first) ----

  if (flags.isCapitalIntro && amt !== null) {
    tag = "capital";
    // Try to match every known asset-type word actually present in the
    // sentence to its own nearest amount — not just the first two
    // numbers found — so "cash X, stock Y, and machinery Z" keeps all
    // three straight instead of losing one and mislabeling another.
    const CAPITAL_ASSET_SYNONYMS = [
      ["cash", "Cash"], ["bank", "Bank"], ["stock", "Stock"], ["goods", "Goods (Stock)"],
      ["furniture", "Furniture"], ["machinery", "Machinery"], ["plant", "Plant"], ["building", "Building"],
      ["land", "Land"], ["vehicle", "Vehicle"], ["computer", "Computer"], ["equipment", "Equipment"],
      ["investment", "Investment"], ["goodwill", "Goodwill"]
    ];
    const seenLabels = new Set(), seenAmounts = new Set();
    const multiItems = [];
    CAPITAL_ASSET_SYNONYMS.forEach(([kw, label]) => {
      if (!text.includes(kw)) return;
      const near = acAmountNear(text, amounts, [kw]);
      if (near === null || seenLabels.has(label) || seenAmounts.has(near)) return;
      seenLabels.add(label); seenAmounts.add(near);
      multiItems.push({ label, amount: near });
    });
    let capitalTotal = 0;
    if (multiItems.length >= 2) {
      multiItems.forEach(it => {
        lines.push({ account: it.label + " A/c", dr: it.amount });
        capitalTotal += it.amount;
        if (it.label !== "Cash" && it.label !== "Bank") ctx.assetBook[it.label] = (ctx.assetBook[it.label] || 0) + it.amount;
      });
    } else if (assetLabel && !/\bcash\b|\bbank\b/.test(text)) {
      lines.push({ account: assetLabel + " A/c", dr: amt });
      capitalTotal += amt;
      ctx.assetBook[assetLabel] = (ctx.assetBook[assetLabel] || 0) + amt;
    } else {
      lines.push({ account: mode === "bank" ? "Bank A/c" : "Cash A/c", dr: amt });
      capitalTotal += amt;
      if (amt2 !== null && isGoods) { lines.push({ account: "Goods (Stock) A/c", dr: amt2 }); capitalTotal += amt2; }
      else if (amt2 !== null && assetLabel) { lines.push({ account: assetLabel + " A/c", dr: amt2 }); capitalTotal += amt2; ctx.assetBook[assetLabel] = (ctx.assetBook[assetLabel] || 0) + amt2; }
    }
    lines.push({ account: "Capital A/c", cr: acRound2(capitalTotal) });
  }

  else if (flags.isGift && amt !== null) {
    tag = "capital";
    if (assetLabel) lines.push({ account: assetLabel + " A/c", dr: amt });
    else lines.push({ account: "Purchases A/c", dr: amt });
    lines.push({ account: "Capital A/c", cr: amt });
  }

  else if (flags.isChequeEndorsed && amt !== null) {
    tag = "debtor";
    const m = original.match(/from\s+([A-Z][a-zA-Z]*)\s+to\s+([A-Z][a-zA-Z]*)/);
    const fromParty = m ? m[1] : "Debtors";
    const toParty = m ? m[2] : "Creditors";
    lines.push({ account: toParty + " A/c", dr: amt });
    lines.push({ account: fromParty + " A/c", cr: amt });
  }

  else if (flags.isChequeSentForCollection && amt !== null) {
    tag = "debtor";
    const acctName = party || "Debtors";
    lines.push({ account: "Cheques Sent for Collection A/c", dr: amt });
    lines.push({ account: acctName + " A/c", cr: amt });
  }

  else if (flags.isChequeCollected && amt !== null) {
    tag = "contra";
    lines.push({ account: "Bank A/c", dr: amt });
    lines.push({ account: "Cheques Sent for Collection A/c", cr: amt });
  }

  else if (flags.isDebtorDepositedBank && amt !== null) {
    tag = "debtor";
    const acctName = party || "Debtors";
    lines.push({ account: "Bank A/c", dr: amt });
    lines.push({ account: acctName + " A/c", cr: amt });
  }

  else if (flags.isRebateByCreditor && amt !== null) {
    tag = "creditor";
    const acctName = party || "Creditors";
    lines.push({ account: acctName + " A/c", dr: amt });
    lines.push({ account: "Discount Received A/c", cr: amt });
  }

  else if (flags.isRebateToCustomer && amt !== null) {
    tag = "debtor";
    const acctName = party || "Debtors";
    lines.push({ account: "Discount Allowed A/c", dr: amt });
    lines.push({ account: acctName + " A/c", cr: amt });
  }

  else if (flags.isLoanRepaymentReceived && amt !== null) {
    tag = "loan";
    const borrower = party ? party : "";
    lines.push({ account: cashOrBank, dr: amt });
    lines.push({ account: borrower ? "Loan to " + borrower + " A/c" : "Loan A/c", cr: amt });
  }

  else if (flags.isProprietorPersonalItem && amt !== null) {
    tag = "drawings";
    lines.push({ account: "Drawings A/c", dr: amt });
    lines.push({ account: cashOrBank, cr: amt });
  }

  else if (flags.isExpensePaidPersonally && amt !== null) {
    tag = "expense";
    lines.push({ account: (expenseLabel || "General Expenses") + " A/c", dr: amt });
    lines.push({ account: "Capital A/c", cr: amt });
  }

  else if (flags.isIncomeTaxFromPersonal) {
    return { ok: false, index: idx, text: original, reason: "Income tax paid by the proprietor from personal funds does not affect the business books — no journal entry required." };
  }

  else if (flags.isIncomeTaxFromBusiness && amt !== null) {
    tag = "drawings";
    lines.push({ account: "Drawings A/c", dr: amt });
    lines.push({ account: cashOrBank, cr: amt });
  }

  else if (flags.isAdditionalCapital && amt !== null) {
    tag = "capital";
    lines.push({ account: mode === "bank" ? "Bank A/c" : "Cash A/c", dr: amt });
    lines.push({ account: "Capital A/c", cr: amt });
  }

  else if (flags.isOpenedBank && amt !== null) {
    tag = "contra";
    lines.push({ account: "Bank A/c", dr: amt });
    lines.push({ account: "Cash A/c", cr: amt });
  }

  else if (flags.isContraDeposit && amt !== null) {
    tag = "contra";
    lines.push({ account: "Bank A/c", dr: amt });
    lines.push({ account: "Cash A/c", cr: amt });
  }

  else if (flags.isContraWithdrawBank && amt !== null) {
    tag = "contra";
    lines.push({ account: "Cash A/c", dr: amt });
    lines.push({ account: "Bank A/c", cr: amt });
  }

  else if (flags.isLoanRepaid && amt !== null) {
    tag = "loan";
    lines.push({ account: "Loan A/c", dr: amt });
    lines.push({ account: cashOrBank, cr: amt });
  }

  else if (flags.isDrawingsCash && amt !== null) {
    tag = "drawings";
    lines.push({ account: "Drawings A/c", dr: amt });
    lines.push({ account: cashOrBank, cr: amt });
  }

  else if (flags.isDrawingsGoods && amt !== null) {
    tag = "drawings";
    lines.push({ account: "Drawings A/c", dr: amt });
    lines.push({ account: "Purchases A/c", cr: amt });
  }

  else if (flags.isInterestOnCapital && amt !== null) {
    tag = "adjustment";
    lines.push({ account: "Interest on Capital A/c", dr: amt });
    lines.push({ account: "Capital A/c", cr: amt });
  }

  else if (flags.isInterestOnDrawings && amt !== null) {
    tag = "adjustment";
    lines.push({ account: "Capital A/c", dr: amt });
    lines.push({ account: "Interest on Drawings A/c", cr: amt });
  }

  else if (flags.isBankInterestAllowed && amt !== null) {
    tag = "income";
    lines.push({ account: "Bank A/c", dr: amt });
    lines.push({ account: "Interest Received A/c", cr: amt });
  }

  else if (flags.isSettlingOutstanding && amt !== null && expenseLabel) {
    tag = "adjustment";
    lines.push({ account: "Outstanding " + expenseLabel + " A/c", dr: amt });
    lines.push({ account: cashOrBank, cr: amt });
  }

  else if (flags.isInstallationCapitalize && amt !== null && assetLabel) {
    tag = "asset";
    lines.push({ account: assetLabel + " A/c", dr: amt });
    lines.push({ account: cashOrBank, cr: amt });
    ctx.assetBook[assetLabel] = (ctx.assetBook[assetLabel] || 0) + amt;
  }

  else if (flags.isCharity && amt !== null) {
    tag = "goods";
    lines.push({ account: "Charity/Donation A/c", dr: amt });
    lines.push({ account: "Purchases A/c", cr: amt });
  }

  else if (flags.isFreeSamples && amt !== null) {
    tag = "goods";
    lines.push({ account: "Free Samples A/c", dr: amt });
    lines.push({ account: "Purchases A/c", cr: amt });
  }

  else if (flags.isStaffWelfare && amt !== null) {
    tag = "goods";
    lines.push({ account: "Staff Welfare Expenses A/c", dr: amt });
    lines.push({ account: "Purchases A/c", cr: amt });
  }

  else if (flags.isOfficeUse && amt !== null) {
    tag = "goods";
    lines.push({ account: "Office Expenses A/c", dr: amt });
    lines.push({ account: "Purchases A/c", cr: amt });
  }

  else if (flags.isClaimAdmitted && amt !== null) {
    tag = "loss";
    lines.push({ account: "Insurance Claim A/c", dr: amt });
    lines.push({ account: "Loss by Fire/Theft A/c", cr: amt });
  }

  else if (flags.isClaimReceived && amt !== null) {
    tag = "loss";
    lines.push({ account: cashOrBank, dr: amt });
    lines.push({ account: "Insurance Claim A/c", cr: amt });
  }

  else if (flags.isPartialClaim && amt !== null && amt2 !== null) {
    tag = "loss";
    const claimAmt = Math.min(amt, amt2), totalLoss = Math.max(amt, amt2);
    const uninsuredLoss = acRound2(totalLoss - claimAmt);
    lines.push({ account: cashOrBank, dr: claimAmt });
    if (uninsuredLoss > 0) lines.push({ account: "Loss by Fire/Theft A/c", dr: uninsuredLoss });
    lines.push({ account: "Purchases A/c", cr: totalLoss });
  }

  else if (flags.isFireTheft && amt !== null) {
    tag = "loss";
    if (claimPct > 0) {
      const claimAmt = acRound2(amt * claimPct / 100);
      const lossAmt = acRound2(amt - claimAmt);
      lines.push({ account: "Insurance Claim A/c", dr: claimAmt });
      lines.push({ account: "Loss by Fire/Theft A/c", dr: lossAmt });
      lines.push({ account: "Purchases A/c", cr: amt });
    } else if (/no claim|not admitted|rejected|no insurance/.test(text)) {
      lines.push({ account: "Loss by Fire/Theft A/c", dr: amt });
      lines.push({ account: "Purchases A/c", cr: amt });
    } else if (/insur/.test(text)) {
      return { ok: false, index: idx, text: original, reason: "Goods lost by fire/theft — insurance is mentioned but the % of claim admitted isn't stated." };
    } else {
      // no insurance mentioned at all -> straightforward uninsured loss
      lines.push({ account: "Loss by Fire/Theft A/c", dr: amt });
      lines.push({ account: "Purchases A/c", cr: amt });
    }
  }

  else if (flags.isGoodsSentApproval && amt !== null) {
    tag = "goods";
    lines.push({ account: "Goods sent on Approval A/c", dr: amt });
    lines.push({ account: "Purchases A/c", cr: amt });
  }

  else if (flags.isGoodsApprovalAccepted && amt !== null) {
    tag = "goods";
    const acctName = party || "Debtors";
    lines.push({ account: acctName + " A/c", dr: amt });
    lines.push({ account: "Sales A/c", cr: amt });
    lines.push({ account: "Purchases A/c", dr: amt });
    lines.push({ account: "Goods sent on Approval A/c", cr: amt });
  }

  else if (flags.isGoodsApprovalReturned && amt !== null) {
    tag = "goods";
    lines.push({ account: "Purchases A/c", dr: amt });
    lines.push({ account: "Goods sent on Approval A/c", cr: amt });
  }

  else if (flags.isAdvancePaidSupplier && amt !== null) {
    tag = "creditor";
    lines.push({ account: "Advance to Supplier A/c", dr: amt });
    lines.push({ account: cashOrBank, cr: amt });
  }

  else if (flags.isAdvanceReceivedCustomer && amt !== null) {
    tag = "debtor";
    lines.push({ account: cashOrBank, dr: amt });
    lines.push({ account: "Advance from Customer A/c", cr: amt });
  }

  else if (flags.isGoodsAgainstAdvancePaid && amt !== null) {
    tag = "goods";
    lines.push({ account: "Purchases A/c", dr: amt });
    lines.push({ account: "Advance to Supplier A/c", cr: amt });
  }

  else if (flags.isGoodsAgainstAdvanceReceived && amt !== null) {
    tag = "goods";
    lines.push({ account: "Advance from Customer A/c", dr: amt });
    lines.push({ account: "Sales A/c", cr: amt });
  }

  else if (!amt && cashDiscPct > 0 && isGoods) {
    return { ok: false, index: idx, text: original, reason: "Cash discount given only as a % — state the base amount so the discount can be computed." };
  }

  else if (flags.isPurchaseReturn && amt !== null) {
    tag = "goods";
    const { total, gstLines } = gstSplitLines(amt, true);
    const partyAcc = party ? party + " A/c" : "Creditors A/c";
    lines.push({ account: partyAcc, dr: total });
    lines.push({ account: "Purchase Returns A/c", cr: amt });
    gstLines.forEach(g => lines.push({ account: g.account, cr: g.amount }));
  }

  else if (flags.isSalesReturn && amt !== null) {
    tag = "goods";
    const { total, gstLines } = gstSplitLines(amt, false);
    const partyAcc = party ? party + " A/c" : "Debtors A/c";
    lines.push({ account: "Sales Returns A/c", dr: amt });
    gstLines.forEach(g => lines.push({ account: g.account, dr: g.amount }));
    lines.push({ account: partyAcc, cr: total });
  }

  else if (flags.isBillDiscounted && amt !== null) {
    tag = "debtor";
    const acctName = party || "Debtors";
    lines.push({ account: "Bank A/c", dr: amt });
    lines.push({ account: acctName + " A/c", cr: amt });
  }

  else if (flags.isDiscountedBillDishonoured && amt !== null) {
    tag = "debtor";
    const acctName = party || "Debtors";
    lines.push({ account: acctName + " A/c", dr: amt });
    lines.push({ account: "Bank A/c", cr: amt });
  }

  else if (flags.isBillReceivableDishonoured && amt !== null) {
    tag = "debtor";
    const acctName = party || "Debtors";
    lines.push({ account: acctName + " A/c", dr: amt });
    lines.push({ account: "Bills Receivable A/c", cr: amt });
  }

  else if (flags.isBillReceivableReceived && amt !== null) {
    tag = "debtor";
    const acctName = party || "Debtors";
    lines.push({ account: "Bills Receivable A/c", dr: amt });
    lines.push({ account: acctName + " A/c", cr: amt });
  }

  else if (flags.isBillPayableAccepted && amt !== null) {
    tag = "creditor";
    const acctName = party || "Creditors";
    lines.push({ account: acctName + " A/c", dr: amt });
    lines.push({ account: "Bills Payable A/c", cr: amt });
  }

  else if (flags.isBillPayablePaid && amt !== null) {
    tag = "creditor";
    lines.push({ account: "Bills Payable A/c", dr: amt });
    lines.push({ account: cashOrBank, cr: amt });
  }

  else if (flags.isDishonoured && amt !== null) {
    tag = "debtor";
    const acctName = party || "Debtors";
    lines.push({ account: acctName + " A/c", dr: amt });
    lines.push({ account: "Bank A/c", cr: amt });
  }

  else if (flags.isChequeReceived && amt !== null) {
    tag = "debtor";
    const acctName = party || "Debtors";
    lines.push({ account: "Cheques in Hand A/c", dr: amt });
    lines.push({ account: acctName + " A/c", cr: amt });
    ctx.lastChequeAmount = amt;
  }

  else if (flags.isChequeDeposited) {
    const depositAmt = amt !== null ? amt : ctx.lastChequeAmount;
    if (depositAmt == null) {
      return { ok: false, index: idx, text: original, reason: "No amount given, and there's no earlier 'received a cheque' transaction to take the amount from." };
    }
    tag = "contra";
    lines.push({ account: "Bank A/c", dr: depositAmt });
    lines.push({ account: "Cheques in Hand A/c", cr: depositAmt });
  }

  else if (flags.isInsolvent && amt !== null) {
    tag = "debtor";
    const acctName = party || "Debtors";
    const a2 = amt2 !== null ? amt2 : 0;
    const recovered = Math.min(amt, a2 || amt);
    const owed = Math.max(amt, a2 || amt);
    const badPortion = acRound2(owed - recovered);
    lines.push({ account: cashOrBank, dr: recovered });
    if (badPortion > 0) lines.push({ account: "Bad Debts A/c", dr: badPortion });
    lines.push({ account: acctName + " A/c", cr: owed });
  }

  else if (flags.isBadDebtRecovered && amt !== null) {
    tag = "debtor";
    lines.push({ account: cashOrBank, dr: amt });
    lines.push({ account: "Bad Debts Recovered A/c", cr: amt });
  }

  else if (flags.isGstLiabilityPayment && amt !== null) {
    tag = "adjustment";
    lines.push({ account: "GST Payable A/c", dr: amt });
    lines.push({ account: cashOrBank, cr: amt });
  }

  else if (flags.isGstSetOff) {
    tag = "adjustment";
    const statedInput = acAmountNear(text, amounts, ["input gst", "input"]);
    const statedOutput = acAmountNear(text, amounts, ["output gst", "output"]);
    if (statedInput !== null && statedOutput !== null && statedInput !== statedOutput) {
      // The question gives Input/Output GST directly (not split by head)
      // — use those stated figures rather than whatever's been tracked
      // from earlier transactions, since an explicit figure in the
      // question always takes priority over an inferred one.
      const setoff = Math.min(statedInput, statedOutput);
      lines.push({ account: "Output GST A/c", dr: setoff });
      lines.push({ account: "Input GST A/c", cr: setoff });
      const remainder = acRound2(statedOutput - statedInput);
      if (remainder > 0) narration += ` (Input GST ₹${acFmt(statedInput)} fully set off; GST payable ₹${acFmt(remainder)} remains)`;
      else if (remainder < 0) narration += ` (Output GST ₹${acFmt(statedOutput)} fully set off; Input GST ₹${acFmt(-remainder)} carried forward)`;
      else narration += " (Input and Output GST fully set off against each other)";
    } else {
      const g = ctx.gstBalances || { inputCGST: 0, inputSGST: 0, inputIGST: 0, outputCGST: 0, outputSGST: 0, outputIGST: 0 };
      const setOffLines = [];
      ["CGST", "SGST", "IGST"].forEach(head => {
        const inp = g["input" + head] || 0, out = g["output" + head] || 0;
        const setoff = Math.min(inp, out);
        if (setoff > 0) {
          setOffLines.push({ account: "Output " + head + " A/c", dr: setoff });
          setOffLines.push({ account: "Input " + head + " A/c", cr: setoff });
        }
      });
      if (!setOffLines.length) {
        return { ok: false, index: idx, text: original, reason: "GST set-off — no Input/Output GST balances have been recorded yet from earlier transactions (or stated directly in this question) to set off against each other." };
      }
      lines.push(...setOffLines);
      narration += " (GST set-off applied within each tax head — CGST against CGST, SGST against SGST, IGST against IGST; assumes no cross-head utilization, since that depends on rules the question would need to state)";
    }
  }

  else if (flags.isBankDirectCredit && amt !== null) {
    tag = "income";
    // "Interest received" is the sensible default when the sentence
    // doesn't name a specific income type — incomeLabel picks the exact
    // one (interest/commission/rent/dividend) when it's stated.
    const acc = incomeLabel || "Interest Received";
    lines.push({ account: "Bank A/c", dr: amt });
    lines.push({ account: acc + (acc.endsWith("A/c") ? "" : " A/c"), cr: amt });
  }

  else if (flags.isBankDirectDebit && amt !== null) {
    tag = "expense";
    const acc = expenseLabel || "Bank Charges";
    lines.push({ account: acc + (acc.endsWith("A/c") ? "" : " A/c"), dr: amt });
    lines.push({ account: "Bank A/c", cr: amt });
  }

  else if (flags.isManagersCommission && amt !== null) {
    tag = "adjustment";
    const rate = acPercentFor(percents, ["commission", "manager"]);
    if (!rate) {
      return { ok: false, index: idx, text: original, reason: "Manager's commission — state the commission rate (%) as well as the net profit figure." };
    }
    const before = /before charging|before commission/.test(text);
    const after = /after charging|after commission/.test(text);
    if (!before && !after) {
      return { ok: false, index: idx, text: original, reason: "Manager's commission — please state whether it's calculated before or after charging such commission; the formula differs (before: Profit × Rate / 100, after: Profit × Rate / (100 + Rate))." };
    }
    const commission = before ? acRound2(amt * rate / 100) : acRound2(amt * rate / (100 + rate));
    narration += ` (${before ? "before" : "after"} charging commission: ₹${acFmt(amt)} × ${rate}${before ? "" : " / (100 + " + rate + ")"}% = ₹${acFmt(commission)})`;
    lines.push({ account: "Manager's Commission A/c", dr: commission });
    lines.push({ account: "Outstanding Manager's Commission A/c", cr: commission });
  }

  else if (flags.isBadDebt && /provision/.test(text) && !/discount/.test(text) && percents.length > 0 && amt !== null) {
    // A compound adjustment stating debtors, a bad-debts write-off, AND
    // a provision requirement together — the provision must be
    // calculated on debtors *after* deducting the bad debts just
    // written off, never on the raw debtors total.
    tag = "adjustment";
    const partyAcc = party ? party + " A/c" : "Debtors A/c";
    const debtorsFig = acAmountNear(text, amounts, ["debtors", "sundry debtors"]);
    const badDebtFig = acAmountNear(text, amounts, ["bad debts", "bad debt"]);
    const provPct = acPercentFor(percents, ["provision"]);
    if (debtorsFig === null || badDebtFig === null || !provPct) {
      return { ok: false, index: idx, text: original, reason: "Bad debts + provision — please state the debtors total, the bad debts amount, and the provision percentage so the adjusted provision can be calculated." };
    }
    const netDebtors = acRound2(debtorsFig - badDebtFig);
    const provision = acRound2(netDebtors * provPct / 100);
    lines.push({ account: "Bad Debts A/c", dr: badDebtFig });
    lines.push({ account: partyAcc, cr: badDebtFig });
    lines.push({ account: "Profit & Loss A/c", dr: provision });
    lines.push({ account: "Provision for Doubtful Debts A/c", cr: provision });
    narration += ` (debtors ₹${acFmt(debtorsFig)} − bad debts ₹${acFmt(badDebtFig)} = ₹${acFmt(netDebtors)}; provision at ${provPct}% = ₹${acFmt(provision)})`;
  }

  else if (flags.isBadDebt && amt !== null) {
    tag = "debtor";
    const partyAcc = party ? party + " A/c" : "Debtors A/c";
    // When the sentence also states a separate debtors/receivable total
    // (e.g. "Debtors ₹1,00,000. Bad debts ₹5,000 written off."), `amt`
    // being the *first* number in the sentence would grab the debtors
    // total rather than the actual bad-debts figure — so look for the
    // figure specifically tied to "bad debt(s)" first.
    const badDebtFig = acAmountNear(text, amounts, ["bad debts", "bad debt"]);
    const writeOff = badDebtFig !== null ? badDebtFig : amt;
    lines.push({ account: "Bad Debts A/c", dr: writeOff });
    lines.push({ account: partyAcc, cr: writeOff });
  }

  else if (flags.isProvisionDD && amt !== null) {
    tag = "adjustment";
    const oldProv = acAmountNear(text, amounts, ["existing provision", "old provision", "previous provision", "existing", "old", "previous"]);
    const newProv = acAmountNear(text, amounts, ["new provision", "required provision", "to be maintained", "provide for", "new", "required"]);
    if (oldProv !== null && newProv !== null && oldProv !== newProv) {
      // Only the *change* in provision is charged/released — never the
      // full new figure on top of an existing one.
      const diff = acRound2(newProv - oldProv);
      if (diff > 0) {
        lines.push({ account: "Profit & Loss A/c", dr: diff });
        lines.push({ account: "Provision for Doubtful Debts A/c", cr: diff });
      } else {
        lines.push({ account: "Provision for Doubtful Debts A/c", dr: -diff });
        lines.push({ account: "Profit & Loss A/c", cr: -diff });
      }
      narration += ` (existing provision ₹${acFmt(oldProv)}, new provision required ₹${acFmt(newProv)}; ${diff > 0 ? "increase" : "decrease"} of ₹${acFmt(Math.abs(diff))} adjusted)`;
    } else {
      lines.push({ account: "Profit & Loss A/c", dr: amt });
      lines.push({ account: "Provision for Doubtful Debts A/c", cr: amt });
    }
  }

  else if (flags.isProvisionDiscountCreditors && amt !== null) {
    tag = "adjustment";
    // The mirror image of Provision for Discount on Debtors: this is an
    // anticipated gain (a discount the business itself expects to
    // receive from creditors), so it's credited to Profit & Loss, not
    // debited like the debtor-side provision.
    lines.push({ account: "Provision for Discount on Creditors A/c", dr: amt });
    lines.push({ account: "Profit & Loss A/c", cr: amt });
  }

  else if (flags.isProvisionDiscount && amt !== null) {
    tag = "adjustment";
    lines.push({ account: "Profit & Loss A/c", dr: amt });
    lines.push({ account: "Provision for Discount on Debtors A/c", cr: amt });
  }

  else if (flags.isDepreciation && (amt !== null || (depPct && assetLabel))) {
    tag = "adjustment";
    const asset = assetLabel || "Asset";
    let depAmt = null;
    if (depPct && amt !== null) {
      // A rate was given alongside a figure — that figure is always the
      // asset's cost/book value the rate applies to, never the
      // depreciation amount itself. This is the single most dangerous
      // mistake this branch can make (treating ₹2,00,000 cost at 10% as
      // ₹2,00,000 depreciation), so it's checked first.
      depAmt = acRound2(amt * depPct / 100);
      narration += ` (₹${acFmt(amt)} × ${depPct}% = ₹${acFmt(depAmt)})`;
    } else if (depPct && assetLabel && ctx.assetBook[assetLabel] !== undefined && ctx.assetBook[assetLabel] > 0) {
      // No figure in this sentence at all — fall back to this asset's
      // tracked book value from an earlier purchase/depreciation entry.
      const base = ctx.assetBook[assetLabel];
      depAmt = acRound2(base * depPct / 100);
      narration += ` (₹${acFmt(base)} × ${depPct}% = ₹${acFmt(depAmt)}, based on the tracked book value)`;
    } else if (amt !== null) {
      // A flat rupee depreciation figure was given directly, with no rate.
      depAmt = amt;
    }
    if (depAmt === null) return { ok: false, index: idx, text: original, reason: "Depreciation given only as a % — state the asset's book value/cost so the amount can be computed." };
    lines.push({ account: "Depreciation A/c", dr: depAmt });
    lines.push({ account: asset + " A/c", cr: depAmt });
    if (assetLabel) ctx.assetBook[assetLabel] = (ctx.assetBook[assetLabel] || 0) - depAmt;
  }

  else if (flags.isPrepaid && amt !== null && expenseLabel) {
    tag = "adjustment";
    lines.push({ account: "Prepaid " + expenseLabel + " A/c", dr: amt });
    lines.push({ account: cashOrBank, cr: amt });
  }

  else if (flags.isAccruedIncome && amt !== null) {
    tag = "adjustment";
    const base = incomeLabel ? incomeLabel.replace(/ Received$/, "") : (/income/.test(text) ? "Income" : null);
    if (!base) return { ok: false, index: idx, text: original, reason: "Accrued income — couldn't tell which income this is (commission/interest/rent/etc.)." };
    lines.push({ account: "Accrued " + base + " A/c", dr: amt });
    lines.push({ account: base + " Received A/c", cr: amt });
  }

  else if (flags.isIncomeAdvance && amt !== null) {
    tag = "adjustment";
    const base = incomeLabel ? incomeLabel.replace(/ Received$/, "") : (/income/.test(text) ? "Income" : null);
    if (!base) return { ok: false, index: idx, text: original, reason: "Income received in advance — couldn't tell which income this is." };
    lines.push({ account: cashOrBank, dr: amt });
    lines.push({ account: base + " Received in Advance A/c", cr: amt });
  }

  else if (flags.isOutstanding && amt !== null && expenseLabel) {
    tag = "adjustment";
    lines.push({ account: expenseLabel + " A/c", dr: amt });
    lines.push({ account: "Outstanding " + expenseLabel + " A/c", cr: amt });
  }

  else if (flags.isLoanTaken && amt !== null) {
    tag = "loan";
    const lender = party ? party : "";
    lines.push({ account: cashOrBank, dr: amt });
    lines.push({ account: lender ? "Loan from " + lender + " A/c" : "Loan A/c", cr: amt });
  }

  else if (flags.isLoanGiven && amt !== null) {
    tag = "loan";
    const borrower = party ? party : "";
    lines.push({ account: borrower ? "Loan to " + borrower + " A/c" : "Loan A/c", dr: amt });
    lines.push({ account: cashOrBank, cr: amt });
  }

  else if (assetLabel && amt !== null && /purchas|bought|acquir/.test(text)) {
    // Fixed-asset purchase — ALWAYS debits the specific asset account
    // (never Purchases A/c, per Rule 9), and generalizes to any mix of
    // cash %, bank/cheque %, trade discount, cash discount, and a
    // credit balance via the shared split engine above, rather than
    // only the handful of exact sample wordings.
    tag = "asset";
    let netAmt = amt;
    if (tradeDiscPct > 0) {
      netAmt = acRound2(amt * (1 - tradeDiscPct / 100));
      narration += ` (marked price ₹${acFmt(amt)} less ${tradeDiscPct}% trade discount = ₹${acFmt(netAmt)})`;
    }
    const { total, gstLines, taxableValue } = gstSplitLines(netAmt, true);
    const assetAmt = taxableValue !== undefined ? taxableValue : netAmt;
    lines.push({ account: assetLabel + " A/c", dr: assetAmt });
    gstLines.forEach(g => lines.push({ account: g.account, dr: g.amount }));

    // Rule 10: every credit portion gets a named supplier/creditor
    // ledger — the stated party if one was given, otherwise a clearly
    // labelled account for this specific asset (e.g. "Furniture
    // Supplier/Creditor A/c"), never a bare generic "Creditors A/c".
    const defaultSupplierAcc = (party ? party : `${assetLabel} Supplier/Creditor`) + " A/c";
    const split = acSplitPaymentPortions(total);
    if (split) {
      let { cashAmt, bankAmt, creditAmt } = split;
      let discAmt = 0;
      if (cashDiscPct > 0) {
        // Cash discount applies only to the portion settled immediately
        // (cash + bank), never to what remains on credit.
        const discCash = acRound2(cashAmt * cashDiscPct / 100);
        const discBank = acRound2(bankAmt * cashDiscPct / 100);
        discAmt = acRound2(discCash + discBank);
        cashAmt = acRound2(cashAmt - discCash);
        bankAmt = acRound2(bankAmt - discBank);
      }
      if (cashAmt > 0.5) lines.push({ account: "Cash A/c", cr: cashAmt });
      if (bankAmt > 0.5) lines.push({ account: "Bank A/c", cr: bankAmt });
      if (discAmt > 0.5) lines.push({ account: "Discount Received A/c", cr: discAmt });
      if (creditAmt > 0.5) lines.push({ account: defaultSupplierAcc, cr: creditAmt });
      narration += ` (cash ₹${acFmt(split.cashAmt)}, bank ₹${acFmt(split.bankAmt)}${discAmt > 0.5 ? `, less ${cashDiscPct}% cash discount ₹${acFmt(discAmt)}` : ""}${creditAmt > 0.5 ? `, ₹${acFmt(creditAmt)} on credit` : ""})`;
    } else {
      const acc = mode === "credit" ? defaultSupplierAcc : cashOrBank;
      lines.push({ account: acc, cr: total });
    }
    ctx.assetBook[assetLabel] = (ctx.assetBook[assetLabel] || 0) + assetAmt;
  }

  else if (flags.isAssetSale && amt !== null && assetLabel) {
    tag = "asset";
    const saleAcc = mode === "credit" ? (party ? party + " A/c" : "Debtors A/c") : cashOrBank;
    const costFig = acAmountNear(text, amounts, ["original cost", "cost"]);
    const accDepFig = acAmountNear(text, amounts, ["accumulated depreciation", "depreciation"]);
    const saleFig = acAmountNear(text, amounts, ["sold for", "sale price", "sold at", "for ₹", "for rs"]);
    if (costFig !== null && accDepFig !== null && saleFig !== null && costFig !== accDepFig && costFig !== saleFig && accDepFig !== saleFig) {
      // All three figures stated explicitly: cost, accumulated
      // depreciation, and sale price — the full disposal calculation,
      // rather than assuming the first number found is the book value.
      const bookValue = acRound2(costFig - accDepFig);
      const diff = acRound2(saleFig - bookValue);
      lines.push({ account: saleAcc, dr: saleFig });
      lines.push({ account: "Accumulated Depreciation A/c", dr: accDepFig });
      lines.push({ account: assetLabel + " A/c", cr: costFig });
      if (diff >= 0) lines.push({ account: "Profit on Sale of " + assetLabel + " A/c", cr: diff });
      else lines.push({ account: "Loss on Sale of " + assetLabel + " A/c", dr: -diff });
      narration += ` (cost ₹${acFmt(costFig)} − accumulated depreciation ₹${acFmt(accDepFig)} = book value ₹${acFmt(bookValue)}; sold for ₹${acFmt(saleFig)})`;
      ctx.assetBook[assetLabel] = 0;
    } else if (amt2 !== null) {
      const bookValue = amt, salePrice = amt2;
      const diff = acRound2(salePrice - bookValue);
      lines.push({ account: saleAcc, dr: salePrice });
      lines.push({ account: assetLabel + " A/c", cr: bookValue });
      if (diff >= 0) lines.push({ account: "Profit on Sale of " + assetLabel + " A/c", cr: diff });
      else lines.push({ account: "Loss on Sale of " + assetLabel + " A/c", dr: -diff });
      ctx.assetBook[assetLabel] = (ctx.assetBook[assetLabel] || 0) - bookValue;
    } else if (/profit of|loss of/.test(text)) {
      const tracked = ctx.assetBook[assetLabel];
      if (tracked !== undefined && tracked > 0) {
        const isProfit = /profit of/.test(text);
        const bookValue = tracked;
        const salePrice = isProfit ? acRound2(bookValue + amt) : acRound2(bookValue - amt);
        lines.push({ account: saleAcc, dr: salePrice });
        lines.push({ account: assetLabel + " A/c", cr: bookValue });
        if (isProfit) lines.push({ account: "Profit on Sale of " + assetLabel + " A/c", cr: amt });
        else lines.push({ account: "Loss on Sale of " + assetLabel + " A/c", dr: amt });
        ctx.assetBook[assetLabel] = 0;
      } else {
        return { ok: false, index: idx, text: original, reason: `Sale of ${assetLabel} at a stated profit/loss alone isn't enough to post a balanced entry unless the asset's book value is already known from an earlier transaction in this sequence — please also state either the book value or the sale price.` };
      }
    } else {
      // Single sale-price figure only, with no book value/profit/loss
      // restated in this sentence — use this asset's tracked book value
      // (built up across its purchase transaction and any depreciation
      // charged since), so profit/loss on disposal is never silently
      // skipped just because the question didn't repeat the figure.
      const tracked = ctx.assetBook[assetLabel];
      if (tracked !== undefined && tracked > 0) {
        const bookValue = tracked, salePrice = amt;
        const diff = acRound2(salePrice - bookValue);
        lines.push({ account: saleAcc, dr: salePrice });
        lines.push({ account: assetLabel + " A/c", cr: bookValue });
        if (diff > 0) lines.push({ account: "Profit on Sale of " + assetLabel + " A/c", cr: diff });
        else if (diff < 0) lines.push({ account: "Loss on Sale of " + assetLabel + " A/c", dr: -diff });
        narration += ` (book value ₹${acFmt(bookValue)} tracked from earlier purchase/depreciation entries, sold for ₹${acFmt(salePrice)})`;
        ctx.assetBook[assetLabel] = 0;
      } else {
        // No tracked book value at all (asset was never purchased in this
        // sequence, or under a different label) — the stated figure is
        // the only information available, so it's booked directly with
        // no invented profit/loss.
        lines.push({ account: saleAcc, dr: amt });
        lines.push({ account: assetLabel + " A/c", cr: amt });
        ctx.assetBook[assetLabel] = (ctx.assetBook[assetLabel] || 0) - amt;
      }
    }
  }

  else if (flags.isMiscIncomeSale && amt !== null) {
    tag = "income";
    lines.push({ account: cashOrBank, dr: amt });
    lines.push({ account: "Sale of Old Newspapers/Miscellaneous Income A/c", cr: amt });
  }

  else if (expenseLabel && amt !== null && /\bpaid\b|\bpay\b|purchased|bought|charged/.test(text)) {
    tag = "expense";
    const { total, gstLines, taxableValue } = gstSplitLines(amt, true);
    const expenseAmt = taxableValue !== undefined ? taxableValue : amt;
    const acc = mode === "credit" ? (party ? party + " A/c" : "Creditors A/c") : cashOrBank;
    lines.push({ account: expenseLabel + " A/c", dr: expenseAmt });
    gstLines.forEach(g => lines.push({ account: g.account, dr: g.amount }));
    lines.push({ account: acc, cr: total });
  }

  else if (incomeLabel && amt !== null && /received|receive\b/.test(text)) {
    tag = "income";
    lines.push({ account: cashOrBank, dr: amt });
    lines.push({ account: incomeLabel + " A/c", cr: amt });
  }

  else if ((isGoods || isBareSaleOrPurchase) && amt !== null && /purchas|bought/.test(text)) {
    tag = "goods";
    let netAmt = amt;
    if (tradeDiscPct > 0) {
      netAmt = acRound2(amt * (1 - tradeDiscPct / 100));
      narration += ` (marked price ₹${acFmt(amt)} less ${tradeDiscPct}% trade discount = ₹${acFmt(netAmt)}; trade discount isn't journalised separately)`;
    }
    const { total, gstLines, taxableValue } = gstSplitLines(netAmt, true);
    const netForBooks = taxableValue !== undefined ? taxableValue : netAmt;
    lines.push({ account: "Purchases A/c", dr: netForBooks });
    gstLines.forEach(g => lines.push({ account: g.account, dr: g.amount }));
    const generalGoodsSplit = acSplitPaymentPortions(total);
    if (isPartialPortionWithCashDisc) {
      const paidPortion = acRound2(total * partialPortionPct / 100);
      const discOnPaid = acRound2(paidPortion * cashDiscPct / 100);
      const actualCash = acRound2(paidPortion - discOnPaid);
      const remainder = acRound2(total - paidPortion);
      lines.push({ account: splitPaidAcc, cr: actualCash });
      lines.push({ account: "Discount Received A/c", cr: discOnPaid });
      if (remainder > 0.5) lines.push({ account: party ? party + " A/c" : "Creditors A/c", cr: remainder });
      narration += ` (${partialPortionPct}% of ₹${acFmt(total)} = ₹${acFmt(paidPortion)} paid now, less ${cashDiscPct}% cash discount ₹${acFmt(discOnPaid)} = ₹${acFmt(actualCash)} actually paid; ₹${acFmt(remainder)} remains owed)`;
    } else if (isSplitPayment && (amt2 !== null || (partialPortionPct > 0 && partialPortionPct < 100)) && balanceMode !== "bank" && balanceMode !== "cash" && !(splitCashPct > 0 && splitBankPct > 0)) {
      // Prefer an explicit percentage of the total over a stray second
      // amount — "paid 50%... balance after 15 days on credit" has no
      // rupee figure for the paid portion at all, only a percentage.
      const paidNow = (partialPortionPct > 0 && partialPortionPct < 100) ? acRound2(total * partialPortionPct / 100) : amt2;
      const creditPortion = acRound2(total - paidNow);
      lines.push({ account: splitPaidAcc, cr: paidNow });
      lines.push({ account: party ? party + " A/c" : "Creditors A/c", cr: creditPortion });
      narration += ` (₹${acFmt(paidNow)} paid now, ₹${acFmt(creditPortion)} remains on credit)`;
    } else if (generalGoodsSplit && (splitCashPct > 0 || splitBankPct > 0)) {
      // General case: a cash % AND a bank/cheque % both stated together
      // (e.g. "40% by cheque, 30% by cash, balance on credit"), or a
      // single stated % whose remainder is explicitly settled in a
      // different mode (e.g. "50% by cash and balance by cheque") rather
      // than left on credit — neither of which the two narrower cases
      // above cover, since both require the remainder to be a credit
      // balance with only one payment mode named.
      let { cashAmt, bankAmt, creditAmt } = generalGoodsSplit;
      let discAmt = 0;
      if (cashDiscPct > 0) {
        const discCash = acRound2(cashAmt * cashDiscPct / 100);
        const discBank = acRound2(bankAmt * cashDiscPct / 100);
        discAmt = acRound2(discCash + discBank);
        cashAmt = acRound2(cashAmt - discCash);
        bankAmt = acRound2(bankAmt - discBank);
      }
      if (cashAmt > 0.5) lines.push({ account: "Cash A/c", cr: cashAmt });
      if (bankAmt > 0.5) lines.push({ account: "Bank A/c", cr: bankAmt });
      if (discAmt > 0.5) lines.push({ account: "Discount Received A/c", cr: discAmt });
      if (creditAmt > 0.5) lines.push({ account: party ? party + " A/c" : "Creditors A/c", cr: creditAmt });
      narration += ` (cash ₹${acFmt(generalGoodsSplit.cashAmt)}, bank ₹${acFmt(generalGoodsSplit.bankAmt)}${discAmt > 0.5 ? `, less ${cashDiscPct}% cash discount ₹${acFmt(discAmt)}` : ""}${creditAmt > 0.5 ? `, ₹${acFmt(creditAmt)} on credit` : ""})`;
    } else if (cashDiscPct > 0 && mode !== "credit") {
      // Trade discount (already excluded above, before the entry is even
      // built) and cash discount are independent and can both apply to
      // the same purchase — trade discount lowers the recorded price;
      // cash discount is a separate account on the immediate payment.
      const acc = cashOrBank;
      const discAmt = acRound2(total * cashDiscPct / 100);
      const netPay = acRound2(total - discAmt);
      lines.push({ account: acc, cr: netPay });
      lines.push({ account: "Discount Received A/c", cr: discAmt });
      narration += ` (cash discount ${cashDiscPct}% on ₹${acFmt(total)} = ₹${acFmt(discAmt)})`;
    } else {
      const acc = mode === "credit" ? (party ? party + " A/c" : "Creditors A/c") : cashOrBank;
      lines.push({ account: acc, cr: total });
    }
  }

  else if ((isGoods || isBareSaleOrPurchase) && amt !== null && /sold|sales? of goods|\bsales?\b/.test(text)) {
    tag = "goods";
    let netAmt = amt;
    if (tradeDiscPct > 0) {
      netAmt = acRound2(amt * (1 - tradeDiscPct / 100));
      narration += ` (marked price ₹${acFmt(amt)} less ${tradeDiscPct}% trade discount = ₹${acFmt(netAmt)}; trade discount isn't journalised separately)`;
    }
    const { total, gstLines, taxableValue } = gstSplitLines(netAmt, false);
    const netForBooks = taxableValue !== undefined ? taxableValue : netAmt;
    if (isPartialPortionWithCashDisc) {
      const receivedPortion = acRound2(total * partialPortionPct / 100);
      const discOnReceived = acRound2(receivedPortion * cashDiscPct / 100);
      const actualCash = acRound2(receivedPortion - discOnReceived);
      const remainder = acRound2(total - receivedPortion);
      lines.push({ account: splitReceivedAcc, dr: actualCash });
      lines.push({ account: "Discount Allowed A/c", dr: discOnReceived });
      if (remainder > 0.5) lines.push({ account: party ? party + " A/c" : "Debtors A/c", dr: remainder });
      narration += ` (${partialPortionPct}% of ₹${acFmt(total)} = ₹${acFmt(receivedPortion)} received now, less ${cashDiscPct}% cash discount ₹${acFmt(discOnReceived)} = ₹${acFmt(actualCash)} actually received; ₹${acFmt(remainder)} remains owed)`;
    } else if (isSplitReceipt && (amt2 !== null || (partialPortionPct > 0 && partialPortionPct < 100))) {
      const receivedNow = (partialPortionPct > 0 && partialPortionPct < 100) ? acRound2(total * partialPortionPct / 100) : amt2;
      const creditPortion = acRound2(total - receivedNow);
      lines.push({ account: splitReceivedAcc, dr: receivedNow });
      lines.push({ account: party ? party + " A/c" : "Debtors A/c", dr: creditPortion });
      narration += ` (₹${acFmt(receivedNow)} received now, ₹${acFmt(creditPortion)} remains on credit)`;
    } else if (cashDiscPct > 0 && mode !== "credit") {
      const discAmt = acRound2(total * cashDiscPct / 100);
      const netReceipt = acRound2(total - discAmt);
      lines.push({ account: cashOrBank, dr: netReceipt });
      lines.push({ account: "Discount Allowed A/c", dr: discAmt });
      narration += ` (cash discount ${cashDiscPct}% on ₹${acFmt(total)} = ₹${acFmt(discAmt)})`;
    } else {
      const acc = mode === "credit" ? (party ? party + " A/c" : "Debtors A/c") : cashOrBank;
      lines.push({ account: acc, dr: total });
    }
    lines.push({ account: "Sales A/c", cr: netForBooks });
    gstLines.forEach(g => lines.push({ account: g.account, cr: g.amount }));
  }

  else if ((party || /\bdebtors?\b/.test(text)) && amt !== null && (/received\b[\s\S]{0,25}\bfrom\b/.test(text) || partySettledSelf || (partyFromContext && /\breceived\b/.test(text) && /settlement/.test(text)))) {
    tag = "debtor";
    const acctName = party || "Debtors";
    let recv = amt, disc = 0;
    const dueFromCtx = party && ctx.partyBalances ? ctx.partyBalances[party.toLowerCase()] : null;
    if (amt2 !== null && flags.isFullSettlement) {
      const settle = Math.min(amt, amt2), gross = Math.max(amt, amt2);
      disc = acRound2(gross - settle); recv = settle;
    } else if (flags.isFullSettlement && dueFromCtx != null && dueFromCtx > amt) {
      // No explicit "of ₹X" figure was given in THIS line — use the
      // amount this party is actually known to owe, from their running
      // balance built up over the preceding transactions, so the
      // discount is never silently dropped.
      disc = acRound2(dueFromCtx - amt); recv = amt;
    } else if (amt2 !== null && /discount/.test(text)) {
      disc = amt2; recv = amt;
    } else if (cashDiscPct > 0) {
      disc = acRound2(amt * cashDiscPct / 100); recv = acRound2(amt - disc);
    }
    lines.push({ account: cashOrBank, dr: recv });
    if (disc > 0) lines.push({ account: "Discount Allowed A/c", dr: disc });
    lines.push({ account: acctName + " A/c", cr: acRound2(recv + disc) });
  }

  else if ((party || /\bcreditors?\b/.test(text)) && amt !== null && (paidToTargetHasTo || paidPartyDirect || isTwoWaySplitPay || (partyFromContext && /\bpaid\b/.test(text) && /settlement/.test(text)))) {
    tag = "creditor";
    const acctName = party || "Creditors";
    // "Paid ₹60,000 by bank and ₹10,000 in cash to settle a creditor of
    // ₹70,000" — two payment amounts, in two different modes, both
    // paid now (no discount, no remaining credit) — distinct from the
    // "paid X, balance on credit" split handled elsewhere.
    if (isTwoWaySplitPay) {
      // "₹60,000 by bank" / "₹10,000 in cash" — the amount directly
      // precedes its mode here, the reverse of "sold for ₹X", so this
      // needs its own tight regex rather than generic nearest-amount
      // matching (which would grab the wrong neighbour).
      const bankMatch = /([\d][\d,]*(?:\.\d+)?)\s*(?:by\s*)?bank/i.exec(text) || /bank[\s\S]{0,15}?([\d][\d,]*(?:\.\d+)?)/i.exec(text);
      const cashMatch = /([\d][\d,]*(?:\.\d+)?)\s*(?:in\s*)?cash/i.exec(text) || /cash[\s\S]{0,15}?([\d][\d,]*(?:\.\d+)?)/i.exec(text);
      const bankAmt = bankMatch ? parseFloat(bankMatch[1].replace(/,/g, "")) : null;
      const cashAmt = cashMatch ? parseFloat(cashMatch[1].replace(/,/g, "")) : null;
      const total = amounts.length > 2 ? amounts[2].value : acRound2((bankAmt || 0) + (cashAmt || 0));
      lines.push({ account: acctName + " A/c", dr: total });
      if (bankAmt) lines.push({ account: "Bank A/c", cr: bankAmt });
      if (cashAmt) lines.push({ account: "Cash A/c", cr: cashAmt });
    } else {
      let paid = amt, disc = 0;
      const dueFromCtxCr = party && ctx.partyBalances ? -(ctx.partyBalances[party.toLowerCase()] || 0) : null;
      if (amt2 !== null && flags.isFullSettlement) {
        const settle = Math.min(amt, amt2), gross = Math.max(amt, amt2);
        disc = acRound2(gross - settle); paid = settle;
      } else if (flags.isFullSettlement && dueFromCtxCr != null && dueFromCtxCr > amt) {
        disc = acRound2(dueFromCtxCr - amt); paid = amt;
      } else if (amt2 !== null && /discount/.test(text)) {
        disc = amt2; paid = amt;
      } else if (cashDiscPct > 0) {
        disc = acRound2(amt * cashDiscPct / 100); paid = acRound2(amt - disc);
      }
      lines.push({ account: acctName + " A/c", dr: acRound2(paid + disc) });
      lines.push({ account: cashOrBank, cr: paid });
      if (disc > 0) lines.push({ account: "Discount Received A/c", cr: disc });
    }
  }

  // "Ram owed ₹60,000. He paid ₹57,000 by cheque and received ₹3,000
  // discount in full settlement." — a narrative combining the amount
  // owed, the amount paid, and the discount as three separate explicit
  // figures, rather than "in full settlement of ₹X" or a tracked
  // balance. Handled before the generic standalone-discount branches
  // below, which would otherwise grab the wrong one of these numbers.
  else if (party && amt !== null && /\bowed\b/.test(text) && /\bpaid\b/.test(text) && /discount/.test(text)) {
    const owed = acAmountNear(text, amounts, ["owed"]);
    const paidFig = acAmountNear(text, amounts, ["paid"]);
    const discFig = acAmountNear(text, amounts, ["discount"]);
    if (owed === null || paidFig === null || discFig === null) {
      return { ok: false, index: idx, text: original, reason: "Please state the amount owed, the amount actually paid, and the discount separately so the entry can be split correctly." };
    }
    tag = "debtor";
    const payAcc = /\b(bank|cheque|chq)\b/.test(text) ? "Bank A/c" : "Cash A/c";
    lines.push({ account: payAcc, dr: paidFig });
    lines.push({ account: "Discount Allowed A/c", dr: discFig });
    lines.push({ account: party + " A/c", cr: owed });
  }

  // Standalone "Allowed her discount ₹500" / "Received discount ₹300
  // from him" lines — a follow-up to a preceding transaction with the
  // same party (resolved above via ctx.lastParty), rather than a
  // discount folded into the same sentence as the receipt/payment.
  else if (party && amt !== null && (/allow(ed|s)?\b[\s\S]{0,20}discount|discount[\s\S]{0,10}allow/.test(text)) && !/trade discount/.test(text)) {
    tag = "debtor";
    const discFig = acAmountNear(text, amounts, ["discount"]) ?? amt;
    lines.push({ account: "Discount Allowed A/c", dr: discFig });
    lines.push({ account: party + " A/c", cr: discFig });
  }

  else if (party && amt !== null && (/(received|receive)\b[\s\S]{0,20}discount|discount[\s\S]{0,10}(received|receive)\b/.test(text)) && !/trade discount/.test(text) && !/cash discount/.test(text)) {
    tag = "creditor";
    const discFig = acAmountNear(text, amounts, ["discount"]) ?? amt;
    lines.push({ account: party + " A/c", dr: discFig });
    lines.push({ account: "Discount Received A/c", cr: discFig });
  }

  if (!lines.length) {
    if (/correct(ed|ing)?\s+(an\s+)?error/.test(text)) {
      return { ok: false, index: idx, text: original, reason: "Correcting an error needs the specifics of what was wrongly recorded (which account, which amount) so the rectifying entry can be worked out — please state the original wrong entry." };
    }
    if (/closing adjustment entry/.test(text)) {
      return { ok: false, index: idx, text: original, reason: "Closing adjustments (outstanding/prepaid expenses, accrued/advance income) need to be entered individually with their amounts — see the outstanding, prepaid, accrued, and advance-income transactions already in this list." };
    }
    if (/exchanged for another/.test(text)) {
      return { ok: false, index: idx, text: original, reason: "An asset-for-asset exchange needs the value of the asset given up (and the new asset's value, if different) to post a balanced entry." };
    }
    if (/partly for cash and partly on credit|partly.*cash.*partly.*credit/.test(text)) {
      return { ok: false, index: idx, text: original, reason: "State how much was paid in cash/by cheque and how much was on credit so the entry can be split correctly." };
    }
    return { ok: false, index: idx, text: original, reason: "Couldn't confidently identify the accounts involved — try stating the item/party, the amount, and cash/bank/credit explicitly." };
  }
  if (!bothSidesOk()) {
    return { ok: false, index: idx, text: original, reason: "Internal check failed: debit and credit did not balance for this line." };
  }
  // Remember the party this transaction was about, so a later line that
  // only says "her"/"his"/"their" without naming anyone can still be
  // resolved correctly. Also update their running balance (+ve = they
  // owe the business, -ve = the business owes them) so a later "in full
  // settlement" line with no explicit due-amount of its own can still
  // work out the correct discount instead of silently dropping it.
  if (party && lines.some(l => l.account === party + " A/c")) {
    ctx.lastParty = party;
    ctx.partyBalances = ctx.partyBalances || {};
    const key = party.toLowerCase();
    const drSum = lines.filter(l => l.account === party + " A/c").reduce((s, l) => s + (l.dr || 0), 0);
    const crSum = lines.filter(l => l.account === party + " A/c").reduce((s, l) => s + (l.cr || 0), 0);
    ctx.partyBalances[key] = acRound2((ctx.partyBalances[key] || 0) + drSum - crSum);
  }
  // Track running Input/Output GST balances by head, so a later GST
  // set-off line has real recorded balances to work from instead of
  // needing every transaction re-stated.
  ctx.gstBalances = ctx.gstBalances || { inputCGST: 0, inputSGST: 0, inputIGST: 0, outputCGST: 0, outputSGST: 0, outputIGST: 0 };
  lines.forEach(l => {
    const m = /^(Input|Output) (CGST|SGST|IGST) A\/c$/.exec(l.account);
    if (!m) return;
    const key = m[1].toLowerCase() + m[2]; // e.g. "inputCGST"
    const delta = m[1] === "Input" ? (l.dr || 0) - (l.cr || 0) : (l.cr || 0) - (l.dr || 0);
    ctx.gstBalances[key] = acRound2((ctx.gstBalances[key] || 0) + delta);
  });
  // Running Cash/Bank balances — lets the engine flag (never block) a
  // transaction that would take Cash negative, since unlike Bank, a
  // cash account genuinely cannot run below zero.
  ctx.cashBalance = ctx.cashBalance === undefined ? 0 : ctx.cashBalance;
  ctx.bankBalance = ctx.bankBalance === undefined ? 0 : ctx.bankBalance;
  let warning = null;
  lines.forEach(l => {
    if (l.account === "Cash A/c") ctx.cashBalance = acRound2(ctx.cashBalance + (l.dr || 0) - (l.cr || 0));
    if (l.account === "Bank A/c") ctx.bankBalance = acRound2(ctx.bankBalance + (l.dr || 0) - (l.cr || 0));
  });
  if (ctx.cashBalance < -0.01) {
    warning = `This leaves Cash at a negative balance (₹${acFmt(ctx.cashBalance)}), which isn't possible — a cash account can't go below zero the way a bank account can with an overdraft. Please check the cash figures in this transaction and the ones before it.`;
  }
  return { ok: true, index: idx, text: original, lines, narration, tag, warning, date };
}

/* ---------- LEDGER / TRIAL BALANCE ---------- */

// Attaches proper ledger "particulars" to each line of a single journal
// entry — the counter account name (e.g. "Cash A/c") for a simple 2-line
// entry, or "Sundries" for a compound entry with more than one line on
// the other side. This is what the Ledger tab shows instead of a bare
// transaction number.
function acAttachParticulars(rLines) {
  const drAccounts = rLines.filter(l => l.dr !== undefined).map(l => l.account);
  const crAccounts = rLines.filter(l => l.cr !== undefined).map(l => l.account);
  return rLines.map(l => {
    if (l.dr !== undefined) return { ...l, particulars: crAccounts.length === 1 ? crAccounts[0] : "Sundries" };
    return { ...l, particulars: drAccounts.length === 1 ? drAccounts[0] : "Sundries" };
  });
}

function acBuildLedgers(journalLines) {
  // journalLines: flat array of {account, dr?, cr?, txnIndex, particulars, date}
  const ledgers = {}; // name -> { dr: [], cr: [], totalDr, totalCr }
  journalLines.forEach(l => {
    if (!ledgers[l.account]) ledgers[l.account] = { name: l.account, dr: [], cr: [], totalDr: 0, totalCr: 0 };
    const led = ledgers[l.account];
    if (l.dr) { led.dr.push({ amount: l.dr, txnIndex: l.txnIndex, particulars: l.particulars, date: l.date }); led.totalDr = acRound2(led.totalDr + l.dr); }
    if (l.cr) { led.cr.push({ amount: l.cr, txnIndex: l.txnIndex, particulars: l.particulars, date: l.date }); led.totalCr = acRound2(led.totalCr + l.cr); }
  });
  Object.values(ledgers).forEach(led => {
    led.balance = acRound2(led.totalDr - led.totalCr);
    led.balanceSide = led.balance > 0 ? "dr" : led.balance < 0 ? "cr" : "nil";
  });
  return ledgers;
}

function acBuildTrialBalance(ledgers) {
  const rows = Object.values(ledgers)
    .filter(l => Math.abs(l.balance) > 0.004)
    .sort((a, b) => a.name.localeCompare(b.name))
    .map(l => ({ account: l.name, debit: l.balance > 0 ? Math.abs(l.balance) : 0, credit: l.balance < 0 ? Math.abs(l.balance) : 0 }));
  const totalDebit = acRound2(rows.reduce((s, r) => s + r.debit, 0));
  const totalCredit = acRound2(rows.reduce((s, r) => s + r.credit, 0));
  return { rows, totalDebit, totalCredit, balanced: Math.abs(totalDebit - totalCredit) < 0.02 };
}

/* ---------- ACCOUNT CLASSIFICATION for Final Accounts ---------- */

const AC_TRADING_DR = ["Purchases", "Wages", "Carriage Inwards", "Freight", "Import Duty", "Factory Rent", "Fuel & Power", "Octroi"];
const AC_TRADING_DR_CONTRA = { "Purchase Returns": "Purchases" }; // netted against
const AC_TRADING_CR = ["Sales"];
const AC_TRADING_CR_CONTRA = { "Sales Returns": "Sales" };

const AC_PL_DR = ["Salary", "Rent", "Electricity Charges", "Telephone Charges", "Printing & Stationery", "Advertisement",
  "Insurance Premium", "Carriage Outwards", "Repairs", "Postage & Courier", "Conveyance", "Travelling Expenses",
  "Legal Charges", "Audit Fee", "General Expenses", "Miscellaneous Expenses", "Donation", "Charity/Donation",
  "Interest on Loan", "Discount Allowed", "Bad Debts", "Depreciation", "Loss by Fire/Theft", "Interest on Capital",
  "Bank Charges", "Commission Paid", "Free Samples", "Staff Welfare Expenses", "Office Expenses", "Renewal Charges"];
const AC_PL_CR = ["Commission Received", "Interest Received", "Rent Received", "Dividend Received", "Discount Received",
  "Bad Debts Recovered", "Interest on Drawings"];

const AC_ASSET_FIXED = ["Furniture", "Machinery", "Plant", "Building", "Computer", "Vehicle", "Land", "Investment", "Goodwill", "Equipment"];

function acIsPLProfitLossAsset(name) { return /^Profit on Sale of /.test(name); }
function acIsPLLossAsset(name) { return /^Loss on Sale of /.test(name); }

function acBuildFinalAccounts(ledgers, closingStock) {
  const names = Object.keys(ledgers);
  const used = new Set();
  const trading = { dr: [], cr: [] };
  const pl = { dr: [], cr: [] };
  const bsAssets = [];
  const bsLiabilities = [];
  let capitalBalance = 0, drawingsBalance = 0;
  const acc = (label) => label + " A/c";

  // Trading account
  // Purchases A/c can carry direct credits beyond returns (goods taken as
  // drawings, given to charity, lost to fire/theft, etc. are all credited
  // straight to Purchases when journalised) — so the Trading-account figure
  // must start from the account's net balance, then remove Purchase
  // Returns on top of that, not just subtract returns from the gross debit side.
  let purchases = ledgers[acc("Purchases")] ? ledgers[acc("Purchases")].balance : 0;
  const purchaseReturns = ledgers[acc("Purchase Returns")] ? ledgers[acc("Purchase Returns")].totalCr : 0;
  purchases = acRound2(purchases - purchaseReturns);
  used.add(acc("Purchases")); used.add(acc("Purchase Returns"));
  if (purchases) trading.dr.push({ label: "Purchases (net of returns)", amount: purchases });
  ["Wages", "Carriage Inwards", "Freight", "Import Duty", "Factory Rent", "Fuel & Power", "Octroi"].forEach(n => {
    if (ledgers[acc(n)]) {
      const bal = acRound2(Math.abs(ledgers[acc(n)].balance));
      if (bal > 0.004) trading.dr.push({ label: n, amount: bal });
      used.add(acc(n));
    }
  });

  let sales = ledgers[acc("Sales")] ? Math.abs(ledgers[acc("Sales")].balance) : 0;
  const salesReturns = ledgers[acc("Sales Returns")] ? ledgers[acc("Sales Returns")].totalDr : 0;
  sales = acRound2(sales - salesReturns);
  used.add(acc("Sales")); used.add(acc("Sales Returns"));
  if (sales) trading.cr.push({ label: "Sales (net of returns)", amount: sales });
  if (closingStock > 0) trading.cr.push({ label: "Closing Stock", amount: closingStock });

  const totalTradingDr = acRound2(trading.dr.reduce((s, r) => s + r.amount, 0));
  const totalTradingCr = acRound2(trading.cr.reduce((s, r) => s + r.amount, 0));
  const grossProfit = acRound2(totalTradingCr - totalTradingDr);

  // P&L account
  // Use net balance, not the raw debit/credit total — an account like
  // "Loss by Fire/Theft A/c" can receive both a debit (the loss) and a
  // later credit (an insurance claim admitted against it), and only the
  // net figure belongs on the P&L.
  AC_PL_DR.forEach(n => {
    if (ledgers[acc(n)] && !used.has(acc(n))) {
      const bal = acRound2(Math.abs(ledgers[acc(n)].balance));
      if (bal > 0.004) pl.dr.push({ label: n, amount: bal });
      used.add(acc(n));
    }
  });
  AC_PL_CR.forEach(n => {
    if (ledgers[acc(n)] && !used.has(acc(n))) {
      const bal = acRound2(Math.abs(ledgers[acc(n)].balance));
      if (bal > 0.004) pl.cr.push({ label: n, amount: bal });
      used.add(acc(n));
    }
  });
  names.forEach(n => {
    if (used.has(n)) return;
    if (acIsPLProfitLossAsset(n)) { pl.cr.push({ label: n.replace(" A/c", ""), amount: ledgers[n].totalCr }); used.add(n); }
    if (acIsPLLossAsset(n)) { pl.dr.push({ label: n.replace(" A/c", ""), amount: ledgers[n].totalDr }); used.add(n); }
  });
  if (grossProfit >= 0) pl.cr.unshift({ label: "Gross Profit b/d", amount: grossProfit });
  else pl.dr.unshift({ label: "Gross Loss b/d", amount: -grossProfit });

  const totalPlDr = acRound2(pl.dr.reduce((s, r) => s + r.amount, 0));
  const totalPlCr = acRound2(pl.cr.reduce((s, r) => s + r.amount, 0));
  const netProfit = acRound2(totalPlCr - totalPlDr);

  // Balance sheet
  if (ledgers[acc("Capital")]) { capitalBalance = -ledgers[acc("Capital")].balance; used.add(acc("Capital")); } // credit balance -> positive
  if (ledgers[acc("Drawings")]) { drawingsBalance = ledgers[acc("Drawings")].balance; used.add(acc("Drawings")); } // debit balance -> positive

  let provDD = 0, provDisc = 0;
  if (ledgers["Provision for Doubtful Debts A/c"]) { provDD = ledgers["Provision for Doubtful Debts A/c"].balance * -1; used.add("Provision for Doubtful Debts A/c"); }
  if (ledgers["Provision for Discount on Debtors A/c"]) { provDisc = ledgers["Provision for Discount on Debtors A/c"].balance * -1; used.add("Provision for Discount on Debtors A/c"); }

  let inputGST = 0, outputGST = 0;
  ["Input CGST A/c", "Input SGST A/c", "Input IGST A/c"].forEach(n => { if (ledgers[n]) { inputGST = acRound2(inputGST + ledgers[n].balance); used.add(n); } });
  ["Output CGST A/c", "Output SGST A/c", "Output IGST A/c"].forEach(n => { if (ledgers[n]) { outputGST = acRound2(outputGST + Math.abs(ledgers[n].balance)); used.add(n); } });
  const netGST = acRound2(inputGST - outputGST);

  names.forEach(n => {
    if (used.has(n)) return;
    const led = ledgers[n];
    const bal = Math.abs(led.balance);
    if (bal < 0.005) { used.add(n); return; }

    if (n === "Cash A/c" || n === "Cheques in Hand A/c" || n === "Stock A/c") { bsAssets.push({ label: n.replace(" A/c", ""), amount: bal }); used.add(n); return; }
    if (n === "Bank A/c") {
      if (led.balance < 0) bsLiabilities.push({ label: "Bank Overdraft", amount: bal });
      else bsAssets.push({ label: "Bank", amount: bal });
      used.add(n); return;
    }
    if (AC_ASSET_FIXED.some(a => n === a + " A/c")) { bsAssets.push({ label: n.replace(" A/c", ""), amount: bal }); used.add(n); return; }
    if (/^Prepaid /.test(n)) { bsAssets.push({ label: n.replace(" A/c", ""), amount: bal }); used.add(n); return; }
    if (/^Accrued /.test(n)) { bsAssets.push({ label: n.replace(" A/c", ""), amount: bal }); used.add(n); return; }
    if (/^Loan to /.test(n)) { bsAssets.push({ label: n.replace(" A/c", ""), amount: bal }); used.add(n); return; }
    if (n === "Insurance Claim A/c") { bsAssets.push({ label: "Insurance Claim Receivable", amount: bal }); used.add(n); return; }
    if (n === "Advance to Supplier A/c" || n === "Goods sent on Approval A/c" || n === "Cheques Sent for Collection A/c") {
      if (led.balance >= 0) bsAssets.push({ label: n.replace(" A/c", ""), amount: bal });
      else bsLiabilities.push({ label: n.replace(" A/c", "") + " (credit balance)", amount: bal });
      used.add(n); return;
    }
    if (n === "Advance from Customer A/c") {
      if (led.balance <= 0) bsLiabilities.push({ label: n.replace(" A/c", ""), amount: bal });
      else bsAssets.push({ label: n.replace(" A/c", "") + " (debit balance)", amount: bal });
      used.add(n); return;
    }
    if (n === "Debtors A/c") {
      if (led.balance >= 0) bsAssets.push({ label: "Debtors", amount: bal });
      else bsLiabilities.push({ label: "Debtors (credit balance / advances)", amount: bal });
      used.add(n); return;
    }
    if (n === "Creditors A/c") {
      if (led.balance <= 0) bsLiabilities.push({ label: "Creditors", amount: bal });
      else bsAssets.push({ label: "Creditors (debit balance / advances)", amount: bal });
      used.add(n); return;
    }
    if (n === "Bills Receivable A/c") {
      if (led.balance >= 0) bsAssets.push({ label: "Bills Receivable", amount: bal });
      else bsLiabilities.push({ label: "Bills Receivable (credit balance)", amount: bal });
      used.add(n); return;
    }
    if (n === "Bills Payable A/c") {
      if (led.balance <= 0) bsLiabilities.push({ label: "Bills Payable", amount: bal });
      else bsAssets.push({ label: "Bills Payable (debit balance)", amount: bal });
      used.add(n); return;
    }

    if (/^Outstanding /.test(n)) { bsLiabilities.push({ label: n.replace(" A/c", ""), amount: bal }); used.add(n); return; }
    if (/Received in Advance A\/c$/.test(n)) { bsLiabilities.push({ label: n.replace(" A/c", ""), amount: bal }); used.add(n); return; }
    if (/^Loan from /.test(n)) { bsLiabilities.push({ label: n.replace(" A/c", ""), amount: bal }); used.add(n); return; }
    if (n === "Loan A/c") {
      if (led.balance < 0) bsLiabilities.push({ label: "Loan", amount: bal }); else bsAssets.push({ label: "Loan", amount: bal });
      used.add(n); return;
    }
    if (/A\/c$/.test(n)) {
      // generic personal / party account (a named debtor/creditor) -> classify by balance side
      const label = n.replace(" A/c", "");
      if (led.balance > 0) bsAssets.push({ label: label + " (Sundry Debtor)", amount: bal });
      else bsLiabilities.push({ label: label + " (Sundry Creditor)", amount: bal });
      used.add(n); return;
    }
    // fallback — surface anything unclassified rather than silently dropping it
    if (led.balance > 0) bsAssets.push({ label: n.replace(" A/c", "") + " (unclassified)", amount: bal });
    else bsLiabilities.push({ label: n.replace(" A/c", "") + " (unclassified)", amount: bal });
    used.add(n);
  });

  if (closingStock > 0) bsAssets.push({ label: "Closing Stock", amount: closingStock });
  if (provDD > 0 || provDisc > 0) {
    const debtorIdx = bsAssets.findIndex(a => /Sundry Debtor/.test(a.label));
    // shown as separate deduction lines rather than folded silently into one debtor line,
    // since transactions may not name every individual debtor
    if (provDD > 0) bsAssets.push({ label: "Less: Provision for Doubtful Debts", amount: -provDD });
    if (provDisc > 0) bsAssets.push({ label: "Less: Provision for Discount on Debtors", amount: -provDisc });
  }
  if (netGST > 0) bsAssets.push({ label: "GST Input Credit (net)", amount: netGST });
  if (netGST < 0) bsLiabilities.push({ label: "GST Payable (net)", amount: -netGST });

  const closingCapital = acRound2(capitalBalance + netProfit - Math.abs(drawingsBalance));
  bsLiabilities.unshift({ label: "Capital (closing)", amount: closingCapital, isCapital: true });

  const totalAssets = acRound2(bsAssets.reduce((s, r) => s + r.amount, 0));
  const totalLiabilities = acRound2(bsLiabilities.reduce((s, r) => s + r.amount, 0));

  return {
    trading: { dr: trading.dr, cr: trading.cr, totalDr: totalTradingDr, totalCr: totalTradingCr, grossProfit },
    pl: { dr: pl.dr, cr: pl.cr, totalDr: totalPlDr, totalCr: totalPlCr, netProfit },
    bs: { assets: bsAssets, liabilities: bsLiabilities, totalAssets, totalLiabilities, balanced: Math.abs(totalAssets - totalLiabilities) < 0.5 },
    capitalOpeningPlusAdj: capitalBalance, drawingsBalance
  };
}


/* ============================================================
   UI — renderAccountingCycle(root)
   New bottom-nav tab. Fully separate from the Journal Entry
   Generator (chapter 3) — does not touch its code, data, or DOM.
   ============================================================ */

const AC_EXAMPLE_SET = `Business commenced with cash ₹1,00,000.
Purchased goods for cash ₹50,000.
Sold goods to Ram on credit ₹60,000.
Opened a bank account and deposited ₹40,000.
Purchased furniture by cheque ₹25,000.
Paid salary ₹8,000.
Received ₹20,000 from Ram.
Paid ₹15,000 to Suresh by cheque.`;

// 74-transaction practice bank — covers capital (cash & asset), contra,
// goods (cash/credit/returns/trade discount), drawings, the full expense
// and income list, cheques-in-hand & dishonour, bank overdraft/interest,
// loans, all the outstanding/prepaid/accrued/advance adjustments, goods
// given away (charity/samples/staff welfare/office use), fire & theft
// losses with insurance claims, insolvency, bad debts & recovery,
// depreciation, asset purchase/sale/installation, and a multi-item
// opening journal entry — added exactly once, in the order supplied.
const AC_PRACTICE_BANK_74 = [
"Started business with cash ₹1,00,000.",
"Introduced furniture worth ₹20,000 as capital.",
"Deposited cash into bank ₹40,000.",
"Purchased goods for cash ₹25,000.",
"Purchased goods from Ramesh on credit ₹30,000.",
"Purchased furniture for cash ₹12,000.",
"Purchased machinery by cheque ₹50,000.",
"Paid carriage inward ₹2,000.",
"Sold goods for cash ₹35,000.",
"Sold goods to Suresh on credit ₹28,000.",
"Returned goods to Ramesh worth ₹5,000.",
"Suresh returned goods worth ₹3,000.",
"Paid rent in cash ₹6,000.",
"Paid salary by cheque ₹8,000.",
"Paid wages ₹4,000.",
"Paid insurance premium ₹3,000.",
"Paid advertisement expenses ₹5,000.",
"Paid electricity charges ₹2,500.",
"Paid repairs ₹1,500.",
"Paid commission ₹2,000.",
"Received commission in cash ₹3,000.",
"Paid carriage outward ₹1,000.",
"Withdrew cash from bank for office use ₹10,000.",
"Withdrew cash from bank for personal use ₹5,000.",
"Withdrew goods worth ₹4,000 for personal use.",
"Received cash from Suresh ₹24,000 and allowed him discount ₹1,000.",
"Paid Ramesh ₹24,000 in full settlement of his account of ₹25,000.",
"Received a cheque from a debtor ₹15,000.",
"Deposited the cheque into bank.",
"A cheque received from a debtor was dishonoured ₹15,000.",
"Paid bank charges ₹500.",
"Bank allowed interest ₹1,000.",
"Took a loan from the bank in cash ₹40,000.",
"Repaid bank loan by cheque ₹10,000.",
"Paid interest on loan ₹2,000.",
"Interest on loan outstanding ₹1,000.",
"Salary outstanding ₹3,000.",
"Paid the outstanding salary ₹3,000.",
"Rent outstanding ₹2,000.",
"Paid outstanding rent ₹2,000.",
"Paid rent in advance ₹4,000.",
"Commission accrued but not received ₹2,500.",
"Received income in advance ₹3,000.",
"Goods worth ₹2,000 were given as charity.",
"Goods worth ₹3,000 were distributed as free samples.",
"Goods worth ₹1,500 were given to employees as welfare benefits.",
"Goods worth ₹2,500 were used for office purposes.",
"Goods worth ₹6,000 were destroyed by fire.",
"Goods worth ₹8,000 were stolen from the business.",
"The insurance company admitted a claim of ₹4,000 for goods destroyed by fire.",
"Received the insurance claim by cheque ₹4,000.",
"A debtor owing ₹5,000 became insolvent and paid only ₹3,000.",
"A debtor owing ₹2,000 became a bad debt.",
"Received bad debts recovered ₹1,500.",
"Charged depreciation on furniture ₹2,000.",
"Charged depreciation on machinery ₹5,000.",
"Sold furniture for cash ₹8,000.",
"Sold machinery at a profit of ₹3,000.",
"Purchased a computer for cash ₹12,000.",
"Sold a computer at a loss of ₹2,000.",
"Paid installation charges on machinery ₹4,000.",
"Paid wages for installation of machinery ₹2,000.",
"Paid repairs on machinery ₹3,000.",
"Purchased a computer on credit from ABC Traders ₹35,000.",
"Purchased stationery for cash ₹2,000.",
"Paid telephone expenses ₹1,500.",
"Paid travelling expenses ₹2,500.",
"Received rent in cash ₹5,000.",
"Received interest in cash ₹2,000.",
"Paid donation in cash ₹1,000.",
"Received cash from a debtor ₹10,000.",
"Paid cash to a creditor ₹7,000.",
"Purchased goods after receiving trade discount of 10% on goods marked at ₹20,000.",
"Sold goods after allowing trade discount of 10% on goods marked at ₹30,000.",
"The following were the assets and liabilities at the beginning of the year: cash ₹20,000, bank balance ₹30,000, stock ₹40,000, furniture ₹15,000, debtors ₹25,000, creditors ₹20,000, and loan ₹10,000. Prepare the opening journal entry.",
"Purchased goods by cheque ₹15,000.",
"Sold goods and received a cheque immediately ₹20,000.",
"Purchased stationery on credit from Mohan ₹3,000.",
"Sold an old computer to Ravi on credit for ₹10,000.",
"Received a cheque from Suresh but kept it in the office ₹8,000.",
"Deposited the cheque received from Suresh into the bank ₹8,000.",
"Issued a cheque to Ramesh ₹12,000, but the cheque has not yet been presented for payment.",
"Endorsed a cheque received from Suresh to Ramesh ₹6,000.",
"Sent a cheque to the bank for collection ₹5,000.",
"The bank collected the cheque sent for collection ₹5,000.",
"The bank charged collection charges ₹200.",
"Received cash directly from a debtor ₹7,000.",
"A debtor directly deposited ₹10,000 into the business bank account.",
"Paid cash directly into the bank ₹15,000.",
"Paid business expenses personally by the proprietor ₹2,000.",
"The proprietor paid the business electricity bill from his personal account ₹3,000.",
"Allowed interest on capital ₹2,000.",
"Charged interest on drawings ₹1,000.",
"Received interest on investment ₹2,500.",
"Interest on investment accrued but was not received ₹1,000.",
"Paid advance to a supplier for goods ₹5,000.",
"Received advance from a customer for goods ₹8,000.",
"Received goods from the supplier against the advance paid ₹5,000.",
"Supplied goods to the customer against the advance received ₹8,000.",
"Gave a loan to Mohan in cash ₹10,000.",
"Gave a loan to Ravi by cheque ₹20,000.",
"Received repayment of a loan from Mohan ₹6,000.",
"Received interest on loan given ₹1,000.",
"Interest on loan given became due but was not received ₹1,500.",
"Purchased goodwill for cash ₹20,000.",
"Purchased goodwill on credit from Raj ₹30,000.",
"Sold goodwill for cash ₹25,000.",
"Purchased a building by cheque ₹2,00,000.",
"Paid legal charges for purchase of building ₹5,000.",
"Paid brokerage on purchase of building ₹3,000.",
"Received goods as a gift worth ₹5,000.",
"Received furniture as a gift worth ₹10,000.",
"Goods worth ₹2,000 were distributed among employees.",
"Goods worth ₹3,000 were used for personal purposes by the proprietor.",
"Goods worth ₹4,000 were given to a customer as a free gift.",
"Goods worth ₹5,000 were sent on approval to a customer.",
"Goods sent on approval were accepted by the customer for ₹5,000.",
"Goods worth ₹2,000 were returned by the customer before approval.",
"A bill receivable was received from a debtor for ₹10,000.",
"A bill payable was accepted in favour of a creditor for ₹15,000.",
"The bill receivable was dishonoured ₹10,000.",
"The bill payable was paid on maturity ₹15,000.",
"Paid renewal charges on a bill payable ₹500.",
"Received a bill receivable from a debtor and discounted it with the bank ₹12,000.",
"The discounted bill was dishonoured ₹12,000.",
"A creditor allowed a rebate of ₹1,000.",
"A customer received a rebate of ₹800.",
"Purchased goods at a cash discount of 5%.",
"Sold goods at a cash discount of 5%.",
"Rent received in advance ₹4,000.",
"Salary paid in advance ₹3,000.",
"Commission received in advance ₹2,000.",
"Commission outstanding ₹1,500.",
"Interest received in advance ₹2,000.",
"Created a provision for doubtful debts ₹3,000.",
"An amount previously written off as bad debt was recovered ₹2,000.",
"Wrote off further bad debts ₹1,000.",
"Goods lost due to an accident ₹7,000.",
"Insurance claim for goods lost was rejected by the insurance company.",
"Received partial insurance claim ₹3,000 against goods lost ₹6,000.",
"A fixed asset was exchanged for another fixed asset.",
"Purchased machinery partly for cash and partly on credit.",
"Sold machinery partly for cash and partly on credit.",
"Paid commission to an agent by cheque ₹2,500.",
"Received commission through bank ₹3,500.",
"Paid income tax from the proprietor's personal account ₹4,000.",
"Paid income tax from business cash ₹4,000.",
"The proprietor took business cash for personal expenses ₹6,000.",
"The proprietor introduced a private vehicle into the business as capital ₹1,50,000.",
"Corrected an error relating to the purchase of furniture.",
"Passed the closing adjustment entry for outstanding expenses, prepaid expenses, accrued income, and income received in advance."
];

function acEl(tag, cls, html) { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; }

function renderAccountingCycle(root) {
  root.appendChild(acEl("div", "hero", `
    <span class="hero-eyebrow">New</span>
    <h1>Accounting Cycle</h1>
    <p>Enter one or many transactions — the engine reads each one, works out which accounts are affected using accounting rules (not a lookup table), and builds the complete cycle: Journal → Ledger → Trial Balance → Final Accounts.</p>
  `));

  const inputCard = acEl("div", "card-solid", "");
  inputCard.style.padding = "26px";
  inputCard.innerHTML = `
    <div class="field-group">
      <label>Transactions — one per line</label>
      <textarea id="acInput" class="field-input" style="min-height:220px; font-family:var(--font-body); resize:vertical; line-height:1.7;" placeholder="Type or paste transactions, one per line...">${AC_EXAMPLE_SET}</textarea>
    </div>
    <div class="field-group" style="max-width:260px;">
      <label>Closing Stock, if any (₹) — optional</label>
      <input type="number" id="acClosingStock" class="field-input" placeholder="e.g. 12000" min="0" step="0.01">
    </div>
    <div style="display:flex; gap:10px; flex-wrap:wrap; align-items:center;">
      <button class="btn-primary ripple-surface" id="acGenerateBtn"><i data-lucide="wand-2"></i> Generate Accounting Cycle</button>
      <button class="chip" id="acClearBtn">Clear</button>
      <span style="font-size:0.78rem; color:var(--ink-faint);">Supports GST, trade &amp; cash discount, bad debts, provisions, depreciation, and more.</span>
    </div>
  `;
  root.appendChild(inputCard);

  const warnBox = acEl("div", "");
  warnBox.style.marginTop = "16px";
  root.appendChild(warnBox);

  const tabBar = acEl("div", "");
  tabBar.style.cssText = "display:flex; gap:8px; flex-wrap:wrap; margin:22px 0 18px;";
  tabBar.hidden = true;
  const TABS = ["Transactions", "Journal", "Ledger", "Trial Balance", "Final Accounts"];
  TABS.forEach((t, i) => {
    const chip = acEl("button", `chip ${i === 0 ? "active" : ""}`, t);
    chip.dataset.tab = t;
    tabBar.appendChild(chip);
  });
  root.appendChild(tabBar);

  const outPanel = acEl("div", "");
  root.appendChild(outPanel);

  const disclaimerBox = acEl("div", "");
  disclaimerBox.hidden = true;
  disclaimerBox.style.cssText = "margin-top:16px; font-size:0.82rem; color:var(--ink-faint); line-height:1.6;";
  disclaimerBox.innerHTML = `⚠️ All answers given by the Accounting Cycle Generator may not always be correct. Please verify the answers before using them.`;
  root.appendChild(disclaimerBox);

  let lastResult = null;

  function showTab(name) {
    $all(".chip", tabBar).forEach(c => c.classList.toggle("active", c.dataset.tab === name));
    outPanel.innerHTML = "";
    if (!lastResult) return;
    if (name === "Transactions") acRenderTransactionsTab(outPanel, lastResult);
    if (name === "Journal") acRenderJournalTab(outPanel, lastResult);
    if (name === "Ledger") acRenderLedgerTab(outPanel, lastResult);
    if (name === "Trial Balance") acRenderTrialBalanceTab(outPanel, lastResult);
    if (name === "Final Accounts") acRenderFinalAccountsTab(outPanel, lastResult);
    icons();
  }
  tabBar.addEventListener("click", e => {
    const chip = e.target.closest(".chip");
    if (chip) showTab(chip.dataset.tab);
  });

  $("#acClearBtn", inputCard).addEventListener("click", () => {
    $("#acInput", inputCard).value = "";
    $("#acInput", inputCard).focus();
  });

  // Typing (or changing) the closing stock figure after already
  // generating once must actually update Final Accounts — previously it
  // only took effect if "Generate" was clicked again, so entering it
  // afterwards and just switching to the Final Accounts tab silently
  // showed stale (often zero) closing stock.
  $("#acClosingStock", inputCard).addEventListener("input", () => {
    if (!lastResult) return; // nothing generated yet — Generate will pick this up
    const closingStock = parseFloat(($("#acClosingStock", inputCard).value || "").replace(/[₹,\s]/g, "")) || 0;
    lastResult.closingStock = closingStock;
    lastResult.fa = acBuildFinalAccounts(lastResult.ledgers, closingStock);
    const activeTab = $(".chip.active", tabBar);
    if (activeTab && activeTab.dataset.tab === "Final Accounts") showTab("Final Accounts");
  });

  $("#acGenerateBtn", inputCard).addEventListener("click", () => {
    const raw = $("#acInput", inputCard).value;
    const closingStock = parseFloat(($("#acClosingStock", inputCard).value || "").replace(/[₹,\s]/g, "")) || 0;
    const rawLines = acMergeOpeningBalanceLines(raw.split(/\r?\n/).map(l => l.replace(/^\s*\d+[\.\)]\s*/, "").trim()).filter(Boolean));

    if (!rawLines.length) {
      warnBox.innerHTML = `<div class="reveal-block" style="background:var(--flag-soft); border-left-color:var(--flag);"><p style="font-size:0.87rem;">Enter at least one transaction.</p></div>`;
      playErrorSound();
      return;
    }

    const parsed = [];
    const failures = [];
    const ctx = {};
    rawLines.forEach((line, i) => {
      const r = acParseTransaction(line, i + 1, ctx);
      if (!r) return;
      if (r.ok) parsed.push(r); else failures.push(r);
    });

    const journalLines = [];
    parsed.forEach(r => {
      acAttachParticulars(r.lines).forEach(l => journalLines.push({ account: l.account, dr: l.dr, cr: l.cr, txnIndex: r.index, particulars: l.particulars, date: r.date }));
    });
    const ledgers = acBuildLedgers(journalLines);
    const tb = acBuildTrialBalance(ledgers);
    const fa = acBuildFinalAccounts(ledgers, closingStock);

    lastResult = { rawLines, parsed, failures, ledgers, tb, fa, closingStock };

    if (failures.length) {
      warnBox.innerHTML = `
        <div class="reveal-block" style="background:var(--flag-soft); border-left-color:var(--flag);">
          <h4><i data-lucide="alert-triangle" style="width:14px;height:14px;vertical-align:-2px;"></i> ${failures.length} line${failures.length > 1 ? "s" : ""} couldn't be processed</h4>
          <ol>${failures.map(f => `<li><b>Line ${f.index}:</b> "${escapeHtml(f.text)}" — ${escapeHtml(f.reason)}</li>`).join("")}</ol>
        </div>`;
    } else {
      warnBox.innerHTML = "";
    }
    icons();

    tabBar.hidden = false;
    disclaimerBox.hidden = false;
    showTab("Transactions");
    if (parsed.length) { toast(`Generated the cycle for ${parsed.length} transaction${parsed.length > 1 ? "s" : ""}.`, "success", "check-circle"); playSuccessSound(); }
  });
}

function acRenderTransactionsTab(panel, res) {
  panel.appendChild(sectionTitle("Transactions entered"));
  const card = acEl("div", "card-solid", "");
  card.style.padding = "22px";
  const rows = res.rawLines.map((line, i) => {
    const failed = res.failures.find(f => f.index === i + 1);
    const warned = !failed && res.parsed.find(p => p.index === i + 1 && p.warning);
    const color = failed ? "var(--flag);" : warned ? "#b8863b;" : "";
    const icon = failed
      ? '<i data-lucide="alert-triangle" style="width:13px;height:13px;vertical-align:-2px;"></i>'
      : warned
        ? '<i data-lucide="alert-circle" style="width:13px;height:13px;vertical-align:-2px;color:#b8863b;"></i>'
        : '<i data-lucide="check" style="width:13px;height:13px;vertical-align:-2px;color:var(--c-eq);"></i>';
    return `<li style="margin-bottom:10px; font-size:0.88rem; color:${color}" ${warned ? `title="${escapeHtml(warned.warning)}"` : ""}>
      <span class="tnum" style="color:var(--ink-faint); margin-right:6px;">${i + 1}.</span>${escapeHtml(line)}
      ${icon}
      ${warned ? `<div style="font-size:0.76rem; color:#b8863b; margin-top:2px;">⚠ ${escapeHtml(warned.warning)}</div>` : ""}
    </li>`;
  }).join("");
  card.innerHTML = `<ul style="list-style:none; padding-left:0; margin:0;">${rows}</ul>`;
  panel.appendChild(card);
}

function acRenderJournalTab(panel, res) {
  panel.appendChild(sectionTitle("Journal"));
  if (!res.parsed.length) { panel.appendChild(acEl("p", "", "No transactions could be journalised.")); return; }
  const card = acEl("div", "card-solid", "");
  card.style.padding = "22px";
  const scroll = acEl("div", "table-scroll");
  let rows = "";
  res.parsed.forEach(r => {
    r.lines.forEach((l, i) => {
      const isFirst = i === 0;
      rows += `<tr>
        <td class="tnum" style="white-space:nowrap; color:var(--ink-faint); font-size:0.82rem; vertical-align:top;">${isFirst && r.date ? escapeHtml(r.date) : ""}</td>
        <td style="font-family:var(--font-body); ${l.cr !== undefined ? "padding-left:26px;" : ""}">${isFirst ? `<span class="tnum" style="color:var(--ink-faint); margin-right:8px;">${r.index}.</span>` : ""}${l.dr !== undefined ? l.account + " Dr." : "-" + l.account}</td>
        <td class="tnum" style="text-align:right;">${l.dr !== undefined ? acFmt(l.dr) : ""}</td>
        <td class="tnum" style="text-align:right;">${l.cr !== undefined ? acFmt(l.cr) : ""}</td>
      </tr>`;
    });
    rows += `<tr><td></td><td colspan="3" style="font-size:0.78rem; color:var(--ink-faint); font-style:italic; padding-bottom:14px; border-bottom:1px dashed var(--line);">(${escapeHtml(r.narration)})</td></tr>`;
  });
  scroll.innerHTML = `<table class="ledger-table"><thead><tr><th>Date</th><th>Account Name</th><th>Debit (₹)</th><th>Credit (₹)</th></tr></thead><tbody>${rows}</tbody></table>`;
  card.appendChild(scroll);
  panel.appendChild(card);
}

function acRenderLedgerTab(panel, res) {
  panel.appendChild(sectionTitle("Ledger — T-accounts"));
  const grid = acEl("div", "");
  grid.style.cssText = "display:grid; grid-template-columns:repeat(auto-fit, minmax(460px, 1fr)); gap:16px;";
  Object.values(res.ledgers).sort((a, b) => a.name.localeCompare(b.name)).forEach(led => {
    const card = acEl("div", "card-solid", "");
    card.style.padding = "18px";
    const maxRows = Math.max(led.dr.length, led.cr.length, 1);
    let rows = "";
    for (let i = 0; i < maxRows; i++) {
      const d = led.dr[i], c = led.cr[i];
      const dLabel = d ? (d.particulars === "Sundries" ? "To Sundries" : "To " + escapeHtml(d.particulars)) : "";
      const cLabel = c ? (c.particulars === "Sundries" ? "By Sundries" : "By " + escapeHtml(c.particulars)) : "";
      rows += `<tr>
        <td style="border:1px solid var(--line); padding:5px 7px; font-size:0.72rem; color:var(--ink-faint); white-space:nowrap;">${d && d.date ? escapeHtml(d.date) : ""}</td>
        <td style="border:1px solid var(--line); padding:5px 7px; font-size:0.8rem;">${dLabel}</td>
        <td style="border:1px solid var(--line); padding:5px 7px; font-size:0.7rem;"></td>
        <td class="tnum" style="border:1px solid var(--line); padding:5px 7px; font-size:0.8rem; text-align:right;">${d ? acFmt(d.amount) : ""}</td>
        <td style="border:1px solid var(--line); padding:5px 7px; font-size:0.72rem; color:var(--ink-faint); white-space:nowrap;">${c && c.date ? escapeHtml(c.date) : ""}</td>
        <td style="border:1px solid var(--line); padding:5px 7px; font-size:0.8rem;">${cLabel}</td>
        <td style="border:1px solid var(--line); padding:5px 7px; font-size:0.7rem;"></td>
        <td class="tnum" style="border:1px solid var(--line); padding:5px 7px; font-size:0.8rem; text-align:right;">${c ? acFmt(c.amount) : ""}</td>
      </tr>`;
    }
    const balSide = led.balanceSide === "dr" ? "By Balance c/d" : led.balanceSide === "cr" ? "To Balance c/d" : "";
    const grandTotal = acFmt(Math.max(led.totalDr, led.totalCr, Math.abs(led.balance)));
    const thStyle = "border:1px solid var(--line-strong); background:var(--c-ac-soft); color:var(--c-ac); padding:4px 6px; font-size:0.64rem; font-weight:600;";
    card.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center; font-weight:700; font-family:var(--font-mono); font-size:0.85rem; margin-bottom:8px;">
        <span>Dr.</span><span>${escapeHtml(led.name)}</span><span>Cr.</span>
      </div>
      <table style="width:100%; border-collapse:collapse;">
        <tr>
          <th style="${thStyle}">Date</th><th style="${thStyle}">Particulars</th><th style="${thStyle}">J.F.</th><th style="${thStyle}">Amount</th>
          <th style="${thStyle}">Date</th><th style="${thStyle}">Particulars</th><th style="${thStyle}">J.F.</th><th style="${thStyle}">Amount</th>
        </tr>
        ${rows}
        <tr style="font-weight:700;">
          <td style="border:1px solid var(--line-strong); padding:5px 7px;"></td>
          <td style="border:1px solid var(--line-strong); padding:5px 7px; font-size:0.78rem;">${led.balanceSide === "cr" ? balSide : ""}</td>
          <td style="border:1px solid var(--line-strong); padding:5px 7px;"></td>
          <td class="tnum" style="border:1px solid var(--line-strong); padding:5px 7px; font-size:0.78rem; text-align:right;">${led.balanceSide === "cr" ? acFmt(Math.abs(led.balance)) : ""}</td>
          <td style="border:1px solid var(--line-strong); padding:5px 7px;"></td>
          <td style="border:1px solid var(--line-strong); padding:5px 7px; font-size:0.78rem;">${led.balanceSide === "dr" ? balSide : ""}</td>
          <td style="border:1px solid var(--line-strong); padding:5px 7px;"></td>
          <td class="tnum" style="border:1px solid var(--line-strong); padding:5px 7px; font-size:0.78rem; text-align:right;">${led.balanceSide === "dr" ? acFmt(Math.abs(led.balance)) : ""}</td>
        </tr>
        <tr style="font-weight:700; background:var(--paper-raised);">
          <td colspan="4" style="border:1px solid var(--line-strong); padding:5px 7px; font-size:0.8rem; text-align:right;">${grandTotal}</td>
          <td colspan="4" style="border:1px solid var(--line-strong); padding:5px 7px; font-size:0.8rem; text-align:right;">${grandTotal}</td>
        </tr>
      </table>`;
    grid.appendChild(card);
  });
  panel.appendChild(grid);
}

function acRenderTrialBalanceTab(panel, res) {
  panel.appendChild(sectionTitle("Trial Balance"));
  const card = acEl("div", "card-solid", "");
  card.style.padding = "22px";
  const rows = res.tb.rows.map(r => `<tr>
    <td>${escapeHtml(r.account)}</td>
    <td class="tnum" style="text-align:right;">${r.debit ? acFmt(r.debit) : ""}</td>
    <td class="tnum" style="text-align:right;">${r.credit ? acFmt(r.credit) : ""}</td>
  </tr>`).join("");
  card.innerHTML = `
    <div class="table-scroll">
      <table class="ledger-table">
        <thead><tr><th>Account</th><th>Debit (₹)</th><th>Credit (₹)</th></tr></thead>
        <tbody>${rows}
          <tr style="font-weight:700; border-top:2px solid var(--line-strong);">
            <td>Total</td>
            <td class="tnum" style="text-align:right;">${acFmt(res.tb.totalDebit)}</td>
            <td class="tnum" style="text-align:right;">${acFmt(res.tb.totalCredit)}</td>
          </tr>
        </tbody>
      </table>
    </div>
    <p style="margin-top:14px; font-size:0.85rem; ${res.tb.balanced ? "color:var(--c-eq);" : "color:var(--flag);"}">
      <i data-lucide="${res.tb.balanced ? "check-circle" : "alert-triangle"}" style="width:15px;height:15px;vertical-align:-3px;"></i>
      ${res.tb.balanced ? "Total Debit equals Total Credit." : "Debit and Credit totals do not match — please review the transactions."}
    </p>`;
  panel.appendChild(card);
}

function acFinalAccountsTable(title, dr, cr, totalDr, totalCr) {
  const maxRows = Math.max(dr.length, cr.length, 1);
  let rows = "";
  for (let i = 0; i < maxRows; i++) {
    const d = dr[i], c = cr[i];
    rows += `<tr>
      <td style="border:1px solid var(--line); padding:8px;">${d ? escapeHtml(d.label) : ""}</td>
      <td class="tnum" style="border:1px solid var(--line); padding:8px; text-align:right;">${d ? acFmt(d.amount) : ""}</td>
      <td style="border:1px solid var(--line); padding:8px;">${c ? escapeHtml(c.label) : ""}</td>
      <td class="tnum" style="border:1px solid var(--line); padding:8px; text-align:right;">${c ? acFmt(c.amount) : ""}</td>
    </tr>`;
  }
  return `
    <h4 style="margin:22px 0 10px;">${title}</h4>
    <div class="table-scroll">
      <table style="width:100%; border-collapse:collapse; min-width:520px;">
        ${rows}
        <tr style="font-weight:700;">
          <td style="border:1px solid var(--line-strong); padding:8px;">Total</td>
          <td class="tnum" style="border:1px solid var(--line-strong); padding:8px; text-align:right;">${acFmt(totalDr)}</td>
          <td style="border:1px solid var(--line-strong); padding:8px;">Total</td>
          <td class="tnum" style="border:1px solid var(--line-strong); padding:8px; text-align:right;">${acFmt(totalCr)}</td>
        </tr>
      </table>
    </div>`;
}

function acRenderFinalAccountsTab(panel, res) {
  panel.appendChild(sectionTitle("Final Accounts"));
  const fa = res.fa;
  const card = acEl("div", "card-solid", "");
  card.style.padding = "22px";

  const tDr = fa.trading.dr.slice();
  const tCr = fa.trading.cr.slice();
  if (fa.trading.grossProfit >= 0) tDr.push({ label: "Gross Profit c/d", amount: fa.trading.grossProfit });
  else tCr.push({ label: "Gross Loss c/d", amount: -fa.trading.grossProfit });
  const tTotal = Math.max(fa.trading.totalDr, fa.trading.totalCr);
  let html = fa.trading.totalDr || fa.trading.totalCr ? acFinalAccountsTable("Trading Account", tDr, tCr, tTotal, tTotal) : `<p style="font-size:0.85rem; color:var(--ink-faint);">No trading (goods purchase/sale) activity — Trading Account not applicable.</p>`;

  const pDr = fa.pl.dr.slice();
  const pCr = fa.pl.cr.slice();
  if (fa.pl.netProfit >= 0) pDr.push({ label: "Net Profit transferred to Capital A/c", amount: fa.pl.netProfit });
  else pCr.push({ label: "Net Loss transferred to Capital A/c", amount: -fa.pl.netProfit });
  const pTotal = Math.max(fa.pl.totalDr, fa.pl.totalCr);
  html += acFinalAccountsTable("Profit &amp; Loss Account", pDr, pCr, pTotal, pTotal);

  html += `<h4 style="margin:22px 0 10px;">Balance Sheet</h4>
    <div class="table-scroll">
      <table style="width:100%; border-collapse:collapse; min-width:520px;">
        <tr><th colspan="2" style="border:1px solid var(--line-strong); background:var(--c-ac-soft); color:var(--c-ac); padding:8px; text-align:left;">Liabilities</th><th colspan="2" style="border:1px solid var(--line-strong); background:var(--c-ac-soft); color:var(--c-ac); padding:8px; text-align:left;">Assets</th></tr>`;
  const maxRows2 = Math.max(fa.bs.liabilities.length, fa.bs.assets.length, 1);
  for (let i = 0; i < maxRows2; i++) {
    const l = fa.bs.liabilities[i], a = fa.bs.assets[i];
    html += `<tr>
      <td style="border:1px solid var(--line); padding:8px; ${l && l.isCapital ? "font-weight:600;" : ""}">${l ? escapeHtml(l.label) : ""}</td>
      <td class="tnum" style="border:1px solid var(--line); padding:8px; text-align:right;">${l ? acFmt(l.amount) : ""}</td>
      <td style="border:1px solid var(--line); padding:8px; ${a && a.amount < 0 ? "color:var(--ink-faint); font-style:italic;" : ""}">${a ? escapeHtml(a.label) : ""}</td>
      <td class="tnum" style="border:1px solid var(--line); padding:8px; text-align:right;">${a ? acFmt(a.amount) : ""}</td>
    </tr>`;
  }
  html += `<tr style="font-weight:700;">
      <td style="border:1px solid var(--line-strong); padding:8px;">Total</td>
      <td class="tnum" style="border:1px solid var(--line-strong); padding:8px; text-align:right;">${acFmt(fa.bs.totalLiabilities)}</td>
      <td style="border:1px solid var(--line-strong); padding:8px;">Total</td>
      <td class="tnum" style="border:1px solid var(--line-strong); padding:8px; text-align:right;">${acFmt(fa.bs.totalAssets)}</td>
    </tr>
  </table></div>
  <p style="margin-top:14px; font-size:0.85rem; ${fa.bs.balanced ? "color:var(--c-eq);" : "color:var(--flag);"}">
    <i data-lucide="${fa.bs.balanced ? "check-circle" : "alert-triangle"}" style="width:15px;height:15px;vertical-align:-3px;"></i>
    ${fa.bs.balanced ? "Balance Sheet is balanced." : "Balance Sheet does not balance — please review the transactions and closing stock entered."}
  </p>`;

  card.innerHTML = html;
  panel.appendChild(card);
}
